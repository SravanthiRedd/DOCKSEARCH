//
//  AppDelegate.h
//  RPRT
//
//  Created by sravanthi Gumma on 08/01/16.
//  Copyright © 2016 DevpointSolutions. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MainViewController.h"
#import "Opportunity_List_New.h"
//#import "Reachability.h"
#import "Home.h"

//#import <Google/SignIn.h>
////#import <FBSDKCoreKit/FBSDKCoreKit.h>
//#import <Google/CloudMessaging.h>
#import <UserNotifications/UserNotifications.h>



@interface AppDelegate : UIResponder <UIApplicationDelegate,UNUserNotificationCenterDelegate>

@property (strong, nonatomic) UIWindow *window;
@property (strong, nonatomic) UIViewController *viewController;
extern NSString *baseURL;
extern NSString *baseImageURL;
extern BOOL isOnlineStatus;



@end

