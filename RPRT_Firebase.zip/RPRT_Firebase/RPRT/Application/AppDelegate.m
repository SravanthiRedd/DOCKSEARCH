//
//  AppDelegate.m
//  RPRT
//
//  Created by sravanthi Gumma on 08/01/16.
//  Copyright © 2016 DevpointSolutions. All rights reserved.
//

#import "AppDelegate.h"
#import <CoreLocation/CoreLocation.h>
//#import <FacebookSDK/FacebookSDK.h>



@interface AppDelegate ()<CLLocationManagerDelegate>
{
    CLLocationCoordinate2D *crentLoc;
    CurrentLocation *LatLog;// = [CurrentLocation
    GeoCodeLocation *geoCode;
    //Reachability *networkReachability;
   // NetworkStatus networkStatus;
    
}
@end

@implementation AppDelegate
NSString *baseURL = @"http://rtrpservice.azurewebsites.net/api/RPRT/";
NSString *baseImageURL =@"http://rtrpservice.azurewebsites.net/Images/";
BOOL isOnlineStatus =YES;
#define SYSTEM_VERSION_GRATERTHAN_OR_EQUALTO(v)  ([[[UIDevice currentDevice] systemVersion] compare:v options:NSNumericSearch] != NSOrderedAscending)



- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    
    // Register for remote notifications
    if (floor(NSFoundationVersionNumber) <= NSFoundationVersionNumber_iOS_7_1) {
      
    } else  if (floor(NSFoundationVersionNumber) <= NSFoundationVersionNumber_iOS_8_1) {
       
    }
    else if (SYSTEM_VERSION_GRATERTHAN_OR_EQUALTO(@"10.0"))
    {
        
        UNUserNotificationCenter *center = [UNUserNotificationCenter currentNotificationCenter];
        center.delegate = self;
        [center requestAuthorizationWithOptions:(UNAuthorizationOptionSound | UNAuthorizationOptionAlert | UNAuthorizationOptionBadge) completionHandler:^(BOOL granted, NSError * _Nullable error){
            if( !error ){
                [[UIApplication sharedApplication] registerForRemoteNotifications];
            }
        }];
    }
    
    NSError* configureError;
   // [[GGLContext sharedInstance] configureWithError: &configureError];
    NSAssert(!configureError, @"Error configuring Google services: %@", configureError);
    
   // [GIDSignIn sharedInstance].delegate = self;
    [[UIApplication sharedApplication] setApplicationIconBadgeNumber:0];
    
 //   [FBSDKLoginButton class];

    self.window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
    
    NSUserDefaults *mPrefLocation = [NSUserDefaults standardUserDefaults];
    
    NSDictionary *result = [self getCurrentLocation];
    [[NSUserDefaults standardUserDefaults] setValue:@(NO) forKey:@"_UIConstraintBasedLayoutLogUnsatisfiable"];
    
    Preferences *mPreferences = [Preferences GetSharedInstance];
    if (result!=nil) {
        NSString *UserID  = [result valueForKey:@"UserID"];
        NSString *rad = [mPrefLocation valueForKey:@"Radious"];
        if (rad==nil) {
            [mPrefLocation setValue:@"1000" forKey:@"Radious"];
        }
        [mPreferences StoreSaveUserID:UserID];
        
    }
    
    [mPrefLocation setValue:@"" forKey:MODULEID];
    [mPrefLocation setValue:HHOME forKey:@"SideMenu"];
    //[self getCurrentLocation];
    
    if (launchOptions != nil)
    {
        //opened from a push notification when the app is closed
        NSDictionary* userInfo = [launchOptions objectForKey:UIApplicationLaunchOptionsRemoteNotificationKey];
        if (userInfo != nil)
        {
            NSLog(@"userInfo->%@",[userInfo objectForKey:@"aps"]);
            userInfo = [userInfo valueForKey:@"Opportunity"];
           // NSString *opportId = [userInfo valueForKey:@"OpportunityId"];
            NSString *moduleId =[NSString stringWithFormat:@"%@", [userInfo valueForKey:@"ModuleId"]];
            
           
            [mPrefLocation setValue:moduleId forKey:MODULEID];
            [mPrefLocation setValue:@"1000" forKey:@"Radious"];
            [mPrefLocation setValue:@"Live" forKey:@"Key"];
            [mPrefLocation setValue:@"Notification" forKey:@"Notification"];
            NSString *opportId = [userInfo valueForKey:@"OpportunityId"];
            [mPrefLocation setValue:opportId forKeyPath:@"NotificationID"];
            if ([moduleId isEqualToString:@"33"]) [mPrefLocation setValue:FOOD forKey:CATEGORY];
            if ([moduleId isEqualToString:@"34"]) [mPrefLocation setValue:SALES forKey:CATEGORY];
            if ([moduleId isEqualToString:@"36"]) [mPrefLocation setValue:JOBS forKey:CATEGORY];
            if ([moduleId isEqualToString:@"37"]) [mPrefLocation setValue:PROFESSIONALHELP forKey:CATEGORY];
            if ([moduleId isEqualToString:@"38"]) [mPrefLocation setValue:SPORTS forKey:CATEGORY];
            if ([moduleId isEqualToString:@"39"]) [mPrefLocation setValue:MEETINGS forKey:CATEGORY];
            if ([moduleId isEqualToString:@"40"]) [mPrefLocation setValue:TRAVELS forKey:CATEGORY];
            if ([moduleId isEqualToString:@"41"]) [mPrefLocation setValue:REALESTATE forKey:CATEGORY];
            if ([moduleId isEqualToString:@"42"]) [mPrefLocation setValue:BANKING forKey:CATEGORY];
            if ([moduleId isEqualToString:@"43"]) [mPrefLocation setValue:HEALTH forKey:CATEGORY];
            self.viewController = [[Opportunity_List_New alloc] initWithNibName:OPPORTUNITYLISTNEW bundle:nil];
            
            self.window.rootViewController = self.viewController;
            [self.window makeKeyAndVisible];
            
        }
        else
        {
           // [mPrefLocation setValue:@"" forKey:MODULEID];
           // [mPrefLocation setValue:HHOME forKey:@"SideMenu"];
            self.viewController = [[Home alloc] initWithNibName:HOMEDASHBOARD bundle:nil];
            //Home_DashBoard1//MAINVIEWCONTROLLER
            self.window.rootViewController = self.viewController;
            [self.window makeKeyAndVisible];
            
        }
        
    }
    else{
        
        NSDictionary* userInfo = [launchOptions objectForKey:UIApplicationLaunchOptionsRemoteNotificationKey];
        if (userInfo != nil)
        {
            NSLog(@"userInfo->%@",[userInfo objectForKey:@"aps"]);
            
            userInfo = [userInfo valueForKey:@"Opportunity"];
            
            NSString *moduleId =[NSString stringWithFormat:@"%@",[userInfo valueForKey:@"ModuleId"]];
            
         //   NSUserDefaults *mPref = [NSUserDefaults standardUserDefaults];
            [mPrefLocation setValue:moduleId forKey:MODULEID];
            [mPrefLocation setValue:@"1000" forKey:@"Radious"];
            [mPrefLocation setValue:@"Notification" forKey:@"Notification"];
            NSString *opportId = [userInfo valueForKey:@"OpportunityId"];
            [mPrefLocation setValue:opportId forKeyPath:@"NotificationID"];

            
             if ([moduleId isEqualToString:@"33"]) [mPrefLocation setValue:FOOD forKey:CATEGORY];
             if ([moduleId isEqualToString:@"34"]) [mPrefLocation setValue:SALES forKey:CATEGORY];
             if ([moduleId isEqualToString:@"36"]) [mPrefLocation setValue:JOBS forKey:CATEGORY];
             if ([moduleId isEqualToString:@"37"]) [mPrefLocation setValue:PROFESSIONALHELP forKey:CATEGORY];
             if ([moduleId isEqualToString:@"38"]) [mPrefLocation setValue:SPORTS forKey:CATEGORY];
             if ([moduleId isEqualToString:@"39"]) [mPrefLocation setValue:MEETINGS forKey:CATEGORY];
             if ([moduleId isEqualToString:@"40"]) [mPrefLocation setValue:TRAVELS forKey:CATEGORY];
             if ([moduleId isEqualToString:@"41"]) [mPrefLocation setValue:REALESTATE forKey:CATEGORY];
             if ([moduleId isEqualToString:@"42"]) [mPrefLocation setValue:BANKING forKey:CATEGORY];
             if ([moduleId isEqualToString:@"43"]) [mPrefLocation setValue:HEALTH forKey:CATEGORY];
            [mPrefLocation setValue:@"Live" forKey:@"Key"];
            ;
            
            self.viewController = [[Opportunity_List_New alloc] initWithNibName:OPPORTUNITYLISTNEW bundle:nil];
            
            self.window.rootViewController = self.viewController;
            [self.window makeKeyAndVisible];
            
            
        }
        else
        {
          //  [mPrefLocation setValue:@"" forKey:MODULEID];
          //  [mPrefLocation setValue:HHOME forKey:@"SideMenu"];
            self.viewController = [[Home alloc] initWithNibName:HOMEDASHBOARD bundle:nil];
            
            self.window.rootViewController = self.viewController;
            [self.window makeKeyAndVisible];
            
        }
        
        
    }
    
    return YES;
}

//-(void)networkChecking:(NSTimer*)timer
//{
//    
//    networkStatus = [networkReachability currentReachabilityStatus];
//    if (networkStatus == NotReachable) {
//        
//        isOnlineStatus = NO;
//        
//    } else  if (networkStatus == ReachableViaWiFi) {
//        
//        isOnlineStatus = YES;
//    }
//    else if (networkStatus == ReachableViaWWAN) {
//        isOnlineStatus = YES;
//        
//    }
//    
//}


-(void)userNotificationCenter:(UNUserNotificationCenter *)center willPresentNotification:(UNNotification *)notification withCompletionHandler:(void (^)(UNNotificationPresentationOptions options))completionHandler{
    
    //Called when a notification is delivered to a foreground app.
    
    NSLog(@"Userinfo %@",notification.request.content.userInfo);
    
    if( [UIApplication sharedApplication].applicationState == UIApplicationStateInactive )
    {
        
        NSLog( @"INACTIVE" );
        completionHandler(UNNotificationPresentationOptionAlert);
    }
    else if( [UIApplication sharedApplication].applicationState == UIApplicationStateBackground )
    {
        NSLog( @"BACKGROUND" );
        completionHandler( UNNotificationPresentationOptionAlert );
    }
    else
    {
        NSLog( @"FOREGROUND" );
        completionHandler( UNNotificationPresentationOptionAlert );
    }
    
    // completionHandler(UNNotificationPresentationOptionAlert);
}

-(void)userNotificationCenter:(UNUserNotificationCenter *)center didReceiveNotificationResponse:(UNNotificationResponse *)response withCompletionHandler:(void(^)())completionHandler{
    
    //Called to let your app know which action was selected by the user for a given notification.
    
    NSLog(@"Userinfo %@",response.notification.request.content.userInfo);
    NSDictionary *NotifiedObj = response.notification.request.content.userInfo;
    NotifiedObj = [NotifiedObj valueForKey:@"Opportunity"];
   // NSString *opportId = [NotifiedObj valueForKey:@"OpportunityId"];
    NSString *moduleId =[NSString stringWithFormat:@"%@",[NotifiedObj valueForKey:@"ModuleId"]];
    
    NSUserDefaults *mPref = [NSUserDefaults standardUserDefaults];
    [mPref setValue:moduleId forKey:MODULEID];
    [mPref setValue:@"1000" forKey:@"Radious"];
    [mPref setValue:@"Live" forKey:@"Key"];
    [mPref setValue:@"Notification" forKey:@"Notification"];
    NSString *opportId = [NotifiedObj valueForKey:@"OpportunityId"];
    [mPref setValue:opportId forKeyPath:@"NotificationID"];

     //NSString *moduleId = [userInfo valueForKey:@"ModuleId"];
    if ([moduleId isEqualToString:@"33"]) [mPref setValue:FOOD forKey:CATEGORY];
    if ([moduleId isEqualToString:@"34"]) [mPref setValue:SALES forKey:CATEGORY];
    if ([moduleId isEqualToString:@"36"]) [mPref setValue:JOBS forKey:CATEGORY];
    if ([moduleId isEqualToString:@"37"]) [mPref setValue:PROFESSIONALHELP forKey:CATEGORY];
    if ([moduleId isEqualToString:@"38"]) [mPref setValue:SPORTS forKey:CATEGORY];
    if ([moduleId isEqualToString:@"39"]) [mPref setValue:MEETINGS forKey:CATEGORY];
    if ([moduleId isEqualToString:@"40"]) [mPref setValue:TRAVELS forKey:CATEGORY];
    if ([moduleId isEqualToString:@"41"]) [mPref setValue:REALESTATE forKey:CATEGORY];
    if ([moduleId isEqualToString:@"42"]) [mPref setValue:BANKING forKey:CATEGORY];
    if ([moduleId isEqualToString:@"43"]) [mPref setValue:HEALTH forKey:CATEGORY];
   // [mPrefLocation setValue:@"Live" forKey:@"Key"];
//    ;

    
    self.viewController = [[Opportunity_List_New alloc] initWithNibName:@"Opportunity_List_New" bundle:nil];
    
    self.window.rootViewController = self.viewController;
    [self.window makeKeyAndVisible];
    
    
}

- (void)application:(UIApplication*)application didRegisterForRemoteNotificationsWithDeviceToken:(NSData*)deviceToken{
    
    NSLog(@"deviceToken: %@", deviceToken);
    NSString * token = [NSString stringWithFormat:@"%@", deviceToken];
    //Format token as you need:
    token = [token stringByReplacingOccurrencesOfString:@" " withString:@""];
    token = [token stringByReplacingOccurrencesOfString:@">" withString:@""];
    token = [token stringByReplacingOccurrencesOfString:@"<" withString:@""];
    NSLog(@"Device Token:%@",token);
    NSUserDefaults *mPrefs = [NSUserDefaults standardUserDefaults];
    NSLog(@"InstanceID token: %@", token);
    [mPrefs setValue:token forKey:@"FCMID"];
    
}

- (void)application:(UIApplication *)application didReceiveRemoteNotification:(NSDictionary *)userInfo fetchCompletionHandler:(void (^)(UIBackgroundFetchResult result))handler {
    
    
    
    NSLog(@"Message ID: %@", userInfo[@"gcm.message_id"]);
    NSLog(@"%@", userInfo);
    
    
    
    NSDictionary *aps = [userInfo valueForKey:@"aps"];
    NSString *alert = [aps valueForKey:@"alert"];
    NSArray *oppdetsils = [alert componentsSeparatedByString:@"|"];
    //   NSString *oppId = [oppdetsils objectAtIndex:0];
    NSString *moduleId = [oppdetsils objectAtIndex:1];
    //  NSString *oppname = [oppdetsils objectAtIndex:2];
    NSUserDefaults *mPref = [NSUserDefaults standardUserDefaults];
    [mPref setValue:moduleId forKey:MODULEID];
    [mPref setValue:@"1000" forKey:@"Radious"];
    [mPref setValue:@"Live" forKey:@"Key"];
    [mPref setValue:@"Notification" forKey:@"Notification"];
    NSString *opportId = [userInfo valueForKey:@"OpportunityId"];
    [mPref setValue:opportId forKeyPath:@"NotificationID"];
    
    switch (application.applicationState) {
        case UIApplicationStateInactive:
            // Do whatever you want if the app is inactive
            handler(UIBackgroundFetchResultNewData);
            
            break;
            
        case UIApplicationStateBackground:
            // Do whatever you want if the app is in background
            handler(UIBackgroundFetchResultNewData);
            break;
            
        case UIApplicationStateActive:
            // Do whatever you want if the app is active
            handler(UIBackgroundFetchResultNewData);
            break;
            
            
    }
    self.viewController = [[Opportunity_List_New alloc] initWithNibName:@"Opportunity_List_New" bundle:nil];
    
    [self.window.rootViewController presentViewController:self.viewController animated:YES completion:nil];//:self.viewController animated:NO];
    
}



- (void)applicationDidBecomeActive:(UIApplication *)application {
 
    
   //  [FBSDKAppEvents activateApp];
    
    if ([UIApplication sharedApplication].applicationIconBadgeNumber > 0) {
        //application is in background, fired notification and user tapped app icon with badge
    }
    
   
    
    //[FBAppCall handleDidBecomeActive];
    
}

// [START disconnect_from_fcm]
- (void)applicationDidEnterBackground:(UIApplication *)application {
    
    //[[FIRMessaging messaging] disconnect];
    NSLog(@"Disconnected from FCM");
}

-(NSDictionary*)getCurrentLocation

{
    
    CLLocationManager  *locationManager = [[CLLocationManager alloc] init];
    locationManager.delegate = self;
    [locationManager setDesiredAccuracy:kCLLocationAccuracyBest];
    if ([[[UIDevice currentDevice] systemVersion] floatValue] >= 8) {
        [locationManager requestAlwaysAuthorization];
    }
    if ([[[UIDevice currentDevice] systemVersion] floatValue] >= 9.2) {
        //             locationManager.allowsBackgroundLocationUpdates = YES;
        [locationManager requestAlwaysAuthorization];
        
    }
    [locationManager startUpdatingLocation];
    CLLocation *location = [locationManager location];
    
    
    CurrentLocation * curentLocation = [CurrentLocation alloc];
    crentLoc = [curentLocation getCurrentLatLog];
    
    if (location.coordinate.latitude  == 0 && location.coordinate.longitude == 0) {
        
        return nil;
        //  [self getCurrentLocation];
    }
    else geoCode = [LatLog getCurrentLocation:crentLoc];
    if (geoCode!=nil) {
        NSDictionary *saveUserResult = [[Web_Services alloc]SaveUser:geoCode];
        return saveUserResult;
    }
    return nil;
    
}




- (void)applicationWillResignActive:(UIApplication *)application {
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

//- (void)applicationDidEnterBackground:(UIApplication *)application {
//    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
//    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
//}

- (void)applicationWillEnterForeground:(UIApplication *)application {
      //[FBSDKAppEvents activateApp];
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
}



- (void)applicationWillTerminate:(UIApplication *)application {
    
    
    NSUserDefaults *mPref = [NSUserDefaults standardUserDefaults];
    [mPref setValue:nil forKey:@"StoredAddress"];
    [mPref setObject:nil forKey:@"UserInfo"];
    [mPref setValue:nil forKey:@"TempRadius"];
    [mPref setValue:nil forKey:@"SaveNotifications"];
    
    
}

/* Google SignIn*/

//- (BOOL)application:(UIApplication *)application
//            openURL:(NSURL *)url
//  sourceApplication:(NSString *)sourceApplication
//         annotation:(id)annotation {
//    
//    NSString *string = [NSString stringWithFormat:@"%@",url];
//    if ([string rangeOfString:@"com.googleusercontent.apps"].location == NSNotFound) {
//        
//        
//        
////        BOOL handled = [[FBSDKApplicationDelegate sharedInstance] application:application
////                                                                      openURL:url
////                                                            sourceApplication:sourceApplication
////                                                                   annotation:annotation
////                        ];
////        // Add any custom logic here.
////        return handled;
//        return nil;
//        
//        
//        
//        //   NSLog(@"string does not contain bla");
//    } else {
//        
//        
//        
//        
//        
//        
//        return [[GIDSignIn sharedInstance] handleURL:url
//                                   sourceApplication:sourceApplication
//                                          annotation:annotation];
//        
//        
//        
//    }
//    
//    
//}


// [END openurl]

// [START signin_handler]
//- (void)signIn:(GIDSignIn *)signIn
//didSignInForUser:(GIDGoogleUser *)user
//     withError:(NSError *)error {
//    
//    
//    NSLog(@"%@",user);
//    // [START_EXCLUDE]
//    
//    if(user!=nil && error== nil)
//    {
//    
//    
//    NSDictionary *signinResponse = @{@"UserId":user.userID,
//                                     @"idToken":user.authentication.idToken,
//                                     @"FullName":user.profile.name,
//                                     @"GivenNam":user.profile.givenName,
//                                     @"FamilyName":user.profile.familyName,
//                                     @"EmailID":user.profile.email,
//                                     @"LoginType":@"google",
//                                     @"systemVersion": [[UIDevice currentDevice] systemVersion],
//                                     @"model":[[UIDevice currentDevice] model]
//                                     };
//    
//    
//    
//    NSLog(@"%@",user);
//    
//    [[NSNotificationCenter defaultCenter]
//     postNotificationName:@"ToggleAuthUINotification"
//     object:nil
//     userInfo:signinResponse];
//    }
//    // [END_EXCLUDE]
//}
//
//- (void)signIn:(GIDSignIn *)signIn
//didDisconnectWithUser:(GIDGoogleUser *)user
//     withError:(NSError *)error {
//    // Perform any operations when the user disconnects from app here.
//    // [START_EXCLUDE]
//    NSDictionary *statusText = @{@"statusText": @"Disconnected user" };
//    [[NSNotificationCenter defaultCenter]
//     postNotificationName:@"ToggleAuthUINotification"
//     object:nil
//     userInfo:statusText];
//    // [END_EXCLUDE]
//}





@end
