//
//  Constances.m
//  RPRT
//
//  Created by sravanthi Gumma on 11/02/16.
//  Copyright © 2016 DevpointSolutions. All rights reserved.
//

#import "Constances.h"

@implementation Constances

//Web Service Method Names

NSString *const BLOCKORNOTIFYOPPORTUNITIES = @"BlockOrNotifyOpportunities";
NSString *const LOGINVENDOR = @"LoginVendor";
NSString *const SEARCHOPPORTUNITIESGOOGLE = @"SearchOpportunitiesGoogle";
NSString *const SAVEUSERS = @"SaveUsers";
NSString *const SAVEUSERSREGISTER = @"SaveUsersRegister";
NSString *const SAVEOPPORTUNITIES = @"SaveOpportunities";
NSString *const SAVEUSERVIEWEDOPPORTUNITY = @"SaveUserViewedOpportunities";
NSString *const SAVEOPPORTUNITYFEEDBACK =@"SaveOpportunityFeedback";
NSString *const GETSTOREDADDRESS= @"GetStoredAddress";
//NSString *const GETOPPORTUNITIESBYID= @"GetOpportunitiesbyUserID";
NSString *const GETNUMBEROFOFFERS=@"GetNumberofOffers";
NSString *const GETFEEDBACKBYOPPORTUNITYID=@"GetFeedBackByOpportunityID";
NSString *const SCANCODEBYID=@"ScanCodeById";
NSString *const GETRESERVEDOPPORTUNITIESBYUSERID=@"GetReservedOpportunitiesBYUserRegId";
NSString *const CHECKEMAILID=@"CheckEmailId";
NSString *const CHECKPHONENO=@"CheckPhoneNo";
NSString *const GETUSERSREGISTERBYID=@"GetUsersRegisterBYID";
NSString *const GETOPPORTUNITIESBYUSERID=@"GetOpportunitiesbyUserID";
NSString *const SAVEUSERSINFO=@"SaveUsersInfo";
NSString *const SENDNOTIFICATIONTONEARBYUSERS= @"SendNotificationForNearByUsers";
NSString *const SAVEUSERSETTINGS = @"SaveUserSettings";
NSString *const SAVEFAVORITEADDRESS = @"SaveFavouriteAddress";
NSString *const GETFAVADDRESS = @"GetFavAddress";


// //// Pagename  constants
NSString *const HOME =@"Home";
NSString *const DASHBOARDCELL =@"DashboardCell";
NSString *const EDITOPPORTUNITY =@"EditOpportunity";
NSString *const EDITOFFER =@"EditOffer";
NSString *const VIEWCONTROLLER =@"ScanCode";
NSString *const LOGIN =@"Login";
NSString *const MAINVIEWCONTROLLER =@"MainViewController";
NSString *const LEFTPANEL =@"LeftPanelViewController";
NSString *const LEFTMENUCELL =@"MainCellLeft";
NSString *const MAP =@"Map";
NSString *const DIRECTIONMAP =@"Direction_Map";
NSString *const OPPORTUNITYCELL =@"OpportunityCell";
NSString *const OFFERTABS =@"Offertabs";
NSString *const OPPORTUNITYLISTCELL =@"Opportunity_list";
NSString *const OPPORTUNITYLISTNEW =@"Opportunity_List_New";
NSString *const OPPORTUNITYCARDCELL =@"Opportunity_Cardcell";
NSString *const OPPORTUNITYDETAILS =@"Opportunity_Details";
NSString *const OPPORTUNITYDETAILSTRAVEL =@"OpportunityDetails_Travel";
NSString *const OPPORTUNITYDETAILSCONTROLLER =@"Opportunity_DeatilsController";
NSString *const POSTING = @"Posting";
NSString *const PFOOD = @"Post_Food1";
NSString *const PJOBS = @"Post_Jobs1";
NSString *const PMEETINGS = @"Post_Meetings1";
NSString *const PPROFESSIONAL = @"Post_ProfessionalHelp";
NSString *const PSALES = @"Post_Sale1";
NSString *const PSPORTS = @"Post_Sports1";
NSString *const PTRAVELS = @"Post_Travel1";
NSString *const PREALESTATE = @"Post_RealEstate1";
NSString *const PBANKINGANDFINANCE = @"Post_Banking1";
NSString *const PHEALTH = @"Post_Health1";
NSString *const RATINGS =@"Rating";
NSString *const REVIEWCELL = @"ReviewCell";
NSString *const REGISTRATION = @"Registration1";
NSString *const MYBLOCKS = @"MyBlocks";
NSString *const RETAILER = @"Retailer_Offer";
NSString *const USERBLOCK = @"UserBlocks";
NSString *const USERBLOCKCELL = @"UserBlockCell1";
NSString *const MYBLOCK = @"MyBlockCell";
NSString *const SETTINGS =@"Setting";
NSString *const HOMEDASHBOARD= @"Home_DashBoard1";
NSString *const HOMEDASHBOARD1= @"Home_DashBoard1 2";


// page constant variables;

NSString *const HHOME =@"Home";
NSString *const HLIST =@"List";
NSString *const MODULEID =@"ModuleID";

NSString *const CATEGORY = @"Category";

NSString *const FOOD = @"Food";
NSString *const SALES= @"Sales";
NSString *const JOBS =@"Jobs";
NSString *const SPORTS = @"Sports";
NSString *const MEETINGS = @"Meetings";
NSString *const PROFESSIONALHELP = @"Professional";
NSString *const USERREGISTERID = @"UserRegisterID";
NSString *const LOGINTYPE= @"LOGINTYPE";
NSString *const TRAVELS = @"Travel";
NSString *const REALESTATE = @"RealEstate";
NSString *const BANKING = @"Banking & Financial";
NSString *const HEALTH = @"Health";


NSString *const LATITUDE =@"Latitude";
NSString *const LONGITUDE =@"Longitude";
NSString *const STATE =@"State";
NSString *const COUNTRY =@"Country";





@end
