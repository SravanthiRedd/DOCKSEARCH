//
//  DataBase.h
//  RPRT
//
//  Created by sravanthi Gumma on 29/02/16.
//  Copyright © 2016 DevpointSolutions. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <sqlite3.h>
@interface DataBase : NSObject
{
     NSString *databasePath;
}
+(DataBase *)GetSharedInstance;
-(instancetype)initWithDatabaseFilename:(NSString *)dbFilename;
-(NSMutableArray*)SelectAllOpportunityByDate;
@end
