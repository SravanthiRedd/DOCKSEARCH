//
//  DataBase.m
//  RPRT
//
//  Created by sravanthi Gumma on 29/02/16.
//  Copyright © 2016 DevpointSolutions. All rights reserved.
//

#import "DataBase.h"
#import "Web_Services.h"

static DataBase *sharedInstance = nil;
static sqlite3 *database = nil;
static sqlite3_stmt *statement = nil;
NSString *documentsDirectory;
NSString *databaseFilename;
NSString *insertSQL;
NSString *PresentTime;
@implementation DataBase
+ (DataBase *)GetSharedInstance {
    if (sharedInstance == nil) {
        
        sharedInstance = [[DataBase alloc] init];
    }
    return sharedInstance;
}

-(instancetype)initWithDatabaseFilename:(NSString *)dbFilename{
    self = [super init];
    if (self) {

        @try {
            
            
            // Set the documents directory path to the documentsDirectory property.
            NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
            documentsDirectory = [paths objectAtIndex:0];

            // Keep the database filename.
            databaseFilename = dbFilename;
            NSDate  *date= [NSDate date];
            NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
            [dateFormatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
            PresentTime = [dateFormatter stringFromDate:date];
            PresentTime= [PresentTime stringByReplacingOccurrencesOfString:@" " withString:@"T"];

            // Copy the database file into the documents directory if necessary.
            [self copyDatabaseIntoDocumentsDirectory];
              return self;
        }
        @catch (NSException *exception) {
            [self showAlertPop:@"Invalid UserName." expObj:exception];
        } @finally {
            
        }
        }

}

-(void)copyDatabaseIntoDocumentsDirectory{

    @try {
        // Check if the database file exists in the documents directory.
        databasePath = [documentsDirectory stringByAppendingPathComponent:databaseFilename];
        NSLog(@"%@",databasePath);
        if (![[NSFileManager defaultManager] fileExistsAtPath:databasePath]) {
            // The database file does not exist in the documents directory, so copy it from the main bundle now.
            NSString *sourcePath = [[[NSBundle mainBundle] resourcePath] stringByAppendingPathComponent:databaseFilename];
            NSError *error;
            [[NSFileManager defaultManager] copyItemAtPath:sourcePath toPath:databasePath error:&error];
            // Check if any error occurred during copying and display it.
            if (error != nil) {
                NSLog(@"%@", [error localizedDescription]);
            }
        }
    } @catch (NSException *exception) {
        [self showAlertPop:@"Invalid UserName." expObj:exception];
    } @finally {

    }

}

- (void)ParseOppQuery:(NSMutableArray *)resultArray {

    @try {
        NSMutableArray *row = [NSMutableArray array];
        do
        {
            NSLog(@"%d",sqlite3_column_count(statement));
            NSMutableDictionary *temDic = [[NSMutableDictionary alloc] init];
            for (int i=0; i<sqlite3_column_count(statement); i++)
            {
                //int colType = sqlite3_column_type(statement, i);
                id  value;
                const unsigned char *ColumnName= sqlite3_column_name(statement, i);
                const unsigned char *Coliumvalue= sqlite3_column_text(statement, i);
                value = [NSString stringWithFormat:@"%s", ColumnName];
                id   value1 = [NSString stringWithFormat:@"%s", Coliumvalue];
                [temDic setValue:value1 forKey:value];
            }
            [row addObject:temDic];
            [resultArray addObject:row];
        }   while (sqlite3_step(statement) == SQLITE_ROW);
        NSLog(@"%d",[resultArray count]);
        sqlite3_reset(statement);
        sqlite3_close(database);
        //  NSLog(@"error: %s", sqlite3_errmsg(statement));
        //return resultArray;
    } @catch (NSException *exception) {
        [self showAlertPop:@"Invalid UserName." expObj:exception];
    } @finally {
        
    }
}

- (void)GetAllOppQuery {

    @try {
        //NSString *qeru = @"select * from RT_Categories";
        NSString *querySQL = [NSString stringWithFormat:@"Select Distinct RTOpp.OpportunityID,RTVenAdd.Latitude,RTVenAdd.Longitude,RTOpp.TotalRatings,RTOpp.RatingValue,RTOpp.VendorAddressId,RTOpp. VendorId,RTOpp.OpportunityName,RTOpp.OpportunityDescription,RTOpp.OpportunityKeywords,RTOpp.CategoryID,RTOpp.StartDate,RTOpp. EndDate,RTOpp.PromoCode,RTOpp.OpportunityType,RTOpp.distance,RTOpp. duration,RTPhoto.PhotoName,RTVen.VendorName,RTVen.DeviceID,RTVen.VendorEmail,RTVen. VendorMobile,RTVen. VendorLandLine,RTVenAdd.Address1,RTVenAdd.Address2,RTVenAdd.Address3,RTVenAdd.AreaName,RTVenAdd.City,RTVenAdd. State,RTVenAdd. Country,RTCat.Category,RTCat.CategoryID from RT_Opportunities RTOpp INNER JOIN RT_OpportunityPhotos RTPhoto ON RTOpp.OpportunityID = RTPhoto.OpportunityID INNER JOIN RT_Vendors RTVen ON RTVen.VendorId = RTOpp.VendorId INNER JOIN RT_VendorAddress RTVenAdd on RTVenAdd.VendorAddressID=RTOpp.VendorAddressId INNER JOIN RT_Categories RTCat ON RTCat.CategoryID = RTOpp.CategoryID  Where RTOpp.EndDate >'%@'",PresentTime];
        //  NSLog(@"sdfg %@",querySQL);
        const char *query_stmt = [querySQL UTF8String];
        NSMutableArray *resultArray = [[NSMutableArray alloc]init];
        if (sqlite3_prepare_v2(database, query_stmt, -1, &statement, NULL) != SQLITE_OK)
        {

        } else {
            if(sqlite3_step(statement) == SQLITE_ROW)
            {
                [self ParseOppQuery:resultArray];
            }
            else{
                sqlite3_close(database);
                //  NSLog(@"error: %s", sqlite3_errmsg(statement));
                //return nil;
            }
        }
        sqlite3_close(database);
        NSLog(@"error: %s", sqlite3_errmsg(statement));
//return nil;
    } @catch (NSException *exception) {
        [self showAlertPop:@"Invalid UserName." expObj:exception];
    } @finally {
        
    }
}

-(NSMutableArray*)SelectAllOpportunityByDate {

    @try {
        databasePath=     [documentsDirectory stringByAppendingPathComponent:databaseFilename];
        const char *dbpath = [databasePath UTF8String];
        if (sqlite3_open(dbpath, &database) == SQLITE_OK)
        {
            [self GetAllOppQuery];
        }
        return nil;
    } @catch (NSException *exception) {
        [self showAlertPop:@"Invalid UserName." expObj:exception];
    } @finally {

    }
}


- (void) showAlertPop:(NSString*)alertText expObj:(NSException*) exp{
    
        
        if(exp != nil)
        {
            NSLog(@"%@", exp.description);
        }
//        UIAlertController *myAlertController =[mWebservice  alert:alertText];
//        [self presentViewController:myAlertController animated:YES completion:nil];
    
   
    
}
@end
