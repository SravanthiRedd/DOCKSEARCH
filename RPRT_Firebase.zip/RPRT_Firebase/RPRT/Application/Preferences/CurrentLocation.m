//
//  CurrentLocation.m
//  RPRT
//
//  Created by sravanthi Gumma on 12/02/16.
//  Copyright © 2016 DevpointSolutions. All rights reserved.
//

#import "CurrentLocation.h"
#import "Constances.h"
#import "Web_Services.h"
static CurrentLocation *sharedInstance = nil;

@implementation CurrentLocation
{
    
}

+ (CurrentLocation *)GetSharedInstance {
    if (sharedInstance == nil) {
        sharedInstance = [[CurrentLocation alloc] init];
        [sharedInstance GetAddressOfCurrentLocation];
        
       // [self getCurrentLocVal];
    }
    return sharedInstance;
}

-(GeoCodeLocation*)getCurrentLocation:(CLLocationCoordinate2D *)loc
{
    
    [self getCurrentLocVal];
    
    if (loc!=nil) {
         return [self geoCodeArea :&loc->latitude Longitude:&loc->longitude];
    }
    else
        return nil;
   
}

-(GeoCodeLocation*)GetAddressOfCurrentLocation
{
    
    CLLocationCoordinate2D *locatioLatLon;
    locatioLatLon= [self getCurrentLatLog];
    
    if (locatioLatLon!=nil) {
    self.Address =[self geoCodeArea :&locatioLatLon->latitude Longitude:&locatioLatLon->longitude];
        return self.Address;
    }
    else
    return nil;
}



-(CLLocationCoordinate2D*)getCurrentLatLog
{
    CLLocationCoordinate2D *locatioLatLon;
    locatioLatLon = [self getCurrentLocVal];
    
    return locatioLatLon;
}

- (CLLocationCoordinate2D *)getCurrentLocVal
{
    locationManager = [[CLLocationManager alloc] init];
    locationManager.delegate = self;
    [locationManager setDesiredAccuracy:kCLLocationAccuracyBest];
    if ([[[UIDevice currentDevice] systemVersion] floatValue] >= 8) {
        [locationManager requestAlwaysAuthorization];
    }
    if ([[[UIDevice currentDevice] systemVersion] floatValue] >= 9.2) {
        //locationManager.allowsBackgroundLocationUpdates = YES;
           [locationManager requestWhenInUseAuthorization];
    }
    [locationManager startUpdatingLocation];

    CLLocation *location = [locationManager location];
    coordinate = [location coordinate];

    return &(coordinate);
}

- (void)locationManager:(CLLocationManager *)manager didUpdateToLocation:(CLLocation *)newLocation fromLocation:(CLLocation *)oldLocation
{
    
}

-(NSString*)GetLocationDistace:(NSMutableDictionary*)Location
{
      NSString *DestLatLon= [NSString stringWithFormat:@"%@,%@",[Location valueForKey:LATITUDE],[Location valueForKey:LONGITUDE]];
    NSDictionary *CurrentLatLon ;//= [self getCurrentLocation];
     NSString *CurentLatlon= [NSString stringWithFormat:@"%@,%@",[CurrentLatLon valueForKey:LATITUDE],[CurrentLatLon valueForKey:LONGITUDE]];
    NSString *urlString = [NSString stringWithFormat:
                           @"https://maps.googleapis.com/maps/api/directions/json?origin=%@&destination=%@&mode=transit&key=AIzaSyA6_HQVIISO042VS4mX5WfJq0jk8wpTfXs",DestLatLon,CurentLatlon];
    NSURL *RPRTUrlpath = [NSURL URLWithString:urlString];
    NSData *myData = [NSData dataWithContentsOfURL:RPRTUrlpath];
    NSError* error1;
    
    NSArray *first = [NSJSONSerialization
                      JSONObjectWithData:myData
                      options:kNilOptions
                      error:&error1];
    NSDictionary *Routes= [first valueForKey:@"routes"];
    NSArray *legs= [Routes valueForKey:@"legs"];
    NSDictionary *ROutedata= [legs objectAtIndex:0];
    NSArray *Distance= [ROutedata valueForKey:@"distance"];
    NSString *distance=[ [Distance valueForKey:@"text"] objectAtIndex:0];
   return distance;
}

-(GeoCodeLocation*)geoCodeArea:(double*)Lat Longitude :(double*)Log {
    // This is important if you only want to receive one tap and hold event

    NSString *Latitude;
    NSString *Longitude;
   // NSString *AddressName;
   
    double lat = *Lat;
    double lon = *Log;
    NSLog(@"%f",lat);
    NSLog(@"%f",lon);
    
    
    if (lat!=0 && lon!=0) {
        
    Latitude = [NSString stringWithFormat:@"%f",lat];
    Longitude = [NSString stringWithFormat:@"%f",lon];
        NSDictionary *latlongOn  = @{@"Latitude":Latitude,
                                                  @"Longitude":Longitude
                                                  };
        
        
        NSDictionary * addessObj = [[Web_Services alloc]GetAddress:latlongOn];
        
    
        GeoCodeLocation *geoCode = [[GeoCodeLocation GetSharedInstance] initOffers:addessObj Latitude:Latitude Longitude:Longitude];;
    return geoCode;
    }
    else
    {
     return nil;
    }
 }

-(CLLocationCoordinate2D) getLocationFromAddressString: (NSString*) addressStr {
   
    
    double latitude = 0, longitude = 0;
    NSString *esc_addr =  [addressStr stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    NSString *req = [NSString stringWithFormat:@"http://maps.google.com/maps/api/geocode/json?sensor=false&address=%@", esc_addr];
    NSString *result = [NSString stringWithContentsOfURL:[NSURL URLWithString:req] encoding:NSUTF8StringEncoding error:NULL];
    if (result) {
        NSScanner *scanner = [NSScanner scannerWithString:result];
        if ([scanner scanUpToString:@"\"lat\" :" intoString:nil] && [scanner scanString:@"\"lat\" :" intoString:nil]) {
            [scanner scanDouble:&latitude];
            if ([scanner scanUpToString:@"\"lng\" :" intoString:nil] && [scanner scanString:@"\"lng\" :" intoString:nil]) {
                [scanner scanDouble:&longitude];
            }
        }
    }
    CLLocationCoordinate2D center;
    center.latitude=latitude;
    center.longitude = longitude;
    NSLog(@"View Controller get Location Logitute : %f",center.latitude);
    NSLog(@"View Controller get Location Latitute : %f",center.longitude);
    return center;
    
    
    
    
    
    
//    double latitude = 0, longitude = 0;
//    NSString * esc_addr = [addressStr stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet URLFragmentAllowedCharacterSet]];
//
//    NSString *req = [NSString stringWithFormat:@"http://maps.google.com/maps/api/geocode/json?sensor=false&address=%@", esc_addr];
//    
//    NSString *result = [NSString stringWithContentsOfURL:[NSURL URLWithString:req] encoding:NSUTF8StringEncoding error:NULL];
//    if (result) {
//        NSScanner *scanner = [NSScanner scannerWithString:result];
//        if ([scanner scanUpToString:@"\"lat\" :" intoString:nil] && [scanner scanString:@"\"lat\" :" intoString:nil]) {
//            [scanner scanDouble:&latitude];
//            if ([scanner scanUpToString:@"\"lng\" :" intoString:nil] && [scanner scanString:@"\"lng\" :" intoString:nil]) {
//                [scanner scanDouble:&longitude];
//            }
//        }
//    }
//    CLLocationCoordinate2D center;
//    center.latitude=latitude;
//    center.longitude = longitude;
//   
//    return center;
    
}


@end
