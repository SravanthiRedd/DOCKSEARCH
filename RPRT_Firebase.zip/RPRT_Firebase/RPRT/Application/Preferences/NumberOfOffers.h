//
//  NumberOfOffers.h
//  RPRT
//
//  Created by sravanthi Gumma on 11/02/16.
//  Copyright © 2016 DevpointSolutions. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NumberOfOffers : NSObject
@property  NSString *food;
@property  NSString *professional;
@property  NSString *sales;
@property  NSString *sports;
@property  NSString *jobs;
@property  NSString *meetings;
@property  NSString *travel;
@property  NSString *realEstate;
@property  NSString *bankandFinancial;
@property  NSString *health;
@property  NSString *education;
@property  NSString *hotel;
@property NSString *ExclusiveOffersCount;
@property NSString *NewCustomersCount;
@property NSMutableArray *Notifications;

+(NumberOfOffers *)GetSharedInstance;
-(id)initOffers:(NSDictionary *)NumberOfOffersResponse;
@end



