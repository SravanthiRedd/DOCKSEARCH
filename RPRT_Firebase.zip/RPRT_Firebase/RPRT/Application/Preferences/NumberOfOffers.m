//
//  NumberOfOffers.m
//  RPRT
//
//  Created by sravanthi Gumma on 11/02/16.
//  Copyright © 2016 DevpointSolutions. All rights reserved.
//

#import "NumberOfOffers.h"
#import "Constances.h"
static NumberOfOffers *sharedInstance = nil;
@implementation NumberOfOffers
@synthesize food = food;
@synthesize professional = professional;
@synthesize sales = sales;
@synthesize sports = sports;
@synthesize jobs = jobs;
@synthesize meetings = meetings;
@synthesize travel = travel;
@synthesize realEstate= realEstate;
@synthesize bankandFinancial = bankandFinancial;
@synthesize health = health;
@synthesize hotel = hotel;
@synthesize education= education;
@synthesize ExclusiveOffersCount= ExclusiveOffersCount;
@synthesize NewCustomersCount= NewCustomersCount;
@synthesize Notifications = Notifications;


//[getnumOff setValue:[Response valueForKey:@"ExclusiveOffersCount"] forKey:@"ExclusiveOffersCount"];
//[getnumOff setValue:[Response valueForKey:@"NewCustomersCount"] forKey:@"NewCustomersCount"];


+(NumberOfOffers*)GetSharedInstance{
    if (sharedInstance == nil) {
        sharedInstance = [[NumberOfOffers alloc] init];
    }
    return sharedInstance;    
}

- (id)initOffers:(NSDictionary *)NumberOfOffersResponse{
    self = [super init];
    if (self) {
        Notifications = [[NSMutableArray alloc]init];
        
        if ( [[NumberOfOffersResponse valueForKey:FOOD] isKindOfClass:[NSNull class]]) {
             self.food =@"0";
        }
        else
        self.food =
        [NumberOfOffersResponse valueForKey:FOOD] ;
        
        if ( [[NumberOfOffersResponse valueForKey:@"Professional Services"] isKindOfClass:[NSNull class]]) {
            self.professional =@"0";
        }
        else
        
        self.professional = 
        [NumberOfOffersResponse valueForKey:@"Professional Services"];
        
        if ( [[NumberOfOffersResponse valueForKey:@"Sale"] isKindOfClass:[NSNull class]]) {
            self.sales =@"0";
        }
        else
        self.sales =
        [NumberOfOffersResponse valueForKey:@"Sale"] ;
        
        if ( [[NumberOfOffersResponse valueForKey:SPORTS] isKindOfClass:[NSNull class]]) {
            self.sports =@"0";
        }
        else
        self.sports =
        [NumberOfOffersResponse valueForKey:SPORTS] ;
        if ( [[NumberOfOffersResponse valueForKey:JOBS] isKindOfClass:[NSNull class]]) {
            self.jobs =@"0";
        }
        else
        self.jobs =  [NumberOfOffersResponse valueForKey:JOBS] ;
        
        if ( [[NumberOfOffersResponse valueForKey:MEETINGS] isKindOfClass:[NSNull class]]) {
            self.meetings =@"0";
        }
        else
        self.meetings =  [NumberOfOffersResponse valueForKey:MEETINGS] ;
        
        if ( [[NumberOfOffersResponse valueForKey:@"Travel"] isKindOfClass:[NSNull class]]) {
            self.travel =@"0";
        }
        else
        self.travel =  [NumberOfOffersResponse valueForKey:@"Travel"] ;
        
        if ( [[NumberOfOffersResponse valueForKey:@"RealEstate"] isKindOfClass:[NSNull class]]) {
            self.realEstate =@"0";
        }
        else
        self.realEstate =  [NumberOfOffersResponse valueForKey:@"RealEstate"] ;
        
        if ( [[NumberOfOffersResponse valueForKey:@"Banking & Financial"] isKindOfClass:[NSNull class]]) {
            self.bankandFinancial =@"0";
        }
        else
        self.bankandFinancial =  [NumberOfOffersResponse valueForKey:@"Banking & Financial"] ;
        
        if ( [[NumberOfOffersResponse valueForKey:@"Health"] isKindOfClass:[NSNull class]]) {
            self.health =@"0";
        }
        else

        self.health =  [NumberOfOffersResponse valueForKey:@"Health"] ;
        
        self.education = @"0";
        self.hotel = @"0";
        
        if ( [[NumberOfOffersResponse valueForKey:@"Education"] isKindOfClass:[NSNull class]]) {
            self.education =@"0";
        }
        else
            
            self.education =  [NumberOfOffersResponse valueForKey:@"Education"] ;
        
        
        if ( [[NumberOfOffersResponse valueForKey:@"Hotel"] isKindOfClass:[NSNull class]]) {
            self.hotel =@"0";
        }
        else
            
            self.hotel =  [NumberOfOffersResponse valueForKey:@"Hotel"] ;
        
        
        
        if ( [[NumberOfOffersResponse valueForKey:@"ExclusiveOffersCount"] isKindOfClass:[NSNull class]]) {
            self.ExclusiveOffersCount =@"0";
        }
        else
            self.ExclusiveOffersCount =
            [NumberOfOffersResponse valueForKey:@"ExclusiveOffersCount"] ;
        
        
        if ( [[NumberOfOffersResponse valueForKey:@"NewCustomersCount"] isKindOfClass:[NSNull class]]) {
            self.NewCustomersCount =@"0";
        }
        else
            self.NewCustomersCount =
            [NumberOfOffersResponse valueForKey:@"NewCustomersCount"] ;
        if ( ![[NumberOfOffersResponse valueForKey:@"Notifications"] isKindOfClass:[NSNull class]]) {
            self.Notifications =[NumberOfOffersResponse valueForKey:@"Notifications"];
        }
        
        
    }
    
    return self;
}
@end
