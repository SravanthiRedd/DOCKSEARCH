//
//  Preferences.h
//  RPRT
//
//  Created by sravanthi Gumma on 11/02/16.
//  Copyright © 2016 DevpointSolutions. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <AddressBook/AddressBook.h>

@interface Preferences : NSObject
{
    NSUserDefaults *PrefLocations;
}
+(Preferences *)GetSharedInstance;
//-(void)StoreCheckLoginResponse: (NSDictionary * )loginResDic;
-(void)StoreUserName:(NSString*)Value;
-(void)StorePassword:(NSString*)Value;
-(void)StoreSaveUserID:(NSString*)Value;
-(void)StoreSaveUserRegisterID:(NSString*)Value;
-(void)StoreUserTime:(NSString*)Values;
-(void)StoreRadious:(NSString*)Values;
-(void)StoreLoginUserDetails:(NSDictionary*)Value;
-(NSDictionary*)remaningTime:(NSDate*)startDate endDate:(NSDate*)endDate;
-(void)SaveRegisterDeatils:(NSDictionary*)RegisteredDetils;
-(void)StorePageName:(NSString*)pagename;
-(BOOL)timeValidatiostring:(NSDate*)startDate endDate:(NSDate*)endDate;
-(void)StoreNotifications:(NSDictionary*)Notifications;

@end
