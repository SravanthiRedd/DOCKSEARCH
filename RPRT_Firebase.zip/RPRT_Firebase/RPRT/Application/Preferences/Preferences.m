//
//  Preferences.m
//  RPRT
//
//  Created by sravanthi Gumma on 11/02/16.
//  Copyright © 2016 DevpointSolutions. All rights reserved.
//

#import "Preferences.h"
#import "Constances.h"

static Preferences *sharedInstance = nil;
@implementation Preferences


- (id)init {
    self = [super init];
    if (self) {
        
        PrefLocations = [NSUserDefaults standardUserDefaults];
    }
    return self;
}

+ (Preferences *)GetSharedInstance {
    if (sharedInstance == nil) {
        
        sharedInstance = [[Preferences alloc] init];
    }
    return sharedInstance;
}
//-(void)StoreCheckLoginResponse:(NSDictionary *)loginResDic
//{
//    @try {
//        [PrefLocations setValue:loginResDic forKey:@"LoginResponse"];
//    } @catch (NSException *exception) {
//        NSLog(@"%@", exception.description);
//    }
//}
- (void)StoreUserName:(NSString *)Value {
    @try {
        
        [PrefLocations setValue:Value forKey:@"UserName"];
    } @catch (NSException *exception) {
        NSLog(@"%@", exception.description);
    }
}

- (void)StorePassword:(NSString *)Value {
    @try {
        
        [PrefLocations setValue:Value forKey:@"Password"];
    } @catch (NSException *exception) {
        NSLog(@"%@", exception.description);
    }
}

//UserRegisterID

- (void)StoreSaveUserRegisterID:(NSString *)Value {
    @try {

        [PrefLocations setValue:Value forKey:USERREGISTERID];
    } @catch (NSException *exception) {
        NSLog(@"%@", exception.description);
    }
}

- (void)StoreSaveUserID:(NSString *)Value {
    @try {
        
        [PrefLocations setValue:Value forKey:@"SaveUserID"];
    } @catch (NSException *exception) {
        NSLog(@"%@", exception.description);
    }
}

-(void)StoreUserTime:(NSString*)Values
{
    @try {
        
        [PrefLocations setValue:Values forKey:@"TimeSlot"];
    } @catch (NSException *exception) {
        NSLog(@"%@", exception.description);
    }
}

-(void)StoreLoginUserDetails:(NSDictionary*)Value
{
     NSData *myData = [NSKeyedArchiver archivedDataWithRootObject:Value];
    [PrefLocations setValue:myData forKey:@"SaveLoginUserDetails"];
}
-(void)StoreRadious:(NSString*)Values
{
    @try {
        
        [PrefLocations setValue:Values forKey:@"Radious"];
    } @catch (NSException *exception) {
        NSLog(@"%@", exception.description);
    }
}

-(BOOL)timeValidatiostring:(NSDate*)startDate endDate:(NSDate*)endDate {
    NSDate *date1;
    
    if (startDate!=nil) {
        date1 = startDate;
    }
    else date1 = [NSDate date];
    
    //NSDate *date1 = startDate;
    NSDate *date2 = endDate;
    
    NSTimeInterval secondsBetween = [date2 timeIntervalSinceDate:date1];
   // int hh = secondsBetween / (60*60);
    double rem = fmod(secondsBetween, (60*60));
   // int mm = rem / 60;
    rem = fmod(rem, 60);
   // int ss = rem;

    if (secondsBetween>=0) {
        
        return YES;
    }
    else
    return NO;
}


-(void)SaveRegisterDeatils:(NSDictionary*)RegisteredDetils
{
    
    NSData *myData = [NSKeyedArchiver archivedDataWithRootObject:RegisteredDetils];
    [PrefLocations setValue:myData forKey:@"SaveRegisterDetails"];

}


-(void)StoreNotifications:(NSDictionary*)Notifications
{
    NSData *myData = [NSKeyedArchiver archivedDataWithRootObject:Notifications];
    [PrefLocations setValue:myData forKey:@"SaveNotifications"];
}



-(NSDictionary*)remaningTime:(NSDate*)startDate endDate:(NSDate*)endDate {
    @try {
        
       
        NSDate *date1 = startDate;
        NSDate *date2 = endDate;
        
        NSTimeInterval secondsBetween = [date2 timeIntervalSinceDate:date1];
        
        int hh = secondsBetween / (60*60);
        double rem = fmod(secondsBetween, (60*60));
        int mm = rem / 60;
        rem = fmod(rem, 60);
        int ss = rem;
        
        //NSString *str = [NSString stringWithFormat:@"%02d:%02d:%02d",hh,mm,ss];

        
        
        
        
        
    NSDateComponents *components;
    NSInteger days;
    NSInteger hour;
    NSInteger minutes;
    NSString *durationString;
    NSMutableDictionary *date = [[NSMutableDictionary alloc]init];
    components = [[NSCalendar currentCalendar] components: NSCalendarUnitDay|NSCalendarUnitHour|NSCalendarUnitMinute
                                                 fromDate: startDate toDate: endDate options: 0];
    days = [components day];
    hour = [components hour];
    minutes = [components minute];
    //NSInteger sec = [components second];
       
    if (days>0 ||hour>0|| minutes>0 || ss >0) {
        durationString = [NSString stringWithFormat:@"%ld day,%ld hours,%ld minutes",(long)days,(long)hh,(long)mm];
        [date setObject:durationString forKey:@"Date"];
        [date setObject:[NSString stringWithFormat:@"%ld",(long)mm] forKey:@"Time"];
        [date setObject:[NSString stringWithFormat:@"%ld",(long)hh] forKey:@"Hour"];
         [date setObject:[NSString stringWithFormat:@"%ld",(long)ss] forKey:@"Seconds"];
        
        return date;
    }
    
    return date;
    }
    @catch (NSException *exception) {
        NSLog(@"%@", exception.description);
 
    }
    @finally {
        
    }


}
-(void)StorePageName:(NSString*)pagename
{
    @try {
        
        [PrefLocations setValue:pagename forKey:@"PageName"];
    } @catch (NSException *exception) {
        NSLog(@"%@", exception.description);
    }
}

@end
