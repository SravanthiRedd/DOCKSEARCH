//
//  TimeCalculator.h
//  RPRT
//
//  Created by sravanthi Gumma on 13/04/16.
//  Copyright © 2016 DevpointSolutions. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
@interface TimeCalculator : NSObject

+(TimeCalculator *)GetSharedInstance;

-(NSDictionary*)GetAddress;
-(NSDictionary*)GetCateGory:(NSDictionary*)SelectedSubCat;

- (UIImage* )setBackgroundImageByColor:(UIColor *)backgroundColor withFrame:(CGRect )rect;


-(NSDictionary*)GetTimeintervals:(NSDictionary*)TimeDetaisl;

- (UIImage *)image:(UIImage*)originlimage scaledToSize:(CGSize)size ;
-(NSDictionary*)getEditeOpportunity:(NSString*)opportunityId;
-(NSString*)ClaimedTime ;

-(NSDictionary*)incrementTime;

-(NSString*)whatspandSMSText:(NSDictionary*)opporDetailsl;
-(NSString*)emailText:(NSDictionary*)opporDetailsl;
- (NSDictionary *)getCountryCodeDictionary;


-(NSMutableArray*)getSubCategoryDetails:(NSString*)ModuleId;
-(NSDictionary*)GetCounts:(NSString*)Lat  Long:(NSString*)longi;


@end
