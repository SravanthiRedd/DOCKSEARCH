//
//  TimeCalculator.m
//  RPRT
//
//  Created by sravanthi Gumma on 13/04/16.
//  Copyright © 2016 DevpointSolutions. All rights reserved.
//

#import "TimeCalculator.h"
#import "Constances.h"
#import "GeoCodeLocation.h"
#import "Web_Services.h"
#import "Preferences.h"
static TimeCalculator *sharedInstance = nil;
@implementation TimeCalculator
{
      GeoCodeLocation *Addre;
    NSUserDefaults *mPref;
}

+ (TimeCalculator *)GetSharedInstance {
    if (sharedInstance == nil) {
        
        sharedInstance = [[TimeCalculator alloc] init];
        
    }
    return sharedInstance;
}

-(NSDictionary*)GetAddress {
    @try {
         mPref = [NSUserDefaults standardUserDefaults];
        
        Addre = [GeoCodeLocation GetSharedInstance];
        
        NSMutableDictionary *AddresDic = [[NSMutableDictionary alloc]init];
        
        [AddresDic setObject:Addre.Address1 forKey:@"Address1"];
        [AddresDic setObject:Addre.Address2 forKey:@"Address2"];
        [AddresDic setObject:Addre.Address3 forKey:@"Address3"];
        [AddresDic setObject:Addre.AreaName forKey:@"AreaName"];
        [AddresDic setObject:Addre.City forKey:@"City"];
        [AddresDic setObject:Addre.State forKey:@"State"];
        [AddresDic setObject:Addre.Country forKey:@"Country"];
        [AddresDic setObject:Addre.AddresName forKey:@"AddressName"];
        [AddresDic setObject:Addre.Latitude forKey:LATITUDE];
        [AddresDic setObject:Addre.Longitude forKey:LONGITUDE];
        // [AddresDic setObject:Limit.text forKey:@"Quantity"];
        [mPref setValue:[NSString stringWithFormat:@"%@,%@,%@",Addre.Address1,Addre.Address2,Addre.Address3] forKey:@"StoredAddress"];
        
        return AddresDic;
    } @catch (NSException *exception) {
       // [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
}

-(NSDictionary*)GetCateGory:(NSDictionary*)SelectedSubCat {
    @try {
       
        
        NSString *CategoryID =[SelectedSubCat valueForKey:@"TypeId"];
        
        NSMutableDictionary *ModuleIDCatID = [[NSMutableDictionary alloc]init];
        
        [ModuleIDCatID setValue:[mPref valueForKey:MODULEID] forKey:@"ModuleId"];
        [ModuleIDCatID setValue:CategoryID forKey:@"CategoryID"];
        
        return ModuleIDCatID;
    } @catch (NSException *exception) {
        //[self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
}

- (UIImage* )setBackgroundImageByColor:(UIColor *)backgroundColor withFrame:(CGRect )rect{
    // tcv - temporary colored view
    UIView *tcv = [[UIView alloc] initWithFrame:rect];
    [tcv setBackgroundColor:backgroundColor];
    // set up a graphics context of button's size
    CGSize gcSize = tcv.frame.size;
    UIGraphicsBeginImageContext(gcSize);
    // add tcv's layer to context
    [tcv.layer renderInContext:UIGraphicsGetCurrentContext()];
    // create background image now
    UIImage *image = UIGraphicsGetImageFromCurrentImageContext();
     //image =[UIImage imageNamed:@"check.png"];
    UIGraphicsEndImageContext();
    return image;
    // [tcv release];
}


-(NSDictionary*)GetTimeintervals:(NSDictionary*)TimeDetaisl
{
    NSDate *currentDateInLocal;
    
    if ([[TimeDetaisl allKeys] containsObject:@"Date"]) {
        currentDateInLocal = [TimeDetaisl valueForKey:@"Date"];
        NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
        [dateFormatter setDateFormat:@"yyyy-MM-dd'T'HH:mm:SS"];
        NSString *currentLocalDateAsStr = [dateFormatter stringFromDate:currentDateInLocal];
        NSArray *date = [currentLocalDateAsStr componentsSeparatedByString:@"T"];
        NSString *dateLbl = [NSString stringWithFormat:@"%@",[date objectAtIndex:0]];
        NSString *Timelabel = [NSString stringWithFormat:@"%@",[date objectAtIndex:1]];
        
        NSString* StartDate = [NSString stringWithFormat:@"%@  %@",dateLbl,Timelabel];
        NSString *dat=Timelabel;
        
        
        NSArray *arr = [dat componentsSeparatedByString:@":"];
        NSString *hou= [arr objectAtIndex:0];
        NSString *mm= [arr objectAtIndex:1];
        NSInteger hour = [hou intValue];
        NSInteger minute = [mm intValue];
        minute = minute;
        NSString *AddTime;
        
        AddTime =[TimeDetaisl valueForKey:@"Time"];
        
        NSString  *TimeInterval = [TimeDetaisl valueForKey:@"TimeInterval"];
        
        int Addvalue = [AddTime intValue];
        
        int minnit = Addvalue;
        
        NSInteger  endtimeH = hour;
        NSInteger   endtimeM = minute+minnit;
        
        
        if (endtimeM>60 ) {
            NSArray *minist = @[@60,@120,@180,@240,@300,@360,@420,@480,@540,@600,@660,@720,@780,@840,@900,@960,@1020,@1080,@1160,@1200,@1260,@1320,@1380,@1440,@1500];
            
            for (int i =0; i<24; i++) {
                
                if (endtimeM > [minist[i] intValue] && endtimeM < [minist[i+1] intValue]) {
                    endtimeH = hour+i+1;
                    endtimeM = endtimeM-[minist[i] intValue];
                    
                }
                
                else if(endtimeM<[minist[i] intValue] &&endtimeM>[minist[i-1] intValue])
                {
                    endtimeH = hour+i;
                    endtimeM = (minute+minnit)-[minist[i-1] intValue];
                }
                
                
                else if(endtimeM == [minist[i] intValue])
                {
                    endtimeH = minute+i+1;
                    endtimeM = 00;
                }
                
            }
            
        }
        if (endtimeH>24) {
            if (endtimeH >24 || endtimeH ==24) {
                
                NSArray *datear =[dateLbl componentsSeparatedByString:@"-"];
                int yaer = [[datear objectAtIndex:0] intValue];
                int months = [[datear objectAtIndex:1] intValue];
                int day = [[datear objectAtIndex:2] intValue];
                day =day+1;
                endtimeH = endtimeH-24;
                NSString *days,*monthss;
                if (day<10) {
                    days = [NSString stringWithFormat:@"0%d",day];
                }
                else if(day>10)
                {
                    days = [NSString stringWithFormat:@"%d",day];
                }
                if (months <10) {
                    monthss = [NSString stringWithFormat:@"0%d",months];
                }
                
                else if (months >10) {
                    monthss = [NSString stringWithFormat:@"%d",months];
                }
                else
                    monthss = [NSString stringWithFormat:@"%d",months];

                dateLbl = [NSString stringWithFormat:@"%d-%@-%@",yaer,monthss,days];
                
            }
            
        }
        else if (endtimeH== 24)
        {
            NSArray *datear =[dateLbl componentsSeparatedByString:@"-"];
            int yaer = [[datear objectAtIndex:0] intValue];
            int months = [[datear objectAtIndex:1] intValue];
            int day = [[datear objectAtIndex:2] intValue];
            day =day+1;
            endtimeH = endtimeH-24;
            NSString *days,*monthss;
            if (day<10) {
                days = [NSString stringWithFormat:@"0%d",day];
            }
            else if(day>10)
            {
                days = [NSString stringWithFormat:@"%d",day];
            }
            if (months <10) {
                monthss = [NSString stringWithFormat:@"0%d",months];
            }
            
            else if (months >10) {
                monthss = [NSString stringWithFormat:@"%d",months];
            }
            else
                monthss = [NSString stringWithFormat:@"%d",months];

            dateLbl = [NSString stringWithFormat:@"%d-%@-%@",yaer,monthss,days];
   
        }
        
        NSString *str1=[NSString stringWithFormat:@"%@",dateLbl];
        
        NSString *str=[NSString stringWithFormat:@"%@ %ld:%ld:00",str1,(long)endtimeH,(long)endtimeM];
        //str = [str stringByReplacingOccurrencesOfString:@"+0000" withString:@""];
        
        
        NSDateFormatter *Format = [[NSDateFormatter alloc]init];
        [Format setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
        
        NSDate * fistdate  =[Format dateFromString:StartDate];
        NSDate *secondtime =[Format dateFromString:str];
        
        NSDateFormatter *formatter = [[NSDateFormatter alloc]init];
        [formatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
        
        
        NSTimeZone *gmt = [NSTimeZone timeZoneWithAbbreviation:@"UTC"];
        [formatter setTimeZone:gmt];
        
        NSString *StartTimecon = [formatter stringFromDate:fistdate];
        NSString *SecondTime = [formatter stringFromDate:secondtime];
        
        
        
        NSDateFormatter *Format1 = [[NSDateFormatter alloc]init];
        [Format1 setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
        
        NSDate * fistdate1  =[Format1 dateFromString:StartTimecon];
        NSDate *secondtime1 =[Format1 dateFromString:SecondTime];
        
        NSDateFormatter *dateFormatter3 = [[NSDateFormatter alloc] init];
        [dateFormatter3 setDateFormat:@"yyyy-MM-dd HH:mm:SS"];
        NSTimeZone *gmt2 = [NSTimeZone timeZoneWithAbbreviation:@"UTC"];
        [dateFormatter3 setTimeZone:gmt2];
        NSString *startDate = [dateFormatter3 stringFromDate:fistdate1];
        NSString *endDate = [dateFormatter3 stringFromDate:secondtime1];
        
        NSMutableDictionary *DateTimeData = [[NSMutableDictionary alloc]init];
        
        [DateTimeData setValue:startDate forKey:@"StartDate"];
        [DateTimeData setValue:endDate forKey:@"EndDate"];
        [DateTimeData setValue:TimeInterval forKey:@"TimeInterval"];
        [DateTimeData setValue:AddTime forKey:@"Time"];
        
        
        if ([DateTimeData count]==3) {
            
            NSString *srtime = [DateTimeData valueForKey:@"EndDate"];
            
            if([DateTimeData valueForKey:@"StartDate"]==nil)

            {
            
            NSArray *array = [srtime componentsSeparatedByString:@" "];
            
            NSString *dat = [array objectAtIndex:0];
            NSString *strttime = [array objectAtIndex:1];
            
            
            NSArray *arr = [strttime componentsSeparatedByString:@":"];
            NSString *hou= [arr objectAtIndex:0];
            NSString *mm= [arr objectAtIndex:1];
            
            int mmm= [mm intValue];
            
            int timeval = [[DateTimeData valueForKey:@"Time"] intValue];
            timeval= timeval;
            int hor=[hou intValue];
            if (mmm < timeval) {
                //hor = [hou intValue];
                hor = hor-1;
                mmm = mmm+60;
                mmm =mmm-timeval;
            }
            else if (mmm>timeval)
            {
                mmm = mmm-timeval;
            }
            
            NSString *str1=[NSString stringWithFormat:@"%@",dat];
            
            
            
            NSString *str=[NSString stringWithFormat:@"%@ %ld:%ld:00",str1,(long)hor,(long)mmm];
            
            NSLog(@" Date  %@",str);
            
            [DateTimeData setValue:str forKey:@"StartDate"];
        }
            else if([DateTimeData valueForKey:@"EndDate"]==nil)
                
            {
                NSString *srtime = [DateTimeData valueForKey:@"StartDate"];
                NSArray *array = [srtime componentsSeparatedByString:@" "];
                
                NSString *Date = [array objectAtIndex:0];
                NSString *strttime = [array objectAtIndex:1];
                
                
                NSArray *arr = [strttime componentsSeparatedByString:@":"];
                NSString *hou= [arr objectAtIndex:0];
                NSString *mm= [arr objectAtIndex:1];
                NSInteger hour = [hou intValue];
                NSInteger minute = [mm intValue];
                minute = minute;
                NSString *AddTime;
                
                AddTime =[TimeDetaisl valueForKey:@"Time"];

                
               // AddTime =[TimeDetaisl valueForKey:@"Time"];
                
               // NSString  *TimeInterval = [TimeDetaisl valueForKey:@"TimeInterval"];
                
                int Addvalue = [AddTime intValue];
                
                int minnit = Addvalue;
                
                NSInteger  endtimeH = hour;
                NSInteger   endtimeM = minute+minnit;
                
                
                if (endtimeM>60 ) {
                    NSArray *minist = @[@60,@120,@180,@240,@300,@360,@420,@480,@540,@600,@660,@720,@780,@840,@900,@960,@1020,@1080,@1160,@1200,@1260,@1320,@1380,@1440,@1500];
                    
                    for (int i =0; i<24; i++) {
                        
                        if (endtimeM > [minist[i] intValue] && endtimeM < [minist[i+1] intValue]) {
                            endtimeH = hour+i+1;
                            endtimeM = endtimeM-[minist[i] intValue];
                            
                        }
                        
                        else if(endtimeM<[minist[i] intValue] &&endtimeM>[minist[i-1] intValue])
                        {
                            endtimeH = hour+i;
                            endtimeM = (minute+minnit)-[minist[i-1] intValue];
                        }
                        
                        
                        else if(endtimeM == [minist[i] intValue])
                        {
                            endtimeH = minute+i+1;
                            endtimeM = 00;
                        }
                        
                    }
                    
                }
                if (endtimeH>24) {
                    if (endtimeH >24 || endtimeH ==24) {
                        
                         NSString *Date = [array objectAtIndex:0];
                        
                        
                        NSArray *datear =[Date componentsSeparatedByString:@"-"];
                        int yaer = [[datear objectAtIndex:0] intValue];
                        int months = [[datear objectAtIndex:1] intValue];
                        int day = [[datear objectAtIndex:2] intValue];
                        day =day+1;
                        endtimeH = endtimeH-24;
                        NSString *days,*monthss;
                        if (day<10) {
                            days = [NSString stringWithFormat:@"0%d",day];
                        }
                        else if(day>10)
                        {
                            days = [NSString stringWithFormat:@"%d",day];
                        }
                        if (months <10) {
                            monthss = [NSString stringWithFormat:@"0%d",months];
                        }
                        
                        else if (months >10) {
                            monthss = [NSString stringWithFormat:@"%d",months];
                        }
                        else
                            monthss = [NSString stringWithFormat:@"%d",months];
                        
                        dateLbl = [NSString stringWithFormat:@"%d-%@-%@",yaer,monthss,days];
                        
                    }
                    
                }
                
                else if (endtimeH == 24)
                {
                     NSString *Date = [array objectAtIndex:0];
                    
                    NSArray *datear =[Date componentsSeparatedByString:@"-"];
                    int yaer = [[datear objectAtIndex:0] intValue];
                    int months = [[datear objectAtIndex:1] intValue];
                    int day = [[datear objectAtIndex:2] intValue];
                    day =day+1;
                    endtimeH = endtimeH-24;
                    NSString *days,*monthss;
                    if (day<10) {
                        days = [NSString stringWithFormat:@"0%d",day];
                    }
                    else if(day>10)
                    {
                        days = [NSString stringWithFormat:@"%d",day];
                    }
                    if (months <10) {
                        monthss = [NSString stringWithFormat:@"0%d",months];
                    }
                    
                    else if (months >10) {
                        monthss = [NSString stringWithFormat:@"%d",months];
                    }
                    else
                        monthss = [NSString stringWithFormat:@"%d",months];

                    
                    dateLbl = [NSString stringWithFormat:@"%d-%@-%@",yaer,monthss,days];
                    
                }

                
              //  NSString *str1=[NSString stringWithFormat:@"%@",dateLbl];
                
                NSString *str=[NSString stringWithFormat:@"%@ %ld:%ld:00",Date,(long)endtimeH,(long)endtimeM];
                
                 [DateTimeData setValue:str forKey:@"EndDate"];
                
            }
           
        
        }
        
        return DateTimeData;

    }

    else {
        
        NSDate *currentDateInLocal = [NSDate date];
        NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
        [dateFormatter setDateFormat:@"yyyy-MM-dd'T'HH:mm:SS"];
        NSString *currentLocalDateAsStr = [dateFormatter stringFromDate:currentDateInLocal];
        NSArray *date = [currentLocalDateAsStr componentsSeparatedByString:@"T"];
        NSString *dateLbl = [NSString stringWithFormat:@"%@",[date objectAtIndex:0]];
        NSString *Timelabel = [NSString stringWithFormat:@"%@",[date objectAtIndex:1]];
        
        NSString* StartDate = [NSString stringWithFormat:@"%@  %@",dateLbl,Timelabel];
        NSString *dat=Timelabel;
        
        NSArray *arr = [dat componentsSeparatedByString:@":"];
        NSString *hou= [arr objectAtIndex:0];
        NSString *mm= [arr objectAtIndex:1];
        NSInteger hour = [hou intValue];
        NSInteger minute = [mm intValue];
        minute = minute+1;
        NSString *AddTime;
        
        AddTime =[TimeDetaisl valueForKey:@"Time"];
        
        NSString  *TimeInterval = [TimeDetaisl valueForKey:@"TimeInterval"];
        
        int Addvalue = [AddTime intValue];
        
        int minnit = Addvalue;
        
        NSInteger  endtimeH = hour;
        NSInteger   endtimeM = minute+minnit;
        
        
        if (endtimeM>60 ) {
            NSArray *minist = @[@60,@120,@180,@240,@300,@360,@420,@480,@540,@600,@660,@720,@780,@840,@900,@960,@1020,@1080,@1160,@1200,@1260,@1320,@1380,@1440,@1500];
            
            for (int i =0; i<24; i++) {
                
                if (endtimeM > [minist[i] intValue] && endtimeM < [minist[i+1] intValue]) {
                    endtimeH = hour+i+1;
                    endtimeM = endtimeM-[minist[i] intValue];
                    
                }
                
                else if(endtimeM<[minist[i] intValue] &&endtimeM>[minist[i-1] intValue])
                {
                    endtimeH = hour+i;
                    endtimeM = (minute+minnit)-[minist[i-1] intValue];
                }
                
                
                else if(endtimeM == [minist[i] intValue])
                {
                    endtimeH = minute+i+1;
                    endtimeM = 00;
                }
                
            }
            
        }
        if (endtimeH>24) {
            if (endtimeH >24 || endtimeH ==24) {
                
                NSArray *datear =[dateLbl componentsSeparatedByString:@"-"];
                int yaer = [[datear objectAtIndex:0] intValue];
                int months = [[datear objectAtIndex:1] intValue];
                int day = [[datear objectAtIndex:2] intValue];
                day =day+1;
                endtimeH = endtimeH-24;
                NSString *days,*monthss;
                if (day<10) {
                    days = [NSString stringWithFormat:@"0%d",day];
                }
                else if(day>10)
                {
                    days = [NSString stringWithFormat:@"%d",day];
                }
                if (months <10) {
                    monthss = [NSString stringWithFormat:@"0%d",months];
                }
                
                else if (months >10) {
                    monthss = [NSString stringWithFormat:@"%d",months];
                }
                
                else
                    monthss = [NSString stringWithFormat:@"%d",months];

                dateLbl = [NSString stringWithFormat:@"%d-%@-%@",yaer,monthss,days];
                
            }
            
        }
        
        else if (endtimeH== 24)
        {
            NSArray *datear =[dateLbl componentsSeparatedByString:@"-"];
            int yaer = [[datear objectAtIndex:0] intValue];
            int months = [[datear objectAtIndex:1] intValue];
            int day = [[datear objectAtIndex:2] intValue];
            day =day+1;
            endtimeH = endtimeH-24;
            NSString *days,*monthss;
            if (day<10) {
                days = [NSString stringWithFormat:@"0%d",day];
            }
            else if(day>10)
            {
                days = [NSString stringWithFormat:@"%d",day];
            }
            if (months <10) {
                monthss = [NSString stringWithFormat:@"0%d",months];
            }
            
            else if (months >10) {
                monthss = [NSString stringWithFormat:@"%d",months];
            }
            else
                monthss = [NSString stringWithFormat:@"%d",months];

            
            dateLbl = [NSString stringWithFormat:@"%d-%@-%@",yaer,monthss,days];
            
        }

        
        
        
        NSString *str1=[NSString stringWithFormat:@"%@",dateLbl];
        
        NSString *str=[NSString stringWithFormat:@"%@ %ld:%ld:00",str1,(long)endtimeH,(long)endtimeM];
        str = [str stringByReplacingOccurrencesOfString:@"+0000" withString:@""];
        
        
        NSDateFormatter *Format = [[NSDateFormatter alloc]init];
        [Format setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
        
        NSDate * fistdate  =[Format dateFromString:StartDate];
        NSDate *secondtime =[Format dateFromString:str];
        
        NSDateFormatter *formatter = [[NSDateFormatter alloc]init];
        [formatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
        
        
        
        NSTimeZone *gmt = [NSTimeZone timeZoneWithAbbreviation:@"UTC"];
        [formatter setTimeZone:gmt];
        
        NSString *StartTimecon = [formatter stringFromDate:fistdate];
        NSString *SecondTime = [formatter stringFromDate:secondtime];
        
        
        
        NSMutableDictionary *DateTimeData = [[NSMutableDictionary alloc]init];
        
        [DateTimeData setValue:StartTimecon forKey:@"StartDate"];
        [DateTimeData setValue:SecondTime forKey:@"EndDate"];
        [DateTimeData setValue:TimeInterval forKey:@"TimeInterval"];
        [DateTimeData setValue:AddTime forKey:@"Time"];
        
        
        if ([DateTimeData count]==3) {
            
            NSString *srtime = [DateTimeData valueForKey:@"EndDate"];
            
            NSArray *array = [srtime componentsSeparatedByString:@" "];
            
            NSString *dat = [array objectAtIndex:0];
            NSString *strttime = [array objectAtIndex:1];
            
            
            NSArray *arr = [strttime componentsSeparatedByString:@":"];
            NSString *hou= [arr objectAtIndex:0];
            NSString *mm= [arr objectAtIndex:1];
            
            int mmm= [mm intValue];
            
            int timeval = [[DateTimeData valueForKey:@"Time"] intValue];
            timeval= timeval;
            int hor=[hou intValue];
            if (mmm < timeval) {
                //hor = [hou intValue];
                hor = hor-1;
                mmm = mmm+60;
                mmm =mmm-timeval;
            }
            else if (mmm>timeval)
            {
                mmm = mmm-timeval;
            }
            
            NSString *str1=[NSString stringWithFormat:@"%@",dat];
            
            NSString *str=[NSString stringWithFormat:@"%@ %ld:%ld:00",str1,(long)hor,(long)mmm];
            
            NSLog(@" Date  %@",str);
            
            [DateTimeData setValue:str forKey:@"StartDate"];
            
            
        }
        
        
        return DateTimeData;
        
        
    }
     
}


-(NSDictionary*)incrementTime
{
    NSDate *currentDateInLocal = [NSDate date];
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"yyyy-MM-dd'T'HH:mm:ss"];
    NSString *currentLocalDateAsStr = [dateFormatter stringFromDate:currentDateInLocal];
    NSArray *date = [currentLocalDateAsStr componentsSeparatedByString:@"T"];
    NSString *dateLbl = [NSString stringWithFormat:@"%@",[date objectAtIndex:0]];
    //NSString *Timelabel = [NSString stringWithFormat:@"%@",[date objectAtIndex:1]];
    
   // NSString* StartDate = [NSString stringWithFormat:@"%@  %@",dateLbl,Timelabel];
   // NSString *dat=Timelabel;
    
      NSDate *now = [NSDate date];
    NSDateFormatter *dateFormattert = [[NSDateFormatter alloc] init];
    dateFormattert.dateFormat = @"HH:mm:ss";
    [dateFormattert setTimeZone:[NSTimeZone systemTimeZone]];
    NSLog(@"The Current Time is %@",[dateFormattert stringFromDate:now]);
    
    
    NSArray *arr = [[dateFormattert stringFromDate:now] componentsSeparatedByString:@":"];
    NSString *hou= [arr objectAtIndex:0];
    NSString *mm= [arr objectAtIndex:1];
    NSString *sce = [arr objectAtIndex:2];
    NSInteger hour = [hou intValue];
    NSInteger minute = [mm intValue];
    minute = minute+1;
    
    
    if (minute>=60) {
        hour = hour+1;
        minute= minute-60;
        
    }
    NSString *timemint;
    
    if (hour<10) {
        timemint =[NSString stringWithFormat:@"0%ld",(long)hour];
    }
    else timemint =[NSString stringWithFormat:@"%ld",(long)hour];
    
    
    NSString *time = [NSString stringWithFormat:@"%@:%ld:%@",timemint,(long)minute,sce];
    time = [time stringByReplacingOccurrencesOfString:@"+0000" withString:@""];
    
    NSMutableDictionary *datedictionary = [[NSMutableDictionary alloc]init];
    [datedictionary setValue:time forKey:@"Time"];
    [datedictionary setValue:dateLbl forKey:@"Date"];
    
    return datedictionary;
}

- (UIImage *)image:(UIImage*)originlimage scaledToSize:(CGSize)size {
    //avoid redundant drawing
    if (CGSizeEqualToSize(originlimage.size, size))
    {
        return originlimage;
    }
    
    //create drawing context
    UIGraphicsBeginImageContextWithOptions(size, NO, 0.0f);
    
    //draw
    [originlimage drawInRect:CGRectMake(0.0f, 0.0f, size.width, size.height)];
    
    //capture resultant image
    UIImage *image = UIGraphicsGetImageFromCurrentImageContext();
    
    UIGraphicsEndImageContext();
    
    //return image
    return image;
}


-(NSString*)ClaimedTime {
    
        NSDate *currentDateInLocal = [NSDate date];
        
        NSDateFormatter *formatter = [[NSDateFormatter alloc]init];
        [formatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
        NSTimeZone *gmt = [NSTimeZone timeZoneWithAbbreviation:@"UTC"];
        [formatter setTimeZone:gmt];
        NSString *StartTimecon = [formatter stringFromDate:currentDateInLocal];
        return StartTimecon;
}

-(NSDictionary*)getEditeOpportunity:(NSString*)opportunityId
{
    @try {
        
    
    NSDictionary *Opportunity=[[Web_Services GetSharedInstance]GetOpportunityByID:opportunityId MethodName:@"GetOpportunityById"];
        
        return Opportunity;
    } @catch (NSException *exception) {
        @throw [NSException exceptionWithName:@"Something is not right exception"
                                       reason:@"Can't perform this operation because of this or that"
                                     userInfo:nil];;
    } @finally {
        
    }
}

-(IBAction)back:(id)sender
{
    @try {
        
    } @catch (NSException *exception) {
        
    } @finally {
        
    }
}

-(NSString*)emailText:(NSDictionary*)opporDetails
{
    
    
    NSString *satrtDate = [NSString stringWithFormat:@"%@",[opporDetails valueForKey:@"EndDate"]];
    
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"yyyy-MM-dd'T'HH:mm:ss"];
    NSTimeZone *gmt = [NSTimeZone timeZoneWithAbbreviation:@"UTC"];
    [dateFormatter setTimeZone:gmt];
    NSDate *date5 = [dateFormatter dateFromString:satrtDate];
    
    NSDictionary *startOffer;
    if (date5!=nil) {
        startOffer= [[Preferences GetSharedInstance] remaningTime:[NSDate date] endDate:date5];
    }
    else{
        
        NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
        [dateFormatter setDateFormat:@"yyyy-MM-dd'T'HH:mm:ss.SSS"];
        
        NSTimeZone *gmt = [NSTimeZone timeZoneWithAbbreviation:@"UTC"];
        [dateFormatter setTimeZone:gmt];
        NSDate *date5 = [dateFormatter dateFromString:satrtDate];
        startOffer= [[Preferences GetSharedInstance] remaningTime:[NSDate date] endDate:date5];
        
    }
    
    int Remaingtyime = [[startOffer valueForKey:@"Time"] intValue];
    int hour = [[startOffer valueForKey:@"Hour"] intValue];
    int seconds = [[startOffer valueForKey:@"Seconds"] intValue];
    
    if (seconds!=0) {
        Remaingtyime = Remaingtyime+(seconds/60);
    }
    if(Remaingtyime!=0)
    {
        
        Remaingtyime = Remaingtyime+(hour*60);
    }
    
    NSString *duration= [NSString stringWithFormat:@"%dh:%dm:%ds",[[startOffer valueForKey:@"Hour"] intValue], [[startOffer valueForKey:@"Time"] intValue],[[startOffer valueForKey:@"Seconds"] intValue]];
    NSString *opportunityname=[opporDetails valueForKey:@"OpportunityName"];
    NSString *areName=[opporDetails valueForKey:@"AreaName"];
    NSString *vendorName=[opporDetails valueForKey:@"UserName"];
    if ([vendorName isKindOfClass:[NSNull class]]) {
        vendorName = [opporDetails valueForKey:@"VendorName"];
    }
    NSString *contactNumber = [opporDetails valueForKey:@"VendorMobile"];
    
    NSString *watsspptext;
    NSString * category = [opporDetails valueForKey:@"Category"];
    if ([category isEqualToString:FOOD]) {
        
        
        if (Remaingtyime==0) {
            watsspptext = [NSString stringWithFormat:@"Hi,\n%@ has posted an offer \"%@\" at %@.\nContact No: %@ \n\nFor further details download the app\n Play store: http://bit.ly/2fdqw6N\n App store: http://apple.co/2fdvEaV \n\nThanks,\nTeam Right Place Right Time",vendorName,opportunityname,areName,contactNumber];
        }
        else
        {
            watsspptext = [NSString stringWithFormat:@"Hi,\n%@ has posted an offer \"%@\" at %@. Time left is %@ \nContact No: %@.\n\nFor further details download the app\n Play store: http://bit.ly/2fdqw6N\n App store: http://apple.co/2fdvEaV\n\nThanks,\nTeam Right Place Right Time",vendorName,opportunityname,areName,duration,contactNumber];
        }
    }
    
    if ([category isEqualToString:@"Sale"]) {
        
        if (Remaingtyime==0) {
            watsspptext = [NSString stringWithFormat:@"Hi,\n%@ has posted an offer \"%@\" at %@.\nContact No:  %@ \n\nFor further details download the app\n Play store: http://bit.ly/2fdqw6N\n App store: http://apple.co/2fdvEaV\n\nThanks,\nTeam Right Place Right Time",vendorName,opportunityname,areName,contactNumber];
        }
        else
            watsspptext = [NSString stringWithFormat:@"Hi,\n%@ has posted an offer \"%@\" at %@.Time left is %@\nContact No: %@ \n\nFor further details download the app\n Play store: http://bit.ly/2fdqw6N\n App store: http://apple.co/2fdvEaV\n\nThanks,\nTeam Right Place Right Time",vendorName,opportunityname,areName,duration,contactNumber];
        
    }
    if ([category isEqualToString:REALESTATE]) {
        
        NSString *property=[opporDetails valueForKey:@"SubCategory"];
        
        NSArray *subcat = [[opporDetails valueForKey:@"OpportunityKeywords"] componentsSeparatedByString:@","];
        
        NSString *share =[NSString stringWithFormat:@"%@",[subcat objectAtIndex:0]];
        
        NSString *areaName=[opporDetails valueForKey:@"AreaName"];
        NSString *vendorName=[opporDetails valueForKey:@"UserName"];
        
        
        if (Remaingtyime==0) {
            watsspptext = [NSString stringWithFormat:@"Hi,\n%@ is available for %@ at %@. Contact %@ for more details.\nContact No: %@ \n\n For further details download the app \n Play store: http://bit.ly/2fdqw6N\n App store: http://apple.co/2fdvEaV\n\nThanks,\nTeam Right Place Right Time",property,share,areaName,vendorName,contactNumber];
        }
        else
            watsspptext = [NSString stringWithFormat:@"Hi,\n%@ is available for %@ at %@. Contact %@ for more details before %@. \nContact No:%@ \n\n For further details download the app \n Play store: http://bit.ly/2fdqw6N\n App store: http://apple.co/2fdvEaV\n\nThanks,\nTeam Right Place Right Time",property,share,areaName,vendorName,duration,contactNumber];
        
    }
    if ([category isEqualToString:@"Jobs"]) {
        
        if (Remaingtyime==0) {
            watsspptext = [NSString stringWithFormat:@"Hi,\n%@ has posted a Job requirement. \"%@\" at %@. \nContact No: %@  \n\nFor further details download the app \n Play store: http://bit.ly/2fdqw6N\n App store: http://apple.co/2fdvEaV\n\nThanks,\nTeam Right Place Right Time",vendorName,opportunityname,areName,contactNumber];
        }
        else
            watsspptext = [NSString stringWithFormat:@"Hi,\n%@ has posted a Job requirement. \"%@\" at %@. Time left to apply is %@\nContact No: %@. \n\nFor further details download the app \n Play store: http://bit.ly/2fdqw6N\n App store: http://apple.co/2fdvEaV\n\nThanks,\nTeam Right Place Right Time",vendorName,opportunityname,areName,duration,contactNumber];
        
    }
    if ([category isEqualToString:TRAVELS]) {
        
        NSString *vehicletype = [opporDetails valueForKey:@"SubCategory"];
        NSArray *addres = [[opporDetails valueForKey:@"OpportunityName"] componentsSeparatedByString:@"to"];
        NSString *source = [addres objectAtIndex:0];
        NSString *destination =[addres objectAtIndex:1];
        NSString *seats = [opporDetails valueForKey:@"Available"];
        NSString *contactperson = [opporDetails valueForKey:@"UserName"];
        NSString *contactNumber = [opporDetails valueForKey:@"VendorMobile"];
        
        watsspptext = [NSString stringWithFormat:@"Hi,\nA %@ is going from \"%@ to %@\" and there are %@ available.\nContact %@ for more details.\nConatct No: %@ \n\n For further details download the app \n Play store: http://bit.ly/2fdqw6N\n App store: http://apple.co/2fdvEaV\n\nThanks,\nTeam Right Place Right Time",vehicletype,source,destination,seats,contactperson,contactNumber];
        
    }
    if ([category isEqualToString:BANKING]) {
        
        
        if (Remaingtyime==0) {
            watsspptext = [NSString stringWithFormat:@"Hi,\n%@ has posted an offer \"%@\" at %@.\nContact No:  %@ \n\nFor further details download the app\n Play store: http://bit.ly/2fdqw6N\n App store: http://apple.co/2fdvEaV\n\nThanks,\nTeam Right Place Right Time",vendorName,opportunityname,areName,contactNumber];
        }
        else
            
            watsspptext = [NSString stringWithFormat:@"Hi,\n%@ has posted an offer \"%@\" at %@. Offer available till %@.\nContact No:  %@. \n\nFor further details download the app\n Play store: http://bit.ly/2fdqw6N\n App store: http://apple.co/2fdvEaV\n\nThanks,\nTeam Right Place Right Time",vendorName,opportunityname,areName,duration,contactNumber];
        
    }
    if ([category isEqualToString:MEETINGS]) {
        if (Remaingtyime==0) {
            watsspptext = [NSString stringWithFormat:@"Hi,\n%@ has posted an event \"%@\" at %@.\nContact No: %@ \n\nFor further details download the app  \n Play store: http://bit.ly/2fdqw6N\n App store: http://apple.co/2fdvEaV\n\nThanks,\nTeam Right Place Right Time",vendorName,opportunityname,areName,contactNumber];
        }
        else
            watsspptext = [NSString stringWithFormat:@"Hi,%@ has posted an event \"%@\" at %@.  Offer available till %@.\nContact No: %@\n\n For further details download the app  \n Play store: http://bit.ly/2fdqw6N\n App store: http://apple.co/2fdvEaV\n\nThanks,\nTeam Right Place Right Time",vendorName,opportunityname,areName,duration,contactNumber];
        
    }
    if ([category isEqualToString:@"Professional Services"]) {
        NSString *experttype=[opporDetails valueForKey:@"SubCategory"];
        watsspptext = [NSString stringWithFormat:@"Hi,\n%@ is requesting for %@, \"%@\" at %@.\nContact No: %@ \n\nFor further details download the app \n Play store: http://bit.ly/2fdqw6N\n App store: http://apple.co/2fdvEaV\n\nThanks,\nTeam Right Place Right Time",vendorName,experttype,opportunityname,areName,contactNumber];
        
    }
    if ([category isEqualToString:SPORTS]) {
        NSString *sporttype=[opporDetails valueForKey:@"SubCategory"];
        
        watsspptext = [NSString stringWithFormat:@"Hi,\n%@ is looking for %@ players, \"%@\" at %@.\nContact No:  %@ \n\n For further details download the app\n Play store: http://bit.ly/2fdqw6N \n App store: http://apple.co/2fdvEaV\n\nThanks,\nTeam Right Place Right Time",vendorName,sporttype,opportunityname,areName,contactNumber];
        
    }
    
    if ([category isEqualToString:HEALTH]) {
        NSString *type=[opporDetails valueForKey:@"SubCategory"];
        watsspptext = [NSString stringWithFormat:@"Hi,\n%@ is requesting for %@, \"%@\" at %@. \nContact No: %@ \n\n For further details download the app\n Play store: http://bit.ly/2fdqw6N\n App store: http://apple.co/2fdvEaV\n\nThanks,\nTeam Right Place Right Time",vendorName,type,opportunityname,areName,contactNumber];
        
    }
    return watsspptext;
}

-(NSString*)whatspandSMSText:(NSDictionary*)opporDetails
{
    
    NSString *satrtDate = [NSString stringWithFormat:@"%@",[opporDetails valueForKey:@"EndDate"]];
    
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"yyyy-MM-dd'T'HH:mm:ss"];
    NSTimeZone *gmt = [NSTimeZone timeZoneWithAbbreviation:@"UTC"];
    [dateFormatter setTimeZone:gmt];
    NSDate *date5 = [dateFormatter dateFromString:satrtDate];
    
    NSDictionary *startOffer;
    if (date5!=nil) {
        startOffer= [[Preferences GetSharedInstance] remaningTime:[NSDate date] endDate:date5];
    }
    else{
        
        NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
        [dateFormatter setDateFormat:@"yyyy-MM-dd'T'HH:mm:ss.SSS"];
        
        NSTimeZone *gmt = [NSTimeZone timeZoneWithAbbreviation:@"UTC"];
        [dateFormatter setTimeZone:gmt];
        NSDate *date5 = [dateFormatter dateFromString:satrtDate];
        startOffer= [[Preferences GetSharedInstance] remaningTime:[NSDate date] endDate:date5];
        
    }
    
    int Remaingtyime = [[startOffer valueForKey:@"Time"] intValue];
    int hour = [[startOffer valueForKey:@"Hour"] intValue];
    int seconds = [[startOffer valueForKey:@"Seconds"] intValue];
    seconds = seconds+35;
    
    if (seconds!=0) {
        Remaingtyime = Remaingtyime+(seconds/60);
    }
    if(Remaingtyime!=0)
    {
        
        Remaingtyime = Remaingtyime+(hour*60);
    }
    
    NSString *duration= [NSString stringWithFormat:@"%dh:%dm:%ds",[[startOffer valueForKey:@"Hour"] intValue], [[startOffer valueForKey:@"Time"] intValue],[[startOffer valueForKey:@"Seconds"] intValue]];
    NSString *opportunityname=[opporDetails valueForKey:@"OpportunityName"];
    NSString *areName=[opporDetails valueForKey:@"AreaName"];
    NSString *vendorName=[opporDetails valueForKey:@"UserName"];
    if ([vendorName isKindOfClass:[NSNull class]]) {
        vendorName = [opporDetails valueForKey:@"VendorName"];
    }
    NSString *contactNumber = [opporDetails valueForKey:@"VendorMobile"];
    NSString *watsspptext;
    
    NSString * category = [opporDetails valueForKey:@"Category"];
    
    if ([category isEqualToString:FOOD]) {
        
        
        if (Remaingtyime==0) {
            watsspptext = [NSString stringWithFormat:@" %@ has posted an offer \"%@\" at %@.\nContact No: %@ \n\nFor further details download the app\n Play store: http://bit.ly/2fdqw6N\n App store: http://apple.co/2fdvEaV",vendorName,opportunityname,areName,contactNumber];
        }
        else
        {
            watsspptext = [NSString stringWithFormat:@" %@ has posted an offer \"%@\" at %@. Time left is %@.\nContact No: %@. \n\nFor further details download the app\n Play store: http://bit.ly/2fdqw6N\n App store: http://apple.co/2fdvEaV",vendorName,opportunityname,areName,duration,contactNumber];
        }
    }
    
    if ([category isEqualToString:@"Sale"]) {
        
        if (Remaingtyime==0) {
            watsspptext = [NSString stringWithFormat:@" %@ has posted an offer \"%@\" at %@.\nContact No:  %@ \n\nFor further details download the app\n Play store: http://bit.ly/2fdqw6N\n App store: http://apple.co/2fdvEaV",vendorName,opportunityname,areName,contactNumber];
        }
        else
            watsspptext = [NSString stringWithFormat:@" %@ has posted an offer \"%@\" at %@.Time left is %@.\nContact No: %@ \n\nFor further details download the app\n Play store: http://bit.ly/2fdqw6N\n App store: http://apple.co/2fdvEaV",vendorName,opportunityname,areName,duration,contactNumber];
        
    }
    if ([category isEqualToString:REALESTATE]) {
        
        NSString *property=[opporDetails valueForKey:@"SubCategory"];
        
        NSArray *subcat = [[opporDetails valueForKey:@"OpportunityKeywords"] componentsSeparatedByString:@","];
        
        NSString *share =[NSString stringWithFormat:@"%@",[subcat objectAtIndex:0]];
        
        NSString *areaName=[opporDetails valueForKey:@"AreaName"];
        NSString *vendorName=[opporDetails valueForKey:@"UserName"];
        
        
        if (Remaingtyime==0) {
            watsspptext = [NSString stringWithFormat:@"%@ is available for %@ at %@. Contact %@ for more details. \nContact No: %@  \n\n For further details download the app \n Play store: http://bit.ly/2fdqw6N\n App store: http://apple.co/2fdvEaV",property,share,areaName,vendorName,contactNumber];
        }
        else
            watsspptext = [NSString stringWithFormat:@"%@ is available for %@ at %@. Contact %@ for more details before %@.\nContact No: %@  \n\n For further details download the app \n Play store: http://bit.ly/2fdqw6N\n App store: http://apple.co/2fdvEaV",property,share,areaName,vendorName,duration,contactNumber];
        
    }
    if ([category isEqualToString:@"Jobs"]) {
        
        if (Remaingtyime==0) {
            watsspptext = [NSString stringWithFormat:@" %@ has posted a Job requirement. \"%@\" at %@. \nContact No: %@  \n\nFor further details download the app \n Play store: http://bit.ly/2fdqw6N\n App store: http://apple.co/2fdvEaV",vendorName,opportunityname,areName,contactNumber];
        }
        else
            watsspptext = [NSString stringWithFormat:@" %@ has posted a Job requirement. \"%@\" at %@.. Time left to apply is %@.\nContact No: %@ \n\nFor further details download the app \n Play store: http://bit.ly/2fdqw6N\n App store: http://apple.co/2fdvEaV",vendorName,opportunityname,areName,duration,contactNumber];
        
    }
    if ([category isEqualToString:TRAVELS]) {
        
        NSString *vehicletype = [opporDetails valueForKey:@"SubCategory"];
        NSArray *addres = [[opporDetails valueForKey:@"OpportunityName"] componentsSeparatedByString:@"to"];
        NSString *source = [addres objectAtIndex:0];
        NSString *destination =[addres objectAtIndex:1];
        NSString *seats = [opporDetails valueForKey:@"Available"];
        NSString *contactperson = [opporDetails valueForKey:@"UserName"];
        NSString *contactNumber = [opporDetails valueForKey:@"VendorMobile"];
        
        watsspptext = [NSString stringWithFormat:@"A %@ is going from \"%@ to %@\" and there are %@ available. Contact %@  for more details.\nContact No: %@\n\n For further details download the app \n Play store: http://bit.ly/2fdqw6N\n App store: http://apple.co/2fdvEaV",vehicletype,source,destination,seats,contactperson,contactNumber];
        
    }
    if ([category isEqualToString:BANKING]) {
        
        
        if (Remaingtyime==0) {
            watsspptext = [NSString stringWithFormat:@" %@ has posted an offer \"%@\" at %@.\nContact No:  %@ \n\nFor further details download the app\n Play store: http://bit.ly/2fdqw6N\n App store: http://apple.co/2fdvEaV",vendorName,opportunityname,areName,contactNumber];
        }
        else
            
            watsspptext = [NSString stringWithFormat:@" %@ has posted an offer \"%@\" at %@.. Offer available till %@.\nContact No:  %@ \n\nFor further details download the app\n Play store: http://bit.ly/2fdqw6N\n App store: http://apple.co/2fdvEaV",vendorName,opportunityname,areName,duration,contactNumber];
        
    }
    if ([category isEqualToString:MEETINGS]) {
        if (Remaingtyime==0) {
            watsspptext = [NSString stringWithFormat:@"%@ has posted an event \"%@\" at %@.\nContact No: %@ \n\nFor further details download the app  \n Play store: http://bit.ly/2fdqw6N\n App store: http://apple.co/2fdvEaV",vendorName,opportunityname,areName,contactNumber];
        }
        else
            watsspptext = [NSString stringWithFormat:@"%@ has posted an event \"%@\" at %@.  Offer available till %@.\nContact No: %@\n\n For further details download the app  \n Play store: http://bit.ly/2fdqw6N\n App store: http://apple.co/2fdvEaV",vendorName,opportunityname,areName,duration,contactNumber];
        
    }
    if ([category isEqualToString:@"Professional Services"]) {
        NSString *experttype=[opporDetails valueForKey:@"SubCategory"];
        watsspptext = [NSString stringWithFormat:@"%@ is requesting for %@, \"%@\" at %@.\nContact No: %@ \n\nFor further details download the app \n Play store: http://bit.ly/2fdqw6N\n App store: http://apple.co/2fdvEaV",vendorName,experttype,opportunityname,areName,contactNumber];
        
    }
    if ([category isEqualToString:SPORTS]) {
        NSString *sporttype=[opporDetails valueForKey:@"SubCategory"];
        
        watsspptext = [NSString stringWithFormat:@"%@ is looking for %@ players, \"%@\" at %@.\nContact No:  %@ \n\n For further details download the app\n Play store: http://bit.ly/2fdqw6N \n App store: http://apple.co/2fdvEaV",vendorName,sporttype,opportunityname,areName,contactNumber];
        
    }
    
    if ([category isEqualToString:HEALTH]) {
        NSString *type=[opporDetails valueForKey:@"SubCategory"];
        watsspptext = [NSString stringWithFormat:@"%@ is requesting for %@, \"%@\" at %@. \nContact No: %@ \n\n For further details download the app\n Play store: http://bit.ly/2fdqw6N\n App store: http://apple.co/2fdvEaV",vendorName,type,opportunityname,areName,contactNumber];
        
    }
    return watsspptext;
}


- (NSDictionary *)getCountryCodeDictionary {
    return [NSDictionary dictionaryWithObjectsAndKeys:@"972", @"IL",
            @"93", @"AF", @"355", @"AL", @"213", @"DZ", @"1", @"AS",
            @"376", @"AD", @"244", @"AO", @"1", @"AI", @"1", @"AG",
            @"54", @"AR", @"374", @"AM", @"297", @"AW", @"61", @"AU",
            @"43", @"AT", @"994", @"AZ", @"1", @"BS", @"973", @"BH",
            @"880", @"BD", @"1", @"BB", @"375", @"BY", @"32", @"BE",
            @"501", @"BZ", @"229", @"BJ", @"1", @"BM", @"975", @"BT",
            @"387", @"BA", @"267", @"BW", @"55", @"BR", @"246", @"IO",
            @"359", @"BG", @"226", @"BF", @"257", @"BI", @"855", @"KH",
            @"237", @"CM", @"1", @"CA", @"238", @"CV", @"345", @"KY",
            @"236", @"CF", @"235", @"TD", @"56", @"CL", @"86", @"CN",
            @"61", @"CX", @"57", @"CO", @"269", @"KM", @"242", @"CG",
            @"682", @"CK", @"506", @"CR", @"385", @"HR", @"53", @"CU",
            @"537", @"CY", @"420", @"CZ", @"45", @"DK", @"253", @"DJ",
            @"1", @"DM", @"1", @"DO", @"593", @"EC", @"20", @"EG",
            @"503", @"SV", @"240", @"GQ", @"291", @"ER", @"372", @"EE",
            @"251", @"ET", @"298", @"FO", @"679", @"FJ", @"358", @"FI",
            @"33", @"FR", @"594", @"GF", @"689", @"PF", @"241", @"GA",
            @"220", @"GM", @"995", @"GE", @"49", @"DE", @"233", @"GH",
            @"350", @"GI", @"30", @"GR", @"299", @"GL", @"1", @"GD",
            @"590", @"GP", @"1", @"GU", @"502", @"GT", @"224", @"GN",
            @"245", @"GW", @"595", @"GY", @"509", @"HT", @"504", @"HN",
            @"36", @"HU", @"354", @"IS", @"91", @"IN", @"62", @"ID",
            @"964", @"IQ", @"353", @"IE", @"972", @"IL", @"39", @"IT",
            @"1", @"JM", @"81", @"JP", @"962", @"JO", @"77", @"KZ",
            @"254", @"KE", @"686", @"KI", @"965", @"KW", @"996", @"KG",
            @"371", @"LV", @"961", @"LB", @"266", @"LS", @"231", @"LR",
            @"423", @"LI", @"370", @"LT", @"352", @"LU", @"261", @"MG",
            @"265", @"MW", @"60", @"MY", @"960", @"MV", @"223", @"ML",
            @"356", @"MT", @"692", @"MH", @"596", @"MQ", @"222", @"MR",
            @"230", @"MU", @"262", @"YT", @"52", @"MX", @"377", @"MC",
            @"976", @"MN", @"382", @"ME", @"1", @"MS", @"212", @"MA",
            @"95", @"MM", @"264", @"NA", @"674", @"NR", @"977", @"NP",
            @"31", @"NL", @"599", @"AN", @"687", @"NC", @"64", @"NZ",
            @"505", @"NI", @"227", @"NE", @"234", @"NG", @"683", @"NU",
            @"672", @"NF", @"1", @"MP", @"47", @"NO", @"968", @"OM",
            @"92", @"PK", @"680", @"PW", @"507", @"PA", @"675", @"PG",
            @"595", @"PY", @"51", @"PE", @"63", @"PH", @"48", @"PL",
            @"351", @"PT", @"1", @"PR", @"974", @"QA", @"40", @"RO",
            @"250", @"RW", @"685", @"WS", @"378", @"SM", @"966", @"SA",
            @"221", @"SN", @"381", @"RS", @"248", @"SC", @"232", @"SL",
            @"65", @"SG", @"421", @"SK", @"386", @"SI", @"677", @"SB",
            @"27", @"ZA", @"500", @"GS", @"34", @"ES", @"94", @"LK",
            @"249", @"SD", @"597", @"SR", @"268", @"SZ", @"46", @"SE",
            @"41", @"CH", @"992", @"TJ", @"66", @"TH", @"228", @"TG",
            @"690", @"TK", @"676", @"TO", @"1", @"TT", @"216", @"TN",
            @"90", @"TR", @"993", @"TM", @"1", @"TC", @"688", @"TV",
            @"256", @"UG", @"380", @"UA", @"971", @"AE", @"44", @"GB",
            @"1", @"US", @"598", @"UY", @"998", @"UZ", @"678", @"VU",
            @"681", @"WF", @"967", @"YE", @"260", @"ZM", @"263", @"ZW",
            @"591", @"BO", @"673", @"BN", @"61", @"CC", @"243", @"CD",
            @"225", @"CI", @"500", @"FK", @"44", @"GG", @"379", @"VA",
            @"852", @"HK", @"98", @"IR", @"44", @"IM", @"44", @"JE",
            @"850", @"KP", @"82", @"KR", @"856", @"LA", @"218", @"LY",
            @"853", @"MO", @"389", @"MK", @"691", @"FM", @"373", @"MD",
            @"258", @"MZ", @"970", @"PS", @"872", @"PN", @"262", @"RE",
            @"7", @"RU", @"590", @"BL", @"290", @"SH", @"1", @"KN",
            @"1", @"LC", @"590", @"MF", @"508", @"PM", @"1", @"VC",
            @"239", @"ST", @"252", @"SO", @"47", @"SJ", @"963", @"SY",
            @"886", @"TW", @"255", @"TZ", @"670", @"TL", @"58", @"VE",
            @"84", @"VN", @"1", @"VG", @"1", @"VI", nil];
}

-(NSMutableArray*)getSubCategoryDetails:(NSString*)ModuleId
{
    @try {
        ;
        
     NSMutableArray   *getSubCategory  = [[Web_Services GetSharedInstance]GetSubCategories:@"GetTypesbyCategoryId" CatgoryID:ModuleId];
        
        return getSubCategory;
    } @catch (NSException *exception) {
        // [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
    
}
-(NSDictionary*)GetCounts:(NSString*)Lat  Long:(NSString*)longi
{
     mPref = [NSUserDefaults standardUserDefaults];
    NSString *userRegID = [mPref valueForKey:USERREGISTERID];
    
    NSString *location= [NSString stringWithFormat:@"%@,%@",Lat,longi];
    NSDictionary *dic = @{@"UserRegisterId":userRegID,
                          @"Location":location,
                          @"radius":@"1000"
                          };
    NSDictionary *response = [[Web_Services GetSharedInstance] GetCounts:dic];
    return response;
}



@end
