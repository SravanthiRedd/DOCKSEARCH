//
//  PopUpViewController.h
//  NMPopUpView
//
//  Created by Nikos Maounis on 9/12/13.
//  Copyright (c) 2013 Nikos Maounis. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>
#import "AppDelegate.h"

@interface SMSController : UIViewController

@property (weak, nonatomic) IBOutlet UIView *popUpView;
@property (weak, nonatomic) IBOutlet UIImageView *logoImg;
@property (weak, nonatomic) IBOutlet UILabel *messageLabel;


@property (weak, nonatomic) IBOutlet UITextView *messageView;

@property (nonatomic ,strong) IBOutlet UILabel *StoreName;
@property (nonatomic ,strong) IBOutlet UILabel *Contactname;
@property (nonatomic ,strong)  NSArray *CustomerNumbers;
@property(nonatomic,strong) NSString *OppName;
@property(nonatomic,strong) NSString *OppDescription;
@property(nonatomic,strong) NSArray *customernamesArray;
@property (nonatomic ,strong)  NSString *StoreNameText;


- (void)showInView:(UIView *)aView withImage:(UIImage *)image withMessage:(NSString *)message animated:(BOOL)animated;

@end
