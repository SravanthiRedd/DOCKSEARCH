//
//  SMSPopUp.h
//  RPRT
//
//  Created by sravanthi Gumma on 20/10/1938 Saka.
//  Copyright © 1938 Saka DevpointSolutions. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SMSPopUp : UIViewController
@property (weak, nonatomic) IBOutlet UIView *popUpView;
@property (weak, nonatomic) IBOutlet UITextView *messageView;

@property (nonatomic ,strong) IBOutlet UILabel *StoreName;
@property (nonatomic ,strong) IBOutlet UILabel *Contactname;
@property (nonatomic ,strong)  NSArray *CustomerNumbers;
@property(nonatomic,strong) NSString *OppName;
@property(nonatomic,strong) NSString *OppDescription;
@property(nonatomic,strong) NSArray *customernamesArray;
@property (nonatomic ,strong)  NSString *StoreNameText;
- (void)showInView:(UIView *)aView withImage:(UIImage *)image withMessage:(NSString *)message animated:(BOOL)animated;

@end
