//
//  SMSPopUp.m
//  RPRT
//
//  Created by sravanthi Gumma on 20/10/1938 Saka.
//  Copyright © 1938 Saka DevpointSolutions. All rights reserved.
//

#import "SMSPopUp.h"
#import "AppDelegate.h"
#import <Messages/Messages.h>
#import <MessageUI/MessageUI.h>
@interface SMSPopUp ()<UITextViewDelegate,MFMessageComposeViewControllerDelegate>
{
    Web_Services *mWebService;
    NSString *StoreNames;
    NSArray *phonenumbersarra;
    NSString *MessageBody;
    NSMutableString *textViewtext;
}
@end

@implementation SMSPopUp

- (void)viewDidLoad {
    [super viewDidLoad];
    mWebService = [Web_Services GetSharedInstance];
    StoreNames =@"";
    self.view.backgroundColor=[[UIColor blackColor] colorWithAlphaComponent:.6];
    self.popUpView.layer.cornerRadius = 5;
    self.popUpView.layer.shadowOpacity = 0.8;
    self.popUpView.layer.shadowOffset = CGSizeMake(0.0f, 0.0f);
    
    self.messageView.layer.borderWidth = 1.0f;
    self.messageView.layer.borderColor = [[UIColor grayColor] CGColor];
    self.messageView.text =_OppName;
    self.StoreName.text = _StoreNameText;
    
    NSUserDefaults *mPref = [NSUserDefaults standardUserDefaults];
    
    
   
    
    
        NSData  *VendorData =    [mPref valueForKey:@"SaveRegisterDetails"];
        NSDictionary *myDictionary =   (NSDictionary*) [NSKeyedUnarchiver unarchiveObjectWithData:VendorData];
        NSLog(@"%@",myDictionary);
        
        
        
        // NSString *regName ;
        if ([[mPref valueForKey:LOGINTYPE] isEqualToString:@"Business"]) {
            StoreNames=[myDictionary valueForKey:@"RegUserName"];
        }
        else if ([[mPref valueForKey:LOGINTYPE] isEqualToString:@"Individual"])
            StoreNames=[[myDictionary  valueForKey:@"BusinessDeatils"] valueForKey:@"ContactPerson"];
    
    
    
    MessageBody =[NSString stringWithFormat:@"Hi,\n%@, \n\n Thanks,\n %@ \n Right Place Right Time",self.messageView.text,StoreNames];
    int characterCount = [MessageBody length];
    
    
    NSLog(@"%lu",(unsigned long)characterCount);
    if(characterCount>160)
    {
        NSMutableString *bosyString;//=
        textViewtext =[self.messageView.text mutableCopy];
        for (int i=characterCount; i>=160; i--) {
            
            bosyString =  [self TrimString:textViewtext];
            NSUInteger characterCount = [bosyString length];
            NSLog(@"%lu",(unsigned long)characterCount);
        }
        MessageBody = bosyString;
        self.messageView.text = textViewtext;
    }

    
    
    
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)showAnimate
{
    self.view.transform = CGAffineTransformMakeScale(1.3, 1.3);
    self.view.alpha = 0;
    [UIView animateWithDuration:.25 animations:^{
        self.view.alpha = 1;
        self.view.transform = CGAffineTransformMakeScale(1, 1);
    }];
    
}


- (void)removeAnimate
{
    [UIView animateWithDuration:.25 animations:^{
        self.view.transform = CGAffineTransformMakeScale(1.3, 1.3);
        self.view.alpha = 0.0;
    } completion:^(BOOL finished) {
        if (finished) {
            [self.view removeFromSuperview];
        }
    }];
    
    //    Home *mHome = [[Home alloc]initWithNibName:HOMEDASHBOARD bundle:nil];
    //    [self presentViewController:mHome animated:YES completion:nil];
}

//- (void)showInView:(UIView *)aView withImage:(UIImage *)image withMessage:(NSString *)message animated:(BOOL)animated
//{
//    [aView addSubview:self.view];
//   // self.logoImg.image = image;
//    //self.messageLabel.text = message;
//    if (animated) {
//        [self showAnimate];
//    }
//}


-(IBAction)cancelBtn:(id)sender
{
    [self removeAnimate];
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"Right Place Right Time"
                                                                   message:@"Your offer is posted successfully!"
                                                            preferredStyle:UIAlertControllerStyleAlert];
    
    UIAlertAction* defaultAction = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault
                                                          handler:^(UIAlertAction * action) {
                                                              
                                                              //  [mPref setObject:remainingTime forKey:@"TimeSlot"];
                                                              Retailer_Offer * mOpportunity_list = [[ Retailer_Offer alloc] initWithNibName:RETAILER bundle:nil];
                                                              [self presentViewController:mOpportunity_list animated:YES completion:nil];
                                                              
                                                          }];
    
    [alert addAction:defaultAction];
    
    [self presentViewController:alert animated:YES completion:nil];

}

-(IBAction)sendbtn:(id)sender
{
    
    [self removeAnimate];
    MFMessageComposeViewController *controller = [[MFMessageComposeViewController alloc] init];
   if([MFMessageComposeViewController canSendText])
    {
            
        controller.body = MessageBody;
        controller.recipients=self.CustomerNumbers;
        controller.messageComposeDelegate = self;
       [self presentViewController:controller animated:YES completion:nil];
    }
    
}

- (void)messageComposeViewController:(MFMessageComposeViewController *)controller didFinishWithResult:(MessageComposeResult)result
{
    
    switch (result)
    {
        case MessageComposeResultSent:
            
            
            break;
        case MessageComposeResultFailed:
            
            
            
            break;
        case MessageComposeResultCancelled:
            
            
            
            break;
            
        default:
            
            break;
    }
    
    [self dismissViewControllerAnimated:YES completion:nil];
    
    
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"Right Place Right Time"
                                                                   message:@"Your offer is posted successfully!"
                                                            preferredStyle:UIAlertControllerStyleAlert];
    
    UIAlertAction* defaultAction = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault
                                                          handler:^(UIAlertAction * action) {
                                                              
                                                              //  [mPref setObject:remainingTime forKey:@"TimeSlot"];
                                                              Retailer_Offer * mOpportunity_list = [[ Retailer_Offer alloc] initWithNibName:RETAILER bundle:nil];
                                                              [self presentViewController:mOpportunity_list animated:YES completion:nil];
                                                              
                                                          }];
    
    [alert addAction:defaultAction];
    
    [self presentViewController:alert animated:YES completion:nil];
    
}


- (void)textViewDidEndEditing:(UITextView *)textView{
    
    [self.messageView resignFirstResponder];
}

- (BOOL)textView:(UITextView *)txtView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text {
    if( [text rangeOfCharacterFromSet:[NSCharacterSet newlineCharacterSet]].location == NSNotFound ) {
        MessageBody =[NSString stringWithFormat:@"Hi,\n%@, \n\n Thanks,\n %@ \n Right Place Right Time",self.messageView.text,StoreNames];
        NSUInteger characterCount = [MessageBody length];
        if (characterCount>160) {
            return NO;
        }
        
        
        return YES;
    }
    
    [txtView resignFirstResponder];
    return NO;
}

- (void)showInView:(UIView *)aView withImage:(UIImage *)image withMessage:(NSString *)message animated:(BOOL)animated
{
    
    
    [aView addSubview:self.view];
    //self.logoImg.image = image;
    //self.messageLabel.text = message;
    if (animated) {
        [self showAnimate];
    }
}





-(NSMutableString*)TrimString:(NSMutableString*)TrimString
{
    
    NSString *newString =[TrimString substringToIndex:[TrimString length]-1];
    textViewtext = [newString mutableCopy];
    
 NSMutableString   *trimString = [[NSString stringWithFormat:@"Hi,\n%@, \n\n Thanks,\n %@ \n Right Place Right Time",newString,StoreNames] mutableCopy];
    
    
//      newString= [NSString stringWithFormat:@"Hi \"%@\",\n \"%@\", \n\"%@\"\n \n Thanks,\n%@\nRight Place Right Time.",self.Contactname.text,self.Contactname.text,self.Contactname.text,self.Contactname.text];
    
    return trimString;
}



@end
