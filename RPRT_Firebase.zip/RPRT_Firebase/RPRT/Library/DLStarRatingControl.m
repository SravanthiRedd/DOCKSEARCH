/*

    DLStarRating
 //  RPRT
 //
 //  Created by sravanthi Gumma on 08/01/16.
 //  Copyright © 2016 DevpointSolutions. All rights reserved.

 */

#import "DLStarRatingControl.h"
#import "DLStarView.h"
#import "UIView+Subviews.h"
#import "TimeCalculator.h"


@implementation DLStarRatingControl

@synthesize star, highlightedStar, delegate, isFractionalRatingEnabled;

#pragma mark -
#pragma mark Initialization

- (void)setupView {
	self.clipsToBounds = YES;
	currentIdx = -1;
    
    CGSize rect = CGSizeMake(20, 20);
    
    //emptystars.png
    //fullstars.png
    
    
	star =[[TimeCalculator alloc]image:[UIImage imageNamed:@"empty.png"] scaledToSize:rect];
	highlightedStar =[[TimeCalculator alloc] image:[UIImage imageNamed:@"star.png"] scaledToSize:rect]; //[UIImage imageNamed:@"fullstar.png"] ;

	for (int i=0; i<numberOfStars; i++) {
		DLStarView *v = [[DLStarView alloc] initWithDefault:self.star highlighted:self.highlightedStar position:i allowFractions:isFractionalRatingEnabled];
		[self addSubview:v];
			}
}

- (id)initWithCoder:(NSCoder *)aDecoder {
    self = [super initWithCoder:aDecoder];
    if (self) {
		numberOfStars = kDefaultNumberOfStars;
        if (isFractionalRatingEnabled)
            numberOfStars *=kNumberOfFractions;
		[self setupView];
    }
    return self;
}

- (id)initWithFrame:(CGRect)frame {
	self = [super initWithFrame:frame];
	if (self) {
		numberOfStars = kDefaultNumberOfStars;
        if (isFractionalRatingEnabled)
            numberOfStars *=kNumberOfFractions;
        [self setupView];

	}
	return self;
}

- (id)initWithFrame:(CGRect)frame andStars:(NSUInteger)_numberOfStars isFractional:(BOOL)isFract{
	self = [super initWithFrame:frame];
	if (self) {
        isFractionalRatingEnabled = isFract;
		numberOfStars = _numberOfStars;
        if (isFractionalRatingEnabled)
            numberOfStars *=kNumberOfFractions;
		[self setupView];
	}
	return self;
}

- (void)layoutSubviews {
	for (int i=0; i < numberOfStars; i++) {
		[(DLStarView*)[self subViewWithTag:i] centerIn:CGRectMake(0, 40, 125 , 38) with:numberOfStars];
	}
}

#pragma mark -
#pragma mark Customization

- (void)setStar:(UIImage*)defaultStarImage highlightedStar:(UIImage*)highlightedStarImage {
  for(NSInteger i = 0; i < numberOfStars; i++){
    [self setStar:defaultStarImage highlightedStar:highlightedStarImage atIndex:i];
  }
}

- (void)setStar:(UIImage*)defaultStarImage highlightedStar:(UIImage*)highlightedStarImage atIndex:(int)index {
    DLStarView *selectedStar = (DLStarView*)[self subViewWithTag:index];
    
    // check if star exists
    if (!selectedStar) return;
    
    // check images for nil else use default stars
    defaultStarImage = (defaultStarImage) ? defaultStarImage : star;
    highlightedStarImage = (highlightedStarImage) ? highlightedStarImage : highlightedStar;
    
    [selectedStar setStarImage:defaultStarImage highlightedStarImage:highlightedStarImage];
}

#pragma mark -
#pragma mark Touch Handling

- (UIButton*)starForPoint:(CGPoint)point {
	for (int i=0; i < numberOfStars; i++) {
		if (CGRectContainsPoint([self subViewWithTag:i].frame, point)) {
			return (UIButton*)[self subViewWithTag:i];
		}
	}
	return nil;
}

- (void)disableStarsDownToExclusive:(int)idx {
	for (int i=numberOfStars; i > idx; --i) {
		UIButton *b = (UIButton*)[self subViewWithTag:i];
		b.highlighted = NO;
	}
}

- (void)disableStarsDownTo:(int)idx {
	for (int i=numberOfStars; i >= idx; --i) {
		UIButton *b = (UIButton*)[self subViewWithTag:i];
		b.highlighted = NO;
	}
}


- (void)enableStarsUpTo:(int)idx {
	for (int i=0; i <= idx; i++) {
		UIButton *b = (UIButton*)[self subViewWithTag:i];
		b.highlighted = YES;
	}
}



#pragma mark -
#pragma mark Rating Property

- (void)setRating:(float)_rating {
    if (isFractionalRatingEnabled) {
        _rating *=kNumberOfFractions;
    }
	[self disableStarsDownTo:0];
	currentIdx = (int)_rating-1;
	[self enableStarsUpTo:currentIdx];
}

- (float)rating {
    if (isFractionalRatingEnabled) {
        return (float)(currentIdx+1)/kNumberOfFractions;
    }
	return (NSUInteger)currentIdx+1;
}


#pragma mark -
#pragma mark Memory Management

- (void)dealloc {
	self.star = nil;
	self.highlightedStar = nil;
	self.delegate = nil;
	}

@end
