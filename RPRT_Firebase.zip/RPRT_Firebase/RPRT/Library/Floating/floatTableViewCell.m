//
//  floatTableViewCell.m
//  RPRT
//
//  Created by sravanthi Gumma on 08/01/16.
//  Copyright © 2016 DevpointSolutions. All rights reserved.
//

#import "floatTableViewCell.h"

@implementation floatTableViewCell
@synthesize imgView, title,overlay;

- (void)awakeFromNib
{
    // Initialization code
    overlay = [UIView new];
    overlay.backgroundColor = [UIColor colorWithWhite:0.8 alpha:0.6];
    [title addSubview:overlay];
    imgView.layer.cornerRadius = 22.0;
    imgView.layer.masksToBounds = YES;
    imgView.backgroundColor = [UIColor colorWithRed:33.0/255.0 green:150.0/255.0 blue:243.0/255.0 alpha:1];
//    self.title.backgroundColor = [UIColor colorWithWhite:0.8 alpha:0.8];
    title.frame = CGRectMake(title.frame.origin.x, title.frame.origin.y, title.frame.size.width+50, title.frame.size.height);
    title.layer.cornerRadius = 5.f;
    self.title.layer.masksToBounds = YES;
    self.selectionStyle = UITableViewCellSelectionStyleNone;
    self.backgroundColor = [UIColor clearColor];
    self.contentView.transform = CGAffineTransformMakeRotation(-M_PI);
}


-(void)setTitle:(NSString*)txt andImage:(UIImage*)img
{
//    self.title.text = txt;
//    
//    CGFloat width = ceil([self.title.text sizeWithAttributes:@{NSFontAttributeName: self.title.font}].width);
//    
//    CGFloat height = ceil([self.title.text sizeWithAttributes:@{NSFontAttributeName: self.title.font}].height);
//    
//    overlay.frame = CGRectMake(CGRectGetMaxX(self.title.frame), CGRectGetMaxY(self.title.frame), width, height);
//    
//    
//    
//    self.imgView.image = img;
    
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
