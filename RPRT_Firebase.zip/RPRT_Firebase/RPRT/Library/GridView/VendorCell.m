//
//  VendorCell.m
//  RPRT
//
//  Created by sravanthi Gumma on 22/02/16.
//  Copyright © 2016 DevpointSolutions. All rights reserved.
//

#import "VendorCell.h"

@implementation VendorCell
static CGFloat radius = 2;

@synthesize opportunity = opprtunity;
@synthesize description = description;
@synthesize view1 = view1;
@synthesize view2 = view2;
@synthesize Avialable = Avialable;

@synthesize resrveCNT =resrveCNT;

@synthesize delivery = delivery;
@synthesize categoryType = categoryType;
@synthesize actualprice = actualprice;
@synthesize price = price;

@synthesize blockBtn= blockBtn;
@synthesize deliveryLbl= deliveryLbl;

@synthesize PriceLabel = PriceLabel;
@synthesize DeliveryLabel = DeliveryLabel;


- (void)awakeFromNib {
    // Initialization code
    [super awakeFromNib];
    //    view1.layer.borderColor = [[UIColor lightGrayColor]CGColor];
    //    view1.layer.borderWidth =1;
    //    view2.layer.borderColor = [[UIColor lightGrayColor]CGColor];
    //    view2.layer.borderWidth =1;
    
}


-(void)layoutSubviews{
    self.layer.cornerRadius = 45/2;
    UIBezierPath *shadowPath = [UIBezierPath
                                bezierPathWithRoundedRect: self.bounds
                                cornerRadius: radius];
    
    
    self.layer.masksToBounds = false;
    self.layer.shadowColor = [UIColor blackColor].CGColor;
    self.layer.shadowOffset = CGSizeMake(0, 1);
    self.layer.shadowOpacity = 0.2;
    self.layer.shadowPath = shadowPath.CGPath;
    
    self.view1.layer.cornerRadius=5;
    
    self.OpportunityImage.layer.cornerRadius = self.OpportunityImage.frame.size.width/2;
    self.OpportunityImage.layer.masksToBounds = YES;
}
-(id)initWithCoder:(NSCoder *)aDecoder{
    return [super initWithCoder:aDecoder];
}


- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
    
    // Configure the view for the selected state
}

-(void)viewDidLoad
{
    NSLog(@"sdfgsdf");
}

@end
