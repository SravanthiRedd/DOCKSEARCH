//
//  FTWCache.h
//  RPRT
//
//  Created by sravanthi Gumma on 08/01/16.
//  Copyright © 2016 DevpointSolutions. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface FTWCache : NSObject

+ (void) resetCache;

+ (void) setObject:(NSData*)data forKey:(NSString*)key;
+ (id) objectForKey:(NSString*)key;

@end
