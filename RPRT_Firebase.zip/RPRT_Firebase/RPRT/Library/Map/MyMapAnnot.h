//
//  MyMapAnnot.h
//  GooglePlacesAPIDemo
//
//  Created by sravanthi Gumma on 07/04/16.
//  Copyright © 2016 DevpointSolutions. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MapKit/MapKit.h"

@interface MyMapAnnot : NSObject <MKAnnotation> {
   
    NSString *_name;
    NSString *_address;

    NSString *pinTitle;
    CLLocationCoordinate2D _theCords;
    
}

-(id)initWithName:(NSString*)_placeName andCoordinates:(CLLocationCoordinate2D)_coordinates;
@property (copy) NSString *name;
@property (copy) NSString *address;
- (id)initWithName:(NSString*)name address:(NSString*)address coordinate:(CLLocationCoordinate2D)coordinate;

@end
