//
//  MyMapAnnot.m
//  GooglePlacesAPIDemo
//
//  Created by sravanthi Gumma on 07/04/16.
//  Copyright © 2016 DevpointSolutions. All rights reserved.
//

#import "MyMapAnnot.h"


@implementation MyMapAnnot

@synthesize name = _name;
@synthesize address = _address;
@synthesize coordinate = _coordinate;

-(id)initWithName:(NSString*)_placeName andCoordinates:(CLLocationCoordinate2D)_coordinates
{
        
    pinTitle = _placeName;
    _theCords = _coordinates;
    
    return self;
    
}


-(NSString*)title
{ if ([_name isKindOfClass:[NSNull class]])
    return @"Unknown charge";
else
    return _name;

    
    return pinTitle;
}

-(CLLocationCoordinate2D)coordinate
{
    
    CLLocationCoordinate2D cords = {_theCords.latitude,_theCords.longitude};
    return cords;
    
}
- (id)initWithName:(NSString*)name address:(NSString*)address coordinate:(CLLocationCoordinate2D)coordinate
{
    if ((self = [super init])) {
        _name = [name copy];
        _address = [address copy];
        _coordinate = coordinate;
        
    }
    return self;
}


- (NSString *)subtitle {
    return _address;
}




@end
