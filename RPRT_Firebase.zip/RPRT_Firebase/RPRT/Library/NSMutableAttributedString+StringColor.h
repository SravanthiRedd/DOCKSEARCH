//
//  NSMutableAttributedString+StringColor.h
//  RPRT
//
//  Created by sravanthi Gumma on 13/07/16.
//  Copyright © 2016 DevpointSolutions. All rights reserved.
//

#import <Foundation/Foundation.h>

#import <UIKit/UIKit.h>

@interface NSMutableAttributedString (StringColor)
-(void)setColorForText:(NSString*) textToFind withColor:(UIColor*) color;
@end
