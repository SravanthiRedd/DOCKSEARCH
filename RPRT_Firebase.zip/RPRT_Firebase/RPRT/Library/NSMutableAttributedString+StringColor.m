//
//  NSMutableAttributedString+StringColor.m
//  RPRT
//
//  Created by sravanthi Gumma on 13/07/16.
//  Copyright © 2016 DevpointSolutions. All rights reserved.
//

#import "NSMutableAttributedString+StringColor.h"

@implementation NSMutableAttributedString (StringColor)
-(void)setColorForText:(NSString*) textToFind withColor:(UIColor*) color
{
    NSRange range = [self.mutableString rangeOfString:textToFind options:NSCaseInsensitiveSearch];
    
    if (range.location != NSNotFound) {
        [self addAttribute:NSForegroundColorAttributeName value:color range:range];
    }
}
@end
