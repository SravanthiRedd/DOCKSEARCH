//
//  PopUpViewController.h
//  NMPopUpView
//
//  Created by Nikos Maounis on 9/12/13.
//  Copyright (c) 2013 Nikos Maounis. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>
#import "AppDelegate.h"

@interface PopUpViewController : UIViewController<UITextFieldDelegate>

@property (weak, nonatomic) IBOutlet UIView *popUpView;

@property (weak, nonatomic) IBOutlet UITextField *OtpUpView;
@property (weak, nonatomic) IBOutlet UIImageView *otpTick;
@property (weak, nonatomic) IBOutlet UIImageView *logoImg;
@property (weak, nonatomic) IBOutlet UITextField *emailID;
@property (weak,nonatomic) IBOutlet UITextField *userName;
@property (weak,nonatomic) IBOutlet UITextField *mobileNumber;
@property (weak,nonatomic) IBOutlet UIButton *submitBtn;
@property (weak,nonatomic) IBOutlet UIView *OTPVIEW;

- (void)showInView:(UIView *)aView withImage:(UIImage *)image withMessage:(NSString *)message animated:(BOOL)animated;

@end
