//
//  PopUpViewController.m
//  NMPopUpView
//
//  Created by Nikos Maounis on 9/12/13.
//  Copyright (c) 2013 Nikos Maounis. All rights reserved.
//

#import "PopUpViewController.h"
#import "Web_Services.h"
#import "TimeCalculator.h"
#import "CustomIOSAlertView.h"
#import "Preferences.h"
@interface PopUpViewController ()<CustomIOSAlertViewDelegate>
{
    Web_Services *mWebservice;
    TimeCalculator *mTimeCalculator;
    NSString *COUNTRYCODE;
    CustomIOSAlertView* OtpAlert;
    UITextField *OtptextField;
    NSString *oneTimePassword;
    NSUserDefaults *mPref;
    Preferences *mPreference;
   // UITextField *textField;
     UIActivityIndicatorView *spinner;
}
@end

@implementation PopUpViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    
    mWebservice  =[Web_Services GetSharedInstance];
    mTimeCalculator= [TimeCalculator GetSharedInstance];
    mPref = [NSUserDefaults standardUserDefaults];
    mPreference = [Preferences GetSharedInstance];
    
    NSString *countryIdentifier = [[NSLocale currentLocale] objectForKey: NSLocaleCountryCode];
    NSLog(@"%@",[NSString stringWithFormat:@"+%@",[[mTimeCalculator getCountryCodeDictionary] objectForKey:countryIdentifier]]);
    COUNTRYCODE =[NSString stringWithFormat:@"%@",[[mTimeCalculator getCountryCodeDictionary] objectForKey:countryIdentifier]];

    //self.mobileNumber.text =COUNTRYCODE;
    
    
    self.view.backgroundColor=[[UIColor blackColor] colorWithAlphaComponent:.6];
    self.popUpView.layer.cornerRadius = 5;
    self.popUpView.layer.shadowOpacity = 0.8;
    self.popUpView.layer.shadowOffset = CGSizeMake(0.0f, 0.0f);
    //self.popUpView.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"bgerror.png"]];
    self.otpTick.hidden= YES;
    self.OtpUpView.userInteractionEnabled= false;
    self.OTPVIEW.hidden=YES;
    
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

- (void)showAnimate
{
    self.view.transform = CGAffineTransformMakeScale(1.3, 1.3);
    self.view.alpha = 0;
    [UIView animateWithDuration:.25 animations:^{
        self.view.alpha = 1;
        self.view.transform = CGAffineTransformMakeScale(1, 1);
    }];
    
}

- (IBAction)textFieldDidBeginEditing:(id)textField {
    @try {
        
        
        [self animateTextField:textField up:YES];
    }
    @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    }
    @finally {
        
    }
    
}

-(IBAction)hidekayBoard:(id)sender
{
   if([self.userName isFirstResponder])
   {
       [self.userName resignFirstResponder];
        [self animateTextField:self.userName up:NO];
   }
    else if ([self.mobileNumber isFirstResponder])
    {
        [self.mobileNumber resignFirstResponder];
         [self animateTextField:self.mobileNumber up:NO];
    }
    else if([self.OtpUpView resignFirstResponder])
    {
        if ([self.OtpUpView.text isEqualToString:oneTimePassword]) {
              [self animateTextField:self.mobileNumber up:NO];
            self.otpTick.hidden= NO;
            
        }
        else
        {
             [self animateTextField:self.mobileNumber up:NO];
              [self showAlertPop:@"invalid OTP" expObj:nil];
        }
    }
}

- (IBAction)textFieldDidEndEditing1:(id)textField {
    @try {
        
        [self animateTextField:textField up:NO];
    }
    @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    }
    @finally {
        
    }
}

-(BOOL)textFiledValidation
{
    if ([self.userName.text isEqualToString:@""]) {
         [self showAlertPop:@"Enter Name" expObj:nil];
        return NO;
    }
    if ([self.mobileNumber.text isEqualToString:@""]) {
        [self showAlertPop:@"please enter MobileNumber" expObj:nil];
        return NO;
    }
    
    else  if ([self.mobileNumber.text length] < 10 ) {
        [self.mobileNumber resignFirstResponder];
        
        [self showAlertPop:@"Invalid Phone OR enter 10 no. only." expObj:nil];
        return NO;
    }
    else if([self validMobileNumber:self.mobileNumber.text])
    {
        [self.mobileNumber resignFirstResponder];
        
        [self showAlertPop:@"Invalid Phone number" expObj:nil];
        return NO;
    }
    else  if (![self.emailID.text isEqualToString:@""]) {
         if (![self validateEmail:self.emailID.text])
        {
            [self showAlertPop:@"Enter valid emailid" expObj:nil];
            return NO;
        }
    }
  
    return YES;
}

- (BOOL)validMobileNumber:(NSString *)mobilenumber {
    
    @try {
        
        NSString *phoneRegex = @"^((\\+)|(00))[0-9]{6,14}$";
        NSPredicate *phoneTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", phoneRegex];
        
        return [phoneTest evaluateWithObject:mobilenumber];
        
        
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    }
}

- (BOOL) textField: (UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString: (NSString *)string {
    if (textField== self.mobileNumber) {
        NSNumberFormatter * nf = [[NSNumberFormatter alloc] init];
        [nf setNumberStyle:NSNumberFormatterNoStyle];
        
        NSString * newString = [NSString stringWithFormat:@"%@%@",textField.text,string];
        NSNumber * number = [nf numberFromString:newString];
        
        if (number)
            return YES;
        else
            return NO;
    }
    
    return YES;
}


-(IBAction)saveBtn:(id)sender
{
  
    @try {
     
    spinner = [[UIActivityIndicatorView alloc]
               initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
    spinner.frame = CGRectMake(0, 0, 320, 560); // CGPointMake(160, 240);
    spinner.color = [UIColor blueColor];
    spinner.backgroundColor = [UIColor lightTextColor];
    spinner.transform = CGAffineTransformMakeScale(2, 2);
    // spinner.hidesWhenStopped = YES;
    [self.view addSubview:spinner];
    spinner.transform = CGAffineTransformMakeScale(2, 2);
    
    [spinner startAnimating];
    
    // how we stop refresh from freezing the main UI thread
    
    dispatch_async(
                   dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^{
                       dispatch_async(dispatch_get_main_queue(), ^{
                           
                           
                           [spinner startAnimating];
                       });
                       dispatch_async(dispatch_get_main_queue(), ^{
                      
    
    if ([self textFiledValidation]) {
        if(oneTimePassword==nil)
        {
        NSString *mobileNumber = self.mobileNumber.text;
        NSDictionary *getOTPResponce= [mWebservice SendOTP:COUNTRYCODE mobileNumber:mobileNumber];
    NSDictionary *response = [getOTPResponce valueForKey:@"response"];
    if ([[response valueForKey:@"code"] isEqualToString:@"OTP_SENT_SUCCESSFULLY"]) {
        oneTimePassword =[NSString stringWithFormat:@"%@",[response valueForKey:@"oneTimePassword"]];
        NSLog(@"OTP is:%@",oneTimePassword);
        self.OtpUpView.userInteractionEnabled= true;
        self.OTPVIEW.hidden=NO;
        [self.submitBtn setTitle:@"Submit" forState:UIControlStateNormal];
         [self showAlertPop:@"Your Register mobile number get OTP Number.Please enter OTP" expObj:nil];
    }
        }
        else if(oneTimePassword!=nil && ![self.OtpUpView.text isEqualToString:@""] && [self.OtpUpView.text  isEqualToString:oneTimePassword])
        {
            
             NSString *uniqueIdentifier = [[[UIDevice currentDevice] identifierForVendor] UUIDString];
            
            NSDictionary *locationInput  = @{@"UserRegisterID":@"0",
                                             @"UserID":@"0",
                                             @"UserSelectedCat":@"Individual",
                                             @"PhotoName":@"",
                                             @"LandLine":@"",
                                              @"ContactPerson":@"",
                                             @"Password":@"",
                                             @"Time":@"60",
                                             @"PhoneNo":self.mobileNumber.text,
                                             @"RegUserName":self.userName.text,
                                             @"RegEmail":self.emailID.text,
                                             @"UserType":@"1",
                                             @"DeviceOS":[[UIDevice currentDevice] model],
                                             @"OsVersion":[[UIDevice currentDevice] systemVersion],
                                             @"LoginType":@"OTP",
                                             @"DeviceId" :uniqueIdentifier
                                             };

            NSLog(@"%@",locationInput);
            
            NSDictionary *storeResponse = [mWebservice SaveRegister:locationInput];
          //  NSDictionary *loginObj;
            
            NSMutableArray *arryResponse =storeResponse;
            
            NSString *BusinessRegID; NSString *IndividualRegID;
                NSMutableDictionary *registerDatavia = [[NSMutableDictionary alloc]init];
            
            if ([arryResponse count]==2) {
                
                
                BusinessRegID = [[arryResponse objectAtIndex:1] valueForKey:@"UserRegisterID"];
                IndividualRegID =[[arryResponse objectAtIndex:0] valueForKey:@"UserRegisterID"];

              
                    [mPref setValue:@"Business" forKey:LOGINTYPE];
                    [mPref setValue:BusinessRegID forKey:USERREGISTERID];
                    [registerDatavia setValue:BusinessRegID forKey:@"UserRegisterID"];
                
                NSDictionary *BusinessRecoed=@{@"StoreDescription":[[arryResponse objectAtIndex:1] valueForKey:@"StoreDescription"],
                                               @"ContactPerson":[[arryResponse objectAtIndex:1] valueForKey:@"ContactPerson"],
                                               @"BranchName":[[arryResponse objectAtIndex:1] valueForKey:@"BranchName"],
                                               @"PhotoName":[[arryResponse objectAtIndex:1] valueForKey:@"PhotoName"]
                                               };
                NSDictionary *IndividualRecoed=@{@"StoreDescription":[[arryResponse objectAtIndex:1] valueForKey:@"StoreDescription"],
                                               @"ContactPerson":[[arryResponse objectAtIndex:1] valueForKey:@"ContactPerson"],
                                               @"BranchName":[[arryResponse objectAtIndex:1] valueForKey:@"BranchName"],
                                               @"PhotoName":[[arryResponse objectAtIndex:0] valueForKey:@"PhotoName"]
                                               };
                
                
                [registerDatavia setValue:BusinessRecoed forKey:@"BusinessDeatils"];
                [registerDatavia setValue:IndividualRecoed forKey:@"IndividualDeatils"];
                [registerDatavia setValue:[[arryResponse objectAtIndex:1] valueForKey:@"DefaultRadius"] forKey:@"DefaultRadius"];
                [registerDatavia setValue:[[arryResponse objectAtIndex:1] valueForKey:@"PhotoName"] forKey:@"PhotoName"];
                [registerDatavia setValue:[[arryResponse objectAtIndex:1] valueForKey:@"DefaultAddress"] forKey:@"DefaultAddress"];
                [registerDatavia setValue:[[arryResponse objectAtIndex:1] valueForKey:@"RegUserName"] forKey:@"RegUserName"];
                [registerDatavia setValue:[[arryResponse objectAtIndex:1] valueForKey:@"ContactPerson"] forKey:@"ContactPerson"];
                [registerDatavia setValue:[[arryResponse objectAtIndex:1] valueForKey:@"BranchName"] forKey:@"BranchName"];
                [registerDatavia setValue:[[arryResponse objectAtIndex:1] valueForKey:@"StoreDescription"] forKey:@"StoreDescription"];
                [registerDatavia setValue:[[arryResponse objectAtIndex:1] valueForKey:@"LoggedUserType"] forKey:@"LoggedUserType"];
                [registerDatavia setValue:[[arryResponse objectAtIndex:1] valueForKey:@"ContactPerson"] forKey:@"ContactPerson"];

                [registerDatavia setValue:[[arryResponse objectAtIndex:1] valueForKey:@"LoginType"] forKey:@"LoginType"];
                [registerDatavia setValue:BusinessRegID forKey:USERREGISTERID];
                [registerDatavia setValue:[[arryResponse objectAtIndex:1] valueForKey:@"DefaultRadius"] forKey:@"DefaultRadius"];
                [registerDatavia setValue:BusinessRegID forKey:@"BusinessRegisterID"];
                [registerDatavia setValue:IndividualRegID forKey:@"IndividualRegisterID"];
                
                [mPreference SaveRegisterDeatils:registerDatavia];
                
                // [mPref setObject:registerDatavia forKey:@"LoginType"];
                
                Home *mHome = [[Home alloc]initWithNibName:HOMEDASHBOARD bundle:nil];
                [self presentViewController:mHome animated:YES completion:nil];

                
                
                          }
            else
            {
                
                       BusinessRegID = @"";
                       IndividualRegID =[[arryResponse objectAtIndex:0] valueForKey:@"UserRegisterID"];
                
                    [mPref setValue:@"Individual" forKey:LOGINTYPE];
                    [mPref setValue:IndividualRegID forKey:USERREGISTERID];
                     [registerDatavia setValue:IndividualRegID forKey:@"UserRegisterID"];
                
                NSDictionary *IndividualRecoed=@{@"StoreDescription":[[arryResponse objectAtIndex:0] valueForKey:@"StoreDescription"],
                                                 @"ContactPerson":[[arryResponse objectAtIndex:0] valueForKey:@"ContactPerson"],
                                                 @"BranchName":[[arryResponse objectAtIndex:0] valueForKey:@"BranchName"],
                                                 @"PhotoName":[[arryResponse objectAtIndex:0] valueForKey:@"PhotoName"]
                                                 };
                
                
                [registerDatavia setValue:nil forKey:@"BusinessDeatils"];
                [registerDatavia setValue:IndividualRecoed forKey:@"IndividualDeatils"];
                
                
                
                    
                    [registerDatavia setValue:[[arryResponse objectAtIndex:0] valueForKey:@"DefaultRadius"] forKey:@"DefaultRadius"];
                    
                    [registerDatavia setValue:[[arryResponse objectAtIndex:0] valueForKey:@"PhotoName"] forKey:@"PhotoName"];
                    [registerDatavia setValue:[[arryResponse objectAtIndex:0] valueForKey:@"DefaultAddress"] forKey:@"DefaultAddress"];
                    [registerDatavia setValue:[[arryResponse objectAtIndex:0] valueForKey:@"RegUserName"] forKey:@"RegUserName"];
                    [registerDatavia setValue:[[arryResponse objectAtIndex:0] valueForKey:@"ContactPerson"] forKey:@"ContactPerson"];
                    [registerDatavia setValue:[[arryResponse objectAtIndex:0] valueForKey:@"BranchName"] forKey:@"BranchName"];
                    [registerDatavia setValue:[[arryResponse objectAtIndex:0] valueForKey:@"StoreDescription"] forKey:@"StoreDescription"];
                    [registerDatavia setValue:[[arryResponse objectAtIndex:0] valueForKey:@"LoggedUserType"] forKey:@"LoggedUserType"];
                    [registerDatavia setValue:[[arryResponse objectAtIndex:0] valueForKey:@"ContactPerson"] forKey:@"ContactPerson"];
                    [registerDatavia setValue:[[arryResponse objectAtIndex:0] valueForKey:@"LoginType"] forKey:@"LoginType"];
                    [registerDatavia setValue:BusinessRegID forKey:USERREGISTERID];
                    [registerDatavia setValue:[[arryResponse objectAtIndex:0] valueForKey:@"DefaultRadius"] forKey:@"DefaultRadius"];
                    [registerDatavia setValue:BusinessRegID forKey:@"BusinessRegisterID"];
                    [registerDatavia setValue:IndividualRegID forKey:@"IndividualRegisterID"];
                
                [mPreference SaveRegisterDeatils:registerDatavia];
                
                // [mPref setObject:registerDatavia forKey:@"LoginType"];
                
                Home *mHome = [[Home alloc]initWithNibName:HOMEDASHBOARD bundle:nil];
                [self presentViewController:mHome animated:YES completion:nil];
                
            }
            
            
           
            
            
        }
        
        else if(![self.OtpUpView.text  isEqualToString:oneTimePassword])
        {
              [self showAlertPop:@"Invalid OTP" expObj:nil];
        }
        
    }
                           [spinner stopAnimating];
                       });
                   });
    
    } @catch (NSException *exception) {
         [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
}


-(IBAction)askMealterBtn:(id)sender
{
    [self removeAnimate];
}


- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    
    [textField resignFirstResponder];
    
    return YES;
}



-(void)textFieldDidEndEditing:(UITextField *)textField
{
   // NSString *textFiledvalue = textField.text;
    if (textField == self.OtpUpView) {
        if ([self.OtpUpView.text  isEqualToString:oneTimePassword]) {
               [self animateTextField:self.mobileNumber up:NO];
                self.otpTick.hidden= NO;
            [self.submitBtn setTitle:@"Submit" forState:UIControlStateNormal];
            
            
        }
        else
        {
            [self animateTextField:self.mobileNumber up:NO];
            [self showAlertPop:@"invalid OTP" expObj:nil];
        }
    }
    
     if (textField == self.userName) {
    
    if ([self.userName.text isEqualToString:@""]) {
        [self showAlertPop:@"Enter Name" expObj:nil];
      //  return NO;
    }
     }
    
     if (textField == self.mobileNumber) {
    
    if ([self.mobileNumber.text isEqualToString:@""]) {
        [self showAlertPop:@"please enter MobileNumber" expObj:nil];
      //  return NO;
    }
     }
    
       if (textField == self.mobileNumber) {
    
      if ([self.mobileNumber.text length] < 10 ) {
        [self.mobileNumber resignFirstResponder];
        
        [self showAlertPop:@"Invalid Phone OR enter 10 no. only." expObj:nil];
        //return NO;
    }
       }
     if (textField == self.mobileNumber) {
    
     if([self validMobileNumber:self.mobileNumber.text])
    {
        [self.mobileNumber resignFirstResponder];
        
        [self showAlertPop:@"Invalid Phone number" expObj:nil];
        //return NO;
    }
     }
     if (textField == self.emailID) {
    
      if ([self.emailID.text isEqualToString:@""]) {
        [self showAlertPop:@"Enter emailId" expObj:nil];
      }
         else if (![self validateEmail:self.emailID.text])
         {
             [self showAlertPop:@"Enter valid emailid" expObj:nil];
         }
     }
    
     [self animateTextField:self.mobileNumber up:NO];
    
}


- (BOOL)validateEmail:(NSString *)inputText {
    NSString *emailRegex = @"[A-Z0-9a-z][A-Z0-9a-z._%+-]*@[A-Za-z0-9][A-Za-z0-9.-]*\\.[A-Za-z]{2,6}";
    NSPredicate *emailTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", emailRegex];
    NSRange aRange;
    if([emailTest evaluateWithObject:inputText]) {
        aRange = [inputText rangeOfString:@"." options:NSBackwardsSearch range:NSMakeRange(0, [inputText length])];
        int indexOfDot = aRange.location;
        //NSLog(@"aRange.location:%d - %d",aRange.location, indexOfDot);
        if(aRange.location != NSNotFound) {
            NSString *topLevelDomain = [inputText substringFromIndex:indexOfDot];
            topLevelDomain = [topLevelDomain lowercaseString];
            //NSLog(@"topleveldomains:%@",topLevelDomain);
            NSSet *TLD;
            TLD = [NSSet setWithObjects:@".aero", @".asia", @".biz", @".cat", @".com", @".coop", @".edu", @".gov", @".info", @".int", @".jobs", @".mil", @".mobi", @".museum", @".name", @".net", @".org", @".pro", @".tel", @".travel", @".ac", @".ad", @".ae", @".af", @".ag", @".ai", @".al", @".am", @".an", @".ao", @".aq", @".ar", @".as", @".at", @".au", @".aw", @".ax", @".az", @".ba", @".bb", @".bd", @".be", @".bf", @".bg", @".bh", @".bi", @".bj", @".bm", @".bn", @".bo", @".br", @".bs", @".bt", @".bv", @".bw", @".by", @".bz", @".ca", @".cc", @".cd", @".cf", @".cg", @".ch", @".ci", @".ck", @".cl", @".cm", @".cn", @".co", @".cr", @".cu", @".cv", @".cx", @".cy", @".cz", @".de", @".dj", @".dk", @".dm", @".do", @".dz", @".ec", @".ee", @".eg", @".er", @".es", @".et", @".eu", @".fi", @".fj", @".fk", @".fm", @".fo", @".fr", @".ga", @".gb", @".gd", @".ge", @".gf", @".gg", @".gh", @".gi", @".gl", @".gm", @".gn", @".gp", @".gq", @".gr", @".gs", @".gt", @".gu", @".gw", @".gy", @".hk", @".hm", @".hn", @".hr", @".ht", @".hu", @".id", @".ie", @" No", @".il", @".im", @".in", @".io", @".iq", @".ir", @".is", @".it", @".je", @".jm", @".jo", @".jp", @".ke", @".kg", @".kh", @".ki", @".km", @".kn", @".kp", @".kr", @".kw", @".ky", @".kz", @".la", @".lb", @".lc", @".li", @".lk", @".lr", @".ls", @".lt", @".lu", @".lv", @".ly", @".ma", @".mc", @".md", @".me", @".mg", @".mh", @".mk", @".ml", @".mm", @".mn", @".mo", @".mp", @".mq", @".mr", @".ms", @".mt", @".mu", @".mv", @".mw", @".mx", @".my", @".mz", @".na", @".nc", @".ne", @".nf", @".ng", @".ni", @".nl", @".no", @".np", @".nr", @".nu", @".nz", @".om", @".pa", @".pe", @".pf", @".pg", @".ph", @".pk", @".pl", @".pm", @".pn", @".pr", @".ps", @".pt", @".pw", @".py", @".qa", @".re", @".ro", @".rs", @".ru", @".rw", @".sa", @".sb", @".sc", @".sd", @".se", @".sg", @".sh", @".si", @".sj", @".sk", @".sl", @".sm", @".sn", @".so", @".sr", @".st", @".su", @".sv", @".sy", @".sz", @".tc", @".td", @".tf", @".tg", @".th", @".tj", @".tk", @".tl", @".tm", @".tn", @".to", @".tp", @".tr", @".tt", @".tv", @".tw", @".tz", @".ua", @".ug", @".uk", @".us", @".uy", @".uz", @".va", @".vc", @".ve", @".vg", @".vi", @".vn", @".vu", @".wf", @".ws", @".ye", @".yt", @".za", @".zm", @".zw", nil];
            if(topLevelDomain != nil && ([TLD containsObject:topLevelDomain])) {
                //NSLog(@"TLD contains topLevelDomain:%@",topLevelDomain);
                return TRUE;
            }
            /*else {
             NSLog(@"TLD DOEST NOT contains topLevelDomain:%@",topLevelDomain);
             }*/
            
        }
    }
    return FALSE;
}



- (void)animateTextField:(UITextField *)textField up:(BOOL)up {
    @try {
        
            int animatedDistance;
          //   int moveUpValue = textField.frame.origin.y + textField.frame.size.height;
            UIInterfaceOrientation orientation =
            [[UIApplication sharedApplication] statusBarOrientation];
            if (orientation == UIInterfaceOrientationPortrait ||
                orientation == UIInterfaceOrientationPortraitUpsideDown) {
                
               animatedDistance = 280 - (250 - 10 - 5);
            } else {
                
                  animatedDistance = 162 - (320 - 50 - 5);
            }
            
            if (animatedDistance > 0) {
                NSString *deviceType = [[UIDevice currentDevice] model];
                
                if ([deviceType isEqualToString:@"iPad"]) {
                }
                
                const int movementDistance = animatedDistance;
                const float movementDuration = 0.3f;
                int movement = (up ? -movementDistance : movementDistance);
                [UIView beginAnimations:nil context:nil];
                [UIView setAnimationBeginsFromCurrentState:YES];
                [UIView setAnimationDuration:movementDuration];
                self.popUpView.frame = CGRectOffset(self.popUpView.frame, 0, movement);
                [UIView commitAnimations];
            }
    
        
    } @catch (NSException *exception) {
        //[self showAlertPop:@"Error while fetching data." expObj:exception];
    }
}

- (void) showAlertPop:(NSString*)alertText expObj:(NSException*) exp{
    @try {
        
        if(exp != nil)
        {
            NSLog(@"%@", exp.description);
        }
        UIAlertController *myAlertController =[mWebservice  alert:alertText];
        [self presentViewController:myAlertController animated:YES completion:nil];
    }
    @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    }
    @finally {
        
    }
    
}

- (void)removeAnimate
{
    [UIView animateWithDuration:.25 animations:^{
        self.view.transform = CGAffineTransformMakeScale(1.3, 1.3);
        self.view.alpha = 0.0;
    } completion:^(BOOL finished) {
        if (finished) {
            [self.view removeFromSuperview];
        }
    }];
    
//    Home *mHome = [[Home alloc]initWithNibName:HOMEDASHBOARD bundle:nil];
//    [self presentViewController:mHome animated:YES completion:nil];
}

- (void)showInView:(UIView *)aView withImage:(UIImage *)image withMessage:(NSString *)message animated:(BOOL)animated
{
    [aView addSubview:self.view];
    self.logoImg.image = image;
    //self.messageLabel.text = message;
    if (animated) {
        [self showAnimate];
    }
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
