//
//  ScanCode.h
//  RPRT
//
//  Created by sravanthi Gumma on 08/01/16.
//  Copyright © 2016 DevpointSolutions. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AVFoundation/AVFoundation.h>

@interface ScanCode : UIViewController <AVCaptureMetadataOutputObjectsDelegate>
{
    AVCaptureSession *session;
    AVCaptureDevice *device;
    AVCaptureDeviceInput *input;
    AVCaptureMetadataOutput *output;
    AVCaptureVideoPreviewLayer *prevLayer;
    NSString *detectionString;
    UIView *highlightView;
}
@property (weak, nonatomic) IBOutlet UIView *toolBar;

- (IBAction)bakc:(id)sender;

@property(nonatomic,weak)IBOutlet UILabel *OppName;
@property(nonatomic,weak)IBOutlet UILabel *OppDescription;
@property(nonatomic,weak)IBOutlet UILabel *UserName;
@property(nonatomic,weak)IBOutlet UILabel *OfferPrice;
@property(nonatomic,weak)IBOutlet UILabel *PhoneNo;
@property(nonatomic,weak)IBOutlet UILabel *Catefory;
@property(nonatomic,weak)IBOutlet UILabel *OfferStatus;
@property(nonatomic,weak)IBOutlet UITextField *Quantity;
@property(nonatomic,weak)IBOutlet UITextField *keyValues;
@property(nonatomic,weak)IBOutlet UIImageView *offerImage;
@property (nonatomic,weak) IBOutlet UIView *profileview;



@end
