//
//  ScanCode.m
//  RPRT
//
//  Created by sravanthi Gumma on 08/01/16.
//  Copyright © 2016 DevpointSolutions. All rights reserved.
//

#import "ScanCode.h"
#import "MainViewController.h"
#import "Web_Services.h"
#import "MZTimerLabel.h"

@interface ScanCode ()<UITextFieldDelegate,CustomIOSAlertViewDelegate>
{
    Web_Services *mWebservice;
    NSDictionary *scanedDetails;
    MZTimerLabel *TimeCoutDown;
    UIActivityIndicatorView *spinner;
    UILabel *quantityLbl;
    UITextField *quantitiTextField;
    CustomIOSAlertView *ImageAlert;
    UIAlertController *alert;
    int Remaingtyime;
    NSUserDefaults *mPref;
    
}

@end

@implementation ScanCode
@synthesize OppName,OppDescription,UserName,offerImage,OfferPrice,OfferStatus,Catefory,PhoneNo,Quantity,profileview,keyValues;
- (void)viewDidLoad
{
    @try {
        
    
    [super viewDidLoad];
      
        self.view.backgroundColor= [UIColor whiteColor];
        
        mPref = [NSUserDefaults standardUserDefaults];
        
        profileview.layer.borderColor= [UIColor colorWithRed:235.0/256.0 green:235.0/256.0 blue:235.0/256.0 alpha:1].CGColor;
        profileview.layer.borderWidth=0.5;
         offerImage.layer.borderColor= [UIColor colorWithRed:235.0/256.0 green:235.0/256.0 blue:235.0/256.0 alpha:1].CGColor;
        offerImage.layer.borderWidth=1;
        
        
    mWebservice = [Web_Services GetSharedInstance];
    highlightView = [[UIView alloc] init];
    highlightView.autoresizingMask = UIViewAutoresizingFlexibleTopMargin |
    UIViewAutoresizingFlexibleLeftMargin |
    UIViewAutoresizingFlexibleRightMargin |
    UIViewAutoresizingFlexibleBottomMargin;
    highlightView.layer.borderColor = [UIColor greenColor].CGColor;
    highlightView.layer.borderWidth = 3;
    highlightView.frame= CGRectMake(10,50,360,550);
    [self.view addSubview:highlightView];
       
    
    session = [[AVCaptureSession alloc] init];
    device = [AVCaptureDevice defaultDeviceWithMediaType:AVMediaTypeVideo];
    NSError *error = nil;
    
    input = [AVCaptureDeviceInput deviceInputWithDevice:device error:&error];
    if (input) {
        [session addInput:input];
    } else {
        NSLog(@"Error: %@", error);
    }
    
    output = [[AVCaptureMetadataOutput alloc] init];
    [output setMetadataObjectsDelegate:self queue:dispatch_get_main_queue()];
    [session addOutput:output];
    
    output.metadataObjectTypes = [output availableMetadataObjectTypes];
    
    prevLayer = [AVCaptureVideoPreviewLayer layerWithSession:session];
    prevLayer.frame =  CGRectMake(5, 80, self.view.frame.size.width-10, 175);
    prevLayer.videoGravity = AVLayerVideoGravityResizeAspectFill;
    [self.view.layer addSublayer:prevLayer];
    [self.view bringSubviewToFront:highlightView];
    [session startRunning];
    
    //highlightView.layer.borderColor = [UIColor redColor].CGColor;
    highlightView.frame = CGRectMake(20, 150, 280, 100);
        
        //CALayer *keyCodeBorder = [CALayer layer];
       // keyCodeBorder.borderColor = [UIColor lightTextColor].CGColor;
        
        
      //  keyCodeBorder.borderColor = [UIColor lightGrayColor].CGColor;
      //  keyCodeBorder.frame = CGRectMake(0, keyValues.frame.size.height - 1, keyValues.frame.size.width, keyValues.frame.size.height);
        keyValues.layer.borderWidth =1;//
        keyValues.layer.borderColor=[UIColor lightTextColor].CGColor;
        //keyValues.layer.masksToBounds = YES;
        
        
        
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


#pragma mark - IBAction method implementation

- (void)captureOutput:(AVCaptureOutput *)captureOutput
didOutputMetadataObjects:(NSArray *)metadataObjects
       fromConnection:(AVCaptureConnection *)connection {
    @try {
        
        CGRect highlightViewRect = CGRectZero;
        AVMetadataMachineReadableCodeObject *barCodeObject;
        detectionString = nil;
        NSArray *barCodeTypes = @[
                                  AVMetadataObjectTypeUPCECode,
                                  AVMetadataObjectTypeCode39Code,
                                  AVMetadataObjectTypeCode39Mod43Code,
                                  AVMetadataObjectTypeEAN13Code,
                                  AVMetadataObjectTypeEAN8Code,
                                  AVMetadataObjectTypeCode93Code,
                                  AVMetadataObjectTypeCode128Code,
                                  AVMetadataObjectTypePDF417Code,
                                  AVMetadataObjectTypeQRCode,
                                  AVMetadataObjectTypeAztecCode
                                  ];
        
        for (AVMetadataObject *metadata in metadataObjects) {
            for (NSString *type in barCodeTypes) {
                if ([metadata.type isEqualToString:type]) {
                    barCodeObject = (AVMetadataMachineReadableCodeObject *)[prevLayer
                                                                            transformedMetadataObjectForMetadataObject:
                                                                            (AVMetadataMachineReadableCodeObject *)metadata];
                    highlightViewRect = barCodeObject.bounds;
                    detectionString =
                    [(AVMetadataMachineReadableCodeObject *)metadata stringValue];
                    
                    break;
                }
            }
            
            if (detectionString != nil) {
                
                [session stopRunning];
                
                
                alert = [UIAlertController
                                            alertControllerWithTitle:@"RPRT"
                                            message:detectionString
                                            preferredStyle:UIAlertControllerStyleAlert];
                
                UIAlertAction *defaultAction =
                [UIAlertAction actionWithTitle:@"OK"
                                         style:UIAlertActionStyleDefault
                                       handler:^(UIAlertAction *action) {
                                           
                                           spinner = [[UIActivityIndicatorView alloc]
                                                      initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
                                           spinner.frame = CGRectMake(0, 0, 320, 560); // CGPointMake(160, 240);
                                           spinner.color = [UIColor blueColor];
                                           spinner.backgroundColor = [UIColor lightTextColor];
                                           spinner.transform = CGAffineTransformMakeScale(2, 2);
                                           // spinner.hidesWhenStopped = YES;
                                           [self.view addSubview:spinner];
                                           spinner.transform = CGAffineTransformMakeScale(2, 2);
                                           
                                           [spinner startAnimating];
                                           
                                           // how we stop refresh from freezing the main UI thread
                                           
                                           dispatch_async(
                                                          dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^{ dispatch_async(dispatch_get_main_queue(), ^{
                                               
                                               [spinner startAnimating];
                                           });
                                                              dispatch_async(dispatch_get_main_queue(), ^{
                                          
                                                                  
                                                               //   NSString *refistedID=[NSString stringWithFormat:@"%@",[mPref objectForKey:USERREGISTERID]];
                                                                [self scanedDetails:detectionString];
                                                                [session startRunning];
                                                                        
                                                                  
                                           
                                                                  NSLog(@"%@",scanedDetails);
                                           
                                                                  [spinner stopAnimating];
                                                                  
                                                              });
                                                          });

                                           
                                           //[session startRunning];
                                           
                                           highlightView.layer.borderColor = [UIColor clearColor].CGColor;
                                           highlightView.frame = highlightViewRect;
////                                           [self ScanBarCode:detectionString];
                                           
                                       }];
                
                [alert addAction:defaultAction];
                
                [self presentViewController:alert animated:YES completion:nil];
                //
                
                break;
            } else if (detectionString == nil)
                
            {
                [session startRunning];
                //detectionString = itemNumber.text;
            }
        }
        highlightView.layer.borderColor = [UIColor greenColor].CGColor;
        highlightView.frame = highlightViewRect;
        
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }}

-(void)scanedDetails:(NSString*)qrCode
{
    
    @try {
        scanedDetails=   [mWebservice GetScanDetails:qrCode];
        if (scanedDetails!=nil)
        {
            
            NSString * erroeMessage =[scanedDetails valueForKey:@"ErrorMessage"];
            
            if ( ( ![erroeMessage isEqual:[NSNull null]] ) && ( [erroeMessage length] != 0 ) ) {
                [self showAlertPop:erroeMessage expObj:nil];
            }
            
            if (( [erroeMessage isEqual:[NSNull null]])) {
                [self LoadBlockedDetails];
                
            }
          
        }


    } @catch (NSException *exception) {
          [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
    
    
    
    
    
//    //if ([[qrCodearry objectAtIndex:2] isEqualToString:@"Expired"])
//    {
//        scanedDetails=   [mWebservice GetScanDetails:qrCodearry];
//        if (scanedDetails!=nil)
//        {
//            [self LoadBlockedDetails];
//        }
//        else  if (scanedDetails == nil)
//        {
//            [session startRunning];
//            [self showAlertPop:@"Sorry! we are unable to find this Offer" expObj:nil];
//           
//        }
//        
//        [self showAlertPop:@"Offer Expired." expObj:nil];
//    }
//    else if ([[qrCodearry objectAtIndex:2] isEqualToString:@"Ongoing"])
//    {
//        scanedDetails=   [mWebservice GetScanDetails:[qrCodearry objectAtIndex:1]];
//        if (scanedDetails!=nil)
//        {
//            [self LoadBlockedDetails];
//        }
//        else  if (scanedDetails == nil)
//        {
//            [session startRunning];
//
//            [self showAlertPop:@"Sorry! we are unable to find this Offer" expObj:nil];
//
//        }
//        
//    }
    
}



#pragma mark - AVCaptureMetadataOutputObjectsDelegate method implementation

- (IBAction)bakc:(id)sender
{ @try
    {
        spinner = [[UIActivityIndicatorView alloc]
                   initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
        spinner.frame = CGRectMake(0, 0, 320, 560); // CGPointMake(160, 240);
        spinner.color = [UIColor blueColor];
        spinner.backgroundColor = [UIColor lightTextColor];
        spinner.transform = CGAffineTransformMakeScale(2, 2);
        // spinner.hidesWhenStopped = YES;
        [self.view addSubview:spinner];
        spinner.transform = CGAffineTransformMakeScale(2, 2);
        
        [spinner startAnimating];
        
        // how we stop refresh from freezing the main UI thread
        
        dispatch_async(
                       dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^{ dispatch_async(dispatch_get_main_queue(), ^{
            
            [spinner startAnimating];
        });
                           dispatch_async(dispatch_get_main_queue(), ^{
                               ////Here you can update code for page nagivation
                             //  NSUserDefaults *mPref = [NSUserDefaults standardUserDefaults];
                               
                             
                               
                               Home * mOpportunity_list = [[ Home alloc] initWithNibName:HOMEDASHBOARD bundle:nil];
                               [self presentViewController:mOpportunity_list animated:YES completion:nil];
                               
                               
                               [spinner stopAnimating];
                               
                           });
                       });
        
        
        
        //[self dismissViewControllerAnimated:YES completion:NULL];
        
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
}

-(BOOL)GetVendorOpportunities:(NSString*)registedId
{
  NSMutableArray  *GetRetailerOpp = [mWebservice GetOpportinityByUserID:registedId];
    //GetRetailerOpp = [NSMutableArray arrayWithObjects:GetRetailer, nil];
    if (GetRetailerOpp.count==0) {
        
        
        [self showAlertPop:@"You Don't have Posted Offer." expObj:nil];
        
    }
    else{
        
        NSString *opporrIDv =[NSString stringWithFormat:@"%@",[scanedDetails valueForKey:@"OpportunityId"]];
        
        for (int i=0; i<[GetRetailerOpp count]; i++) {
            NSString *str= [NSString stringWithFormat:@"%@",[[GetRetailerOpp objectAtIndex:i]  valueForKey:@"OpportunityID"]];
           
            if ([opporrIDv isEqualToString:str]) {
                return YES;
            }
           
        }
         [self showAlertPop:@"You Don't have Posted this Offer." expObj:nil];
        return NO;
       
    }
    
    
    return NO;
    
}


-(void)LoadBlockedDetails {
    @try {
        
        //scanedDetails
        
        //OpportunityId
        
  
        NSString *RegisterID =   [mPref objectForKey:USERREGISTERID];
  BOOL res =  [self GetVendorOpportunities:RegisterID];
        
        if (res) {
            
            keyValues.text = [scanedDetails valueForKey:@"KeyValue"];
            OppName.text=[scanedDetails valueForKey:@"OpportunityName"];
            
            OppDescription.text=[scanedDetails valueForKey:@"OpportunityDescription"];
            
            OfferPrice.text= [scanedDetails valueForKey:@"Category"];
            
            UserName.text= [scanedDetails valueForKey:@"ContactPerson"];
            
            PhoneNo.text= [scanedDetails valueForKey:@"PhoneNo"];
            
            NSString *satrtDate = [NSString stringWithFormat:@"%@",[scanedDetails valueForKey:@"EndDate"]];
            
            NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
            [dateFormatter setDateFormat:@"yyyy-MM-dd'T'HH:mm:ss"];
            NSTimeZone *gmt = [NSTimeZone timeZoneWithAbbreviation:@"UTC"];
            [dateFormatter setTimeZone:gmt];
            NSDate *date5 = [dateFormatter dateFromString:satrtDate];
            
            NSDictionary *startOffer;
            if (date5!=nil) {
                startOffer= [[Preferences GetSharedInstance]remaningTime:[NSDate date] endDate:date5];
            }
            else{
                
                NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
                [dateFormatter setDateFormat:@"yyyy-MM-dd'T'HH:mm:ss.SSS"];
                
                NSTimeZone *gmt = [NSTimeZone timeZoneWithAbbreviation:@"UTC"];
                [dateFormatter setTimeZone:gmt];
                NSDate *date5 = [dateFormatter dateFromString:satrtDate];
                startOffer= [[Preferences GetSharedInstance]remaningTime:[NSDate date] endDate:date5];
                
            }
            
             Remaingtyime = [[startOffer valueForKey:@"Time"] intValue];
            int hour = [[startOffer valueForKey:@"Hour"] intValue];
            int seconds = [[startOffer valueForKey:@"Seconds"] intValue];
            if (seconds!=0) {
                Remaingtyime = Remaingtyime+(seconds/60);
            }
            if(Remaingtyime!=0)
            {
                Remaingtyime = Remaingtyime+(hour*60);
                Remaingtyime = Remaingtyime+5;
                TimeCoutDown = [[MZTimerLabel alloc] initWithLabel:OfferStatus andTimerType:MZTimerLabelTypeTimer];
                [TimeCoutDown setCountDownTime:Remaingtyime*60];
                [TimeCoutDown start];
                
            }
            else
            {
                OfferStatus.text = @"Opportunities Expired!!";
                 [self showAlertPop:@"You cant able to Claim the Offer Because Offer Expired" expObj:nil];
            }
            
            Catefory.text= [scanedDetails valueForKey:@"RegEmail"];
            
            NSString *imageName = [NSString stringWithFormat:@"%@",[scanedDetails valueForKey:@"PhotoName"]];;
            NSArray *imageAry = [imageName componentsSeparatedByString:@","];
            NSString *ImageURL = [NSString stringWithFormat:@"%@%@",baseImageURL, [imageAry objectAtIndex:0]];
            
            if ([[imageAry objectAtIndex:0] isEqualToString:@""]) {
                
                imageName = [NSString stringWithFormat:@"%@",[scanedDetails valueForKey:@"CategoryImage"]];;
                ImageURL = [NSString stringWithFormat:@"%@%@",baseImageURL, imageName];
                
                NSURL *imageURL = [NSURL URLWithString:ImageURL];
                // NSString *key = [ImageURL MD5Hash];
                NSData *getData = [NSData dataWithContentsOfURL:imageURL];;
                UIImage *image = [UIImage imageWithData:getData];
                offerImage.image  = image;
                
            }
            
            else {
                ImageURL = [NSString stringWithFormat:@"%@%@",baseImageURL, [imageAry objectAtIndex:0]];
                
                NSURL *imageURL = [NSURL URLWithString:ImageURL];
                // NSString *key = [ImageURL MD5Hash];
                NSData *getData = [NSData dataWithContentsOfURL:imageURL];;
                UIImage *image = [UIImage imageWithData:getData];
                offerImage.image  = image;
                
            }
            
            UITapGestureRecognizer *singleTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(ImageTap:)];
            singleTap.numberOfTapsRequired = 1;
            [offerImage setUserInteractionEnabled:YES];
            [offerImage addGestureRecognizer:singleTap];
            
            [self addtoolbarItems];
        }
        
        else
        {
             [self showAlertPop:@"You cant able to Claim the Offer" expObj:nil];
            
            OfferPrice.text= @"";
            OfferStatus.text = @"";
            OppName.text= @"";
            OppDescription.text = @"";
            UserName.text = @"";
            PhoneNo.text = @"";
            offerImage.image= nil;
            Catefory.text= @"";
            [TimeCoutDown stop];
            [session startRunning];
        }
        
       
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
}

-(void)addtoolbarItems {
    @try {
        
        UIButton *okBtn= [[UIButton alloc]initWithFrame:CGRectMake(300, 20, 40, 40)];
        [okBtn setImage:[UIImage imageNamed:@"ic_Wtick.png"] forState:UIControlStateNormal];
        [okBtn addTarget:self action:@selector(ok:) forControlEvents:UIControlEventTouchUpInside];
        [self.toolBar addSubview:okBtn];
        
        
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
}

- (void) showAlertPop:(NSString*)alertText expObj:(NSException*) exp{
    @try {
        
        if(exp != nil)
        {
            NSLog(@"%@", exp.description);
        }
        UIAlertController *myAlertController =[mWebservice  alert:alertText];
        [self presentViewController:myAlertController animated:YES completion:nil];
    }
    @catch (NSException *exception) {
        [self showAlertPop:@"Invalid UserName." expObj:exception];
    }
    @finally {
        
    }
    
}

-(void)ok:(UIButton*)sender {
    @try {
        
        if ([Quantity.text isEqualToString:@""]) {
            [self showAlertPop:@"Please enter Quantity" expObj:nil];
        }
        
        else if (Remaingtyime == 0)
        {
            
            alert = [UIAlertController
                     alertControllerWithTitle:@"RPRT"
                     message:@"Offer is expired, do you want to continue?"
                     preferredStyle:UIAlertControllerStyleAlert];
            
            UIAlertAction *defaultAction =
            [UIAlertAction actionWithTitle:@"Cancel"
                                     style:UIAlertActionStyleDefault
                                   handler:^(UIAlertAction *action) {
                                   }];
         UIAlertAction *calimAction =    [UIAlertAction actionWithTitle:@"Continue"
                                     style:UIAlertActionStyleDefault
                                   handler:^(UIAlertAction *action) {
                                       
                                       [self claimOffer];
                                       
                                   }];
            
            [alert addAction:defaultAction];
            [alert addAction:calimAction];
            
            [self presentViewController:alert animated:YES completion:nil];
            
            
            
         //   [self showAlertPop:@"Offer is expired, do you want to continue?" expObj:nil];
        }
        else{
            [self claimOffer];
            
               }

        
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
}


-(void)claimOffer
{
    spinner = [[UIActivityIndicatorView alloc]
               initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
    spinner.frame = CGRectMake(0, 0, 320, 560); // CGPointMake(160, 240);
    spinner.color = [UIColor blueColor];
    spinner.backgroundColor = [UIColor lightTextColor];
    spinner.transform = CGAffineTransformMakeScale(2, 2);
    // spinner.hidesWhenStopped = YES;
    [self.view addSubview:spinner];
    spinner.transform = CGAffineTransformMakeScale(2, 2);
    
    [spinner startAnimating];
    
    // how we stop refresh from freezing the main UI thread
    
    dispatch_async(
                   dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^{ dispatch_async(dispatch_get_main_queue(), ^{
        
        [spinner startAnimating];
    });
                       dispatch_async(dispatch_get_main_queue(), ^{
                           
                           NSString *claimedTime = [self ClaimedTime];
                           
                           NSMutableDictionary *blockdetails= [[NSMutableDictionary alloc]init];
                           [blockdetails setValue:[scanedDetails valueForKey:@"BlockId"] forKey:@"BlockId"];
                           [blockdetails setValue:@"" forKey:@"BlockedUserId"];
                           [blockdetails setValue:[scanedDetails valueForKey:@"OpportunityId"] forKey:@"OpportunityId"];
                           [blockdetails setValue:@"Claimed" forKey:@"BlockText"];
                           [blockdetails setValue:[scanedDetails valueForKey:@"KeyValue"] forKey:@"KeyValue"];
                           [blockdetails setValue:@"" forKey:@"DeviceId"];
                           [blockdetails setValue:Quantity.text forKey:@"Quantity"];
                           [blockdetails setValue:claimedTime forKey:@"ClaimedTime"];
                           [blockdetails setValue:@"true" forKey:@"TransactionComplete"];
                           
                           NSDictionary *response=[mWebservice SaveBlockeditem:blockdetails];
                           if (response!=nil) {
                               
                               alert = [UIAlertController
                                        alertControllerWithTitle:@"RPRT"
                                        message:@"Offer Claimed sucessfully"
                                        preferredStyle:UIAlertControllerStyleAlert];
                               
                               UIAlertAction *defaultAction =
                               [UIAlertAction actionWithTitle:@"OK"
                                                        style:UIAlertActionStyleDefault
                                                      handler:^(UIAlertAction *action) {
                                                          
                                                          Home  *mHome = [[Home alloc]initWithNibName:HOMEDASHBOARD bundle:nil];
                                                          [self presentViewController:mHome animated:YES completion:nil];
                                                          
                                                      }];
                               
                               [alert addAction:defaultAction];
                               
                               [self presentViewController:alert animated:YES completion:nil];
                           }
                           
                           [spinner stopAnimating];
                           
                       });
                   });
 }




-(void)ImageTap:(UIPinchGestureRecognizer *)recognizer{
    
    @try {
        
        
        UIImageView *tableGridImage = (UIImageView*)recognizer.view;
        [self customimageAlert:tableGridImage];
        
        
        
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
    
    //ImageAlert = [CustomIOSAlertView ]
}

-(NSString*)ClaimedTime {
    
    @try {
        NSDate *currentDateInLocal = [NSDate date];
        
        NSDateFormatter *formatter = [[NSDateFormatter alloc]init];
        [formatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
        NSTimeZone *gmt = [NSTimeZone timeZoneWithAbbreviation:@"UTC"];
        [formatter setTimeZone:gmt];
        NSString *StartTimecon = [formatter stringFromDate:currentDateInLocal];
       
        return StartTimecon;
    }
    @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }

}

-(void)customimageAlert:(UIImageView*)tableGridImage {
    @try {
        
        
        ImageAlert=[[CustomIOSAlertView alloc] init];
        UIView  *imageView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 300, 200)];
        [ImageAlert setContainerView:imageView];
        [ImageAlert setButtonTitles:[NSMutableArray arrayWithObjects:@"", nil]];
        
        [ImageAlert setDelegate:self];
        
        
        // You may use a Block, rather than a delegate.
        [ImageAlert setOnButtonTouchUpInside:^(CustomIOSAlertView *alertView, int buttonIndex) {
            NSLog(@"Block: Button at position %d is clicked on alertView %d.", buttonIndex, (int)[alertView tag]);
            [alertView close];
        }];
        
        [ImageAlert setUseMotionEffects:true];
        
        UIButton *cancel = [[UIButton alloc]initWithFrame:CGRectMake(275, 0, 20, 20)];
        
        [cancel setImage:[UIImage imageNamed:@"ic_close"] forState:UIControlStateNormal];
        [cancel addTarget:self action:@selector(cancel:) forControlEvents:UIControlEventTouchUpInside];
        
        
        UIImageView *VendorProfile = [[UIImageView alloc]initWithImage:tableGridImage.image];
        VendorProfile.frame = CGRectMake(0, 20, 300, 230);
        [imageView addSubview:cancel];
        [imageView addSubview:VendorProfile];
        
        [ImageAlert show];
        ImageAlert.tag = 2;
    }
    @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
}


-(void)cancel:(UIButton*)sender {
    [ImageAlert close];
}


-(IBAction)getDetails:(id)sender
{
    @try {
        
        [Quantity resignFirstResponder];
        [keyValues resignFirstResponder];
        
     
        
        if ([keyValues.text isEqualToString:@""]) {
              [self showAlertPop:@"Please enter KeyCode" expObj:nil];
        }
        else if (![keyValues.text isEqualToString:@""])
        {
            
            NSString *string =keyValues.text;
            if ([string rangeOfString:@"RPRT"].location == NSNotFound) {
                [self showAlertPop:@"This Keycode doesn't contains RPRT" expObj:nil];
            } else {
                
            spinner = [[UIActivityIndicatorView alloc]
                       initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
            spinner.frame = CGRectMake(0, 0, 320, 560); // CGPointMake(160, 240);
            spinner.color = [UIColor blueColor];
            spinner.backgroundColor = [UIColor lightTextColor];
            spinner.transform = CGAffineTransformMakeScale(2, 2);
            // spinner.hidesWhenStopped = YES;
            [self.view addSubview:spinner];
            spinner.transform = CGAffineTransformMakeScale(2, 2);
            
            [spinner startAnimating];
            
            // how we stop refresh from freezing the main UI thread
            
            dispatch_async(
                           dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^{ dispatch_async(dispatch_get_main_queue(), ^{
                
                [spinner startAnimating];
            });
                               dispatch_async(dispatch_get_main_queue(), ^{
                                   

            
            
            
            scanedDetails=   [mWebservice GetScanDetails:keyValues.text];
            if (scanedDetails!=nil)
            {
                [self LoadBlockedDetails];
            }
            else  if (scanedDetails == nil)
            {
                [self showAlertPop:@"Sorry! we are unable to find this Offer" expObj:nil];
                
            }
                                   [spinner stopAnimating];
                                   
                               });
                           });
            }
            
           //[self scanedDetails:qrcode];
        }
        
        
    } @catch (NSException *exception) {
          [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
}


- (IBAction)hideKeyBoardKeyWord:(id)sender {
    
    @try {
        
        
        if ([Quantity isFirstResponder]) {
            [Quantity resignFirstResponder];
            
            if (![self validMobileNumber:Quantity.text]) {
                [Quantity becomeFirstResponder];
               
                [self showAlertPop:@"Please enter numbers only" expObj:nil];
            }
            
           else if ([keyValues isFirstResponder])
           {
                 [keyValues resignFirstResponder];
           }
    
}
    }
        @catch (NSException *exception) {
            [self showAlertPop:@"Error while fetching data." expObj:exception];
        } @finally {
    
        }
}


- (BOOL)validMobileNumber:(NSString *)mobilenumber {
    
    @try {
        
        BOOL isValid = NO;
        NSCharacterSet *alphaNumbersSet = [NSCharacterSet decimalDigitCharacterSet];
        NSCharacterSet *stringSet = [NSCharacterSet characterSetWithCharactersInString:mobilenumber];
        isValid = [alphaNumbersSet isSupersetOfSet:stringSet];
        return isValid;
        
        
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    }
}

- (IBAction)textFieldDidBeginEditing:(id)textField {
    @try {
        
        
        [self animateTextField:textField up:YES];
    }
    @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    }
    @finally {
        
    }
    
}

- (IBAction)textFieldDidEndEditing:(id)textField {
    @try {
        
        [self animateTextField:textField up:NO];
    }
    @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    }
    @finally {
        
    }
}

- (void)animateTextField:(UITextField *)textField up:(BOOL)up {
    @try {
        
            
            
            int animatedDistance;
          //  int moveUpValue = textField.frame.origin.y + textField.frame.size.height;
            UIInterfaceOrientation orientation =
            [[UIApplication sharedApplication] statusBarOrientation];
            if (orientation == UIInterfaceOrientationPortrait ||
                orientation == UIInterfaceOrientationPortraitUpsideDown) {
                
                animatedDistance = 280 - (250 - 75 - 5);
            } else {
                animatedDistance = 162 - (320 - 75 - 5);
            }
            
            if (animatedDistance > 0) {
                NSString *deviceType = [[UIDevice currentDevice] model];
                
                if ([deviceType isEqualToString:@"iPad"]) {
                }
                
                const int movementDistance = animatedDistance;
                const float movementDuration = 0.3f;
                int movement = (up ? -movementDistance : movementDistance);
                [UIView beginAnimations:nil context:nil];
                [UIView setAnimationBeginsFromCurrentState:YES];
                [UIView setAnimationDuration:movementDuration];
                self.view.frame = CGRectOffset(self.view.frame, 0, movement);
                [UIView commitAnimations];
            }
        
        
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    }
}

@end
