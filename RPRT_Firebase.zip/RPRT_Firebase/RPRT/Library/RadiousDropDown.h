//
//  NIDropDown.h
//  NIDropDown
//
//  Created by Bijesh N on 12/28/12.
//  Copyright (c) 2012 Nitor Infotech. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "QuartzCore/QuartzCore.h"
#import "MainCellLeft.h"
#import "Web_Services.h"

@class RadiousDropDown;
@protocol RadiousDropDownDelegate
- (void) RadiousDropDownDelegateMethod: (RadiousDropDown *) sender;
@end

@interface RadiousDropDown : UIView <UITableViewDelegate, UITableViewDataSource>
{
    NSString *animationDirection;
    UIImageView *imgView;
    NSMutableArray *arSelectedRows;
    NSMutableArray *SelectedRows;
}
@property (nonatomic, retain) id <RadiousDropDownDelegate> delegate;
@property (nonatomic, retain) NSString *animationDirection;


-(void)hideDropDown:(UIButton *)b;
- (id)showDropDown:(UIButton *)b:(CGFloat *)height:(NSArray *)arr:(NSArray *)imgArr:(NSString *)direction;
@end

