//
//  NIDropDown.m
//  NIDropDown
//
//  Created by Bijesh N on 12/28/12.
//  Copyright (c) 2012 Nitor Infotech. All rights reserved.
//

#import "RadiousDropDown.h"


@interface RadiousDropDown ()
{
    NSString *categorystring;
    NSArray *GetAllCatagories;
    NSMutableArray *selections;
     NSMutableArray *CategoryValue;
    Web_Services *mWebservice;
}
@property(nonatomic, strong) UITableView *table;
@property(nonatomic, strong) UIButton *btnSender;
@property(nonatomic, retain) NSArray *GetAllCatagories;
@property(nonatomic, retain) NSArray *imageList;
@end

@implementation RadiousDropDown
@synthesize table;
@synthesize btnSender;
@synthesize GetAllCatagories;
@synthesize imageList;
@synthesize delegate;
@synthesize animationDirection;

- (id)showDropDown:(UIButton *)b:(CGFloat *)height:(NSArray *)arr:(NSArray *)imgArr:(NSString *)direction {
    @try {
        
        mWebservice = [Web_Services GetSharedInstance];
    btnSender = b;
    animationDirection = direction;
    self.table = (UITableView *)[super init];
    
     arSelectedRows = [[NSMutableArray alloc]init];
    
    if (self) {
        // Initialization code
        CGRect btn = b.frame;
         selections = [[NSMutableArray alloc] init];
      
        NSString *path = [[NSBundle mainBundle] pathForResource:@"Category" ofType:@"plist"];
        NSMutableDictionary *dict = [NSMutableDictionary dictionaryWithContentsOfFile:path];
        
        GetAllCatagories = [dict valueForKey:@"Radious"];

    
        if ([direction isEqualToString:@"up"]) {
            self.frame = CGRectMake(btn.origin.x, btn.origin.y, btn.size.width, 0);
            self.layer.shadowOffset = CGSizeMake(-5, -5);
        }else if ([direction isEqualToString:@"down"]) {
            self.frame = CGRectMake(btn.origin.x, btn.origin.y+btn.size.height, btn.size.width, 0);
            self.layer.shadowOffset = CGSizeMake(-5, 5);
        }
        
        self.layer.masksToBounds = NO;
        self.layer.cornerRadius = 8;
        self.layer.shadowRadius = 5;
        self.layer.shadowOpacity = 0.5;
        
        table = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, 265, 350)];
        table.delegate = self;
        table.dataSource = self;
        table.layer.cornerRadius = 5;
        //table.backgroundColor = [UIColor colorWithRed:0.239 green:0.239 blue:0.239 alpha:1];
        table.separatorStyle = UITableViewCellSeparatorStyleSingleLine;
        //table.separatorColor = [UIColor whiteColor];
        
        [UIView beginAnimations:nil context:nil];
        [UIView setAnimationDuration:0.5];
        if ([direction isEqualToString:@"up"]) {
            self.frame = CGRectMake(btn.origin.x, btn.origin.y-*height, 265, *height);
        } else if([direction isEqualToString:@"down"]) {
            self.frame = CGRectMake(btn.origin.x, btn.origin.y+btn.size.height, 250, 350);
        }
        table.frame = CGRectMake(-100, 0, 150, 150);
        [UIView commitAnimations];
        [b.superview addSubview:self];
        [self addSubview:table];
    }
    return self;
    } @catch (NSException *exception) {
        [self showAlertPop:@"Invalid UserName." expObj:exception];
    } @finally {
        
    }

}

-(void)hideDropDown:(UIButton *)b {
    @try {
           CGRect btn = b.frame;
    
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.5];
    if ([animationDirection isEqualToString:@"up"]) {
        self.frame = CGRectMake(btn.origin.x, btn.origin.y, btn.size.width, 0);
    }else if ([animationDirection isEqualToString:@"down"]) {
        self.frame = CGRectMake(btn.origin.x, btn.origin.y+btn.size.height, btn.size.width, 0);
    }
    
    table.frame = CGRectMake(0, 0, 200, 0);
    [UIView commitAnimations];
    } @catch (NSException *exception) {
        [self showAlertPop:@"Invalid UserName." expObj:exception];
    } @finally {
        
    }

}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 40;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [GetAllCatagories count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    @try {
        
    
    static NSString *simpleTableIdentifier = @"MainCellLeft";
    
    MainCellLeft *cell = (MainCellLeft *)[tableView dequeueReusableCellWithIdentifier:simpleTableIdentifier];
    if (cell == nil)
    {
        NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"MainCellLeft" owner:self options:nil];
        cell = [nib objectAtIndex:0];
    }
    cell.title.text = GetAllCatagories[indexPath.row];
    return cell;
    } @catch (NSException *exception) {
        [self showAlertPop:@"Invalid UserName." expObj:exception];
    } @finally {
        
    }

}
- (void) showAlertPop:(NSString*)alertText expObj:(NSException*) exp{
    if(exp != nil)
    {
        NSLog(@"%@", exp.description);
    }
    UIAlertController *myAlertController =[mWebservice  alert:alertText];
//    [self presentViewController:myAlertController animated:YES completion:nil];
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{

   
}


- (void) myDelegate {
    [self.delegate RadiousDropDownDelegateMethod:self];
}

-(void)dealloc {
 
}



@end
