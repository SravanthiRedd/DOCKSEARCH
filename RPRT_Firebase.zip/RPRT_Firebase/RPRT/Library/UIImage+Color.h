//
//  UIImage+Color.h
//  RPRT
//
//  Created by sravanthi Gumma on 19/04/16.
//  Copyright © 2016 DevpointSolutions. All rights reserved.
//

#import <UIKit/UIKit.h>




@interface UIImage (Color)


- (UIImage *)imageWithTint:(UIColor *)tintColor;
//scale and resize...
-(UIImage*)scaleToSize:(CGSize)size;

+(UIImage *)changeWhiteColorTransparent: (UIImage *)image;

- (UIImage *)imageWithColor:(UIColor *)color1;

@end
