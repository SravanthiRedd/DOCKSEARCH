/*

    DLStarRating
 //  RPRT
 //
 //  Created by sravanthi Gumma on 08/01/16.
 //  Copyright © 2016 DevpointSolutions. All rights reserved.

 */

#import <UIKit/UIKit.h>


@interface UIView (Subviews)

- (UIView*)subViewWithTag:(int)tag;

@end
