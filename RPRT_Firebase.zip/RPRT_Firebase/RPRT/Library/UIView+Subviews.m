/*

    DLStarRating
 //  RPRT
 //
 //  Created by sravanthi Gumma on 08/01/16.
 //  Copyright © 2016 DevpointSolutions. All rights reserved.

 */

#import "UIView+Subviews.h"


@implementation UIView (Subviews)

- (UIView*)subViewWithTag:(int)tag {
	for (UIView *v in self.subviews) {
		if (v.tag == tag) {
			return v;
		}
	}
	return nil;
}

@end
