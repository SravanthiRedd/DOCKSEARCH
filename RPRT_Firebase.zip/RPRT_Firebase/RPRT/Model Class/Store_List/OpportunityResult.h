//
//  OpportunityResult.h
//  RPRT
//
//  Created by sravanthi Gumma on 28/10/1938 Saka.
//  Copyright © 1938 Saka DevpoNSNumber *Solutions. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "RMMapper.h"
#import "NSObject+RMArchivable.h"
@interface OpportunityResult : NSObject<RMMapping>
@property (nonatomic ,retain) NSNumber *OpportunityID ;

@property (nonatomic ,retain) NSNumber * UserID ;

@property (nonatomic ,retain) NSNumber * UserRegisterId ;

@property (nonatomic ,retain) NSString * OpportunityName ;

@property (nonatomic ,retain) NSString * OpportunityDescription ;

@property (nonatomic ,retain) NSString * OpportunityKeywords ;

@property (nonatomic ,retain) NSNumber * CategoryID ;

@property (nonatomic ,retain) NSString * Category ;

@property (nonatomic ,retain) NSString * CategoryImage ;
@property (nonatomic ,retain) NSString * durminit;

@property (nonatomic ,retain) NSDate *StartDate ;

@property (nonatomic ,retain) NSDate *EndDate ;

@property (nonatomic ,retain) NSString * OpportunityType ;

@property (nonatomic ,retain) NSString * TimeInterval;

@property (nonatomic ,retain) NSString * PromoCode ;

@property (nonatomic ,retain) NSString * VendorName ;

@property (nonatomic ,retain) NSString * VendorEmail ;

@property (nonatomic ,retain) NSString * VendorMobile ;

@property (nonatomic ,retain) NSString * VendorLandLine ;


@property (nonatomic ,retain) NSString * OppStatus ;


@property (nonatomic ,retain) NSString * Address1 ;

@property (nonatomic ,retain) NSString * Address2 ;

@property (nonatomic ,retain) NSString * Address3 ;

@property (nonatomic ,retain) NSString * AreaName ;

@property (nonatomic ,retain) NSString * City ;

@property (nonatomic ,retain) NSString * State ;

@property (nonatomic ,retain) NSString * Country ;

@property (nonatomic ,retain) NSString * PhotoName ;

@property (nonatomic ,retain) NSNumber * PhotoID ;

@property (nonatomic ,retain) NSString * Latitude ;

@property (nonatomic ,retain) NSString * Longitude ;

@property (nonatomic ,retain) NSNumber * VendorAddressId ;

@property (nonatomic ,retain) NSString * DeviceId ;

@property (nonatomic ,retain) NSString * Password ;

@property (nonatomic ,retain) NSString * GCM_Regid ;

@property (nonatomic ,retain) NSString * RatingValue ;

@property (nonatomic ,retain) NSString * TotalRatings ;



@property (nonatomic ,retain) NSString * distance ;

@property (nonatomic ,retain) NSString * duration ;


@property (nonatomic ,retain) NSString * Reservations ;


@property (nonatomic ,retain) NSString * Available ;


@property (nonatomic ,retain) NSString * ModuleId ;


@property (nonatomic ,retain) NSString * Price ;


@property (nonatomic ,retain) NSString * Delivery ;


@property (nonatomic ,retain) NSString * ActualPrice ;


//@property (nonatomic ,retain) TimeSpan durminit ;


@property (nonatomic ,retain) NSNumber * BlockId ;


@property (nonatomic ,retain) NSNumber * BlockedQuantity ;


@property (nonatomic ,retain) NSString * BlockText ;

@property (nonatomic ,retain) NSString * BlockedKeyValue ;

@property (nonatomic ,retain) NSString * UserName ;

@property (nonatomic ,retain) NSString * SubCategory ;
@end
