//
//  OpportunityResult.m
//  RPRT
//
//  Created by sravanthi Gumma on 28/10/1938 Saka.
//  Copyright © 1938 Saka DevpointSolutions. All rights reserved.
//

#import "OpportunityResult.h"

@implementation OpportunityResult

@end
