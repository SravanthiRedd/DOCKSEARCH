//
//  Store_List.h
//  RPRT
//
//  Created by sravanthi Gumma on 28/10/1938 Saka.
//  Copyright © 1938 Saka DevpointSolutions. All rights reserved.
//
#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>
#import "OpportunityResult.h"
#import "RMMapper.h"
#import "NSObject+RMArchivable.h"
@interface RTStore_List : NSObject<RMMapping>

@property (nonatomic, retain) NSNumber *UserRegisterId;
@property (nonatomic, retain) NSString *PhotoName;

@property (nonatomic, retain) NSString *LandLine;

@property (nonatomic, retain) NSString *ContactPerson;

@property (nonatomic, retain) NSString *PhoneNo;

@property (nonatomic, retain) NSString *RegUserName;

@property (nonatomic, retain) NSString *RegEmail;

@property (nonatomic, retain) NSString *UserType ;

@property (nonatomic, retain) NSString *DefaultAddress;

@property (nonatomic, retain) NSString *LatLong;

@property (nonatomic, retain) NSArray *Offers;

@property (nonatomic, retain) NSNumber *CustomerCount;

@property  (nonatomic, retain) NSString *Distance;

@property (nonatomic, retain) NSString *BusinessType;

@property(nonatomic, retain) NSString *CustomerReaction;

@property (nonatomic, retain) NSString *StoreDescription;

@property (nonatomic, retain) NSString *RequestStatus ;

@end
