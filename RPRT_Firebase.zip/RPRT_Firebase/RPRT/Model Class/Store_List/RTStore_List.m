//
//  Store_List.m
//  RPRT
//
//  Created by sravanthi Gumma on 28/10/1938 Saka.
//  Copyright © 1938 Saka DevpointSolutions. All rights reserved.
//

#import "RTStore_List.h"

@implementation RTStore_List
- (instancetype)init
{
    self = [super init];
    if (self) {
        
    }
    return self;
}


-(Class)rm_itemClassForArrayProperty:(NSString *)property {
    if ([property isEqualToString:@"Offers"]) {
        return [OpportunityResult class];
    }
    
    return nil;
}
@end
