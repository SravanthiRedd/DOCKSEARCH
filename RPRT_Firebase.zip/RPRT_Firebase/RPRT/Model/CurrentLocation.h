//
//  CurrentLocation.h
//  RPRT
//
//  Created by sravanthi Gumma on 12/02/16.
//  Copyright © 2016 DevpointSolutions. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreLocation/CoreLocation.h>
#import <MobileCoreServices/MobileCoreServices.h>
#import <UIKit/UIKit.h>
#import "GeoCodeLocation.h"


@interface CurrentLocation : NSObject<CLLocationManagerDelegate>
{
        CLLocationManager *locationManager;
        CLLocationCoordinate2D coordinate;
}
-(NSMutableDictionary*)getCurrentLatLog;
-(GeoCodeLocation*)getCurrentLocation;

+(CurrentLocation *)GetSharedInstance;

-(NSString*)GetLocationDistace:(NSMutableDictionary*)Location;
-(GeoCodeLocation*)geoCodeArea:(double*)Lat Longitude :(double*)Log;

@end
