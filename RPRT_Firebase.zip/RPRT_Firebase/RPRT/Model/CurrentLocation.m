//
//  CurrentLocation.m
//  RPRT
//
//  Created by sravanthi Gumma on 12/02/16.
//  Copyright © 2016 DevpointSolutions. All rights reserved.
//

#import "CurrentLocation.h"


static CurrentLocation *sharedInstance = nil;

@implementation CurrentLocation

+ (CurrentLocation *)GetSharedInstance {
    if (sharedInstance == nil) {
        
        sharedInstance = [[CurrentLocation alloc] init];
    }
    return sharedInstance;
}

-(GeoCodeLocation*)getCurrentLocation
{
    NSMutableDictionary *locatioLatLon;
    locatioLatLon = [self getCurrentLocVal];
    
    return [self geoCodeArea :&coordinate.latitude Longitude:&coordinate.longitude];
}




-(NSDictionary*)getCurrentLatLog
{
    NSMutableDictionary *locatioLatLon;
    locatioLatLon = [self getCurrentLocVal];
    
    return locatioLatLon;
}

- (NSMutableDictionary *)getCurrentLocVal
{
    locationManager = [[CLLocationManager alloc] init];
    locationManager.delegate = self;
    [locationManager setDesiredAccuracy:kCLLocationAccuracyBest];
    if ([[[UIDevice currentDevice] systemVersion] floatValue] >= 8) {
        [locationManager requestAlwaysAuthorization];
    }
    if ([[[UIDevice currentDevice] systemVersion] floatValue] >= 9.2) {
        locationManager.allowsBackgroundLocationUpdates = YES;
    }
    [locationManager startUpdatingLocation];
    
    CLLocation *location = [locationManager location];
    coordinate = [location coordinate];
    NSString *Latitude=[NSString stringWithFormat:@"%f",coordinate.latitude];
    NSString *Longitude=[NSString stringWithFormat:@"%f",coordinate.longitude];
    NSLog(@"lat %@",Latitude);
    NSLog(@"Lon %@",Longitude);
    NSMutableDictionary *locatioLatLon = [[NSMutableDictionary alloc]init];
    [locatioLatLon setValue:Latitude forKey:@"Latitude"];
    [locatioLatLon setValue:Longitude forKey:@"Longitude"];
    return locatioLatLon;
}



-(NSString*)GetLocationDistace:(NSMutableDictionary*)Location
{
      NSString *DestLatLon= [NSString stringWithFormat:@"%@,%@",[Location valueForKey:@"Latitude"],[Location valueForKey:@"Longitude"]];
    NSDictionary *CurrentLatLon = [self getCurrentLocation];
    
     NSString *CurentLatlon= [NSString stringWithFormat:@"%@,%@",[CurrentLatLon valueForKey:@"Latitude"],[CurrentLatLon valueForKey:@"Longitude"]];
    
    NSString *urlString = [NSString stringWithFormat:
                           @"https://maps.googleapis.com/maps/api/directions/json?origin=%@&destination=%@&mode=transit&key=AIzaSyA6_HQVIISO042VS4mX5WfJq0jk8wpTfXs",DestLatLon,CurentLatlon];
    NSURL *RPRTUrlpath = [NSURL URLWithString:urlString];
    
    NSData *myData = [NSData dataWithContentsOfURL:RPRTUrlpath];
    
    NSError* error1;
    
    NSArray *first = [NSJSONSerialization
                      JSONObjectWithData:myData
                      options:kNilOptions
                      error:&error1];
    NSDictionary *Routes= [first valueForKey:@"routes"];
    NSArray *legs= [Routes valueForKey:@"legs"];
    NSDictionary *ROutedata= [legs objectAtIndex:0];
    NSArray *Distance= [ROutedata valueForKey:@"distance"];
   
   NSString *distance=[ [Distance valueForKey:@"text"] objectAtIndex:0];
    
    
    return distance;
}

-(GeoCodeLocation*)geoCodeArea:(double*)Lat Longitude :(double*)Log {
    // This is important if you only want to receive one tap and hold event
    
    
    
    
   
    NSString *Latitude;
    NSString *Longitude;
    NSString *AddressName;
    
    

    
   
        double lat = *Lat;
        double lon = *Log;
        NSLog(@"sjkndkvjndfv%f",lat);
        NSLog(@"sjkndkvjndfv%f",lon);
        Latitude = [NSString stringWithFormat:@"%f",lat];
        Longitude = [NSString stringWithFormat:@"%f",lon];
        NSString *latlon=[NSString stringWithFormat:@"%@,%@",Latitude,Longitude];
        
        NSString *esc_addr =  [latlon stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
        
        NSString *req = [NSString stringWithFormat:@"https://maps.google.com/maps/api/geocode/json?sensor=false&address=%@", esc_addr];
        NSString *result = [NSString stringWithContentsOfURL:[NSURL URLWithString:req] encoding:NSUTF8StringEncoding error:NULL];
        NSMutableDictionary *data = [NSJSONSerialization JSONObjectWithData:[result dataUsingEncoding:NSUTF8StringEncoding]options:NSJSONReadingMutableContainers error:nil];
        NSMutableArray *dataArray = (NSMutableArray *)[data valueForKey:@"results"];
        NSDictionary *Collection =[dataArray objectAtIndex:0];
        
        AddressName = [Collection valueForKey:@"formatted_address"];
        NSArray *Addressary = [AddressName componentsSeparatedByString:@","];
        
    
    GeoCodeLocation *geoCode = [[GeoCodeLocation GetSharedInstance] initOffers:Addressary Lat:Latitude Log:Longitude];
    return geoCode;
    
//    NSMutableDictionary *locatioLatLon = [[NSMutableDictionary alloc]init];
//    [locatioLatLon setValue:Latitude forKey:@"Latitude"];
//    [locatioLatLon setValue:Longitude forKey:@"Longitude"];
    
       }
@end
