//
//  GeoCodeLocation.m
//  RPRT
//
//  Created by devpoint11 on 2/15/16.
//  Copyright © 2016 DevpointSolutions. All rights reserved.
//

#import "GeoCodeLocation.h"

static GeoCodeLocation *sharedInstance = nil;

@implementation GeoCodeLocation

@synthesize Address1 = Address1;
@synthesize Address2 = Address2;
@synthesize Address3 = Address3;
@synthesize AreaName = AreaName;
@synthesize City = City;
@synthesize State = State;
@synthesize Country = Country;
@synthesize Latitude = Latitude;
@synthesize Longitude = Longitude;
@synthesize addressLines =addressLines;
@synthesize countryCode = countryCode;
@synthesize postalCode = postalCode;



@synthesize feature = feature;
@synthesize admin = admin;
@synthesize subadmin = subadmin;
@synthesize locality = locality;
@synthesize thoroughfare = thoroughfare;
@synthesize hasLatitude =hasLatitude;
@synthesize hasLongitude = hasLongitude;
@synthesize phone = phone;
@synthesize url = url;
@synthesize extras = extras;
@synthesize AddresName = AddresName;


NSString *Address1;
NSString *Address2;
NSString *Address3;
NSString *AreaName;
NSString *City;
NSString *State;
NSString *Country;
NSString *addressLines;

+(GeoCodeLocation*)GetSharedInstance{
        if (sharedInstance == nil) {
            
        sharedInstance = [[GeoCodeLocation alloc] init];
    }
    return sharedInstance;
}


- (id)initOffers:(NSDictionary *)GeoCodeRes Latitude:(NSString*)Latitu  Longitude:(NSString*)Longi{
    self = [super init];
    if (self) {       
        if ( [[GeoCodeRes valueForKey:@"Address1"] isKindOfClass:[NSNull class]]) {
            self.Address1 =@"";
        }
        else
            self.Address1 =
            [GeoCodeRes valueForKey:@"Address1"] ;
        
        
        
        if ( [[GeoCodeRes valueForKey:@"Address2"] isKindOfClass:[NSNull class]]) {
            self.Address2 =@"";
        }
        else
            self.Address2 =
            [GeoCodeRes valueForKey:@"Address2"] ;
        
        
        if ( [[GeoCodeRes valueForKey:@"Address3"] isKindOfClass:[NSNull class]]) {
            self.Address3 =@"";
        }
        else
            self.Address3 =
            [GeoCodeRes valueForKey:@"Address3"] ;
        
        
        if ( [[GeoCodeRes valueForKey:@"AddressName"] isKindOfClass:[NSNull class]]) {
            self.AddresName =@"";
        }
        else
            self.AddresName =
            [GeoCodeRes valueForKey:@"AddressName"] ;
        
        
        if ( [[GeoCodeRes valueForKey:@"AreaName"] isKindOfClass:[NSNull class]]) {
            self.AreaName =@"";
        }
        else
            self.AreaName =
            [GeoCodeRes valueForKey:@"AreaName"] ;
        
        
        if ( [[GeoCodeRes valueForKey:@"City"] isKindOfClass:[NSNull class]]) {
            self.City =@"";
        }
        else
            self.City =
            [GeoCodeRes valueForKey:@"City"] ;
        
        
        if ( [[GeoCodeRes valueForKey:@"Country"] isKindOfClass:[NSNull class]]) {
            self.Country =@"";
        }
        else
            self.Country =
            [GeoCodeRes valueForKey:@"Country"] ;
        
        
        if ( [Longi isKindOfClass:[NSNull class]]) {
            self.Longitude =@"";
        }
        else
            self.Longitude =
            Longi ;
        
        
        if ( [Latitu isKindOfClass:[NSNull class]]) {
            self.Latitude =@"";
        }
        else
            self.Latitude =
           Latitu ;
        
        
        if ( [[GeoCodeRes valueForKey:@"State"] isKindOfClass:[NSNull class]]) {
            self.State =@"";
        }
        else
            self.State =
            [GeoCodeRes valueForKey:@"State"] ;
        
        
        if ( [[GeoCodeRes valueForKey:@"ZipCode"] isKindOfClass:[NSNull class]]) {
            self.postalCode =@"";
        }
        else
            self.postalCode =
            [GeoCodeRes valueForKey:@"ZipCode"] ;
        
        
        if ( [[GeoCodeRes valueForKey:@"CountryCode"] isKindOfClass:[NSNull class]]) {
            self.countryCode =@"";
        }
        else
            self.countryCode =
            [GeoCodeRes valueForKey:@"CountryCode"] ;
        
        
//        if () {
//            //CountryCode<#statements#>
//        }
    

        
    }
    return self;
}

@end
