//
//  MyLocation.h
//  RPRT
//
//  Created by sravanthi Gumma on 23/09/1938 Saka.
//  Copyright © 1938 Saka DevpointSolutions. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MyLocation : NSObject
@property  NSString *Address1;
@property  NSString *Address2;
@property  NSString *Address3;
@property  NSString *AreaName;
@property  NSString *City;
@property  NSString *State;
@property  NSString *Country;
@property  NSString *Latitude;
@property  NSString *Longitude;
@property NSString *feature;
@property NSString *admin;
@property NSString *subadmin;
@property NSString *locality;
@property NSString *thoroughfare;
@property NSString *postalCode;
@property NSString *countryCode;
@property NSString *countryName;
@property NSString *hasLatitude;
@property NSString *hasLongitude;
@property NSString *phone;
@property NSString *url;
@property NSString *extras;
@property NSString*AddresName;
@property NSString *addressLines;
@property NSString *ZipCode;

+(MyLocation *)GetSharedInstance;
-(id)initLocation:(NSDictionary *)MyLocationObject;

@end
