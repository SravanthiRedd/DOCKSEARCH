//
//  MyLocation.m
//  RPRT
//
//  Created by sravanthi Gumma on 23/09/1938 Saka.
//  Copyright © 1938 Saka DevpointSolutions. All rights reserved.
//

#import "MyLocation.h"

@implementation MyLocation
static MyLocation *sharedInstance = nil;


@synthesize Address1 = Address1;
@synthesize Address2 = Address2;
@synthesize Address3 = Address3;
@synthesize AreaName = AreaName;
@synthesize City = City;
@synthesize State = State;
@synthesize Country = Country;
@synthesize Latitude = Latitude;
@synthesize Longitude = Longitude;
@synthesize addressLines =addressLines;
@synthesize countryCode = countryCode;
@synthesize ZipCode = ZipCode;

@synthesize thoroughfare = thoroughfare;
@synthesize hasLatitude =hasLatitude;
@synthesize hasLongitude = hasLongitude;
@synthesize AddresName = AddresName;




+(MyLocation*)GetSharedInstance{
    if (sharedInstance == nil) {
        
        sharedInstance = [[MyLocation alloc] init];
    }
    return sharedInstance;
}

-(id)initLocation:(NSDictionary *)MyLocationObject{
    self = [super init];
    if (self) {
        
        if ( [[MyLocationObject valueForKey:@"Address1"] isKindOfClass:[NSNull class]]) {
            self.Address1 =@"";
        }
        else
            self.Address1 =
            [MyLocationObject valueForKey:@"Address1"] ;
        
        
        
        if ( [[MyLocationObject valueForKey:@"Address2"] isKindOfClass:[NSNull class]]) {
            self.Address2 =@"";
        }
        else
            self.Address2 =
            [MyLocationObject valueForKey:@"Address2"] ;

        
        if ( [[MyLocationObject valueForKey:@"Address3"] isKindOfClass:[NSNull class]]) {
            self.Address3 =@"";
        }
        else
            self.Address3 =
            [MyLocationObject valueForKey:@"Address3"] ;

        
        if ( [[MyLocationObject valueForKey:@"AddressName"] isKindOfClass:[NSNull class]]) {
            self.AddresName =@"";
        }
        else
            self.AddresName =
            [MyLocationObject valueForKey:@"AddressName"] ;

        
        if ( [[MyLocationObject valueForKey:@"AreaName"] isKindOfClass:[NSNull class]]) {
            self.AreaName =@"";
        }
        else
            self.AreaName =
            [MyLocationObject valueForKey:@"AreaName"] ;

        
        if ( [[MyLocationObject valueForKey:@"City"] isKindOfClass:[NSNull class]]) {
            self.City =@"";
        }
        else
            self.City =
            [MyLocationObject valueForKey:@"City"] ;

        
        if ( [[MyLocationObject valueForKey:@"Country"] isKindOfClass:[NSNull class]]) {
            self.Country =@"";
        }
        else
            self.Country =
            [MyLocationObject valueForKey:@"Country"] ;

        
        if ( [[MyLocationObject valueForKey:@"Longitude"] isKindOfClass:[NSNull class]]) {
            self.Longitude =@"";
        }
        else
            self.Longitude =
            [MyLocationObject valueForKey:@"Longitude"] ;

        
        if ( [[MyLocationObject valueForKey:@"Latitude"] isKindOfClass:[NSNull class]]) {
            self.Latitude =@"";
        }
        else
            self.Latitude =
            [MyLocationObject valueForKey:@"Latitude"] ;

        
        if ( [[MyLocationObject valueForKey:@"State"] isKindOfClass:[NSNull class]]) {
            self.State =@"";
        }
        else
            self.State =
            [MyLocationObject valueForKey:@"State"] ;

        
        if ( [[MyLocationObject valueForKey:@"ZipCode"] isKindOfClass:[NSNull class]]) {
            self.ZipCode =@"";
        }
        else
            self.ZipCode =
            [MyLocationObject valueForKey:@"ZipCode"] ;
        }
return self;
}


@end
