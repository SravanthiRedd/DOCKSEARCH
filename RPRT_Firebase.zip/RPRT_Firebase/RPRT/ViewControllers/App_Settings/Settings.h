//
//  Settings.h
//  RPRT
//
//  Created by sravanthi Gumma on 03/10/16.
//  Copyright © 2016 DevpointSolutions. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MainViewController.h"


@interface Settings : UIViewController<UITableViewDelegate,UITableViewDataSource>

{
    NSDictionary *locationDetails;
}

@property(strong,nonatomic) NSDictionary * locationDetilsObj;
@property(weak,nonatomic)IBOutlet UIButton *categoryBtn;
@property(strong,nonatomic) UITableView *categoryTable;

@property (weak,nonatomic) IBOutlet UITextField *addressField;
@property(weak,nonatomic)IBOutlet UIButton *radiusBtn;

@property (weak, nonatomic) IBOutlet UIView *Contentview;
@property (weak, nonatomic) IBOutlet UIScrollView *scrollview;



@end
