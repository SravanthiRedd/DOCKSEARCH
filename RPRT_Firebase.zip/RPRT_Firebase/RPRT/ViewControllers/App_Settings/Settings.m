//
//  Settings.m
//  RPRT
//
//  Created by sravanthi Gumma on 03/10/16.
//  Copyright © 2016 DevpointSolutions. All rights reserved.
//

#import "Settings.h"
#import "Setting_Cell.h"
#import "Constances.h"

@interface Settings ()
{
    NSArray *categoryItems;
     BOOL isMultipleSelection;
    NSArray *radiusItems;
    UITableView *radTable;
    NSString *selectedRadius;
    NSUserDefaults *mPrefs;
    NSDictionary *selectedCategories;
    Web_Services *mWebServices;
    NSString *UserSettingsID;
     GeoCodeLocation *geoCode;
    NSString *latLong;
 //   NSMutableArray
}

@property(strong ,nonatomic)  NSMutableArray *checkedArray;
@end

@implementation Settings

@synthesize checkedArray;

- (void)viewDidLoad {
    [super viewDidLoad];
    selectedRadius = @"";
    UserSettingsID = @"";
    latLong= @"";
    self.categoryBtn.tag = 0;
     mPrefs = [NSUserDefaults standardUserDefaults];
    mWebServices = [Web_Services GetSharedInstance];
    geoCode = [GeoCodeLocation GetSharedInstance];
    
     // isMultipleSelection=isMultiple;
    
    checkedArray = [[NSMutableArray alloc]init];
    
    self.categoryTable = [[UITableView alloc]initWithFrame:CGRectMake(self.categoryBtn.frame.origin.x, self.categoryBtn.frame.origin.y+40, self.categoryBtn.frame.size.width, 200) style:UITableViewStylePlain];
    
     self.categoryTable.layer.borderColor = [UIColor colorWithRed:198.0/256.0 green:198.0/256.0 blue:198.0/256.0 alpha:1].CGColor;
    
    self.categoryTable.delegate= self;
    self.categoryTable.dataSource = self;
    [self.categoryTable setHidden:YES];
    [self.Contentview addSubview:self.categoryTable];
    
    NSString *path = [[NSBundle mainBundle] pathForResource:CATEGORY ofType:@"plist"];
    NSMutableDictionary *dict = [NSMutableDictionary dictionaryWithContentsOfFile:path];
    categoryItems = [dict valueForKey:@"Categories"];
    
    radiusItems = [dict valueForKey:@"Radious"];
    
     radTable = [[UITableView alloc]initWithFrame:CGRectMake(self.radiusBtn.frame.origin.x, self.radiusBtn.frame.origin.y+40, self.radiusBtn.frame.size.width, 200) style:UITableViewStylePlain];
    radTable.layer.borderColor = [UIColor colorWithRed:198.0/256.0 green:198.0/256.0 blue:198.0/256.0 alpha:1].CGColor;
    radTable.delegate = self;
    radTable.dataSource = self;
    [radTable setHidden:YES];
    [self.Contentview addSubview:radTable];
    
    [self getUserSeetings];
    
    
    if (geoCode!=nil) {
        self.addressField.text = [NSString stringWithFormat:@"%@,%@",geoCode.Address1,geoCode.AreaName];
        latLong = [NSString stringWithFormat:@"%@,%@",geoCode.Latitude,geoCode.Longitude];
    }
    
    
    self.addressField.layer.borderColor = [UIColor colorWithRed:198.0/256.0 green:198.0/256.0 blue:198.0/256.0 alpha:1].CGColor;
    self.addressField.layer.borderWidth=1;
    
    
    // Do any additional setup after loading the view from its nib.
}


-(void)getUserSeetings
{
   // NSDictionary *gerUserSettingResponse = [mWebServices GetUserSettings:[mPrefs valueForKey:USERREGISTERID]];
    
    
    
    
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}





-(IBAction)back:(id)sender
{
    [self dismissViewControllerAnimated:YES completion:nil];
}

-(IBAction)selectCategories:(id)sender
{
    if (self.categoryBtn.tag == 0) {
        self.categoryBtn.tag =1;
        [self.categoryTable setHidden:NO];
        [self.categoryTable reloadData];
    }
    else if(self.categoryBtn.tag == 1)
    {
        self.categoryBtn.tag =0;
        [self.categoryTable setHidden:YES];
        //[self.categoryTable reloadData];
      //  [
        
        // [NSString stringWithFormat:@"%@",[self selectedCategories]];
        
         selectedCategories = [self selectedCategories];
        
        [self.categoryBtn setTitle: [NSString stringWithFormat:@"%@",[selectedCategories valueForKey:@"CategoryName"]] forState:UIControlStateNormal];
    }
    
   
}

-(NSDictionary*)selectedCategories
{
    
    NSMutableArray *arryResponceData=[[NSMutableArray alloc]init];
      NSMutableArray *arryCatIDs=[[NSMutableArray alloc]init];
    

    
    for (int i=0; i<[checkedArray count]; i++) {
     NSIndexPath *path=[self.checkedArray objectAtIndex:i];
        NSString *res = [[categoryItems objectAtIndex:path.row] valueForKey:@"CategoryName"];
        
        [arryResponceData addObject:res];
        
        NSString *catId = [[categoryItems objectAtIndex:path.row] valueForKey:@"CategoryID"];
        [arryCatIDs addObject:catId];

        
    }
    
    NSMutableDictionary *category = [[NSMutableDictionary alloc]init];
    [category setValue:[arryResponceData componentsJoinedByString:@","]  forKey:@"CategoryName"];
    [category setValue:[arryCatIDs componentsJoinedByString:@","]  forKey:@"CategoryID"];

    
 //   NSString *categorystring =[arryResponceData componentsJoinedByString:@" & "];

    
    return category;
}


-(IBAction)selectRadius:(id)sender
{
    [radTable setHidden:NO];
    [radTable reloadData];
}

-(void) viewDidLayoutSubviews {
    
    @try {
        [super viewDidLayoutSubviews];
        [self.scrollview layoutIfNeeded];
        self.scrollview.contentSize=self.Contentview.bounds.size;
        UIGraphicsBeginImageContext(self.view.frame.size);
        UIImage *image = UIGraphicsGetImageFromCurrentImageContext();
        UIGraphicsEndImageContext();
        self.Contentview.backgroundColor = [UIColor colorWithPatternImage:image];
    } @catch (NSException *exception) {
        //[self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    @try {
        
        if (self.categoryTable== tableView) {
            return [categoryItems count];
        }
        else if (radTable == tableView)
        {
            return  [radiusItems count];
        }
            
        
    } @catch (NSException *exception) {
        //[self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
    
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
        return 50;
    
}


// This will tell your UITableView what data to put in which cells in your table.
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    @try {
        
        if (tableView == self.categoryTable) {
        
        Setting_Cell *cell = (Setting_Cell *)[tableView dequeueReusableCellWithIdentifier:@"Setting_Cell"];
        if (cell == nil)
        {
            NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"Setting_Cell" owner:self options:nil];
            cell = [nib objectAtIndex:0];
        }
        // tableView.backgroundColor = [UIColor blackColor];
        
        
        
        cell.categoryName.text = [categoryItems[indexPath.row] valueForKey:@"CategoryName"];
        
        if([checkedArray containsObject:indexPath]){
            cell.check.image=[UIImage imageNamed:@"aftercheck.png"];
           // cell.check.backgroundColor = [UIColor lightGrayColor];
        } else
            cell.check.image=[UIImage imageNamed:@"beforecheck.png"];//uncheck.png
        
        return cell;
        }
        
        else if (tableView == radTable)
        {
            static NSString *CellIdentifier = @"Cell";
            // Reuse and create cell
            UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
            if (cell == nil) {
                cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
            }
            NSString *Addreline = [[radiusItems objectAtIndex:indexPath.row] valueForKey:@"Value"];
            cell.textLabel.text = Addreline;
            return cell;
 
            
        }
        
        
    } @catch (NSException *exception) {
       // [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
    
    
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
    @try {
        
        if (tableView == self.categoryTable) {
            if([checkedArray containsObject:indexPath]){
                [checkedArray removeObject:indexPath];
            } else {
                [checkedArray addObject:indexPath];
            }
            [tableView reloadData];
            
        }
        else if (tableView == radTable)
        {
            selectedRadius =[[radiusItems objectAtIndex:indexPath.row] valueForKey:@"Radious"];
        // NSString   *selectedrad =[[radiusItems objectAtIndex:indexPath.row] valueForKey:@"Radious"];
            [self.radiusBtn setTitle:[[radiusItems objectAtIndex:indexPath.row] valueForKey:@"Value"] forState:UIControlStateNormal];
            [radTable setHidden:YES];
        }
        
          } @catch (NSException *exception) {
      //  [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
    
}

-(IBAction)saveUserSeetings:(id)sender
{
    
    
 UIActivityIndicatorView   *spinner = [[UIActivityIndicatorView alloc]
               initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
    spinner.frame = CGRectMake(0, 0, 320, 560); // CGPointMake(160, 240);
    spinner.color = [UIColor blueColor];
    spinner.backgroundColor = [UIColor lightTextColor];
    spinner.transform = CGAffineTransformMakeScale(2, 2);
    // spinner.hidesWhenStopped = YES;
    [self.view addSubview:spinner];
    spinner.transform = CGAffineTransformMakeScale(2, 2);
    
    [spinner startAnimating];
    
    // how we stop refresh from freezing the main UI thread
    
    dispatch_async(
                   dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^{
                       
                       // back to the main thread for the UI call
                       dispatch_async(dispatch_get_main_queue(), ^{
                           [spinner startAnimating];
                       });
                       dispatch_async(dispatch_get_main_queue(), ^{

    
    
    NSString *userRegistedId = [mPrefs valueForKey:USERREGISTERID];
    
    NSString *catIds =[selectedCategories valueForKey:@"CategoryID"];
    
    
    NSDate *currentDateInLocal = [NSDate date];
    
    NSDateFormatter *formatter = [[NSDateFormatter alloc]init];
    [formatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
    NSTimeZone *gmt = [NSTimeZone timeZoneWithAbbreviation:@"UTC"];
    [formatter setTimeZone:gmt];
    NSString *StartTimecon = [formatter stringFromDate:currentDateInLocal];
    
    NSDictionary *usersettingObj = @{@"UserSettingsID":@"0",
                                     @"UserID":userRegistedId,
                                     @"SendNotifications":@"true",
                                     @"NotifyCategories":catIds,
                                     @"DefaultRadius":selectedRadius,
                                     @"DefaultAddress":self.addressField.text,
                                     @"UserIdCreated":userRegistedId,
                                     @"CreatedDate":StartTimecon,
                                     @"UserIdModified":userRegistedId,
                                     @"ModifiedDate":StartTimecon,
                                     @"RowStatus":@"A",
                                     @"LatLong":@""
                                     };
    NSDictionary *response = [mWebServices SaveUserSettings:usersettingObj];
    NSLog(@"%@",response);
    
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"Right Place Right Time"
                                                                   message:@"App Settings saved sucessfully!"
                                                            preferredStyle:UIAlertControllerStyleAlert];
    
    UIAlertAction* defaultAction = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault
                                                          handler:^(UIAlertAction * action) {
                                                              
                                                              Home  *mHome = [[Home alloc]initWithNibName:HOMEDASHBOARD bundle:nil];
                                                              [self presentViewController:mHome animated:YES completion:nil];
                                                              
                                                          }];
    
    [alert addAction:defaultAction];
    
    [self presentViewController:alert animated:YES completion:nil];
    
                           [spinner stopAnimating];
                       });
                   });
    
    
    
}


@end
