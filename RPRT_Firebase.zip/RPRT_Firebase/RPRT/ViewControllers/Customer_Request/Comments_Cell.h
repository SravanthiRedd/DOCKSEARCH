//
//  Comments_Cell.h
//  RPRT
//
//  Created by sravanthi Gumma on 18/09/1938 Saka.
//  Copyright © 1938 Saka DevpointSolutions. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Comments_Cell : UITableViewCell
@property(nonatomic,weak) IBOutlet UILabel *storename;
@property(nonatomic,weak) IBOutlet UILabel *storeComments;
@property(nonatomic,weak) IBOutlet UILabel *storeCommentslabel;
@property(nonatomic,weak) IBOutlet UIButton *storeReplyBtn;
@property(nonatomic,weak) IBOutlet UIImageView *storeImage;
@property(nonatomic,weak) IBOutlet UIView *customView;
@end
