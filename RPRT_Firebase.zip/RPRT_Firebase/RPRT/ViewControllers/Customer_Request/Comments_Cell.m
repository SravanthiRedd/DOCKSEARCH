//
//  Comments_Cell.m
//  RPRT
//
//  Created by sravanthi Gumma on 18/09/1938 Saka.
//  Copyright © 1938 Saka DevpointSolutions. All rights reserved.
//

#import "Comments_Cell.h"

@implementation Comments_Cell

@synthesize storename= storename;
@synthesize storeReplyBtn = storeReplyBtn;
@synthesize storeImage = storeImage;
@synthesize storeComments = storeComments;
@synthesize storeCommentslabel = storeCommentslabel;

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

//-(void)layoutSubviews{
//    
//    self.customView.layer.shadowColor = [UIColor grayColor].CGColor;
//    self.customView.layer.borderColor = [UIColor colorWithRed:175.0/256.0 green:175.0/256.0 blue:175.0/256.0 alpha:1].CGColor;
//    self.customView.layer.borderWidth=0.5f;
//    self.customView.layer.shadowOffset = CGSizeMake(1.0, 1.0);
//    self.customView.layer.shadowOpacity = 0.7;
//    self.customView.layer.cornerRadius = 4.0;
//    
//}


@end
