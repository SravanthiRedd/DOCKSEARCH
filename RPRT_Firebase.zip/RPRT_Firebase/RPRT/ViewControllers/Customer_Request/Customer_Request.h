//
//  Customer_Request.h
//  RPRT
//
//  Created by sravanthi Gumma on 18/09/1938 Saka.
//  Copyright © 1938 Saka DevpointSolutions. All rights reserved.
//

#import <UIKit/UIKit.h>
@interface Customer_Request : UIViewController<UITextViewDelegate,UITableViewDelegate,UITableViewDataSource>
{
    NSDictionary *GetStoreInfo;
}
@property (strong,nonatomic) NSDictionary *StoreInfo;

@property(weak,nonatomic) IBOutlet UIView *requestView;
//@property (weak,nonatomic)  UITextView *requesttext;
@property(strong,nonatomic ) IBOutlet UIButton *PrioBtn;
@property(weak,nonatomic) IBOutlet  UITableView *customerRequestTable;

@end
