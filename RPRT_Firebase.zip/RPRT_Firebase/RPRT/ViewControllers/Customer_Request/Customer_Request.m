//
//  Customer_Request.m
//  RPRT
//
//  Created by sravanthi Gumma on 18/09/1938 Saka.
//  Copyright © 1938 Saka DevpointSolutions. All rights reserved.
//

#import "Customer_Request.h"
#import "Web_Services.h"
#import <QuartzCore/QuartzCore.h>
#import "Comments_Cell.h"
#import "CustomIOSAlertView.h"
#import "Customer_childcell.h"
#define isNSNull(value) [value isKindOfClass:[NSNull class]]
@interface Customer_Request ()<CustomIOSAlertViewDelegate>
{
    Web_Services *mWebService;
    NSUserDefaults *mPref;
    NSArray *priorityArray;
    UITableView *priotable;
    NSMutableArray *userRequestarray;
    NSString *RequestPriority;
    NSString *reply;
    CustomIOSAlertView *replyalert;
    UITextView *requesttext;
    NSDictionary *selectedObject;
    NSString *customerID;
    UIRefreshControl *refreshController;
}
@property (nonatomic,weak) IBOutlet UITableView *tblForCollapse;
@property (nonatomic, retain) NSArray *arrayOriginal;
@property (nonatomic, retain) NSMutableArray *arForTable;

-(void)miniMizeThisRows:(NSArray*)ar;

@end

@implementation Customer_Request

@synthesize arrayOriginal,arForTable;


- (void)viewDidLoad {
    [super viewDidLoad];
    mWebService = [Web_Services GetSharedInstance];
    mPref = [NSUserDefaults standardUserDefaults];
    RequestPriority = @"1";
    customerID = @"0";
    GetStoreInfo = self.StoreInfo;
    priorityArray = [NSArray arrayWithObjects:@"High",@"Normal",@"Low", nil];
     priotable = [[UITableView alloc]initWithFrame:CGRectMake(self.PrioBtn.frame.origin.x, self.PrioBtn.frame.origin.y-50, self.PrioBtn.frame.size.width, 150) style:UITableViewStylePlain];
    priotable.delegate= self;
    priotable.dataSource = self;
    priotable.hidden = YES;
    [self.requestView addSubview:priotable];
    reply= @"Indicator";
   
    
    self.requestView.layer.shadowColor = [UIColor grayColor].CGColor;
    self.requestView.layer.borderColor = [UIColor colorWithRed:175.0/256.0 green:175.0/256.0 blue:175.0/256.0 alpha:1].CGColor;
    self.requestView.layer.borderWidth=0.5f;
    self.requestView.layer.shadowOffset = CGSizeMake(1.0, 1.0);
    self.requestView.layer.shadowOpacity = 0.7;
    self.requestView.layer.cornerRadius = 4.0;
    
    NSDictionary *dTmp = [[NSDictionary alloc] initWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"data" ofType:@"plist"]];
    self.arrayOriginal = [dTmp valueForKey:@"Objects"];
    
    self.arForTable = [[NSMutableArray alloc] init];
    [self.arForTable addObjectsFromArray:self.arrayOriginal];
    self.title=@"Sugartin.info";
    
    refreshController = [[UIRefreshControl alloc] init];
    refreshController.tintColor = [UIColor grayColor];
    [refreshController addTarget:self action:@selector(refershControlAction) forControlEvents:UIControlEventValueChanged];
    [self.customerRequestTable addSubview:refreshController];
    self.customerRequestTable.alwaysBounceVertical = YES;
 
    [self GetCustoreRequest];
    
}

-(void)refershControlAction
{
    [refreshController endRefreshing];
     [self GetCustoreRequest];
    
}

-(void)GetCustoreRequest
{
    
    NSString *storeID = [GetStoreInfo valueForKey:@"UserRegisterId"];
    NSString *customerId = [mPref valueForKey:USERREGISTERID];
    NSDictionary *dic;
    
    if ([[mPref valueForKey:LOGINTYPE] isEqualToString:@"Business"]) {
        if (storeID !=customerId ) {
            dic =@{ @"RequestId": @"0",
                    @"StoreId": storeID,
                    @"CustomerId": customerId,
                    @"OpportunityId": @"0"
                    
                    };
        }
        else
        {
        dic =@{ @"RequestId": @"0",
                @"StoreId": storeID,
                @"CustomerId": @"0",
                @"OpportunityId": @"0"
                };
        }
    }
    else  if ([[mPref valueForKey:LOGINTYPE] isEqualToString:@"Individual"]) {
        
            dic =@{ @"RequestId": @"0",
                    @"StoreId": storeID,
                    @"CustomerId": customerId,
                    @"OpportunityId": @"0"
                    
                    };
        }
   arrayOriginal = [mWebService GetCustomerRequests:dic];
    
    arForTable = [[NSMutableArray alloc] init];
    [arForTable addObjectsFromArray:arrayOriginal];
   
    
}

-(void)customReply
{
        replyalert=[[CustomIOSAlertView alloc] init];
    UIView  *replyView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 300, 250)];
        [replyalert setContainerView:replyView];
        [replyalert setButtonTitles:[NSMutableArray arrayWithObjects:@"", nil]];
    
        [replyalert setDelegate:self];
    
    
        // You may use a Block, rather than a delegate.
        [replyalert setOnButtonTouchUpInside:^(CustomIOSAlertView *alertView, int buttonIndex) {
            NSLog(@"Block: Button at position %d is clicked on alertView %d.", buttonIndex, (int)[alertView tag]);
            [alertView close];
        }];
    
        [replyalert setUseMotionEffects:true];
    
    
        UILabel *requestTitle = [[UILabel alloc]initWithFrame:CGRectMake(5, 5, 200, 20)];
        requestTitle.text = @"Right Place Right Time";
        [requestTitle setFont:[UIFont fontWithName:@"Roboto-Medium" size:14]];
    
    
        UIButton *cancel = [[UIButton alloc]initWithFrame:CGRectMake(275, 0, 20, 20)];
    
        [cancel setImage:[UIImage imageNamed:@"ic_close"] forState:UIControlStateNormal];
        [cancel addTarget:self action:@selector(cancel:) forControlEvents:UIControlEventTouchUpInside];
        [replyView addSubview:requestTitle];
    
        UILabel *requestName = [[UILabel alloc]initWithFrame:CGRectMake(5, 30, 100, 20)];
        requestName.text = @"Request :";
        [requestName setFont:[UIFont fontWithName:@"Roboto-Medium" size:14]];
        [replyView addSubview:requestName];
    
         requesttext = [[UITextView alloc]initWithFrame:CGRectMake(5, 50, 290, 140)];
        requesttext.delegate= self;
        requesttext.layer.borderColor = [UIColor lightTextColor].CGColor;
        [replyView addSubview:requesttext];
    
        UIButton *sendBtn = [[UIButton alloc] initWithFrame:CGRectMake(50, 200, 200, 40)];
        [sendBtn setTitle:@"Send" forState:UIControlStateNormal];
        [sendBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        [sendBtn addTarget:self action:@selector(sendBtn:) forControlEvents:UIControlEventTouchUpInside];
        sendBtn.backgroundColor =[UIColor colorWithRed:144.0/256.0 green:147.0/256.0 blue:167.0/256.0 alpha:1];
        [replyView addSubview:sendBtn];
        
        [replyView addSubview:cancel];
        
        [replyalert show];
        replyView.tag = 2;

}


-(void)customRequest
{
    replyalert=[[CustomIOSAlertView alloc] init];
    UIView  *replyView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 300, 250)];
    [replyalert setContainerView:replyView];
    [replyalert setButtonTitles:[NSMutableArray arrayWithObjects:@"", nil]];
    
    [replyalert setDelegate:self];
    
    
    // You may use a Block, rather than a delegate.
    [replyalert setOnButtonTouchUpInside:^(CustomIOSAlertView *alertView, int buttonIndex) {
        NSLog(@"Block: Button at position %d is clicked on alertView %d.", buttonIndex, (int)[alertView tag]);
        [alertView close];
    }];
    
    [replyalert setUseMotionEffects:true];
    
    
    UILabel *requestTitle = [[UILabel alloc]initWithFrame:CGRectMake(5, 5, 200, 20)];
    requestTitle.text = @"Right Place Right Time";
    [requestTitle setFont:[UIFont fontWithName:@"Roboto-Medium" size:14]];
    
    
    UIButton *cancel = [[UIButton alloc]initWithFrame:CGRectMake(275, 0, 20, 20)];
    
    [cancel setImage:[UIImage imageNamed:@"ic_close"] forState:UIControlStateNormal];
    [cancel addTarget:self action:@selector(cancel:) forControlEvents:UIControlEventTouchUpInside];
    [replyView addSubview:requestTitle];
    
    UILabel *requestName = [[UILabel alloc]initWithFrame:CGRectMake(5, 30, 100, 20)];
    requestName.text = @"Request :";
    [requestName setFont:[UIFont fontWithName:@"Roboto-Medium" size:14]];
    [replyView addSubview:requestName];
    
    requesttext = [[UITextView alloc]initWithFrame:CGRectMake(5, 50, 290, 140)];
    requesttext.delegate= self;
    requesttext.layer.borderColor = [UIColor lightTextColor].CGColor;
    [replyView addSubview:requesttext];
    
    UIButton *sendBtn = [[UIButton alloc] initWithFrame:CGRectMake(50, 200, 200, 40)];
    [sendBtn setTitle:@"Send" forState:UIControlStateNormal];
    [sendBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [sendBtn addTarget:self action:@selector(requestBtn:) forControlEvents:UIControlEventTouchUpInside];
    sendBtn.backgroundColor =[UIColor colorWithRed:144.0/256.0 green:147.0/256.0 blue:167.0/256.0 alpha:1];
    [replyView addSubview:sendBtn];
    
    [replyView addSubview:cancel];
    
    [replyalert show];
    replyView.tag = 3;
    
}
-(void)requestBtn:(UIButton*)sender
{
    [requesttext resignFirstResponder];
    
    NSString *storeID = [GetStoreInfo valueForKey:@"UserRegisterId"];
    NSString *customerId = [mPref valueForKey:USERREGISTERID];
    
    NSData  *VendorData =    [mPref valueForKey:@"SaveRegisterDetails"];
    NSDictionary   *myDictionary =   (NSDictionary*) [NSKeyedUnarchiver unarchiveObjectWithData:VendorData];
    
    NSString *Customer =  [myDictionary valueForKey:@"RegUserName"];
    NSString *storeName = [GetStoreInfo valueForKey:@"RegUserName"];
    NSDateFormatter *dateFormat = [[NSDateFormatter alloc] init];
    [dateFormat setDateFormat: @"yyyy-MM-dd HH:mm:ss"];
    
    //Optionally for time zone conversions
    [dateFormat setTimeZone:[NSTimeZone timeZoneWithAbbreviation:@"UTC"]];
    
    NSString *stringFromDate = [dateFormat stringFromDate:[NSDate date]];
    
    NSDictionary *dic =   @{ @"RequestId": @"0",
                             @"StoreId": storeID,
                             @"CustomerId": customerId,
                             @"OpportunityId": @"",
                             @"RequestType": @"Request",
                             @"RequestDescription":requesttext.text,
                             @"RequestDate": stringFromDate,
                             @"ParentId": @"",
                             @"RequestPriority":@"1",
                             @"RowStatus": @"A",
                             @"StoreName": storeName,
                             @"Customer": Customer,
                             @"FromUserId":customerId
                             };
    
    [mWebService SaveRequestReply:dic];
    arrayOriginal = [mWebService GetCustomerRequests:dic];
    
    arForTable = [[NSMutableArray alloc] init];
    [arForTable addObjectsFromArray:arrayOriginal];

    [self.customerRequestTable reloadData];
    [replyalert close];

}



-(void)sendBtn:(UIButton*)sender
{
  
    //GetStoreInfo
    [requesttext resignFirstResponder];
    
    NSString *storeID = [selectedObject valueForKey:@"StoreId"];
    NSString *customerId = [selectedObject valueForKey:@"CustomerId"];
    
//    NSData  *VendorData =    [mPref valueForKey:@"SaveRegisterDetails"];
//    NSDictionary   *myDictionary =   (NSDictionary*) [NSKeyedUnarchiver unarchiveObjectWithData:VendorData];
    
    NSString *Customer =  [selectedObject valueForKey:@"Customer"];
    NSString *storeName = [selectedObject valueForKey:@"StoreName"];
    NSDateFormatter *dateFormat = [[NSDateFormatter alloc] init];
    [dateFormat setDateFormat: @"yyyy-MM-dd HH:mm:ss"];
    //NSString *ParentId = [selectedObject valueForKey:@""];
    
    //Optionally for time zone conversions
    [dateFormat setTimeZone:[NSTimeZone timeZoneWithAbbreviation:@"UTC"]];
    
    NSString *stringFromDate = [dateFormat stringFromDate:[NSDate date]];
    NSString *parentId =[NSString stringWithFormat:@"%@",[selectedObject valueForKey:@"ParentId"]];
    if ([parentId isEqualToString:@"0"]) {
        parentId =[NSString stringWithFormat:@"%@",[selectedObject valueForKey:@"RequestId"]];
    }
    
    NSString *fromUserId = [mPref valueForKey:USERREGISTERID];
    
    
    NSDictionary *dic =   @{ @"RequestId": @"0",
                             @"StoreId": storeID,
                             @"CustomerId": customerId,
                             @"OpportunityId": @"",
                             @"RequestType": @"Reply",
                             @"RequestDescription":requesttext.text,
                             @"RequestDate": stringFromDate,
                             @"ParentId":parentId,
                             @"RequestPriority":@"1",
                             @"RowStatus": @"A",
                             @"StoreName": storeName,
                             @"Customer": Customer,
                             @"FromUserId":fromUserId
                             };
    
        arrayOriginal = [mWebService SaveRequestReply:dic];
    
    [replyalert close];
    
    [self GetCustoreRequest];
    [self.customerRequestTable reloadData];
}


-(void)cancel:(UIButton*)sender
{
    [replyalert close];
}




-(void)GetCustomerRequests
{
//NSString *storeID = [
    
}

-(IBAction)SaveRequestReply:(id)sender
{
     [self customRequest];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [self.arForTable count];
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{   if ([reply isEqualToString:@"Indicator"])
    {
        return 98;
    }
    else return 76
        ;
}


// Customize the appearance of table view cells.
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    if ([reply isEqualToString:@"Indicator"])
    {
    Comments_Cell *cell = (Comments_Cell *)[tableView dequeueReusableCellWithIdentifier:@"Comments_Cell"];
    
            if (cell == nil)
            {
                NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"Comments_Cell" owner:self options:nil];
                cell = [nib objectAtIndex:0];
              
            }
        
            tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    
            NSDictionary *dic =[self.arForTable objectAtIndex:indexPath.row];
            cell.storename.text=[dic  valueForKey:@"FromUserName"];
            cell.storeComments.text = [dic valueForKey:@"RequestDescription"];
            [cell setIndentationLevel:indexPath.row];
            NSArray *chidsarray = [dic valueForKey:@"Childs"];
            if (!isNSNull(chidsarray) && [chidsarray count]>0 ) {
                cell.storeCommentslabel.hidden = NO;
            }
            else
            {
                cell.storeCommentslabel.hidden = YES;
            }
    
            [cell.storeReplyBtn  addTarget:self action:@selector(replyBtn:) forControlEvents:UIControlEventTouchUpInside];
    
    return cell;
    }
    else
    {
        Customer_childcell *cell = (Customer_childcell *)[tableView dequeueReusableCellWithIdentifier:@"Customer_childcell"];
        
        if (cell == nil)
        {
            NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"Customer_childcell" owner:self options:nil];
            cell = [nib objectAtIndex:0];
            
        }
        //cell.userInteractionEnabled= false;
        NSDictionary *dic =[self.arForTable objectAtIndex:indexPath.row];
        cell.storename.text=[dic  valueForKey:@"FromUserName"];
        cell.storeComments.text = [dic valueForKey:@"RequestDescription"];
        [cell setIndentationLevel:indexPath.row];
        NSString *fisrtindex = [NSString stringWithFormat:@"%ld",(long)indexPath.row];
        if ([fisrtindex isEqualToString: @"1"]) {
            cell.storedownArrow.hidden = NO;
        }
        else  cell.storedownArrow.hidden = YES;
            
        [cell.storeReplyBtn  addTarget:self action:@selector(replyBtn:) forControlEvents:UIControlEventTouchUpInside];
        
        //[cell.storedownArrow addTarget:self action:@selector(hideList:) forControlEvents:UIControlEventTouchUpInside];
        
        
        return cell;
    }
}


-(void)replyBtn:(UIButton*)sender
{
   
    CGPoint buttonPosition = [sender convertPoint:CGPointZero toView:self.customerRequestTable];
    
    NSIndexPath *indexPath = [self.customerRequestTable indexPathForRowAtPoint:buttonPosition];
    
    selectedObject = [self.arForTable objectAtIndex:indexPath.row];
    
    [self.customerRequestTable deselectRowAtIndexPath:indexPath animated:YES];
    
    [self customReply];
 
}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    reply= @"";
    //self.arForTable= nil;
    
      // thisCell.storeName.image = [UIImage imageNamed:@"carat-open.png"];
    
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    NSMutableArray *array = [[NSMutableArray alloc]init];
    [array addObject:[self.arForTable objectAtIndex:indexPath.row]];
    
    NSDictionary *d=[self.arForTable objectAtIndex:indexPath.row];
    if([d valueForKey:@"Childs"]) {
      //  NSArray *ar=[d valueForKey:@"Childs"];
        NSArray *ar = [d valueForKey:@"Childs"];
        if (!isNSNull(ar) && [ar count]>0 ) {
            {
        BOOL isAlreadyInserted=NO;
        
        for(NSDictionary *dInner in ar ){
            NSInteger index=[self.arForTable indexOfObjectIdenticalTo:dInner];
            isAlreadyInserted=(index>0 && index!=NSIntegerMax);
            if(isAlreadyInserted) break;
        }
        
        if(isAlreadyInserted) {
            reply =@"Indicator";
            // thisCell.storeName.image = [UIImage imageNamed:@"carat.png"];
            [self miniMizeThisRows:ar];
        } else {
            NSUInteger count=indexPath.row+1;
            NSMutableArray *arCells=[NSMutableArray array];
            for(NSDictionary *dInner in ar ) {
                [arCells addObject:[NSIndexPath indexPathForRow:count inSection:0]];
                [self.arForTable insertObject:dInner atIndex:count++];
            }
            [tableView insertRowsAtIndexPaths:arCells withRowAnimation:UITableViewRowAnimationLeft];
        }
        
            }
        }
        
//        BOOL isAlreadyInserted=NO;
//        
//        for(NSDictionary *dInner in ar ){
//            NSInteger index=[self.arForTable indexOfObjectIdenticalTo:dInner];
//            isAlreadyInserted=(index>0 && index!=NSIntegerMax);
//            if(isAlreadyInserted) break;
//        }
//        
//        if(isAlreadyInserted) {
//            thisCell.storeName.image = [UIImage imageNamed:@"carat.png"];
//            [self miniMizeThisRows:ar];
//        } else {
//            NSUInteger count=indexPath.row+1;
//            NSMutableArray *arCells=[NSMutableArray array];
//            for (int i=0; i<[ar count]; i++) {
//                NSDictionary *dInner = [ar objectAtIndex:i];
//                [arCells addObject:[NSIndexPath indexPathForRow:count inSection:0]];
//                NSLog(@"%d",i);
//                [array insertObject:dInner atIndex:i+1];
//            }
//            
//            
////            for(NSDictionary *dInner in ar ) {
////              
////            }
//            self.arForTable =array;
//            
//            [tableView insertRowsAtIndexPaths:arCells withRowAnimation:UITableViewRowAnimationLeft];
//        }
    }
    
    
}

-(void)miniMizeThisRows:(NSArray*)ar{
    
    for(NSDictionary *dInner in ar ) {
        NSUInteger indexToRemove=[self.arForTable indexOfObjectIdenticalTo:dInner];
        [self.arForTable removeObjectAtIndex:indexToRemove];
//        if(arInner && [arInner count]>0){
//            [self miniMizeThisRows:arInner];
//        }
        
        if([self.arForTable indexOfObjectIdenticalTo:dInner]==NSNotFound) {
            //[self.arForTable removeObjectIdenticalTo:dInner];
            [self.tblForCollapse deleteRowsAtIndexPaths:[NSArray arrayWithObject:
                                                         [NSIndexPath indexPathForRow:indexToRemove inSection:0]
                                                         ]
                                       withRowAnimation:UITableViewRowAnimationRight];
        }
    }
}



-(IBAction)back:(id)sender
{
    [self dismissViewControllerAnimated:YES completion:nil];
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
