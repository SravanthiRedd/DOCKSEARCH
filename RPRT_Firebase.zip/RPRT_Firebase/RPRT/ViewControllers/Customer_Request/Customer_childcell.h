//
//  Customer_childcell.h
//  RPRT
//
//  Created by sravanthi Gumma on 23/09/1938 Saka.
//  Copyright © 1938 Saka DevpointSolutions. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Customer_childcell : UITableViewCell
@property(nonatomic,weak) IBOutlet UILabel *storename;
@property(nonatomic,weak) IBOutlet UILabel *storeComments;
@property(nonatomic,weak) IBOutlet UIButton *storeReplyBtn;
@property(nonatomic,weak) IBOutlet UIImageView *storeImage;
@property(nonatomic,weak) IBOutlet UIButton *storedownArrow;
@property(nonatomic,weak) IBOutlet UIView *customView;
@end
