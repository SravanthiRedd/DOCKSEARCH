//
//  Customer_childcell.m
//  RPRT
//
//  Created by sravanthi Gumma on 23/09/1938 Saka.
//  Copyright © 1938 Saka DevpointSolutions. All rights reserved.
//

#import "Customer_childcell.h"

@implementation Customer_childcell
@synthesize storename= storename;
@synthesize storeReplyBtn = storeReplyBtn;
@synthesize storeImage = storeImage;
@synthesize storeComments = storeComments;
@synthesize storedownArrow = storedownArrow;
- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
