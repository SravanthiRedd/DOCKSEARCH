//
//  EditOffer.m
//  RPRT
//
//  Created by sravanthi Gumma on 27/05/16.
//  Copyright © 2016 DevpointSolutions. All rights reserved.
//

#import "EditOffer.h"
#import "MZTimerLabel.h"
#import "CustomIOSAlertView.h"
#import "AppDelegate.h"
#import "MyBlockCell.h"
#import "Web_Services.h"
#import "Direction_Map.h"
#import "TimeCalculator.h"
#import "UIImage+MDQRCode.h"
#import "NSMutableAttributedString+StringColor.h"

@interface EditOffer ()<DLStarRatingDelegate,CustomIOSAlertViewDelegate>
{
   
    UIImageView *ImageView;
    UIView *footerView;
   
    NSString *reviewRate;

    MZTimerLabel *TimeCoutDown;
    UIPageControl *pagecontroller;
    CustomIOSAlertView *ImageAlert;
    NSUserDefaults *mPref ;
    UIActivityIndicatorView *spinner;
    NSInteger timerCount;
    NSInteger indexs;
    int Remaingtyime;
    NSDictionary *startOffer;
    UIButton *block;
    NSDictionary *GetOpportunity;
    NSString *OpportunityID;
    UILabel *Timer;
    NSMutableArray *reserveList;
    UITableView  *rTableview;
    TimeCalculator *mConverter;
    Web_Services *mWebservice;
    

}
@property (nonatomic, copy)  NSDictionary *setCache;
@property (weak, nonatomic) IBOutlet UIView *Contentview;
@property (weak, nonatomic) IBOutlet UIScrollView *scrollview;
@property (strong, nonatomic) IBOutlet UIScrollView *PhotoScroll;
//@property (nonatomic, strong) IBOutlet UIPageControl *pageControl;
@property (nonatomic, strong) NSMutableArray *Images;
@property (nonatomic, copy) NSArray *chosenImages;

@end

@implementation EditOffer
@synthesize EditOpportunity,EditOpportunityID,Index;
- (void)viewDidLoad {
    
    @try {
        
    
    [super viewDidLoad];
        mWebservice= [Web_Services GetSharedInstance];
    mConverter= [TimeCalculator GetSharedInstance];
        mPref = [NSUserDefaults standardUserDefaults];
    NSString *string = self.Index;
    if ([string isEqualToString:@"0"]) {
        GetOpportunity = self.EditOpportunity;
        [self LoadOpportunityDetails];
    }
    else if ([string isEqualToString:@"1"])
    {
        GetOpportunity = self.EditOpportunity;
        OpportunityID = self.EditOpportunityID;
        [self LoadReserveList];
    }
    }
    @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    }
    @finally {
        
    }
    
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/
-(void)LoadOpportunityDetails
{
   
    @try {
        
     UIColor *textcolor = [UIColor colorWithRed:0/256.0 green:122./256.0 blue:250./256.0 alpha:1];
    UIView *vendorview = [[UIView alloc]initWithFrame:CGRectMake(0, 210, 374, 114)];
    
    
    UIImageView *home = [[UIImageView alloc]initWithFrame:CGRectMake(2, 5, 24, 24)];
    [home setImage:[UIImage imageNamed:@"homeic.png"]];
    [vendorview addSubview:home];
    
    
    UILabel *OpportunityName = [[UILabel alloc]initWithFrame:CGRectMake(45, 8, 233, 21)];
    [OpportunityName setFont:[UIFont fontWithName:@"Roboto-Regular" size:15]];

    OpportunityName.text =[NSString stringWithFormat:@"%@",[EditOpportunity valueForKey:@"VendorName"]];
    
    [vendorview addSubview:OpportunityName];
    
    
    
    UILabel *vndrNameAdd = [[UILabel alloc]initWithFrame:CGRectMake(45, 32, 316, 21)];
    [vndrNameAdd setFont:[UIFont fontWithName:@"Roboto-Regular" size:15]];
    
    vndrNameAdd.text =[NSString stringWithFormat:@"%@,%@",[EditOpportunity valueForKey:@"VendorName"],[EditOpportunity valueForKey:@"AreaName"]];
    [vndrNameAdd setTextColor:[UIColor colorWithRed:0/256.0 green:186.0/256.0 blue:210/256.0 alpha:1]];
    
     [vendorview addSubview:vndrNameAdd];
    
    
    [vendorview setBackgroundColor:[UIColor colorWithRed:238.0/256 green:238.0/256.0 blue:238.0/256.0 alpha:1]];
        
    UILabel *rate = [[UILabel alloc]initWithFrame:CGRectMake(45, 61, 316, 21)];
    [rate setFont:[UIFont fontWithName:@"Roboto-Regular" size:15]];
    
    rate.text =[NSString stringWithFormat:@"%@",[EditOpportunity valueForKey:@"VendorName"]];
    DLStarRatingControl *customNumberOfStars = [[DLStarRatingControl alloc] initWithFrame:CGRectMake(65,61,120,20)];
    customNumberOfStars.delegate = self;
    
    NSString *rating = [EditOpportunity valueForKey:@"RatingValue"];
    customNumberOfStars.rating = [rating intValue];
    
    double  your_float = [rating floatValue];
    rate.text = [NSString stringWithFormat:@"%.1f",your_float];
    
    [vendorview addSubview:customNumberOfStars];

    [vendorview addSubview:rate];
    
    UILabel *viewRating = [[UILabel alloc]initWithFrame:CGRectMake(215, 61, 93, 21)];
     [viewRating setFont:[UIFont fontWithName:@"Roboto-Medium" size:14]];
      viewRating.text= @"View Ratings";
    [viewRating setTextColor:textcolor];
        
        viewRating.userInteractionEnabled = YES;
        UITapGestureRecognizer *tapGesture =
        [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapViewRatings)];
        [viewRating addGestureRecognizer:tapGesture];
    

    [vendorview addSubview:viewRating];
    
    Timer = [[UILabel alloc]initWithFrame:CGRectMake(45, 85, 122, 21)];
    [Timer setFont:[UIFont fontWithName:@"Roboto-Regular" size:14]];

    [vendorview addSubview:Timer];
    
    
    [self.view addSubview:vendorview];
   
   // [self ViewRatings:[Opportunity valueForKey:@"RatingValue"]];
     UILabel *aboutofferlbl = [[UILabel alloc]initWithFrame:CGRectMake(5, 325, 350, 21)];
        [aboutofferlbl setFont:[UIFont fontWithName:@"Roboto-Medium" size:14]];
        [self.view addSubview:aboutofferlbl];
        
        UILabel *aboutoffer = [[UILabel alloc]initWithFrame:CGRectMake(aboutofferlbl.frame.origin.x, aboutofferlbl.frame.origin.y+25, 350, 40)];
        [aboutoffer setFont:[UIFont fontWithName:@"Roboto-Medium" size:14]];
        aboutoffer.numberOfLines=2;
        [self.view addSubview:aboutoffer];
        
        UILabel *location = [[UILabel alloc]initWithFrame:CGRectMake(aboutoffer.frame.origin.x, aboutoffer.frame.origin.y+40, 289, 21)];
        location.text= @"Location";
        [location setFont:[UIFont fontWithName:@"Roboto-Medium" size:14]];
        [self.view addSubview:location];

        UILabel *address = [[UILabel alloc]initWithFrame:CGRectMake(location.frame.origin.x, location.frame.origin.y+30, 302, 40)];
        [address setFont:[UIFont fontWithName:@"Roboto-Medium" size:14]];
        address.numberOfLines=2;
       
        
        UIButton *route = [[UIButton alloc]initWithFrame:CGRectMake(323, 400, 48, 48)];
        [route setImage:[UIImage imageNamed:@"route.png"] forState:UIControlStateNormal];
        [route addTarget:self action:@selector(route:) forControlEvents:UIControlEventTouchUpInside];
        [self.view addSubview:route];
        
        UILabel *contact = [[UILabel alloc]initWithFrame:CGRectMake(address.frame.origin.x, address.frame.origin.y+50, 289, 21)];
        contact.text= @"Contact";
        contact.textColor = textcolor;
        [contact setFont:[UIFont fontWithName:@"Roboto-Medium" size:14]];
        [self.view addSubview:contact];
        
        UILabel *contactNumber = [[UILabel alloc]initWithFrame:CGRectMake(contact.frame.origin.x, contact.frame.origin.y+25, 141, 21)];
        [contactNumber setFont:[UIFont fontWithName:@"Roboto-Medium" size:14]];
        contactNumber.text = [NSString stringWithFormat:@"%@",[EditOpportunity valueForKey:@"VendorMobile"]];
        [self.view addSubview:contactNumber];
        
        
        UIButton *call = [[UIButton alloc]initWithFrame:CGRectMake(323, 475, 48, 48)];
        [call setImage:[UIImage imageNamed:@"call.png"] forState:UIControlStateNormal];
        [call addTarget:self action:@selector(call:) forControlEvents:UIControlEventTouchUpInside];
        [self.view addSubview:call];
        
        UIImageView *calimg = [[UIImageView alloc]initWithImage:[UIImage imageNamed:@"datetimeicon.png"]];
        calimg.frame = CGRectMake(address.frame.origin.x, contactNumber.frame.origin.y+20, 32, 32);
        [self.view addSubview:calimg];
        
        UILabel *offerTime = [[UILabel alloc]initWithFrame:CGRectMake(calimg.frame.origin.x+calimg.frame.size.width+10, calimg.frame.origin.y, 204, 21)];
        [offerTime setFont:[UIFont fontWithName:@"Roboto-Medium" size:14]];
        
        
        UILabel *lbl= [[UILabel alloc]initWithFrame:CGRectMake(location.frame.origin.x, location.frame.origin.y+20, 350, 24)];
        lbl.text = @"Location";
        lbl.textColor = textcolor;
        [lbl setFont:[UIFont fontWithName:@"Roboto-Medium" size:14]];
        [self.view addSubview:lbl];

        
    
        if([[EditOpportunity valueForKey:@"Category"] isEqualToString:REALESTATE])
        {
            address.text = [NSString stringWithFormat:@"%@,%@,%@",[EditOpportunity valueForKey:@"Address1"],[EditOpportunity valueForKey:@"Address2"],[EditOpportunity valueForKey:@"AreaName"]];
            
            address.frame= CGRectMake(address.frame.origin.x, address.frame.origin.y+10, address.frame.size.width,address.frame.size.height);
            
            
            NSArray *offertype = [[EditOpportunity valueForKey:@"OpportunityKeywords"] componentsSeparatedByString:@","];
            NSString *concat = [NSString stringWithFormat:@"Type: %@             PropertyType: %@",[offertype objectAtIndex:0],[offertype objectAtIndex:1]];
            
            
            NSMutableAttributedString *string = [[NSMutableAttributedString alloc] initWithString:concat];
            [string setColorForText:@"Type:" withColor:textcolor];
            
            [string setColorForText:@"PropertyType:" withColor:textcolor];
            aboutofferlbl.attributedText = string;
            
            NSString *descrstring = [NSString stringWithFormat:@"About Offer: %@ ",[EditOpportunity valueForKey:@"OpportunityDescription"]];
            NSMutableAttributedString *desString = [[NSMutableAttributedString alloc] initWithString:descrstring];
            [desString setColorForText:@"About Offer:" withColor:textcolor];
            
            aboutoffer.attributedText = desString;
            
            NSString *value = [NSString stringWithFormat:@"Value: %@ ",[EditOpportunity valueForKey:@"Price"]];
            NSMutableAttributedString *valuestring = [[NSMutableAttributedString alloc] initWithString:value];
            [valuestring setColorForText:@"Value:" withColor:textcolor];
            
            location.attributedText = valuestring;
            
            
        }
    else   if([[EditOpportunity valueForKey:@"Category"] isEqualToString:FOOD] ||  [[EditOpportunity valueForKey:@"Category"] isEqualToString:@"Sale"])
        {
            address.text = [NSString stringWithFormat:@"%@,%@,%@",[EditOpportunity valueForKey:@"Address1"],[EditOpportunity valueForKey:@"Address2"],[EditOpportunity valueForKey:@"AreaName"]];
        
            aboutofferlbl.text = @"About Opportunities";
            aboutofferlbl.textColor = textcolor;
            aboutoffer.text =[NSString stringWithFormat:@"%@",[EditOpportunity valueForKey:@"OpportunityDescription"]];
           
            
            NSString *price =[NSString stringWithFormat:@"Actula Price:  %@   Opportunities Price: %@ ",[EditOpportunity valueForKey:@"ActualPrice"],[EditOpportunity valueForKey:@"Price"]];
            NSMutableAttributedString *pricestring = [[NSMutableAttributedString alloc] initWithString:price];
            [pricestring setColorForText:@"Actula Price:" withColor:[UIColor colorWithRed:0/256.0 green:122./256.0 blue:250./256.0 alpha:1]];
            [pricestring setColorForText:@"Opportunities Price:" withColor:[UIColor colorWithRed:0/256.0 green:122./256.0 blue:250./256.0 alpha:1]];
            location.attributedText = pricestring;
            
            address.frame = CGRectMake(address.frame.origin.x, address.frame.origin.y+10, address.frame.size.width, address.frame.size.height);
            [self.view addSubview:address];
            
            
        }
        
    else if([[EditOpportunity valueForKey:@"Category"] isEqualToString:JOBS] || [[EditOpportunity valueForKey:@"Category"] isEqualToString:SPORTS] ||  [[EditOpportunity valueForKey:@"Category"] isEqualToString:@"Professional Services"] ||[[EditOpportunity valueForKey:@"Category"] isEqualToString:MEETINGS] ){
        
        
        address.text = [NSString stringWithFormat:@"%@,%@,%@",[EditOpportunity valueForKey:@"Address1"],[EditOpportunity valueForKey:@"Address2"],[EditOpportunity valueForKey:@"AreaName"]];
        [self.view addSubview:address];
        
        [aboutofferlbl setTextColor:textcolor];
        location.hidden= YES;
        
        aboutofferlbl.text = @"About Opportunities";
        aboutoffer.textColor = textcolor;
        aboutoffer.text = [NSString stringWithFormat:@"%@",[EditOpportunity valueForKey:@"OpportunityDescription"]];
        aboutoffer.textColor = [UIColor blackColor];
        
        lbl.frame = CGRectMake(lbl.frame.origin.x, lbl.frame.origin.y-20, lbl.frame.size.width, lbl.frame.size.height);
        [self.view addSubview:lbl];
        
        
    }
        else if ([[EditOpportunity valueForKey:@"Category"] isEqualToString:TRAVELS])
        {
           
           
            NSArray *offername = [[EditOpportunity valueForKey:@"OpportunityName"] componentsSeparatedByString:@"to"];
            
            NSString *fromToadd =[NSString stringWithFormat:@"FROM:  %@  TO: %@ ",[offername objectAtIndex:0],[offername objectAtIndex:1]];
            NSMutableAttributedString *addresstring = [[NSMutableAttributedString alloc] initWithString:fromToadd];
            [addresstring setColorForText:@"From:" withColor:textcolor];
            [addresstring setColorForText:@"To:" withColor:textcolor];
            aboutofferlbl.attributedText = addresstring;
            aboutofferlbl.numberOfLines = 2;
            
             
            NSString *price =[NSString stringWithFormat:@"Price:  %@    Available Seats: %@ ",[EditOpportunity valueForKey:@"Price"],[EditOpportunity valueForKey:@"Available"]];
            NSMutableAttributedString *pricestring = [[NSMutableAttributedString alloc] initWithString:price];
            [pricestring setColorForText:@"Price:" withColor:textcolor];
            [pricestring setColorForText:@"Available Seats:" withColor:textcolor];
            aboutoffer.attributedText = pricestring;
            location.frame = CGRectMake(location.frame.origin.x, location.frame.origin.y-7, location.frame.size.width, location.frame.size.height-10);
            location.text = @"Note";
            location.textColor = textcolor;
            
            lbl.textColor= [UIColor blackColor];
            
            
            NSString *descrstring = [NSString stringWithFormat:@"About Opportunities: %@ ",[EditOpportunity valueForKey:@"OpportunityDescription"]];
            NSMutableAttributedString *desString = [[NSMutableAttributedString alloc] initWithString:descrstring];
            [desString setColorForText:@"About Opportunities:" withColor:textcolor];
            lbl.frame =CGRectMake(lbl.frame.origin.x, lbl.frame.origin.y-15, lbl.frame.size.width-40, lbl.frame.size.height+20);
            lbl.attributedText = desString;
            lbl.numberOfLines=2;
            [lbl setFont:[UIFont fontWithName:@"Roboto-Medium" size:14]];
            address.numberOfLines =3;
            address.frame = CGRectMake(address.frame.origin.x, address.frame.origin.y+15, address.frame.size.width, address.frame.size.height+10);
            
            NSString *addre = [NSString stringWithFormat:@"PickUp Point \n %@,%@,%@",[EditOpportunity valueForKey:@"Address1"],[EditOpportunity valueForKey:@"Address2"],[EditOpportunity valueForKey:@"AreaName"]];
            
            NSMutableAttributedString *addresstrng = [[NSMutableAttributedString alloc] initWithString:addre];
            [addresstrng setColorForText:@"PickUp Point" withColor:textcolor];
            address.attributedText =addresstrng ;
           
            
            contact.frame = CGRectMake(contact.frame.origin.x, contact.frame.origin.y+15, contact.frame.size.width, contact.frame.size.height);
            [self.view addSubview:contact];
           
            contactNumber.frame = CGRectMake(contactNumber.frame.origin.x, contactNumber.frame.origin.y+10, contactNumber.frame.size.width, contactNumber.frame.size.height);
            
            
            calimg.frame = CGRectMake(calimg.frame.origin.x,calimg.frame.origin.y+15,calimg.frame.size.width, calimg.frame.size.height);
            [self.view addSubview:calimg];
            
            
            offerTime.frame =CGRectMake(offerTime.frame.origin.x,calimg.frame.origin.y,offerTime.frame.size.width, offerTime.frame.size.height);
            [self.view addSubview:offerTime];

            
        }
        
        
        else   if([[EditOpportunity valueForKey:@"Category"] isEqualToString:HEALTH])
        {
            address.text = [NSString stringWithFormat:@"%@,%@,%@",[EditOpportunity valueForKey:@"Address1"],[EditOpportunity valueForKey:@"Address2"],[EditOpportunity valueForKey:@"AreaName"]];
            [self.view addSubview:address];
            
            [aboutofferlbl setTextColor:textcolor];
            location.hidden= YES;
            
            aboutofferlbl.text = @"About Opportunities";
            aboutoffer.textColor = textcolor;
            aboutoffer.text = [NSString stringWithFormat:@"%@",[EditOpportunity valueForKey:@"OpportunityDescription"]];
            aboutoffer.textColor = [UIColor blackColor];
            
            lbl.frame = CGRectMake(lbl.frame.origin.x, lbl.frame.origin.y-20, lbl.frame.size.width, lbl.frame.size.height);
            [self.view addSubview:lbl];
        }
        
        else   if([[EditOpportunity valueForKey:@"Category"] isEqualToString:BANKING])
        {
            address.text = [NSString stringWithFormat:@"%@,%@,%@",[EditOpportunity valueForKey:@"Address1"],[EditOpportunity valueForKey:@"Address2"],[EditOpportunity valueForKey:@"AreaName"]];
            [self.view addSubview:address];
            
            [aboutofferlbl setTextColor:textcolor];
            location.hidden= YES;
            
            aboutofferlbl.text = @"About Opportunities";
            aboutoffer.textColor = textcolor;
            aboutoffer.text = [NSString stringWithFormat:@"%@",[EditOpportunity valueForKey:@"OpportunityDescription"]];
            aboutoffer.textColor = [UIColor blackColor];
            
            lbl.frame = CGRectMake(lbl.frame.origin.x, lbl.frame.origin.y-20, lbl.frame.size.width, lbl.frame.size.height);
            [self.view addSubview:lbl];
            
        }
        
        [self.view addSubview:address];
        
        
//       aboutoffer.text = [NSString stringWithFormat:@"%@",[EditOpportunity valueForKey:@"OpportunityName"]];
    
    //NSString *Date =[[EditOpportunity valueForKey:@"StartDate"] stringByReplacingOccurrencesOfString:@"T" withString:@" "];
    
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"yyyy-MM-dd'T'HH:mm:ss"];
    NSTimeZone *gmt = [NSTimeZone timeZoneWithAbbreviation:@"UTC"];
    [dateFormatter setTimeZone:gmt];
    NSDate *date5 = [dateFormatter dateFromString:[EditOpportunity valueForKey:@"StartDate"]];
    NSString *start = [dateFormatter stringFromDate:date5];
    
    if (start==nil) {
        [dateFormatter setDateFormat:@"yyyy-MM-dd'T'HH:mm:ss.SSS"];
        gmt = [NSTimeZone timeZoneWithAbbreviation:@"UTC"];
        [dateFormatter setTimeZone:gmt];
        date5 = [dateFormatter dateFromString:[EditOpportunity valueForKey:@"StartDate"]];
        start = [dateFormatter stringFromDate:date5];
    }
    
    offerTime.text =[NSString stringWithFormat:@"%@",[start stringByReplacingOccurrencesOfString:@"T" withString:@" "]];
    
    
    [self.view addSubview:offerTime];
    
    [self LoadFloatButtons];
    
    
    [self updateImageToScrollView:EditOpportunity];
    }
    @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    }
    @finally {
        
    }
    
}

-(void)LoadFloatButtons
{
    @try {
        
    
    UIButton *blockk =[[UIButton alloc]initWithFrame:CGRectMake(315, 210, 44, 44)];
    //[blockk setImage:[UIImage imageNamed:@"play.png"] forState:UIControlStateNormal];
    blockk.layer.masksToBounds = YES;
    blockk.layer.cornerRadius = 0.5 * blockk.bounds.size.width;
    [blockk setBackgroundColor:[UIColor colorWithRed:74/256.0 green:173./256.0 blue:81.0/256.0 alpha:1]];
    [self.view addSubview:blockk];
        
        
    NSString *satrtDate = [NSString stringWithFormat:@"%@",[EditOpportunity valueForKey:@"EndDate"]];
    
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"yyyy-MM-dd'T'HH:mm:ss"];
    NSTimeZone *gmt = [NSTimeZone timeZoneWithAbbreviation:@"UTC"];
    [dateFormatter setTimeZone:gmt];
    NSDate *date5 = [dateFormatter dateFromString:satrtDate];

    
        if (date5!=nil) {
            startOffer= [[Preferences GetSharedInstance]remaningTime:[NSDate date] endDate:date5];
        }
        else{
            
            NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
            [dateFormatter setDateFormat:@"yyyy-MM-dd'T'HH:mm:ss.SSS"];
            
            NSTimeZone *gmt = [NSTimeZone timeZoneWithAbbreviation:@"UTC"];
            [dateFormatter setTimeZone:gmt];
            NSDate *date5 = [dateFormatter dateFromString:satrtDate];
            startOffer= [[Preferences GetSharedInstance]remaningTime:[NSDate date] endDate:date5];
            
        }
        
        Remaingtyime = [[startOffer valueForKey:@"Time"] intValue];
        // NSString   *OfferTag =[NSString stringWithFormat:@"%d",Remaingtyime];
        int hour = [[startOffer valueForKey:@"Hour"] intValue];
        int seconds = [[startOffer valueForKey:@"Seconds"] intValue];
        if (seconds!=0) {
            Remaingtyime = Remaingtyime+(seconds/60);
        }
        Timer.textColor =  [UIColor redColor];;
        
//        if (seconds!=0) {
//            Remaingtyime = Remaingtyime+(seconds/60);
//        }
        
        if(Remaingtyime!=0 || seconds !=0)
        {
            Remaingtyime = Remaingtyime+(hour*60);
            
            [Timer setFont:[UIFont fontWithName:@"Oswald-Bold" size:24]];
            TimeCoutDown = [[MZTimerLabel alloc] initWithLabel:Timer andTimerType:MZTimerLabelTypeTimer];
            [TimeCoutDown setCountDownTime:Remaingtyime*60];
            [TimeCoutDown start];
            [blockk setImage:[UIImage imageNamed:@"food_stop.png"] forState:UIControlStateNormal];
            [blockk addTarget:self action:@selector(StopOpp) forControlEvents:UIControlEventTouchUpInside];
            
            
            
        }
        else
        {
            Timer.text = @"Opportunities Expired!!";
             CGSize siz =CGSizeMake(20, 20);
            UIImage  *image=   [[TimeCalculator alloc]image:[UIImage imageNamed:@"food_play.png"] scaledToSize:siz];
            [blockk addTarget:self action:@selector(EditOpp) forControlEvents:UIControlEventTouchUpInside];
            [blockk setImage:image forState:UIControlStateNormal];
        }
        
    
    
   // [self.view addSubview:block];
    
        
        
        UIButton *editBtn =[[UIButton alloc]initWithFrame:CGRectMake(2, 255, 42, 42)];
        [editBtn setImage:[UIImage imageNamed:@"edit.png"] forState:UIControlStateNormal];
        editBtn.layer.masksToBounds = YES;
        editBtn.layer.cornerRadius = 0.5 * blockk.bounds.size.width;
        [editBtn setBackgroundColor:[UIColor colorWithRed:63/256.0 green:81./256.0 blue:181.0/256.0 alpha:1]];
        [editBtn addTarget:self action:@selector(EditedOpportunity) forControlEvents:UIControlEventTouchUpInside];
        [self.view addSubview:editBtn];

        
    
    
    Timer.textColor =  [UIColor redColor];;
    Timer.highlightedTextColor = [UIColor orangeColor];
    
    }
    @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    }
    @finally {
        
    }
    
    
}

-(void)EditedOpportunity
{
 
    @try {
        
        spinner = [[UIActivityIndicatorView alloc]
                   initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
        spinner.frame = CGRectMake(0, 0, 320, 560); // CGPointMake(160, 240);
        spinner.color = [UIColor blueColor];
        spinner.backgroundColor = [UIColor lightTextColor];
        spinner.transform = CGAffineTransformMakeScale(2, 2);
        // spinner.hidesWhenStopped = YES;
        [self.view addSubview:spinner];
        spinner.transform = CGAffineTransformMakeScale(2, 2);
        
        [spinner startAnimating];
        
        // how we stop refresh from freezing the main UI thread
        
        dispatch_async(
                       dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^{
                           
                           // back to the main thread for the UI call
                           dispatch_async(dispatch_get_main_queue(), ^{
                               [spinner startAnimating];
                           });
                           dispatch_async(dispatch_get_main_queue(), ^{

        
        if ([[EditOpportunity  valueForKey:@"ModuleId"] isEqualToString:@"33"]) {
            Post_Food *mPost = [[Post_Food alloc]initWithNibName:PFOOD bundle:nil];
            mPost.EditOpportunity = EditOpportunity;
            [self presentViewController:mPost animated:YES completion:nil];
        }
        
        else if ([[EditOpportunity  valueForKey:@"ModuleId"] isEqualToString:@"34"]) {
            Post_Sales *mPost = [[Post_Sales alloc]initWithNibName:PSALES bundle:nil];
            mPost.EditOpportunity = EditOpportunity;
            [self presentViewController:mPost animated:YES completion:nil];
        }
        else if ([[EditOpportunity  valueForKey:@"ModuleId"] isEqualToString:@"36"]) {
            Post_Jobs *mPost = [[Post_Jobs alloc]initWithNibName:PJOBS bundle:nil];
            mPost.EditOpportunity = EditOpportunity;
            [self presentViewController:mPost animated:YES completion:nil];
        }
        else if ([[EditOpportunity  valueForKey:@"ModuleId"] isEqualToString:@"37"]) {
            Post_Professional *mPost = [[Post_Professional alloc]initWithNibName:PPROFESSIONAL bundle:nil];
            mPost.EditOpportunity = EditOpportunity;
            [self presentViewController:mPost animated:YES completion:nil];
        }
        else if ([[EditOpportunity  valueForKey:@"ModuleId"] isEqualToString:@"38"]) {
            Post_Sports *mPost = [[Post_Sports alloc]initWithNibName:PSPORTS bundle:nil];
            mPost.EditOpportunity = EditOpportunity;
            [self presentViewController:mPost animated:YES completion:nil];
        }
        else if ([[EditOpportunity  valueForKey:@"ModuleId"] isEqualToString:@"39"]) {
            Post_Meetings *mPost = [[Post_Meetings alloc]initWithNibName:PMEETINGS bundle:nil];
            mPost.EditOpportunity = EditOpportunity;
            [self presentViewController:mPost animated:YES completion:nil];
        }
        
        else if ([[EditOpportunity  valueForKey:@"ModuleId"] isEqualToString:@"40"]) {
            Post_Travels *mPost = [[Post_Travels alloc]initWithNibName:PTRAVELS bundle:nil];
            mPost.EditOpportunity = EditOpportunity;
            [self presentViewController:mPost animated:YES completion:nil];
        }
        else if ([[EditOpportunity  valueForKey:@"ModuleId"] isEqualToString:@"41"]) {
            Post_RealEstate *mPost = [[Post_RealEstate alloc]initWithNibName:PREALESTATE bundle:nil];
            mPost.EditOpportunity = EditOpportunity;
            [self presentViewController:mPost animated:YES completion:nil];
        }
        else if ([[EditOpportunity  valueForKey:@"ModuleId"] isEqualToString:@"42"]) {
            Post_banking_Finance *mPost = [[Post_banking_Finance alloc]initWithNibName:PBANKINGANDFINANCE bundle:nil];
            mPost.EditOpportunity = EditOpportunity;
            [self presentViewController:mPost animated:YES completion:nil];
        }
                               
        else if ([[EditOpportunity  valueForKey:@"ModuleId"] isEqualToString:@"43"]) {
            Post_Health *mPost = [[Post_Health alloc]initWithNibName:PHEALTH bundle:nil];
            mPost.EditOpportunity = EditOpportunity;
            [self presentViewController:mPost animated:YES completion:nil];
        }
            [spinner stopAnimating];
        
                           });
                       });

    }
    @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    }
    @finally {
        
    }
    
}

-(NSDictionary*)EditedDate
{
    @try {
        
    
    NSDate *currentDateInLocal = [NSDate date];
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"yyyy-MM-dd'T'HH:mm:SS"];
    NSString *currentLocalDateAsStr = [dateFormatter stringFromDate:currentDateInLocal];
    NSArray *date = [currentLocalDateAsStr componentsSeparatedByString:@"T"];
    NSString  *Datelabel = [NSString stringWithFormat:@"%@",[date objectAtIndex:0]];
    NSString  *Timelabel = [NSString stringWithFormat:@"%@",[date objectAtIndex:1]];
    
    
                    NSString *TimeInterval;
                NSString *dat=Timelabel;
    
                
                NSArray *arr = [dat componentsSeparatedByString:@":"];
                NSString *hou= [arr objectAtIndex:0];
                NSString *mm= [arr objectAtIndex:1];
                NSInteger hour = [hou intValue];
                NSInteger minute = [mm intValue];
                minute = minute;
                NSString *AddTime;
    
    //NSString *moduleid =[NSString stringWithFormat:@"%@",[EditOpportunity valueForKey:@"ModuleId"]];
    
    
        AddTime=@"15";
    
    
                
               // AddTime =    [offertime  valueForKey:@"Time"];
                
                TimeInterval = @"1";
                
    int Addvalue = [AddTime intValue];
                
                int minnit = Addvalue;
                
                NSInteger  endtimeH = hour;
                NSInteger   endtimeM = minute+minnit;
                
                if(endtimeM>60&&endtimeM<120)
                {
                    endtimeH = hour+1;
                    endtimeM = endtimeM-60;
                }
                else if(endtimeM<60)
                {
                    endtimeH = hour;
                    endtimeM = minute+minnit;
                }
                else if(endtimeM==60)
                {
                    endtimeH = minute+1;
                    endtimeM = 00;
                }
    
                else if(endtimeM<120&&endtimeM>60)
                {
                    endtimeH = hour+1;
                    endtimeM = (minute+minnit)-60;
                }
    
                
    
                
                
                NSString *str1=[NSString stringWithFormat:@"%@",Datelabel];
                
                NSString *str=[NSString stringWithFormat:@"%@ %ld:%ld:00",str1,(long)endtimeH,(long)endtimeM];
                str = [str stringByReplacingOccurrencesOfString:@"+0000" withString:@""];
                
                
                NSDateFormatter *Format = [[NSDateFormatter alloc]init];
                [Format setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
                
    
                NSDate *secondtime =[Format dateFromString:str];
                
                NSDateFormatter *formatter = [[NSDateFormatter alloc]init];
                [formatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
                
                
                
                NSTimeZone *gmt = [NSTimeZone timeZoneWithAbbreviation:@"UTC"];
                [formatter setTimeZone:gmt];
                
    
                NSString *SecondTime = [formatter stringFromDate:secondtime];
                
                NSMutableDictionary *DateTimeData = [[NSMutableDictionary alloc]init];
                
    
                [DateTimeData setValue:SecondTime forKey:@"EndDate"];
                [DateTimeData setValue:AddTime forKey:@"Time"];
    
                return DateTimeData;
    
    }
    @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    }
    @finally {
        
    }
    
}


-(void)tapViewRatings
{
    @try {
//        Rating *mRatings = [Rating alloc];
//        mRatings.SetOpportunities = EditOpportunity;
//        Rating *mPlaceOrderA01 =
//        [mRatings initWithNibName:RATINGS bundle:nil];
//        [self presentViewController:mPlaceOrderA01 animated:YES completion:nil];
        
    } @catch (NSException *exception) {
        
    } @finally {
        
    }
}

-(void)EditOpp
{
    @try
    {
        spinner = [[UIActivityIndicatorView alloc]
                   initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
        spinner.frame = CGRectMake(0, 0, 320, 560); // CGPointMake(160, 240);
        spinner.color = [UIColor blueColor];
        spinner.backgroundColor = [UIColor lightTextColor];
        spinner.transform = CGAffineTransformMakeScale(2, 2);
        // spinner.hidesWhenStopped = YES;
        [self.view addSubview:spinner];
        spinner.transform = CGAffineTransformMakeScale(2, 2);
        
        [spinner startAnimating];
        
        // how we stop refresh from freezing the main UI thread
        
        dispatch_async(
                       dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^{
                           
                           // back to the main thread for the UI call
                           dispatch_async(dispatch_get_main_queue(), ^{
                               [spinner startAnimating];
                           });
                           dispatch_async(dispatch_get_main_queue(), ^{
                               
                               NSString *DeviceID = [[[UIDevice currentDevice] identifierForVendor] UUIDString];
                               NSDictionary *date = [self EditedDate];
                               

                               
                               NSDictionary *Oppor= [self getEditeOpportunity];
                               
                               NSString *photoname  = [Oppor valueForKey:@"PhotoName"];
                               
                               photoname = [self getOpportunityimage:photoname];
                               
                               
                               NSString *AddressName= [NSString stringWithFormat:@"%@,%@,%@,%@",[EditOpportunity valueForKey:@"Address1"],[EditOpportunity valueForKey:@"Address2"],[EditOpportunity valueForKey:@"Address3"],[EditOpportunity valueForKey:@"AreaName"]];
                               
                               NSString *Location = [NSString stringWithFormat:@"%@,%@",[Oppor valueForKey:LATITUDE],[Oppor valueForKey:LONGITUDE]];
                             
                              // NSString *regid =[mPref valueForKey:USERREGISTERID];
                               
                               
                              
                               
                                   NSString *gcmID = [mPref valueForKey:@"FCMID"];
                                   if ([gcmID isEqualToString:@""] || gcmID==nil) {
                                       gcmID=@"";
                                   }

                                   
                                   
                               NSDictionary    *Opportunity  = @{@"OpportunityID":@"0",
                                                                 @"OpportunityName":[Oppor valueForKey:@"OpportunityName"],
                                                                 @"OpportunityDescription":[Oppor valueForKey:@"OpportunityDescription"],
                                                                 @"OpportunityKeywords":[Oppor valueForKey:@"OpportunityKeywords"],
                                                                 @"CategoryID":[Oppor valueForKey:@"CategoryID"],
                                                                 @"ModuleId":[Oppor valueForKey:@"ModuleId"],
                                                                 @"UserID":@"0",
                                                                 
                                                                 @"StartDate":[Oppor valueForKey:@"StartDate"],
                                                                 @"EndDate":[date valueForKey:@"EndDate"],
                                                                 @"PromoCode":@"Promo",
                                                                 @"OpportunityType":[Oppor valueForKey:@"OpportunityType"],
                                                                 @"DeviceId":DeviceID,
                                                                 @"PhotoName":photoname,
                                                                 
                                                                 @"GcmId":gcmID,
                                                                 @"AddressName":AddressName,
                                                                 @"IsPrimary":@"true",
                                                                 @"Address1":[Oppor valueForKey:@"Address1"],
                                                                 @"Address3":[Oppor valueForKey:@"Address3"],
                                                                 @"Address2":[Oppor valueForKey:@"Address2"],
                                                                 @"AreaName":[Oppor valueForKey:@"AreaName"],
                                                                 @"Quantity":[Oppor valueForKey:@"Available"],
                                                                 @"City":[Oppor valueForKey:@"City"],
                                                                 @"State":[Oppor valueForKey:@"State"],
                                                                 @"Country":[Oppor valueForKey:@"Country"],
                                                                 LATITUDE:[Oppor valueForKey:LATITUDE],
                                                                 LONGITUDE:[Oppor valueForKey:LONGITUDE],
                                                                 @"KeyWords":@"",
                                                                 @"Time":@"15",
                                                                 @"PageSize":@"10",
                                                                 @"PageNo":@"1",
                                                                 @"radius":@"500",
                                                                 @"LocationFlag":@"NotChanged",
                                                                 @"Location":Location,
                                                                 @"Categories":@"",
                                                                 @"types":@"",
                                                                 @"UserRegisterId":[Oppor valueForKey:@"UserRegisterId"],
                                                                 @"Name":[Oppor valueForKey:@"OpportunityName"],
                                                                 @"Price":[Oppor valueForKey:@"Price"],
                                                                 @"ActualPrice":[Oppor valueForKey:@"ActualPrice"],
                                                                  @"Delivery":@"",
                                                                  @"Action":@"Restart"
                               
                               
                                                                 };
                               
                               
                               
                               
                               
                               
                               NSDictionary *Reponse =  [[Web_Services GetSharedInstance]PostOffer:Opportunity];
                               if (Reponse!=nil) {
                                   
                                    [self showAlertPop:@"Your Opportunities is updated." expObj:nil];
                                  // [mPref setObject:remainingTime forKey:@"TimeSlot"];
                                   Retailer_Offer * mOpportunity_list = [[ Retailer_Offer alloc] initWithNibName:RETAILER bundle:nil];
                                   [self presentViewController:mOpportunity_list animated:YES completion:nil];
                               
                               }
                               [spinner stopAnimating];
                               
                           });
                       });
    }
    @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    }
    @finally {
        
    }

}

-(NSMutableDictionary*)StopTime
{
    NSMutableDictionary *DateTimeData= [[NSMutableDictionary alloc]init];
        NSDate *currentDateInLocal = [NSDate date];
        
        NSDateFormatter *formatter = [[NSDateFormatter alloc]init];
        [formatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
        NSTimeZone *gmt = [NSTimeZone timeZoneWithAbbreviation:@"UTC"];
        [formatter setTimeZone:gmt];
        NSString *StartTimecon = [formatter stringFromDate:currentDateInLocal];
        [DateTimeData setValue:StartTimecon forKey:@"EndDate"];
        [DateTimeData setValue:@"15" forKey:@"Time"];
    return DateTimeData;
}

-(void)StopOpp
{ @try
    {
        spinner = [[UIActivityIndicatorView alloc]
                   initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
        spinner.frame = CGRectMake(0, 0, 320, 560); // CGPointMake(160, 240);
        spinner.color = [UIColor blueColor];
        spinner.backgroundColor = [UIColor lightTextColor];
        spinner.transform = CGAffineTransformMakeScale(2, 2);
        // spinner.hidesWhenStopped = YES;
        [self.view addSubview:spinner];
        spinner.transform = CGAffineTransformMakeScale(2, 2);
        
        [spinner startAnimating];
        
        // how we stop refresh from freezing the main UI thread
        
        dispatch_async(
                       dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^{
                           
                           // back to the main thread for the UI call
                           dispatch_async(dispatch_get_main_queue(), ^{
                               [spinner startAnimating];
                           });
                           dispatch_async(dispatch_get_main_queue(), ^{
                               
                               
                               
                               
                               NSString *DeviceID = [[[UIDevice currentDevice] identifierForVendor] UUIDString];
                               NSDictionary *date = [self StopTime];
                               
                               
                               
                               NSDictionary *Oppor= [self getEditeOpportunity];
                               
                               NSString *photoname  = [Oppor valueForKey:@"PhotoName"];
                               
                               photoname = [self getOpportunityimage:photoname];
                               
                               
                               NSString *AddressName= [NSString stringWithFormat:@"%@,%@,%@,%@",[EditOpportunity valueForKey:@"Address1"],[EditOpportunity valueForKey:@"Address2"],[EditOpportunity valueForKey:@"Address3"],[EditOpportunity valueForKey:@"AreaName"]];
                               
                               NSString *Location = [NSString stringWithFormat:@"%@,%@",[Oppor valueForKey:LATITUDE],[Oppor valueForKey:LONGITUDE]];
    
                               
                               NSString *gcmID = [mPref valueForKey:@"FCMID"];
                               if ([gcmID isEqualToString:@""] || gcmID==nil) {
                                   gcmID=@"";
                               }

                               
                               
    NSDictionary *Opportunitu= @{@"OpportunityID":[Oppor valueForKey:@"OpportunityID"],
        @"OpportunityName":[Oppor valueForKey:@"OpportunityName"],
        @"OpportunityDescription":[Oppor valueForKey:@"OpportunityDescription"],
        @"OpportunityKeywords":[Oppor valueForKey:@"OpportunityKeywords"],
        @"Name":[Oppor valueForKey:@"OpportunityName"],
        @"Price":[Oppor valueForKey:@"Price"],
        @"CategoryID":[Oppor valueForKey:@"CategoryID"],
        @"Time":@"15",
        @"ModuleId":[Oppor valueForKey:@"ModuleId"],
        @"UserID":@"0",
        @"UserRegisterId":[Oppor valueForKey:@"UserRegisterId"],
        @"StartDate":[Oppor valueForKey:@"StartDate"],
        @"EndDate":[date valueForKey:@"EndDate"],
        @"PromoCode":@"Promo",
        @"OpportunityType":[Oppor valueForKey:@"OpportunityType"],
        @"DeviceId":DeviceID,
        @"PhotoName":photoname,
        @"IsPrimary":@"true",
        @"TimeInterval":@"1",
        @"GcmId":gcmID,
        @"Address1":[Oppor valueForKey:@"Address1"],
        @"Address2":[Oppor valueForKey:@"Address2"],
        @"Address3":[Oppor valueForKey:@"Address3"],
        @"AreaName":[Oppor valueForKey:@"AreaName"],
        @"AddressName":AddressName,
        @"Quantity":@"0",
        @"City":[Oppor valueForKey:@"City"],
        @"State":[Oppor valueForKey:@"State"],
        @"Country":[Oppor valueForKey:@"Country"],
        LATITUDE:[Oppor valueForKey:LATITUDE],
        LONGITUDE:[Oppor valueForKey:LONGITUDE],
        @"Location":Location,
        @"Categories":@"",
        @"types":@"",
        @"KeyWords":@"",
        @"PageNo":@"1",
        @"PageSize":@"10",
        @"ActualPrice":@"0",
        @"radius":@"500",
        @"LocationFlag":@"NotChanged",
        @"Delivery":@"",
        @"Action":@"Stop"
    };
                               NSDictionary *Reponse =  [[Web_Services GetSharedInstance]PostOffer:Opportunitu];
                               if (Reponse!=nil) {
                                   
                                   if ([[Oppor valueForKey:@"ModuleId"] isEqualToString:@"33"]) {
                                       [self showAlertPop:@"Your Opportunities is stopped." expObj:nil];
                                   }
                                   else  if ([[Oppor valueForKey:@"ModuleId"] isEqualToString:@"34"]) {
                                       [self showAlertPop:@"Your Opportunities is stopped." expObj:nil];
                                   }
                                   
                                   else  if ([[Oppor valueForKey:@"ModuleId"] isEqualToString:@"36"]) {
                                       [self showAlertPop:@"Your job requirement is stopped." expObj:nil];
                                   }
                                   
                                   else if ([[Oppor valueForKey:@"ModuleId"] isEqualToString:@"37"]) {
                                       [self showAlertPop:@"Your Opportunities is stopped." expObj:nil];
                                   }
                                   else if ([[Oppor valueForKey:@"ModuleId"] isEqualToString:@"38"]) {
                                       [self showAlertPop:@"Your Opportunities is stopped." expObj:nil];
                                   }
                                   else if ([[Oppor valueForKey:@"ModuleId"] isEqualToString:@"39"]) {
                                       [self showAlertPop:@"Your Opportunities is stopped." expObj:nil];
                                   }
                                   else if ([[Oppor valueForKey:@"ModuleId"] isEqualToString:@"40"]) {
                                       [self showAlertPop:@"Your travel post is stopped." expObj:nil];
                                   }
                                   else if ([[Oppor valueForKey:@"ModuleId"] isEqualToString:@"41"]) {
                                       [self showAlertPop:@"Your property post is stopped." expObj:nil];
                                   }
                                 
                                   
                                   // [mPref setObject:remainingTime forKey:@"TimeSlot"];
                                   Retailer_Offer * mOpportunity_list = [[ Retailer_Offer alloc] initWithNibName:RETAILER bundle:nil];
                                   [self presentViewController:mOpportunity_list animated:YES completion:nil];
                               }
                               [spinner stopAnimating];
                               
                           });
                       });
    }
    @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    }
    @finally {
        
    }
   
}


-(NSDictionary*)getEditeOpportunity
{
    @try {
        
    
    NSString *opportunityId= [EditOpportunity valueForKey:@"OpportunityID"];
    
NSDictionary *Opportunity=[[Web_Services GetSharedInstance]GetOpportunityByID:opportunityId MethodName:@"GetOpportunityById"];
    
    return Opportunity;
    }
    @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    }
    @finally {
        
    }
    
}

-(NSString*)getOpportunityimage:(NSString*)imagenames
{
    @try {
        
    
    NSArray *imagearr =[imagenames componentsSeparatedByString:@","];
    NSMutableArray *imagearray = [[NSMutableArray alloc]init];
    
    for (int i=0;i<[imagearr count]; i++) {
        
        NSString *dict= [imagearr objectAtIndex:i];
        
        if (![dict isEqual:@""])
        {
        
            
            NSMutableString* aString = [NSMutableString stringWithFormat:@"%@%@",baseImageURL,dict];
            NSURL *imageURL = [NSURL URLWithString:aString];

            NSData *getData = [NSData dataWithContentsOfURL:imageURL];

            NSString *base64String = [getData base64EncodedStringWithOptions:0];
            [imagearray addObject:base64String];
            
        }
        
    }
    

    

    if ([imagearray count]==0) {
    imagenames =@"";
    }
    else{
        imagenames = [imagearray componentsJoinedByString:@","];
    }



    return imagenames;
    }
    @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    }
    @finally {
        
    }
    
}

-(void)updateImageToScrollView:(NSDictionary*)Opportunity
{
    @try {
        
        self.PhotoScroll = [[UIScrollView alloc]initWithFrame:CGRectMake(0, 7, 375, 200)];
        
        self.PhotoScroll.delegate = self;
        
        
        [self.view addSubview:self.PhotoScroll];
        
        NSString *imag = [Opportunity objectForKey:@"PhotoName"];
        NSArray *stringArray = [imag componentsSeparatedByString:@","];
        CGRect workingFrame = self.PhotoScroll.frame;
        self.PhotoScroll.backgroundColor = [UIColor clearColor];
        workingFrame.origin.x = 0;
        
        
        _Images = [NSMutableArray arrayWithCapacity:[stringArray count]];
        
        if (stringArray!=0 && ![stringArray[0] isEqualToString:@""]) {
            for (NSDictionary *dict in stringArray)
            {
                if (![dict isEqual:@""])
                {
                    UIImage *image;
                    
                    
                    NSMutableString* aString = [NSMutableString stringWithFormat:@"%@%@",baseImageURL,dict];
                    NSURL *imageURL = [NSURL URLWithString:aString];
                    NSString *key = [aString MD5Hash];
                    NSData *getData = [FTWCache objectForKey:key];
                    if (getData) {
                        image = [UIImage imageWithData:getData];
                        CGSize size = CGSizeMake(800, 450);
                        
                        [_Images addObject:[mConverter image:image scaledToSize:size]];
                        // cell.OpportunityImage.image  = image;
                    }
                    else {
                        //cell.OpportunityImage.image  = [UIImage imageNamed:@"img_def"];
                        dispatch_queue_t queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_HIGH, 0ul);
                        dispatch_async(queue, ^{
                            NSData *newData = [NSData dataWithContentsOfURL:imageURL];
                            [FTWCache setObject:newData forKey:key];
                            UIImage *image = [UIImage imageWithData:newData];
                            dispatch_sync(dispatch_get_main_queue(), ^{
                                CGSize size = CGSizeMake(800, 450);
                                
                                [_Images addObject:[mConverter image:image scaledToSize:size]];
                                // cell.OpportunityImage.image  = image;
                                
                            });
                        });
                    }
                    
                    
                    //image.size.height = 250.0f;
                    
                    CGSize size = CGSizeMake(800, 450);
                    
                    ImageView = [[UIImageView alloc] initWithImage:[mConverter image:image scaledToSize:size]];
                    
                    [ImageView setContentMode:UIViewContentModeScaleAspectFit];
                    
                    ImageView.frame = workingFrame;
                    
                    // NSLog(@"%@",workingFrame);
                    [self.PhotoScroll addSubview:ImageView];
                    
                    workingFrame.origin.x = workingFrame.origin.x + workingFrame.size.width;
                    
                }
                
                
            }
        }
        
        
        else
        {
            NSString *dict =[Opportunity objectForKey:@"CategoryImage"];
            NSMutableString* aString = [NSMutableString stringWithFormat:@"%@%@",baseImageURL,dict];
            
            UIImage *image;
            NSURL *imageURL = [NSURL URLWithString:aString];
            NSString *key = [aString MD5Hash];
            NSData *getData = [FTWCache objectForKey:key];
            if (getData) {
                image = [UIImage imageWithData:getData];
                CGSize size = CGSizeMake(800, 450);
                
                [_Images addObject:[mConverter image:image scaledToSize:size]];
                // cell.OpportunityImage.image  = image;
            }
            else {
                //cell.OpportunityImage.image  = [UIImage imageNamed:@"img_def"];
                dispatch_queue_t queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_HIGH, 0ul);
                dispatch_async(queue, ^{
                    NSData *newData = [NSData dataWithContentsOfURL:imageURL];
                    [FTWCache setObject:newData forKey:key];
                    UIImage *image = [UIImage imageWithData:newData];
                    dispatch_sync(dispatch_get_main_queue(), ^{
                        CGSize size = CGSizeMake(800, 450);
                        
                        [_Images addObject:[mConverter image:image scaledToSize:size]];
                        // cell.OpportunityImage.image  = image;
                        
                    });
                });
            }
            
            
            //image.size.height = 250.0f;
            
            CGSize size = CGSizeMake(800, 450);
            
            ImageView = [[UIImageView alloc] initWithImage:[mConverter image:image scaledToSize:size]];
            
            [ImageView setContentMode:UIViewContentModeScaleAspectFit];
            
            ImageView.frame = workingFrame;
            
            // NSLog(@"%@",workingFrame);
            [self.PhotoScroll addSubview:ImageView];
            
            workingFrame.origin.x = workingFrame.origin.x + workingFrame.size.width;
            
        }
        
        
        UITapGestureRecognizer *singleTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(ImageTap:)];
        singleTap.numberOfTapsRequired = 1;
        [ImageView setUserInteractionEnabled:YES];
        [ImageView addGestureRecognizer:singleTap];
        
        
        pagecontroller = [[UIPageControl alloc]initWithFrame:CGRectMake(150, 180, 50, 20)];
        
        pagecontroller.numberOfPages = [_Images count];
        pagecontroller.currentPage = 0;
        pagecontroller.pageIndicatorTintColor = [UIColor blueColor];
        [pagecontroller addTarget:self action:@selector(changePage:) forControlEvents:UIControlEventTouchUpInside];
        
        
        
        [self.view addSubview:pagecontroller];
        
        
        block = [[UIButton alloc]initWithFrame:CGRectMake(300, 200, 40, 40)];
        block.layer.masksToBounds = YES;
        //    blockBtn.layer.cornerRadius = 2;
        //
        block.layer.cornerRadius = 0.5 * block.bounds.size.width;
        
        
        
        
        
        [self.PhotoScroll setPagingEnabled:YES];
        
        [self.PhotoScroll setContentSize:CGSizeMake(workingFrame.origin.x, workingFrame.size.height)];
    }
    @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    }
    @finally {
        
    }
    
}

- (void)scrollViewDidScroll:(UIScrollView *)sender {
    @try {
        
        CGFloat pageWidth = _PhotoScroll.frame.size.width;
        float fractionalPage = _PhotoScroll.contentOffset.x / pageWidth;
        NSInteger page = lround(fractionalPage);
        pagecontroller.currentPage = page;
    }
    @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
}

-(IBAction)changePage:(UIPageControl*)sender
{
    @try {
        
    
    NSInteger page = pagecontroller.currentPage;
    if (page < 0)
        return;
    if (page >= 2)
        return;
    CGRect frame = _PhotoScroll.frame;
    frame.origin.x = frame.size.width * page;
    frame.origin.y = 0;
    _PhotoScroll.frame = frame;
    // [scrollView scrollRectToVisible:frame animated:YES];
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }

    
}


-(void)cancel:(UIButton*)sender
{
    [ImageAlert close];
}

-(void)ImageTap:(UIPinchGestureRecognizer *)recognizer{
    
    @try {
        
    
    UIImageView *tableGridImage = (UIImageView*)recognizer.view;
    
    
    ImageAlert=[[CustomIOSAlertView alloc] init];
    UIView  *imageView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 300, 200)];
    [ImageAlert setContainerView:imageView];
    [ImageAlert setButtonTitles:[NSMutableArray arrayWithObjects:@"", nil]];
    
    [ImageAlert setDelegate:self];
    
    
    // You may use a Block, rather than a delegate.
    [ImageAlert setOnButtonTouchUpInside:^(CustomIOSAlertView *alertView, int buttonIndex) {
        NSLog(@"Block: Button at position %d is clicked on alertView %d.", buttonIndex, (int)[alertView tag]);
        [alertView close];
    }];
    
    [ImageAlert setUseMotionEffects:true];
    
    UIButton *cancel = [[UIButton alloc]initWithFrame:CGRectMake(275, 0, 20, 20)];
    
    [cancel setImage:[UIImage imageNamed:@"ic_close"] forState:UIControlStateNormal];
    [cancel addTarget:self action:@selector(cancel:) forControlEvents:UIControlEventTouchUpInside];
    
    
    UIImageView *VendorProfile = [[UIImageView alloc]initWithImage:tableGridImage.image];
    VendorProfile.frame = CGRectMake(0, 20, 300, 230);
    [imageView addSubview:cancel];
    [imageView addSubview:VendorProfile];
    
    [ImageAlert show];
    ImageAlert.tag = 2;

    
    //ImageAlert = [CustomIOSAlertView ]
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
    
}



-(void)route:(id)sender
{
    @try {
        
    Direction_Map *mMap= [Direction_Map alloc];
    mMap.direction =EditOpportunity;
    Direction_Map *mMapview =
    [mMap initWithNibName:RATINGS bundle:nil];
    [self presentViewController:mMapview animated:YES completion:nil];
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }

    
}

-(void)call:(id)sender
{
    @try {
        
    NSString *contNumber = [EditOpportunity valueForKey:@"VendorMobile"];
    
   
    
        UIDevice *device = [UIDevice currentDevice];
        if ([[device model] isEqualToString:@"iPhone"]) {
            
            NSURL *phoneUrl = [NSURL
                               URLWithString:[NSString stringWithFormat:@"telprompt:%@", contNumber]];
            
            if ([[UIApplication sharedApplication] canOpenURL:phoneUrl]) {
                UIApplication *application = [UIApplication sharedApplication];
                [application openURL:phoneUrl options:@{} completionHandler:nil];

                
               // [[UIApplication sharedApplication] openURL:phoneUrl];
            }
            
        } else {
            
                        UIAlertController *myAlertController =
                        [[Web_Services alloc] alert:@"Your device doesn't support this feature."];
                        [self presentViewController:myAlertController
                                           animated:YES
                                         completion:nil];
        }
        
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
    

}

-(void)LoadReserveList
{
    @try {
        
    
    Web_Services *mwebservice = [Web_Services GetSharedInstance];
    
    reserveList= [mwebservice GetVendorBlocks:EditOpportunityID MethodName:@"GetReservedOpportunitiesBYID"];
    
    UILabel *opportunityName = [[UILabel alloc]initWithFrame:CGRectMake(0, 15, 350, 30)];
    opportunityName.text = [GetOpportunity valueForKey:@"OpportunityName"];
    [opportunityName setFont:[UIFont fontWithName:@"Roboto-Regular" size:16]];
    opportunityName.textAlignment = NSTextAlignmentCenter;
    [self.view addSubview:opportunityName];
    
    
    rTableview = [[UITableView alloc] init];//;]WithFrame:self.view.bounds style:UITableViewStylePlain];
    rTableview.separatorStyle = UITableViewCellSeparatorStyleNone;
    rTableview.frame = CGRectMake(5, 50, 370, 500);
    rTableview.delegate = self;
    rTableview.dataSource = self;
    self.view.backgroundColor=[UIColor colorWithRed:236.0/256.0 green:236.0/256.0 blue:236.0/256.0 alpha:1];
    [self.view addSubview:rTableview];
    }
    @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    }
    @finally {
        
    }
    
    
}

#pragma mark - UITableViewDataSource

- (NSInteger)numberOfSectionsInTableView:(UITableView *)theTableView
{
    return 1;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 110;
}


- (NSInteger)tableView:(UITableView *)theTableView numberOfRowsInSection:(NSInteger)section
{
    return [reserveList count];
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    @try {
       // static NSString *simpleTableIdentifier = @"UserBlockCell";
        
        UserBlockCell *cell = (UserBlockCell *)[tableView dequeueReusableCellWithIdentifier:USERBLOCKCELL];
        if (cell == nil)
        {
            NSArray *nib = [[NSBundle mainBundle] loadNibNamed:USERBLOCKCELL owner:self options:nil];
            cell = [nib objectAtIndex:0];
        }
        
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        cell.backgroundColor = [UIColor clearColor];
        //cell.view1.layer.borderColor = [[UIColor lightGrayColor] CGColor];
        cell.layer.cornerRadius = 45/2;
        
        
        
        NSDictionary *dic = [reserveList objectAtIndex:indexPath.row];
        cell.VendorName.text =[NSString stringWithFormat:@"%@",[dic valueForKey:@"RegUserName"]];
        cell.emaiId.text =[NSString stringWithFormat:@"%@", [dic valueForKey:@"RegEmail"]];
       // cell.BlockText.text =[NSString stringWithFormat:@"%@", [dic valueForKey:@"BlockText"]];
        cell.key.text =[NSString stringWithFormat:@"%@", [dic valueForKey:@"KeyValue"]];

        
        NSArray *imagearr= [[dic valueForKey:@"PhotoName"] componentsSeparatedByString:@","];
        
        NSString *ImageURL = [NSString stringWithFormat:@"%@%@",baseImageURL, [imagearr objectAtIndex:0]];
        
        NSURL *imageURL = [NSURL URLWithString:ImageURL];
        NSString *key = [ImageURL MD5Hash];
        NSData *getData = [FTWCache objectForKey:key];
        if (getData) {
            UIImage *image = [UIImage imageWithData:getData];
            cell.UserImage.image  = image;
        }
        else {
            cell.UserImage.image  = [UIImage imageNamed:@"img_def"];
            dispatch_queue_t queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_HIGH, 0ul);
            dispatch_async(queue, ^{
                NSData *newData = [NSData dataWithContentsOfURL:imageURL];
                [FTWCache setObject:newData forKey:key];
                UIImage *image = [UIImage imageWithData:newData];
                dispatch_sync(dispatch_get_main_queue(), ^{
                    cell.UserImage.image  = image;
                    
                });
            });
        }
        
        NSString *satrtDate = [NSString stringWithFormat:@"%@",[dic valueForKey:@"EndDate"]];
        NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
        [dateFormatter setDateFormat:@"yyyy-MM-dd'T'HH:mm:ss"];
        NSTimeZone *gmt = [NSTimeZone timeZoneWithAbbreviation:@"UTC"];
        [dateFormatter setTimeZone:gmt];
        NSDate *date5 = [dateFormatter dateFromString:satrtDate];
        
        NSDictionary *offertime= [[Preferences GetSharedInstance]remaningTime:[NSDate date] endDate:date5];
        int Remaingtime = [[offertime valueForKey:@"Time"] intValue];
        if ([offertime count]!=0) {
            TimeCoutDown = [[MZTimerLabel alloc] initWithLabel:cell.offerTimer andTimerType:MZTimerLabelTypeTimer];
            [TimeCoutDown setCountDownTime:Remaingtime*60];
            [TimeCoutDown start];
            
        }
        else
        {
            cell.offerTimer.text = @"Expired!!";
        }
        
  UIButton      *upcomingBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        upcomingBtn.frame = CGRectMake(200, 70, 150, 30);
       
        UIImage *upimg = [[UIImage alloc]init];
        upimg = [UIImage imageNamed:@"call_blk.png"];
        
        CGSize size =CGSizeMake(18, 18);
     UIImage   *image=   [mConverter image:upimg scaledToSize:size];
        [upcomingBtn setImage: image forState:UIControlStateNormal];
        
        [upcomingBtn setTitleEdgeInsets:UIEdgeInsetsMake(30, 0, 30, -15)];
        [upcomingBtn setTitle:[NSString stringWithFormat:@"%@", [dic valueForKey:@"PhoneNo"]] forState:UIControlStateNormal];
        [upcomingBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
       [upcomingBtn addTarget:self action:@selector(tablecall:) forControlEvents:UIControlEventTouchUpInside];
        [cell addSubview:upcomingBtn];
        
        
        return cell;
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }

    

}

-(void)tablecall:(id)sender
{
    CGPoint buttonPosition = [sender convertPoint:CGPointZero toView:rTableview];
    NSIndexPath *indexPath = [rTableview indexPathForRowAtPoint:buttonPosition];
    NSDictionary *selectedItem = [reserveList objectAtIndex:indexPath.row];
    NSString *contNumber = [selectedItem valueForKey:@"PhoneNo"];
    
    @try {
        UIDevice *device = [UIDevice currentDevice];
        if ([[device model] isEqualToString:@"iPhone"]) {
            
            NSURL *phoneUrl = [NSURL
                               URLWithString:[NSString stringWithFormat:@"telprompt:%@", contNumber]];
            
            if ([[UIApplication sharedApplication] canOpenURL:phoneUrl]) {
                [[UIApplication sharedApplication] openURL:phoneUrl];
            }
            
        } else {
            
            UIAlertController *myAlertController =
            [[Web_Services alloc] alert:@"Your device doesn't support this feature."];
            [self presentViewController:myAlertController
                               animated:YES
                             completion:nil];
        }
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }

    
    
}
   
- (void) showAlertPop:(NSString*)alertText expObj:(NSException*) exp{
        @try {
            
            if(exp != nil)
            {
                NSLog(@"%@", exp.description);
            }
            UIAlertController *myAlertController =[mWebservice  alert:alertText];
            [self presentViewController:myAlertController animated:YES completion:nil];
        } @catch (NSException *exception) {
            [self showAlertPop:@"Error while fetching data." expObj:exception];
        } @finally {
            
        }

        
}


@end
