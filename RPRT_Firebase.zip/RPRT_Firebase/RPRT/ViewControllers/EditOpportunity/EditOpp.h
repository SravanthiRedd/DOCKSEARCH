//
//  EditOpp.h
//  RPRT
//
//  Created by sravanthi Gumma on 27/07/1938 Saka.
//  Copyright © 1938 Saka DevpointSolutions. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface EditOpp : UIViewController<UIScrollViewDelegate>
@property(nonatomic,strong)NSDictionary *selectedOpportunity;



@property (nonatomic,strong) IBOutlet UIButton *OpporBtn;
@property (strong,nonatomic)  IBOutlet UILabel *offerName;
@property (strong,nonatomic)  IBOutlet UILabel *subCategory;
@property (strong,nonatomic)  IBOutlet UILabel *vendorname;
@property (strong,nonatomic)  IBOutlet UILabel *offerDescription;
@property (strong,nonatomic)  IBOutlet UILabel *Timer;

@property (strong,nonatomic) NSString *ReserveKey;


@property (strong,nonatomic)  IBOutlet UILabel *address;
@property (strong,nonatomic)  IBOutlet UILabel *phoneNumber;
@property (strong,nonatomic)  IBOutlet UILabel *offerDate;
@property (strong,nonatomic)  IBOutlet UILabel *offerStatus;
@property (strong,nonatomic)  IBOutlet UILabel *available;
@property (strong,nonatomic) IBOutlet UIImageView *scrollImage;

@property(strong,nonatomic) IBOutlet UIView *contentView;
@property(strong,nonatomic) IBOutlet UIScrollView *scrollView;

@property(strong,nonatomic) IBOutlet UITabBar *tabBar;

@property (strong,nonatomic) IBOutlet UITableView *reservationTable;



-(IBAction)back:(id)sender;

-(IBAction)route:(id)sender;
-(IBAction)Edit:(id)sender;
@property (strong,nonatomic)  IBOutlet UIButton *editBtn;

@property (strong,nonatomic)  IBOutlet UIButton *Editedbtn;

@end
