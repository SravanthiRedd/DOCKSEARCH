//
//  EditOpp.m
//  RPRT
//
//  Created by sravanthi Gumma on 27/07/1938 Saka.
//  Copyright © 1938 Saka DevpointSolutions. All rights reserved.
//

#import "EditOpp.h"
#import "Constances.h"
#import "Web_Services.h"
#import "MZTimerLabel.h"
#import "CustomIOSAlertView.h"
#import "AppDelegate.h"
#import "MyBlockCell.h"
#import "Web_Services.h"
#import "Direction_Map.h"
#import "TimeCalculator.h"
#import "UIImage+MDQRCode.h"
#import "NSMutableAttributedString+StringColor.h"


@interface EditOpp ()<CustomIOSAlertViewDelegate>
{
    NSDictionary *GetSelectedOpportunity;
    Web_Services *mWebservice;
    
    
    UIImageView *ImageView;
    UIView *footerView;
    
    NSString *reviewRate;
    
    MZTimerLabel *TimeCoutDown;
    UIPageControl *pagecontroller;
    CustomIOSAlertView *ImageAlert;
    NSUserDefaults *mPref ;
    UIActivityIndicatorView *spinner;
    NSInteger timerCount;
    NSInteger indexs;
    int Remaingtyime;
    NSDictionary *startOffer;
    UIButton *block;
    NSDictionary *GetOpportunity;
    NSString *OpportunityID;
    
    NSMutableArray *reserveList;
    UITableView  *rTableview;
    TimeCalculator *mConverter;
    //Web_Services *mWebservice;
    
    NSMutableArray *FinalReservationArray;
    NSMutableArray *FinalintrestedArray;
    NSMutableArray *intrestedArray;
    
    
}
@end

@implementation EditOpp

@synthesize Timer,reservationTable;

- (void)viewDidLoad {
    [super viewDidLoad];
    mWebservice = [Web_Services GetSharedInstance];
   // mWebservice= [Web_Services GetSharedInstance];
    mConverter= [TimeCalculator GetSharedInstance];
    mPref = [NSUserDefaults standardUserDefaults];

    
    GetSelectedOpportunity= self.selectedOpportunity;
    
    NSMutableArray *tabBarItems = [[NSMutableArray alloc] init];
    UITabBarItem *activityTab =  [[UITabBarItem alloc] initWithTitle:@"Details" image:[UIImage imageNamed:@"myactivities_.png"] tag:1];
    UITabBarItem *myBlockTab =  [[UITabBarItem alloc] initWithTitle:@"Reservations" image:[UIImage imageNamed:@"myblocks_drw.png"] tag:2];
    
     UITabBarItem *intrestedTab =  [[UITabBarItem alloc] initWithTitle:@"Intrested" image:[UIImage imageNamed:@"myblocks_drw.png"] tag:3];
    
    [tabBarItems addObject:activityTab];
    [tabBarItems addObject:myBlockTab];
    [tabBarItems addObject:intrestedTab];
    self.tabBar.items = tabBarItems;
    self.tabBar.selectedItem = [tabBarItems objectAtIndex:0];
    [self loadOppDetails];
    [self LoadReserveList];
    self.reservationTable.hidden= YES;
    
    
    
    if ([self.ReserveKey isEqualToString:@"Reserve"]) {
        //isEqualToString:@"Reserve"] ||[[NotificationObj valueForKey:@"NotificationType"] isEqualToString:@"Intrested"]
        self.tabBar.selectedItem = [tabBarItems objectAtIndex:1];
       // self.reservationTable.hidden= NO;
        
        [self.scrollView setHidden:YES];
        [reservationTable setHidden:NO];
        
        reserveList = FinalReservationArray;
        intrestedArray = nil;
        
        if ([reserveList count]==0) {
            [reservationTable setHidden:YES];
        }
        [reservationTable reloadData];

        
        
    }
    else if ([self.ReserveKey isEqualToString:@"Intrested"])
    {
       // self.reservationTable.hidden= NO;
        self.tabBar.selectedItem = [tabBarItems objectAtIndex:2];
        
        reserveList= nil;
        intrestedArray= FinalintrestedArray;
        
        
        [self.scrollView setHidden:YES];
        [reservationTable setHidden:NO];
        
        if ([intrestedArray count]==0) {
            [reservationTable setHidden:YES];
        }
        [reservationTable reloadData];

        
        
    }
    
    
    
    
    
    
    //  NSUInteger *count = [GetBlocks count];
    // [[tabBarItems objectAtIndex:1] setBadge1];
    
    
  //  searchString = [[NSMutableArray alloc]init];
  //  prefss = [NSUserDefaults standardUserDefaults];
  //   NSString *RegisterID =   [prefss objectForKey:USERREGISTERID];
  //  [self GetVendorOpportunities:RegisterID];
  //  [self GetUserBlock:RegisterID];
    
    
    
   [[self.tabBar.items objectAtIndex:1] setBadgeValue:[NSString stringWithFormat:@"%lu",(unsigned long)[FinalReservationArray count]]];
    
    [[self.tabBar.items objectAtIndex:2] setBadgeValue:[NSString stringWithFormat:@"%lu",(unsigned long)[FinalintrestedArray count]]];
    
    
    
    

    // Do any additional setup after loading the view from its nib.
}

-(void)loadOppDetails
{
    
    self.offerName.text = [NSString stringWithFormat:@"%@",[GetSelectedOpportunity valueForKey:@"OpportunityName"]];
    self.subCategory.text = [NSString stringWithFormat:@"%@",[GetSelectedOpportunity valueForKey:@"SubCategory"]];
    self.vendorname.text = [NSString stringWithFormat:@"%@",[GetSelectedOpportunity valueForKey:@"VendorName"]];
    
    self.offerDescription.text =[NSString stringWithFormat:@"%@",[GetSelectedOpportunity valueForKey:@"OpportunityDescription"]];
    
    self.address.text =[NSString stringWithFormat:@"%@,%@,%@",[GetSelectedOpportunity valueForKey:@"Address1"],[GetSelectedOpportunity valueForKey:@"Address3"],[GetSelectedOpportunity valueForKey:@"AreaName"]];
    self.phoneNumber.text = [NSString stringWithFormat:@"%@",[GetSelectedOpportunity valueForKey:@"VendorMobile"]];
    
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"yyyy-MM-dd'T'HH:mm:ss"];
    NSTimeZone *gmt = [NSTimeZone timeZoneWithAbbreviation:@"UTC"];
    [dateFormatter setTimeZone:gmt];
    NSDate *date5 = [dateFormatter dateFromString:[GetSelectedOpportunity valueForKey:@"StartDate"]];
    //  NSString *start = [dateFormatter stringFromDate:date5];
    
    
    //  NSDate *date1 = [dateFormatter dateFromString:startime];
    
    NSDateFormatter *dateFormatter1 = [[NSDateFormatter alloc] init];
    [dateFormatter1 setDateFormat:@"yyyy-MM-dd'T'HH:mm:ss"];
    NSTimeZone *gmt1 = [NSTimeZone timeZoneWithAbbreviation:@"GMT"];
    [dateFormatter setTimeZone:gmt1];
    NSString *date = [dateFormatter1 stringFromDate:date5];
    
    date  = [date stringByReplacingOccurrencesOfString:@"T" withString:@" "];
    self.offerDate.text = date;
    
    [self EditOpp];
    
    
    NSString *imag = [GetSelectedOpportunity objectForKey:@"PhotoName"];
    NSArray *stringArray = [imag componentsSeparatedByString:@","];
    NSString *imageName;
    if (![stringArray[0] isEqualToString:@""]) {
        imageName = [stringArray objectAtIndex:0];
    }
    else
    {
        imageName =[GetSelectedOpportunity objectForKey:@"CategoryImage"];
    }
          UIImage *image;
                NSMutableString* aString = [NSMutableString stringWithFormat:@"%@%@",baseImageURL,imageName];
                NSURL *imageURL = [NSURL URLWithString:aString];
                NSString *key = [aString MD5Hash];
                NSData *getData = [FTWCache objectForKey:key];
                if (getData) {
                    image = [UIImage imageWithData:getData];
                    CGSize size = CGSizeMake(800, 450);
                   
                     self.scrollImage.image  = [mConverter image:image scaledToSize:size];
                }
                else {
                    //cell.OpportunityImage.image  = [UIImage imageNamed:@"img_def"];
                    dispatch_queue_t queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_HIGH, 0ul);
                    dispatch_async(queue, ^{
                        NSData *newData = [NSData dataWithContentsOfURL:imageURL];
                        [FTWCache setObject:newData forKey:key];
                        UIImage *image = [UIImage imageWithData:newData];
                        dispatch_sync(dispatch_get_main_queue(), ^{
                            CGSize size = CGSizeMake(800, 450);
                            
                            self.scrollImage.image  = [mConverter image:image scaledToSize:size];

                            
                        });
                    });
                }
    
    
    UITapGestureRecognizer *photoScrollTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(photoScrollTap)];
    photoScrollTap.numberOfTapsRequired = 1;
    [self.scrollImage setUserInteractionEnabled:YES];
    [self.scrollImage addGestureRecognizer:photoScrollTap];
    
    
    
}

-(void)cancel:(UIButton*)sender
{
    [ImageAlert close];
}



-(void)photoScrollTap{
    
    @try {
        
        
        ImageAlert=[[CustomIOSAlertView alloc] init];
        UIView  *imageView =[[UIView alloc] initWithFrame:CGRectMake(0, 0, 300, 310)];
        [ImageAlert setContainerView:imageView];
        [ImageAlert setButtonTitles:[NSMutableArray arrayWithObjects:@"", nil]];
        
        [ImageAlert setDelegate:self];
        
        
        // You may use a Block, rather than a delegate.
        [ImageAlert setOnButtonTouchUpInside:^(CustomIOSAlertView *alertView, int buttonIndex) {
            NSLog(@"Block: Button at position %d is clicked on alertView %d.", buttonIndex, (int)[alertView tag]);
            [alertView close];
        }];
        
        [ImageAlert setUseMotionEffects:true];
        
        
        UILabel *labl = [[UILabel alloc]initWithFrame:CGRectMake(10, 15, 200, 24)];
        labl.text= @"Right Place Right Time";
        
        UIButton *cancel = [[UIButton alloc]initWithFrame:CGRectMake(275, 10, 24, 24)];
        
        [cancel setImage:[UIImage imageNamed:@"ic_close"] forState:UIControlStateNormal];
        [cancel addTarget:self action:@selector(cancel:) forControlEvents:UIControlEventTouchUpInside];
        
        UIScrollView *pScoll= [[UIScrollView alloc]initWithFrame:CGRectMake(0, 20, 300, 300)];
        pScoll.delegate= self;
        
        NSString *imag = [GetSelectedOpportunity objectForKey:@"PhotoName"];
        NSArray *stringArray = [imag componentsSeparatedByString:@","];
        
        NSMutableArray   *Images = [NSMutableArray arrayWithCapacity:[stringArray count]];
        
        if (stringArray!=0 && ![stringArray[0] isEqualToString:@""]) {
            for (NSDictionary *dict in stringArray)
            {
                if (![dict isEqual:@""])
                {
                    UIImage *image;
                    
                    
                    NSMutableString* aString = [NSMutableString stringWithFormat:@"%@%@",baseImageURL,dict];
                    
                    
                    NSURL *imageURL = [NSURL URLWithString:aString];
                    NSString *key = [aString MD5Hash];
                    NSData *getData = [FTWCache objectForKey:key];
                    if (getData) {
                        image = [UIImage imageWithData:getData];
                        
                        [Images addObject:image];
                        
                    }
                    else {
                        //cell.OpportunityImage.image  = [UIImage imageNamed:@"img_def"];
                        dispatch_queue_t queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_HIGH, 0ul);
                        dispatch_async(queue, ^{
                            NSData *newData = [NSData dataWithContentsOfURL:imageURL];
                            [FTWCache setObject:newData forKey:key];
                            UIImage *image = [UIImage imageWithData:newData];
                            dispatch_sync(dispatch_get_main_queue(), ^{
                                [Images addObject:image];
                            });
                        });
                    }
                    
                }
            }
        }
        CGRect workingFrames =CGRectMake(pScoll.frame.origin.x, pScoll.frame.origin.y, pScoll.frame.size.width+10, pScoll.frame.size.height);
        
        
        UIImageView *imagView;
        
        for (int i=0 ; i<[Images count] ;i++)
        {
            
            UIImage *im= [Images objectAtIndex:i];
            
            CGSize size = CGSizeMake(250, 250);//[self image:img scaledToSize:size]
            
            
            imagView = [[UIImageView alloc] initWithImage:[mConverter image:im scaledToSize:size]];
            
            [imagView setContentMode:UIViewContentModeScaleAspectFit];
            
            imagView.frame = workingFrames;
            // ImageView.frame = CGRectMake(workingFrames.origin.x, 0, workingFrames.size.width+150, workingFrames.size.height+150);
            
            // NSLog(@"%@",workingFrame);
            [pScoll addSubview:imagView];
            
            workingFrames.origin.x = workingFrames.origin.x + workingFrames.size.width;
            
        }
        
        [pScoll setPagingEnabled:YES];
        
        [pScoll setContentSize:CGSizeMake(workingFrames.origin.x, workingFrames.size.height)];
        
        pagecontroller = [[UIPageControl alloc]initWithFrame:CGRectMake(150, 315, 50, 20)];
        
        pagecontroller.numberOfPages = [Images count];
        pagecontroller.currentPage = 0;
        pagecontroller.pageIndicatorTintColor = [UIColor blueColor];
       /// [pagecontroller addTarget:self action:@selector(changePage:) forControlEvents:UIControlEventTouchUpInside];
        [imageView addSubview:pagecontroller];
        
        
        // UIImageView *VendorProfile = [[UIImageView alloc]initWithImage:self.scrollImage.image];
        // VendorProfile.frame = CGRectMake(0, 20, 300, 230);
        [imageView addSubview:labl];
        [imageView addSubview:cancel];
        
        [imageView addSubview:pScoll];
        
        [ImageAlert show];
        ImageAlert.tag = 2;
        
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
    
    //ImageAlert = [CustomIOSAlertView ]
}

//-(void)


-(void)EditOpp
{
    
    [self.Editedbtn setImage:[UIImage imageNamed:@"editoffer.png"] forState:UIControlStateNormal];
    
    
    //self.Editedbtn.layer.masksToBounds = YES;
    //self.Editedbtn.layer.cornerRadius = 0.5 * self.Editedbtn.bounds.size.width;
    //[self.Editedbtn setBackgroundColor:[UIColor colorWithRed:63/256.0 green:81./256.0 blue:181.0/256.0 alpha:1]];
    
    [self.Editedbtn addTarget:self action:@selector(EditedOpportunity) forControlEvents:UIControlEventTouchUpInside];

    
    
    
    NSString *satrtDate = [NSString stringWithFormat:@"%@",[GetSelectedOpportunity valueForKey:@"EndDate"]];
    
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"yyyy-MM-dd'T'HH:mm:ss"];
    NSTimeZone *gmt = [NSTimeZone timeZoneWithAbbreviation:@"UTC"];
    [dateFormatter setTimeZone:gmt];
    NSDate *date5 = [dateFormatter dateFromString:satrtDate];
    
    
    if (date5!=nil) {
        startOffer= [[Preferences GetSharedInstance]remaningTime:[NSDate date] endDate:date5];
    }
    else{
        
        NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
        [dateFormatter setDateFormat:@"yyyy-MM-dd'T'HH:mm:ss.SSS"];
        
        NSTimeZone *gmt = [NSTimeZone timeZoneWithAbbreviation:@"UTC"];
        [dateFormatter setTimeZone:gmt];
        NSDate *date5 = [dateFormatter dateFromString:satrtDate];
        startOffer= [[Preferences GetSharedInstance]remaningTime:[NSDate date] endDate:date5];
        
    }
    
    Remaingtyime = [[startOffer valueForKey:@"Time"] intValue];
    // NSString   *OfferTag =[NSString stringWithFormat:@"%d",Remaingtyime];
    int hour = [[startOffer valueForKey:@"Hour"] intValue];
    int seconds = [[startOffer valueForKey:@"Seconds"] intValue];
    if (seconds!=0) {
        Remaingtyime = Remaingtyime+(seconds/60);
    }
    Timer.textColor =  [UIColor redColor];;
    
    //        if (seconds!=0) {
    //            Remaingtyime = Remaingtyime+(seconds/60);
    //        }
    
    if(Remaingtyime!=0 || seconds !=0)
    {
        Remaingtyime = Remaingtyime+(hour*60);
        
        [Timer setFont:[UIFont fontWithName:@"Oswald-Bold" size:24]];
        TimeCoutDown = [[MZTimerLabel alloc] initWithLabel:Timer andTimerType:MZTimerLabelTypeTimer];
        [TimeCoutDown setCountDownTime:Remaingtyime*60];
        [TimeCoutDown start];
        [self.editBtn setImage:[UIImage imageNamed:@"de_cancel.png"] forState:UIControlStateNormal];
        [self.editBtn addTarget:self action:@selector(StopOpp) forControlEvents:UIControlEventTouchUpInside];
    }
    
    else
    {
        Timer.text = @"Opportunities Expired!!";
        //CGSize siz =CGSizeMake(100, 50);
        // UIImage  *image=   [[TimeCalculator alloc]image:[UIImage imageNamed:@"de_restart.png"] scaledToSize:siz];
        [self.editBtn addTarget:self action:@selector(StartOpp) forControlEvents:UIControlEventTouchUpInside];
         [self.editBtn setImage:[UIImage imageNamed:@"de_restart.png"] forState:UIControlStateNormal];
        
        
        //[self.editBtn setImage:image forState:UIControlStateNormal];
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


-(void)tabBar:(UITabBar *)tabBar didSelectItem:(UITabBarItem *)item
{
    if(item.tag==1)
    {
        [self.scrollView setHidden:NO];
        [reservationTable setHidden:YES];
    }
    else  if(item.tag==2)
    {
       
        [self.scrollView setHidden:YES];
        [reservationTable setHidden:NO];
        
        reserveList = FinalReservationArray;
        intrestedArray = nil;
        
        if ([reserveList count]==0) {
            [reservationTable setHidden:YES];
        }
        else{
         [reservationTable reloadData];
        }
    }
    
    else  if(item.tag==3)
    {
        reserveList= nil;
        intrestedArray= FinalintrestedArray;
        
       
        [self.scrollView setHidden:YES];
        [reservationTable setHidden:NO];
        
        if ([intrestedArray count]==0) {
            [reservationTable setHidden:YES];
        }
        else{
         [reservationTable reloadData];
        }
    }
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/


-(NSMutableDictionary*)StopTime
{
    NSMutableDictionary *DateTimeData= [[NSMutableDictionary alloc]init];
    NSDate *currentDateInLocal = [NSDate date];
    
    NSDateFormatter *formatter = [[NSDateFormatter alloc]init];
    [formatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
    NSTimeZone *gmt = [NSTimeZone timeZoneWithAbbreviation:@"UTC"];
    [formatter setTimeZone:gmt];
    NSString *StartTimecon = [formatter stringFromDate:currentDateInLocal];
    [DateTimeData setValue:StartTimecon forKey:@"EndDate"];
    [DateTimeData setValue:@"15" forKey:@"Time"];
    return DateTimeData;
}

-(void)StopOpp
{ @try
    {
        spinner = [[UIActivityIndicatorView alloc]
                   initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
        spinner.frame = CGRectMake(0, 0, 320, 560); // CGPointMake(160, 240);
        spinner.color = [UIColor blueColor];
        spinner.backgroundColor = [UIColor lightTextColor];
        spinner.transform = CGAffineTransformMakeScale(2, 2);
        // spinner.hidesWhenStopped = YES;
        [self.view addSubview:spinner];
        spinner.transform = CGAffineTransformMakeScale(2, 2);
        
        [spinner startAnimating];
        
        // how we stop refresh from freezing the main UI thread
        
        dispatch_async(
                       dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^{
                           
                           // back to the main thread for the UI call
                           dispatch_async(dispatch_get_main_queue(), ^{
                               [spinner startAnimating];
                           });
                           dispatch_async(dispatch_get_main_queue(), ^{
                               
                               
                               
                               
                               NSString *DeviceID = [[[UIDevice currentDevice] identifierForVendor] UUIDString];
                               NSDictionary *date = [self StopTime];
                               
                               
                               
                               NSDictionary *Oppor= [self getEditeOpportunity];
                               
                               NSString *photoname  = [Oppor valueForKey:@"PhotoName"];
                               
                               photoname = [self getOpportunityimage:photoname];
                               
                               
                               NSString *AddressName= [NSString stringWithFormat:@"%@,%@,%@,%@",[GetSelectedOpportunity valueForKey:@"Address1"],[GetSelectedOpportunity valueForKey:@"Address2"],[GetSelectedOpportunity valueForKey:@"Address3"],[GetSelectedOpportunity valueForKey:@"AreaName"]];
                               
                               NSString *Location = [NSString stringWithFormat:@"%@,%@",[Oppor valueForKey:LATITUDE],[Oppor valueForKey:LONGITUDE]];
                               
                               
                               NSString *gcmID = [mPref valueForKey:@"FCMID"];
                               if ([gcmID isEqualToString:@""] || gcmID==nil) {
                                   gcmID=@"";
                               }
                               
                               
                               
                               NSDictionary *Opportunitu= @{@"OpportunityID":[Oppor valueForKey:@"OpportunityID"],
                                                            @"OpportunityName":[Oppor valueForKey:@"OpportunityName"],
                                                            @"OpportunityDescription":[Oppor valueForKey:@"OpportunityDescription"],
                                                            @"OpportunityKeywords":[Oppor valueForKey:@"OpportunityKeywords"],
                                                            @"Name":[Oppor valueForKey:@"OpportunityName"],
                                                            @"Price":[Oppor valueForKey:@"Price"],
                                                            @"CategoryID":[Oppor valueForKey:@"CategoryID"],
                                                            @"Time":@"15",
                                                            @"ModuleId":[Oppor valueForKey:@"ModuleId"],
                                                            @"UserID":@"0",
                                                            @"UserRegisterId":[Oppor valueForKey:@"UserRegisterId"],
                                                            @"StartDate":[Oppor valueForKey:@"StartDate"],
                                                            @"EndDate":[date valueForKey:@"EndDate"],
                                                            @"PromoCode":@"Promo",
                                                            @"OpportunityType":[Oppor valueForKey:@"OpportunityType"],
                                                            @"DeviceId":DeviceID,
                                                            @"PhotoName":photoname,
                                                            @"IsPrimary":@"true",
                                                            @"TimeInterval":@"1",
                                                            @"GcmId":gcmID,
                                                            @"Address1":[Oppor valueForKey:@"Address1"],
                                                            @"Address2":[Oppor valueForKey:@"Address2"],
                                                            @"Address3":[Oppor valueForKey:@"Address3"],
                                                            @"AreaName":[Oppor valueForKey:@"AreaName"],
                                                            @"AddressName":AddressName,
                                                            @"Quantity":@"0",
                                                            @"City":[Oppor valueForKey:@"City"],
                                                            @"State":[Oppor valueForKey:@"State"],
                                                            @"Country":[Oppor valueForKey:@"Country"],
                                                            LATITUDE:[Oppor valueForKey:LATITUDE],
                                                            LONGITUDE:[Oppor valueForKey:LONGITUDE],
                                                            @"Location":Location,
                                                            @"Categories":@"",
                                                            @"types":@"",
                                                            @"KeyWords":@"",
                                                            @"PageNo":@"1",
                                                            @"PageSize":@"10",
                                                            @"ActualPrice":@"0",
                                                            @"radius":@"500",
                                                            @"LocationFlag":@"NotChanged",
                                                            @"Delivery":@"",
                                                            @"Action":@"Stop"
                                                            };
                               NSDictionary *Reponse =  [[Web_Services GetSharedInstance]PostOffer:Opportunitu];
                               if (Reponse!=nil) {
                                   Retailer_Offer * mOpportunity_list = [[ Retailer_Offer alloc] initWithNibName:RETAILER bundle:nil];
                                   [self presentViewController:mOpportunity_list animated:YES completion:nil];
                                   
                                   if ([[Oppor valueForKey:@"ModuleId"] isEqualToString:@"33"]) {
                                       [self showAlertPop:@"Your Opportunities is stopped." expObj:nil];
                                   }
                                   else  if ([[Oppor valueForKey:@"ModuleId"] isEqualToString:@"34"]) {
                                       [self showAlertPop:@"Your Opportunities is stopped." expObj:nil];
                                   }
                                   
                                   else  if ([[Oppor valueForKey:@"ModuleId"] isEqualToString:@"36"]) {
                                       [self showAlertPop:@"Your job requirement is stopped." expObj:nil];
                                   }
                                   
                                   else if ([[Oppor valueForKey:@"ModuleId"] isEqualToString:@"37"]) {
                                       [self showAlertPop:@"Your Opportunities is stopped." expObj:nil];
                                   }
                                   else if ([[Oppor valueForKey:@"ModuleId"] isEqualToString:@"38"]) {
                                       [self showAlertPop:@"Your Opportunities is stopped." expObj:nil];
                                   }
                                   else if ([[Oppor valueForKey:@"ModuleId"] isEqualToString:@"39"]) {
                                       [self showAlertPop:@"Your Opportunities is stopped." expObj:nil];
                                   }
                                   else if ([[Oppor valueForKey:@"ModuleId"] isEqualToString:@"40"]) {
                                       [self showAlertPop:@"Your travel post is stopped." expObj:nil];
                                   }
                                   else if ([[Oppor valueForKey:@"ModuleId"] isEqualToString:@"41"]) {
                                       [self showAlertPop:@"Your property post is stopped." expObj:nil];
                                   }
                                   
                                   
                                   // [mPref setObject:remainingTime forKey:@"TimeSlot"];
                                 
                               }
                               [spinner stopAnimating];
                               
                           });
                       });
    }
    @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    }
    @finally {
        
    }
    
}


-(NSDictionary*)getEditeOpportunity
{
    @try {
        
        
        NSString *opportunityId= [GetSelectedOpportunity valueForKey:@"OpportunityID"];
        
        NSDictionary *Opportunity=[[Web_Services GetSharedInstance]GetOpportunityByID:opportunityId MethodName:@"GetOpportunityById"];
        
        return Opportunity;
    }
    @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    }
    @finally {
        
    }
    
}

-(NSString*)getOpportunityimage:(NSString*)imagenames
{
    @try {
        
        
        NSArray *imagearr =[imagenames componentsSeparatedByString:@","];
        NSMutableArray *imagearray = [[NSMutableArray alloc]init];
        
        for (int i=0;i<[imagearr count]; i++) {
            
            NSString *dict= [imagearr objectAtIndex:i];
            
            if (![dict isEqual:@""])
            {
                
                
                NSMutableString* aString = [NSMutableString stringWithFormat:@"%@%@",baseImageURL,dict];
                NSURL *imageURL = [NSURL URLWithString:aString];
                
                NSData *getData = [NSData dataWithContentsOfURL:imageURL];
                
                NSString *base64String = [getData base64EncodedStringWithOptions:0];
                [imagearray addObject:base64String];
                
            }
            
        }
        
        
        
        
        if ([imagearray count]==0) {
            imagenames =@"";
        }
        else{
            imagenames = [imagearray componentsJoinedByString:@","];
        }
        
        
        
        return imagenames;
    }
    @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    }
    @finally {
        
    }
    
}

-(void)StartOpp
{
    @try
    {
        spinner = [[UIActivityIndicatorView alloc]
                   initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
        spinner.frame = CGRectMake(0, 0, 320, 560); // CGPointMake(160, 240);
        spinner.color = [UIColor blueColor];
        spinner.backgroundColor = [UIColor lightTextColor];
        spinner.transform = CGAffineTransformMakeScale(2, 2);
        // spinner.hidesWhenStopped = YES;
        [self.view addSubview:spinner];
        spinner.transform = CGAffineTransformMakeScale(2, 2);
        
        [spinner startAnimating];
        
        // how we stop refresh from freezing the main UI thread
        
        dispatch_async(
                       dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^{
                           
                           // back to the main thread for the UI call
                           dispatch_async(dispatch_get_main_queue(), ^{
                               [spinner startAnimating];
                           });
                           dispatch_async(dispatch_get_main_queue(), ^{
                               
                               NSString *DeviceID = [[[UIDevice currentDevice] identifierForVendor] UUIDString];
                               NSDictionary *date = [self EditedDate];
                               
                               
                               
                               NSDictionary *Oppor= [self getEditeOpportunity];
                               
                               NSString *photoname  = [Oppor valueForKey:@"PhotoName"];
                               
                               photoname = [self getOpportunityimage:photoname];
                               
                               
                               NSString *AddressName= [NSString stringWithFormat:@"%@,%@,%@,%@",[GetSelectedOpportunity valueForKey:@"Address1"],[GetSelectedOpportunity valueForKey:@"Address2"],[GetSelectedOpportunity valueForKey:@"Address3"],[GetSelectedOpportunity valueForKey:@"AreaName"]];
                               
                               NSString *Location = [NSString stringWithFormat:@"%@,%@",[Oppor valueForKey:LATITUDE],[Oppor valueForKey:LONGITUDE]];
                               
                           //    NSString *regid =[mPref valueForKey:USERREGISTERID];
                               
                               
                               
                               
                               NSString *gcmID = [mPref valueForKey:@"FCMID"];
                               if ([gcmID isEqualToString:@""] || gcmID==nil) {
                                   gcmID=@"";
                               }
                               
                               
                               
                               NSDictionary    *Opportunity  = @{@"OpportunityID":@"0",
                                                                 @"OpportunityName":[Oppor valueForKey:@"OpportunityName"],
                                                                 @"OpportunityDescription":[Oppor valueForKey:@"OpportunityDescription"],
                                                                 @"OpportunityKeywords":[Oppor valueForKey:@"OpportunityKeywords"],
                                                                 @"CategoryID":[Oppor valueForKey:@"CategoryID"],
                                                                 @"ModuleId":[Oppor valueForKey:@"ModuleId"],
                                                                 @"UserID":@"0",
                                                                 
                                                                 @"StartDate":[Oppor valueForKey:@"StartDate"],
                                                                 @"EndDate":[date valueForKey:@"EndDate"],
                                                                 @"PromoCode":@"Promo",
                                                                 @"OpportunityType":[Oppor valueForKey:@"OpportunityType"],
                                                                 @"DeviceId":DeviceID,
                                                                 @"PhotoName":photoname,
                                                                 
                                                                 @"GcmId":gcmID,
                                                                 @"AddressName":AddressName,
                                                                 @"IsPrimary":@"true",
                                                                 @"Address1":[Oppor valueForKey:@"Address1"],
                                                                 @"Address3":[Oppor valueForKey:@"Address3"],
                                                                 @"Address2":[Oppor valueForKey:@"Address2"],
                                                                 @"AreaName":[Oppor valueForKey:@"AreaName"],
                                                                 @"Quantity":[Oppor valueForKey:@"Available"],
                                                                 @"City":[Oppor valueForKey:@"City"],
                                                                 @"State":[Oppor valueForKey:@"State"],
                                                                 @"Country":[Oppor valueForKey:@"Country"],
                                                                 LATITUDE:[Oppor valueForKey:LATITUDE],
                                                                 LONGITUDE:[Oppor valueForKey:LONGITUDE],
                                                                 @"KeyWords":@"",
                                                                 @"Time":@"15",
                                                                 @"PageSize":@"10",
                                                                 @"PageNo":@"1",
                                                                 @"radius":@"500",
                                                                 @"LocationFlag":@"NotChanged",
                                                                 @"Location":Location,
                                                                 @"Categories":@"",
                                                                 @"types":@"",
                                                                 @"UserRegisterId":[Oppor valueForKey:@"UserRegisterId"],
                                                                 @"Name":[Oppor valueForKey:@"OpportunityName"],
                                                                 @"Price":[Oppor valueForKey:@"Price"],
                                                                 @"ActualPrice":[Oppor valueForKey:@"ActualPrice"],
                                                                 @"Delivery":@"",
                                                                 @"Action":@"Restart"
                                                                 
                                                                 };
                               
                               
                               NSDictionary *Reponse =  [[Web_Services GetSharedInstance]PostOffer:Opportunity];
                               if (Reponse!=nil) {
                                   Retailer_Offer * mOpportunity_list = [[ Retailer_Offer alloc] initWithNibName:RETAILER bundle:nil];
                                   [self presentViewController:mOpportunity_list animated:YES completion:nil];
                                   [self showAlertPop:@"Your Opportunities is updated." expObj:nil];
                                   // [mPref setObject:remainingTime forKey:@"TimeSlot"];
                                 
                               }
                               [spinner stopAnimating];
                               
                           });
                       });
    }
    @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    }
    @finally {
        
    }
    
}


-(NSDictionary*)EditedDate
{
    @try {
        
        
        NSDate *currentDateInLocal = [NSDate date];
        NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
        [dateFormatter setDateFormat:@"yyyy-MM-dd'T'HH:mm:SS"];
        NSString *currentLocalDateAsStr = [dateFormatter stringFromDate:currentDateInLocal];
        NSArray *date = [currentLocalDateAsStr componentsSeparatedByString:@"T"];
        NSString  *Datelabel = [NSString stringWithFormat:@"%@",[date objectAtIndex:0]];
        NSString  *Timelabel = [NSString stringWithFormat:@"%@",[date objectAtIndex:1]];
        
        
        NSString *TimeInterval;
        NSString *dat=Timelabel;
        
        
        NSArray *arr = [dat componentsSeparatedByString:@":"];
        NSString *hou= [arr objectAtIndex:0];
        NSString *mm= [arr objectAtIndex:1];
        NSInteger hour = [hou intValue];
        NSInteger minute = [mm intValue];
        minute = minute;
        NSString *AddTime;
        
        //NSString *moduleid =[NSString stringWithFormat:@"%@",[EditOpportunity valueForKey:@"ModuleId"]];
        
        
        AddTime=@"15";
        
        
        
        // AddTime =    [offertime  valueForKey:@"Time"];
        
        TimeInterval = @"1";
        
        int Addvalue = [AddTime intValue];
        
        int minnit = Addvalue;
        
        NSInteger  endtimeH = hour;
        NSInteger   endtimeM = minute+minnit;
        
        if(endtimeM>60&&endtimeM<120)
        {
            endtimeH = hour+1;
            endtimeM = endtimeM-60;
        }
        else if(endtimeM<60)
        {
            endtimeH = hour;
            endtimeM = minute+minnit;
        }
        else if(endtimeM==60)
        {
            endtimeH = minute+1;
            endtimeM = 00;
        }
        
        else if(endtimeM<120&&endtimeM>60)
        {
            endtimeH = hour+1;
            endtimeM = (minute+minnit)-60;
        }
        
        
        NSString *str1=[NSString stringWithFormat:@"%@",Datelabel];
        
        NSString *str=[NSString stringWithFormat:@"%@ %ld:%ld:00",str1,(long)endtimeH,(long)endtimeM];
        str = [str stringByReplacingOccurrencesOfString:@"+0000" withString:@""];
        
        
        NSDateFormatter *Format = [[NSDateFormatter alloc]init];
        [Format setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
        
        
        NSDate *secondtime =[Format dateFromString:str];
        
        NSDateFormatter *formatter = [[NSDateFormatter alloc]init];
        [formatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
        
        
        
        NSTimeZone *gmt = [NSTimeZone timeZoneWithAbbreviation:@"UTC"];
        [formatter setTimeZone:gmt];
        
        
        NSString *SecondTime = [formatter stringFromDate:secondtime];
        
        NSMutableDictionary *DateTimeData = [[NSMutableDictionary alloc]init];
        
        
        [DateTimeData setValue:SecondTime forKey:@"EndDate"];
        [DateTimeData setValue:AddTime forKey:@"Time"];
        
        return DateTimeData;
        
    }
    @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    }
    @finally {
        
    }
    
}



-(void) viewDidLayoutSubviews
{
    
    
    
    [ super viewDidLayoutSubviews];
    [self.scrollView layoutIfNeeded];
    
    self.scrollView.contentSize = self.contentView.bounds.size;
    
    UIGraphicsBeginImageContext(self.view.frame.size);
    UIImage *image = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    self.contentView.backgroundColor = [UIColor colorWithPatternImage:image];
    
    
}

-(IBAction)route:(id)sender
{
    @try {
        
        Direction_Map *mMap= [Direction_Map alloc];
        mMap.direction =GetSelectedOpportunity;
        Direction_Map *mMapview =
        [mMap initWithNibName:@"Direction_Map" bundle:nil];
        [self presentViewController:mMapview animated:YES completion:nil];
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
}
- (void) showAlertPop:(NSString*)alertText expObj:(NSException*) exp{
    @try {
        
        if(exp != nil)
        {
            NSLog(@"%@", exp.description);
        }
        UIAlertController *myAlertController =[mWebservice  alert:alertText];
        [self presentViewController:myAlertController animated:YES completion:nil];
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
    
    
}


-(void)EditedOpportunity
{
    
    @try {
        
        spinner = [[UIActivityIndicatorView alloc]
                   initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
        spinner.frame = CGRectMake(0, 0, 320, 560); // CGPointMake(160, 240);
        spinner.color = [UIColor blueColor];
        spinner.backgroundColor = [UIColor lightTextColor];
        spinner.transform = CGAffineTransformMakeScale(2, 2);
        // spinner.hidesWhenStopped = YES;
        [self.view addSubview:spinner];
        spinner.transform = CGAffineTransformMakeScale(2, 2);
        
        [spinner startAnimating];
        
        // how we stop refresh from freezing the main UI thread
        
        dispatch_async(
                       dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^{
                           
                           // back to the main thread for the UI call
                           dispatch_async(dispatch_get_main_queue(), ^{
                               [spinner startAnimating];
                           });
                           dispatch_async(dispatch_get_main_queue(), ^{
                               
                               
                               if ([[GetSelectedOpportunity  valueForKey:@"ModuleId"] isEqualToString:@"33"]) {
                                   Post_Food *mPost = [[Post_Food alloc]initWithNibName:PFOOD bundle:nil];
                                   mPost.EditOpportunity = GetSelectedOpportunity;
                                   [self presentViewController:mPost animated:YES completion:nil];
                               }
                               
                               else if ([[GetSelectedOpportunity  valueForKey:@"ModuleId"] isEqualToString:@"34"]) {
                                   Post_Sales *mPost = [[Post_Sales alloc]initWithNibName:PSALES bundle:nil];
                                   mPost.EditOpportunity = GetSelectedOpportunity;
                                   [self presentViewController:mPost animated:YES completion:nil];
                               }
                               else if ([[GetSelectedOpportunity  valueForKey:@"ModuleId"] isEqualToString:@"36"]) {
                                   Post_Jobs *mPost = [[Post_Jobs alloc]initWithNibName:PJOBS bundle:nil];
                                   mPost.EditOpportunity = GetSelectedOpportunity;
                                   [self presentViewController:mPost animated:YES completion:nil];
                               }
                               else if ([[GetSelectedOpportunity  valueForKey:@"ModuleId"] isEqualToString:@"37"]) {
                                   Post_Professional *mPost = [[Post_Professional alloc]initWithNibName:PPROFESSIONAL bundle:nil];
                                   mPost.EditOpportunity = GetSelectedOpportunity;
                                   [self presentViewController:mPost animated:YES completion:nil];
                               }
                               else if ([[GetSelectedOpportunity  valueForKey:@"ModuleId"] isEqualToString:@"38"]) {
                                   Post_Sports *mPost = [[Post_Sports alloc]initWithNibName:PSPORTS bundle:nil];
                                   mPost.EditOpportunity = GetSelectedOpportunity;
                                   [self presentViewController:mPost animated:YES completion:nil];
                               }
                               else if ([[GetSelectedOpportunity  valueForKey:@"ModuleId"] isEqualToString:@"39"]) {
                                   Post_Meetings *mPost = [[Post_Meetings alloc]initWithNibName:PMEETINGS bundle:nil];
                                   mPost.EditOpportunity = GetSelectedOpportunity;
                                   [self presentViewController:mPost animated:YES completion:nil];
                               }
                               
                               else if ([[GetSelectedOpportunity  valueForKey:@"ModuleId"] isEqualToString:@"40"]) {
                                   Post_Travels *mPost = [[Post_Travels alloc]initWithNibName:PTRAVELS bundle:nil];
                                   mPost.EditOpportunity = GetSelectedOpportunity;
                                   [self presentViewController:mPost animated:YES completion:nil];
                               }
                               else if ([[GetSelectedOpportunity  valueForKey:@"ModuleId"] isEqualToString:@"41"]) {
                                   Post_RealEstate *mPost = [[Post_RealEstate alloc]initWithNibName:PREALESTATE bundle:nil];
                                   mPost.EditOpportunity = GetSelectedOpportunity;
                                   [self presentViewController:mPost animated:YES completion:nil];
                               }
                               else if ([[GetSelectedOpportunity  valueForKey:@"ModuleId"] isEqualToString:@"42"]) {
                                   Post_banking_Finance *mPost = [[Post_banking_Finance alloc]initWithNibName:PBANKINGANDFINANCE bundle:nil];
                                   mPost.EditOpportunity = GetSelectedOpportunity;
                                   [self presentViewController:mPost animated:YES completion:nil];
                               }
                               
                               else if ([[GetSelectedOpportunity  valueForKey:@"ModuleId"] isEqualToString:@"43"]) {
                                   Post_Health *mPost = [[Post_Health alloc]initWithNibName:PHEALTH bundle:nil];
                                   mPost.EditOpportunity = GetSelectedOpportunity;
                                   [self presentViewController:mPost animated:YES completion:nil];
                               }
                               [spinner stopAnimating];
                               
                           });
                       });
        
    }
    @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    }
    @finally {
        
    }
    
}



-(void)LoadReserveList
{
    @try {
        
        
        Web_Services *mwebservice = [Web_Services GetSharedInstance];
        
        NSString *oppId =[NSString stringWithFormat:@"%@", [GetSelectedOpportunity valueForKey:@"OpportunityID"]];
        
       // NSMutableArray *FinalReservationArray;
        FinalintrestedArray = [[NSMutableArray alloc]init];
        
        FinalReservationArray= [mwebservice GetVendorBlocks:oppId
                     MethodName:@"GetReservedOpportunitiesBYID"];
        
        
        
        for (int i=0; i<[FinalReservationArray count]; i++) {
            if ([[[FinalReservationArray objectAtIndex:i] valueForKey:@"BlockText"] isEqualToString:@"Notify"])
            {
                [FinalintrestedArray addObject:[FinalReservationArray objectAtIndex:i]];
            }
        }
        
        
        UILabel *opportunityName = [[UILabel alloc]initWithFrame:CGRectMake(0, 15, 350, 30)];
        opportunityName.text = [GetOpportunity valueForKey:@"OpportunityName"];
        [opportunityName setFont:[UIFont fontWithName:@"Roboto-Regular" size:16]];
        opportunityName.textAlignment = NSTextAlignmentCenter;
        [self.view addSubview:opportunityName];

    }
    @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    }
    @finally {
        
    }
    
    
}

#pragma mark - UITableViewDataSource
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (reserveList.count>0) {
        return reserveList.count;
    }
    else if (intrestedArray.count>0)
    {
        reserveList=intrestedArray;
        return reserveList.count;
    }
     return 10;
    
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 130;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    @try {
        // static NSString *simpleTableIdentifier = @"MyBlockCell";
        
        UserBlockCell *cell = (UserBlockCell *)[tableView dequeueReusableCellWithIdentifier:USERBLOCKCELL];
        if (cell == nil)
        {
            NSArray *nib = [[NSBundle mainBundle] loadNibNamed:USERBLOCKCELL owner:self options:nil];
            cell = [nib objectAtIndex:0];
        }
        
        // [cell updateConstraintsIfNeeded];
        
        NSDictionary *dic = [reserveList objectAtIndex:indexPath.row];
        cell.VendorName.text =[NSString stringWithFormat:@"%@",[dic valueForKey:@"RegUserName"]];
        cell.intrested.text = @"Intrested";
        //RegUserName
        cell.emaiId.text = [NSString stringWithFormat:@"%@",[dic valueForKey:@"RegEmail"]];
        cell.key.text = [NSString stringWithFormat:@"%@",[dic valueForKey:@"KeyValue"]];
        
        
      //  CGFloat imageSize = ceilf(self.view.bounds.size.width * 0.6f);
     //   UIImageView *imageView = [[UIImageView alloc] initWithFrame:CGRectMake(floorf(self.view.bounds.size.width * 0.5f - imageSize * 0.5f), floorf(self.view.bounds.size.height * 0.5f - imageSize * 0.5f), imageSize, imageSize)];
        
        
        NSArray *imagearr= [[dic valueForKey:@"PhotoName"] componentsSeparatedByString:@","];
        cell.vendorMobileNumber.text= [NSString stringWithFormat:@"%@",[dic valueForKey:@"PhoneNo"]];
        
        [cell.callBtn addTarget:self action:@selector(callBtn:) forControlEvents:UIControlEventTouchUpInside];
        
        
        // NSString *imageName = [NSString stringWithFormat:@"%@",[dic valueForKey:@"PhotoName"]];;
        
        NSString *ImageURL = [NSString stringWithFormat:@"%@%@",baseImageURL, [imagearr objectAtIndex:0]];
        
        NSURL *imageURL = [NSURL URLWithString:ImageURL];
        NSString *key = [ImageURL MD5Hash];
        NSData *getData = [FTWCache objectForKey:key];
        if (getData) {
            UIImage *image = [UIImage imageWithData:getData];
            cell.UserImage.image  = image;
        }
        else {
            cell.UserImage.image  = [UIImage imageNamed:@"img_def"];
            dispatch_queue_t queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_HIGH, 0ul);
            dispatch_async(queue, ^{
                NSData *newData = [NSData dataWithContentsOfURL:imageURL];
                [FTWCache setObject:newData forKey:key];
                UIImage *image = [UIImage imageWithData:newData];
                dispatch_sync(dispatch_get_main_queue(), ^{
                    cell.UserImage.image  = image;
                    
                });
            });
        }
        
        
        
        
        NSString *satrtDate = [NSString stringWithFormat:@"%@",[dic valueForKey:@"EndDate"]];
        
        NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
        [dateFormatter setDateFormat:@"yyyy-MM-dd'T'HH:mm:ss.SSS"];
        NSTimeZone *gmt = [NSTimeZone timeZoneWithAbbreviation:@"UTC"];
        [dateFormatter setTimeZone:gmt];
        NSDate *date5 = [dateFormatter dateFromString:satrtDate];
        
        NSDictionary *startOffer;
        if (date5!=nil) {
            
            // NSString *date =  [NSDate stringForDisplayFromDate:date5];
            
            NSDateFormatter *dateFormatter1 = [[NSDateFormatter alloc] init];
            [dateFormatter1 setDateFormat:@"yyyy-MM-dd'T'HH:mm:ss"];
            NSTimeZone *gmt1 = [NSTimeZone timeZoneWithAbbreviation:@"GMT"];
            [dateFormatter setTimeZone:gmt1];
            NSString *date = [dateFormatter1 stringFromDate:date5];
            
            cell.blockTime.text  = [date stringByReplacingOccurrencesOfString:@"T" withString:@" "];
            
            
            
            //            NSString *str=  [dateFormatter stringFromDate:date5];
            //            cell.blockTime.text  =[NSString stringWithFormat:@"%@",[str stringByReplacingOccurrencesOfString:@"T" withString:@" "]];
            startOffer= [[Preferences GetSharedInstance]remaningTime:[NSDate date] endDate:date5];
        }
        else{
            
            NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
            [dateFormatter setDateFormat:@"yyyy-MM-dd'T'HH:mm:ss"];
            
            NSTimeZone *gmt = [NSTimeZone timeZoneWithAbbreviation:@"UTC"];
            [dateFormatter setTimeZone:gmt];
            NSDate *date5 = [dateFormatter dateFromString:satrtDate];
            
            
            NSDateFormatter *dateFormatter1 = [[NSDateFormatter alloc] init];
            [dateFormatter1 setDateFormat:@"yyyy-MM-dd'T'HH:mm:ss"];
            NSTimeZone *gmt1 = [NSTimeZone timeZoneWithAbbreviation:@"GMT"];
            [dateFormatter setTimeZone:gmt1];
            NSString *date = [dateFormatter1 stringFromDate:date5];
            
            cell.blockTime.text  = [date stringByReplacingOccurrencesOfString:@"T" withString:@" "];
            
            
            //            NSString *str=  [dateFormatter stringFromDate:date5];
            //            cell.blockTime.text  =[NSString stringWithFormat:@"%@",[str stringByReplacingOccurrencesOfString:@"T" withString:@" "]];
            //  cell.blockedTime.text = [NSString stringWithFormat:@"%@",date5];
            
            startOffer= [[Preferences GetSharedInstance]remaningTime:[NSDate date] endDate:date5];
            
        }
        
        // NSDictionary *startOffer= [[Preferences alloc]remaningTime:[NSDate date] endDate:date5];
        int remain = [[startOffer valueForKey:@"Time"] intValue];
        int hour = [[startOffer valueForKey:@"Hour"] intValue];
        // Timer.textColor = categoryColor;
        int seconds = [[startOffer valueForKey:@"Seconds"] intValue];
        if (seconds!=0)
            remain = remain+(seconds/60);
        
        if(remain!=0 || seconds !=0)
        {
            remain = remain+(hour*60);
            TimeCoutDown = [[MZTimerLabel alloc] initWithLabel:cell.offerTimer andTimerType:MZTimerLabelTypeTimer];
            [TimeCoutDown setCountDownTime:remain*60];
            [TimeCoutDown start];
            
        }
        else
        {
            
            cell.offerTimer.text = @"Expired!!";
        }
        
        
        
        return cell;
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
    
    
    
}

-(void)callBtn:(id)sender
{
    CGPoint buttonPosition = [sender convertPoint:CGPointZero toView:rTableview];
    NSIndexPath *indexPath = [rTableview indexPathForRowAtPoint:buttonPosition];
    NSDictionary *selectedItem = [reserveList objectAtIndex:indexPath.row];
    NSString *contNumber = [selectedItem valueForKey:@"PhoneNo"];
    
    @try {
        UIDevice *device = [UIDevice currentDevice];
        if ([[device model] isEqualToString:@"iPhone"]) {
            
            NSURL *phoneUrl = [NSURL
                               URLWithString:[NSString stringWithFormat:@"telprompt:%@", contNumber]];
            
            if ([[UIApplication sharedApplication] canOpenURL:phoneUrl]) {
                UIApplication *application = [UIApplication sharedApplication];
                [application openURL:phoneUrl options:@{} completionHandler:nil];

                
                //  [[UIApplication sharedApplication] openURL:phoneUrl];
            }
            
        } else {
            
            UIAlertController *myAlertController =
            [[Web_Services alloc] alert:@"Your device doesn't support this feature."];
            [self presentViewController:myAlertController
                               animated:YES
                             completion:nil];
        }
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
    
    
    
}

-(IBAction)back:(id)sender
{
    [self dismissViewControllerAnimated:YES completion:nil];
}




@end
