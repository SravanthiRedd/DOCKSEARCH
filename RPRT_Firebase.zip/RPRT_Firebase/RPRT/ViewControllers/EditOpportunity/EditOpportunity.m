//
//  EditOpportunity.m
//  RPRT
//
//  Created by sravanthi Gumma on 27/05/16.
//  Copyright © 2016 DevpointSolutions. All rights reserved.
//

#import "EditOpportunity.h"
#import "EditOffer.h"
#import "Constances.h"
#import "Web_Services.h"
@interface EditOpportunity ()
{
    NSArray  *tabs;
    NSDictionary *GetSelectedOpportunity;
    Web_Services *mWebservice;
}
@end

@implementation EditOpportunity
@synthesize selectedOpportunity;
- (void)viewDidLoad {
    
    @try {
        
    [super viewDidLoad];
    
        mWebservice = [Web_Services GetSharedInstance];
    
    GetSelectedOpportunity= self.selectedOpportunity;
    
        
        NSString *path = [[NSBundle mainBundle] pathForResource:CATEGORY ofType:@"plist"];
        NSMutableDictionary *dict = [NSMutableDictionary dictionaryWithContentsOfFile:path];
     tabs = [dict valueForKey:CATEGORY];
     
//        self.dataSource = self;
//        self.delegate = self;
//        self.title = @"View Pager";
//        self.titlesLabels = [[NSMutableArray alloc] init];
//        // Keeps tab bar below navigation bar on iOS 7.0+
//        // if ([[[UIDevice currentDevice] systemVersion] floatValue] >= 7.0) {
//        //     self.edgesForExtendedLayout = UIRectEdgeNone;
//        // }
//        self.indicatorColor = [[UIColor blueColor] colorWithAlphaComponent:0.64];
//    self.tabsViewBackgroundColor = [UIColor colorWithRed:0.0/256 green:186.0/256 blue:210.0/256.0 alpha:1]; //colorWithAlphaComponent:0.32];
//        self.contentViewBackgroundColor = [[UIColor darkGrayColor] colorWithAlphaComponent:0.32];
//        self.dividerColor = [UIColor blackColor];
//        self.startFromSecondTab = NO;
//        self.centerCurrentTab = NO;
//        self.tabLocation = ViewPagerTabLocationTop;
//        self.tabHeight = 49;
//        self.tabOffset = 40;
//        self.tabWidth = UIInterfaceOrientationIsLandscape([[UIApplication sharedApplication] statusBarOrientation]) ? 128.0f : 110.0f;
//        self.fixFormerTabsPositions = NO;
//        self.fixLatterTabsPositions = NO;
//        self.shouldShowDivider = YES;
//        self.shouldAnimateIndicator = ViewPagerIndicatorAnimationWhileScrolling;
      //  self.numberOfTabs = 2;
        
       
        
    }
    @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    }
    @finally {
        
    }

    
        
    
}

#pragma mark - Setters

//- (void)setNumberOfTabs:(NSUInteger)numberOfTabs {
//  
//    @try {
//        
//    // Set numberOfTabs
//    _numberOfTabs = numberOfTabs;
//    // Reload data
//   // [self reloadData];
//    }
//    @catch (NSException *exception) {
//        [self showAlertPop:@"Error while fetching data." expObj:exception];
//    }
//    @finally {
//        
//    }
//    
//}
//
//#pragma mark - Helpers
//
//- (void)selectTabWithNumberFive {
//    @try {
//        
//   // [self selectTabAtIndex:0];
//    }
//    @catch (NSException *exception) {
//        [self showAlertPop:@"Error while fetching data." expObj:exception];
//    }
//    @finally {
//        
//    }
//}
//
//- (void)loadContent {
//    self.numberOfTabs = 2;
//}
//
//#pragma mark - Interface Orientation Changes
//
//- (void)willRotateToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation duration:(NSTimeInterval)duration {
//    @try {
//        
//    // Update changes after screen rotates
//    [self performSelector:@selector(setNeedsReloadOptions) withObject:nil afterDelay:duration];
//    }
//    @catch (NSException *exception) {
//        [self showAlertPop:@"Error while fetching data." expObj:exception];
//    }
//    @finally {
//        
//    }
//}
//
//#pragma mark - ViewPagerDataSource
//
//- (NSUInteger)numberOfTabsForViewPager:(ViewPagerController *)viewPager {
//    return self.numberOfTabs;
//}
//
//- (UIView *)viewPager:(ViewPagerController *)viewPager viewForTabAtIndex:(NSUInteger)index {
//    @try {
//        
//    // @try {
//        UILabel *label = [UILabel new];
//        label.backgroundColor = [UIColor clearColor];
//        //label.font = [UIFont systemFontOfSize:14.0];
//        label.text = [NSString stringWithFormat:@"%@", tabs[index]];
//        [label setFont:[UIFont fontWithName:@"Roboto-Medium" size:14]];
//        label.textAlignment = NSTextAlignmentCenter;
//        label.textColor = [UIColor whiteColor];
//        [label sizeToFit];
//    
//   
//    
//        [self.titlesLabels insertObject:label atIndex:index];
//        return label;
//    }
//    @catch (NSException *exception) {
//        [self showAlertPop:@"Error while fetching data." expObj:exception];
//    }
//    @finally {
//        
//    }
//    
//}
//
//- (UIViewController *)viewPager:(ViewPagerController *)viewPager contentViewControllerForTabAtIndex:(NSUInteger)index {
//    @try {
//        
//      EditOffer *cvc = [[ EditOffer alloc] initWithNibName:EDITOFFER bundle:nil];
//    
//    if (index == 0) {
//      
//        cvc.EditOpportunity = GetSelectedOpportunity;
//        cvc.Index =[NSString stringWithFormat:@"%lu", (unsigned long)index];
//        //return cvc;
//    }
//    else if (index==1)
//    {
//        cvc.EditOpportunity = GetSelectedOpportunity;
//        cvc.EditOpportunityID = [GetSelectedOpportunity valueForKey:@"OpportunityID"];
//        cvc.Index =[NSString stringWithFormat:@"%lu", (unsigned long)index];
//        
//    }
//    
//    
//    return cvc;
//    
//    
//   // @try {
//    
//        //getOppList = self.setOppList;
//        //cvc.SetOpportunities =self.setOppList;
//    
////    } @catch (NSException *exception) {
////        [self showAlertPop:@"Error while fetching data." expObj:exception];
////    } @finally {
////        
////    }
//    }
//    @catch (NSException *exception) {
//        [self showAlertPop:@"Error while fetching data." expObj:exception];
//    }
//    @finally {
//        
//    }
//    
//}
//
//- (void)viewPager:(ViewPagerController *)viewPager didChangeTabToIndex:(NSUInteger)index {
//    @try {
//        NSLog(@"index1 = %lu", (unsigned long)index);
//        for (UILabel *label in self.titlesLabels){
//            label.textColor = [UIColor whiteColor];
//        }
//        UILabel *label = self.titlesLabels[index];
//        label.textColor = [UIColor whiteColor];
//        
//        
//    } @catch (NSException *exception) {
//        [self showAlertPop:@"Error while fetching data." expObj:exception];
//    } @finally {
//        
//    }
//}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(IBAction)back:(id)sender
{
    @try {
        
    
     [self dismissViewControllerAnimated:YES completion:NULL];
    }
    @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    }
    @finally {
        
    }
}
- (void) showAlertPop:(NSString*)alertText expObj:(NSException*) exp{
    @try {
        
        if(exp != nil)
        {
            NSLog(@"%@", exp.description);
        }
        UIAlertController *myAlertController =[mWebservice  alert:alertText];
        [self presentViewController:myAlertController animated:YES completion:nil];
    }
    @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    }
    @finally {
        
    }
    
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
