//
//  Excluseive_Offer.h
//  RPRT
//
//  Created by sravanthi Gumma on 07/09/1938 Saka.
//  Copyright © 1938 Saka DevpointSolutions. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MainViewController.h"
//#import "MyBlocks.h"

@interface Excluseive_Offer : UIViewController<UITableViewDelegate,UITableViewDataSource,UITextFieldDelegate,UISearchBarDelegate>
{
    NSMutableArray *GetExclusiveArray;
    UIButton  *liveBtn;
    UIButton  *upcomingBtn;
    UIButton  *expiredBtn;
    UIButton *liveTapped;
    UIButton *upcomingTapped;
    UIButton *expiredTapped;
    NSMutableArray *opportunityArray;
    NSMutableArray *opporArray;
     UISearchBar *search;
}

@property(nonatomic,strong) IBOutlet UITableView *ExclusiveOfferTable;
@property(nonatomic,weak) IBOutlet UIView *helpSection;
@property (weak,nonatomic) IBOutlet UIView *checkview;
@property (weak,nonatomic) IBOutlet UIView *toolBar;

// HelpSection

@property(weak,nonatomic) IBOutlet UILabel *availbleStatus;
@property(weak,nonatomic) IBOutlet UILabel *availbleStatus1;
@property(weak,nonatomic) IBOutlet UILabel *availbleStatus2;
@property(weak,nonatomic) IBOutlet UILabel *soryString;
@property(weak,nonatomic) IBOutlet UILabel *ulString;
@property(weak,nonatomic) IBOutlet UILabel *grtDayString;
@property(weak,nonatomic) IBOutlet UILabel *howitsWorkLbl;

@property(weak,nonatomic) IBOutlet UIImageView *catImage1;
@property(weak,nonatomic) IBOutlet UIImageView *catImage2;
@property(weak,nonatomic) IBOutlet UIImageView *catImage3;
@end
