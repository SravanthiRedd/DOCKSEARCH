//
//  Excluseive_Offer.m
//  RPRT
//
//  Created by sravanthi Gumma on 07/09/1938 Saka.
//  Copyright © 1938 Saka DevpointSolutions. All rights reserved.
//

#import "Excluseive_Offer.h"
#import "MainViewController.h"
#import "Web_Services.h"
#import "Exclusive_Cell.h"
#import "TimeCalculator.h"
#import "MZTimerLabel.h"
#import "Details_Health.h"
#import "UIImage+Color.h"
#import "UIImage+MDQRCode.h"
#import <MessageUI/MessageUI.h>
#import "PopUpViewController.h"




@interface Excluseive_Offer ()<UIAlertViewDelegate,MFMailComposeViewControllerDelegate,MFMessageComposeViewControllerDelegate,CustomIOSAlertViewDelegate>
{
    NSDictionary *GetExlusiveOffers;
    Web_Services *mwebService;
    NSUserDefaults *mPref;
    NSString *CURRENCY_SYMBOL;
     GeoCodeLocation *geoCode;
     TimeCalculator *mTimecalculator;
    Preferences *mTimePreference;
    MZTimerLabel *TimeCoutDown;
    NSString * notifyIcon;
    NSString * blockIcon ;
    NSString * stopIcon;
    NSString * claimIcon;
    NSString * notifedIcon;
    
    NSMutableArray *livearry;
    NSMutableArray *upcomingarry;
    NSMutableArray *expiredarray;
    NSString *Key;
    UIActivityIndicatorView *spinner;
    CustomIOSAlertView *ImageAlert;
     UIColor *catColour;
   // TimeCalculator *mTimecalculator;
    
      BOOL isSearching;
}
@property (strong, nonatomic) PopUpViewController *popViewController;
@property (weak, nonatomic) IBOutlet UIView *Contentview;
@property (weak, nonatomic) IBOutlet UIScrollView *scrollview;

@end

@implementation Excluseive_Offer


- (void)viewDidLoad {
    [super viewDidLoad];
       mwebService = [Web_Services GetSharedInstance];
    mPref = [NSUserDefaults standardUserDefaults];
    [self.helpSection setHidden:YES];
    geoCode = [GeoCodeLocation GetSharedInstance];
    GetExclusiveArray = [[NSMutableArray alloc]init];
    mTimePreference= [Preferences GetSharedInstance];
    mTimecalculator = [TimeCalculator GetSharedInstance];
    opporArray = [[NSMutableArray alloc]init];
    notifyIcon = @"intrested.png";
    blockIcon = @"list_reserve.png";
    stopIcon= @"list_cancelbtn.png";
    claimIcon= @"list_claim.png";
    notifedIcon= @"list_notified.png";
    
    NSDictionary *components = [NSDictionary dictionaryWithObject:geoCode.countryCode forKey:NSLocaleCountryCode];
    NSString *localeIdent = [NSLocale localeIdentifierFromComponents:components];
    NSLocale *locale = [[NSLocale alloc] initWithLocaleIdentifier:localeIdent];
    CURRENCY_SYMBOL = [locale objectForKey:NSLocaleCurrencySymbol];
    
    [self GetMyExlusiveOffer];
    [self LoadCheckBoxs];
    [self loadTableview];

    
}

-(void)GetMyExlusiveOffer
{
    NSString *userRegID = [mPref valueForKey:USERREGISTERID];
    if (userRegID!=nil) {
        
        NSDictionary *dic = @{@"UserRegisterId":userRegID,
                              @"PageNo":@"1",
                              @"PageSize":@"10"
                              };
    GetExlusiveOffers =    [mwebService GetMyExclusiveOpportunities:dic];
        
        NSLog(@"Data %@",GetExclusiveArray);
        
    }
    
}
-(void)LoadCheckBoxs
{
    @try {
        
        
        // [[NSUserDefaults standardUserDefaults] setObject:colorData forKey:@"myColor"];
        
     //  NSString *category =[mPref valueForKey:CATEGORY];
        
        
        self.helpSection.layer.shadowColor = [UIColor lightGrayColor].CGColor;
        self.helpSection.layer.shadowOffset = CGSizeMake(0, 4);
        self.helpSection.layer.shadowOpacity = 1;
        self.helpSection.layer.shadowRadius = 1.0;
        
        
        NSMutableAttributedString *text = [self.howitsWorkLbl.attributedText mutableCopy];
        [text addAttribute:NSUnderlineStyleAttributeName value:@(NSUnderlineStyleSingle) range:NSMakeRange(0, text.length)];
        self.howitsWorkLbl.attributedText = text;
        
        catColour = [UIColor colorWithRed:204.0/256.0 green:40.0/256.0 blue:63.0/256.0 alpha:1];
        NSData *colorData = [NSKeyedArchiver archivedDataWithRootObject:catColour];
        [mPref setObject:colorData forKey:@"COLOR"];
        
        //CatImage.image = [UIImage imageNamed:@"food_lbk.png"];
        //toolbarLbl.text =@"Food";
        
        self.soryString.text = @"Sorry!! No Opportunities are going on now.";
        self.ulString.text = @"No more wastage of food";
        self.availbleStatus.text = @"Restaurants can post a 15 mins offer before closing the store.";
        self.availbleStatus1.text = @"You will be notified about it if you are near by";
        self.availbleStatus2.text = @"Block the Opportunities and redeem at the store.";
        
        self.grtDayString.text = @"Bon apetit!!";
        self.catImage1.image = [UIImage imageNamed:@"food_lst.png"];
        self.catImage2.image = [UIImage imageNamed:@"food_lst.png"];
        self.catImage3.image = [UIImage imageNamed:@"food_lst.png"];
        
        
        notifyIcon = @"list_notify.png";
        blockIcon = @"list_reserve.png";
        stopIcon= @"list_cancelbtn.png";
        claimIcon= @"list_claim.png";
        notifedIcon= @"list_notified.png";
       
       
        
        [mPref setValue:@"intrested_list.png" forKey:@"Notify"];
        [mPref setValue:@"de_reserve.png" forKey:@"Block"];
        [mPref setValue:@"de_cancel.png" forKey:@"Stop"];
        [mPref setValue:@"de_claim.png" forKey:@"Claim"];
        [mPref setValue:@"de_notified.png" forKey:@"Notified"];
        
        //Key = @"Live";
        Key = @"Live";
         catColour =[UIColor colorWithRed:104.0/256.0 green:162.0/256.0 blue:44.0/256.0 alpha:1];
        self.toolBar.backgroundColor =catColour;
        liveBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        liveBtn.frame = CGRectMake(10, 10, 150, 25);
        [liveBtn addTarget:self action:@selector(liveBtnClick:) forControlEvents:UIControlEventTouchUpInside];
        UIImage *image = [[UIImage alloc]init];
        image = [UIImage imageNamed:@"check.png"];
        
        
        CGSize siz =CGSizeMake(18, 18);
        image=   [mTimecalculator image:[UIImage imageNamed:@"check.png"] scaledToSize:siz];
        
        
        image =  [image imageWithTint:self.toolBar.backgroundColor];
        
        //    image = [self colorImage:image withColor:toolBarView.backgroundColor];
        //
        
        [liveBtn setImage: image forState:UIControlStateNormal];
        // [liveBtn ]
        [liveBtn setTitleEdgeInsets:UIEdgeInsetsMake(30, 0, 30, -15)];
        [liveBtn setTitle:@"Live" forState:UIControlStateNormal];
        [liveBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        liveBtn.tag = 1;
        
        [self.checkview addSubview:liveBtn];
        
        
        
        expiredBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        expiredBtn.frame = CGRectMake(135, 10, 150, 25);
        [expiredBtn addTarget:self action:@selector(expiredBtnClick:) forControlEvents:UIControlEventTouchUpInside];
        UIImage *eximg = [[UIImage alloc]init];
        eximg = [UIImage imageNamed:@"uncheck.png"];
        
        CGSize sizex =CGSizeMake(18, 18);
        eximg=   [mTimecalculator image:[UIImage imageNamed:@"uncheck.png"] scaledToSize:sizex];
        [expiredBtn setImage: eximg forState:UIControlStateNormal];
        [expiredBtn setTitleEdgeInsets:UIEdgeInsetsMake(30, 0, 30, -15)];
        [expiredBtn setTitle:@"Expired" forState:UIControlStateNormal];
        [expiredBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        expiredBtn.tag = 0;
        
        //        UILabel *lbl_card_count = [[UILabel alloc]initWithFrame:CGRectMake(120           ,0, 18, 18)];
        //        lbl_card_count.textColor = [UIColor whiteColor];
        //        lbl_card_count.textAlignment = NSTextAlignmentCenter;
        //        lbl_card_count.text = [NSString stringWithFormat:@"1"];
        //        lbl_card_count.layer.borderWidth = 1;
        //        lbl_card_count.layer.cornerRadius = 8;
        //        lbl_card_count.layer.masksToBounds = YES;
        //        lbl_card_count.layer.borderColor =[[UIColor clearColor] CGColor];
        //        lbl_card_count.layer.shadowColor = [[UIColor clearColor] CGColor];
        //        lbl_card_count.layer.shadowOffset = CGSizeMake(0.0, 0.0);
        //        lbl_card_count.layer.shadowOpacity = 0.0;
        //        lbl_card_count.backgroundColor = [UIColor colorWithRed:247.0/255.0 green:45.0/255.0 blue:143.0/255.0 alpha:1.0];
        //        lbl_card_count.font = [UIFont fontWithName:@"ArialMT" size:11];
        //        [expiredBtn addSubview:lbl_card_count];
        
        
        self.checkview.layer.cornerRadius = 45/2;
        
        
        self.checkview.layer.masksToBounds = false;
        self.checkview.layer.shadowColor = [UIColor blackColor].CGColor;
        self.checkview.layer.shadowOffset = CGSizeMake(0, 1);
        self.checkview.layer.shadowOpacity = 0.2;
        self.checkview.layer.cornerRadius = 5;
        [self.checkview addSubview:expiredBtn];

        
        
         // GetExclusiveArray =[GetExlusiveOffers valueForKey:@"Listongoing"];
        
        
    }
    @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
    
}
-(void)loadTableview
{
    //self.postLabel.backgroundColor =[UIColor colorWithRed:204.0/256.0 green:40.0/256.0 blue:63.0/256.0 alpha:1];
   // self.postLabel.textColor = [UIColor whiteColor];
    NSArray *expiredarrayCnt =[GetExlusiveOffers valueForKey:@"ListExpire"];
    
    UILabel *expiredTag = [[UILabel alloc]initWithFrame:CGRectMake(125,0, 18, 18)];
    expiredTag.textColor = [UIColor whiteColor];
    expiredTag.textAlignment = NSTextAlignmentCenter;
    expiredTag.text = [NSString stringWithFormat:@"%ld",(unsigned long)[expiredarrayCnt count]];
    expiredTag.layer.borderWidth = 1;
    expiredTag.layer.cornerRadius = 8;
    expiredTag.layer.masksToBounds = YES;
    expiredTag.layer.borderColor =[[UIColor clearColor] CGColor];
    expiredTag.layer.shadowColor = [[UIColor clearColor] CGColor];
    expiredTag.layer.shadowOffset = CGSizeMake(0.0, 0.0);
    expiredTag.layer.shadowOpacity = 0.0;
    expiredTag.backgroundColor =[UIColor colorWithRed:204.0/256.0 green:40.0/256.0 blue:63.0/256.0 alpha:1];// [UIColor colorWithRed:247.0/255.0 green:45.0/255.0 blue:143.0/255.0 alpha:1.0];
    
    expiredTag.font = [UIFont fontWithName:@"ArialMT" size:11];
    if ([expiredarrayCnt count]>0) {
        [expiredBtn addSubview:expiredTag];
    }
    
    
    NSArray *liverrayCnt =[GetExlusiveOffers valueForKey:@"Listongoing"];
    
    UILabel *liveTag = [[UILabel alloc]initWithFrame:CGRectMake(110,0, 18, 18)];
    liveTag.textColor = [UIColor whiteColor];
    liveTag.textAlignment = NSTextAlignmentCenter;
    liveTag.text = [NSString stringWithFormat:@"%ld",(unsigned long)[liverrayCnt count]];
    liveTag.layer.borderWidth = 1;
    liveTag.layer.cornerRadius = 8;
    liveTag.layer.masksToBounds = YES;
    liveTag.layer.borderColor =[[UIColor clearColor] CGColor];
    liveTag.layer.shadowColor = [[UIColor clearColor] CGColor];
    liveTag.layer.shadowOffset = CGSizeMake(0.0, 0.0);
    liveTag.layer.shadowOpacity = 0.0;
    liveTag.backgroundColor =[UIColor colorWithRed:204.0/256.0 green:40.0/256.0 blue:63.0/256.0 alpha:1];// [UIColor colorWithRed:247.0/255.0 green:45.0/255.0 blue:143.0/255.0 alpha:1.0];
    liveTag.font = [UIFont fontWithName:@"ArialMT" size:11];
    
    if ([liverrayCnt count]>0) {
        [liveBtn addSubview:liveTag];
    }
    
    if ([mPref valueForKey:@"Notification"]) {
    //    NotifiedOpportunityId =[NSString stringWithFormat:@"%@",[mPref valueForKey:@"NotificationID"]];
        [mPref setValue:nil forKeyPath:@"Notification"];
        [mPref setValue:nil forKeyPath:@"NotificationID"];
    }
    
    
    Key= [mPref valueForKey:@"Key"];
    if ([Key isEqualToString:@"Live"]) {
        
        livearry = [GetExlusiveOffers valueForKey:@"Listongoing"];
        if ([GetExclusiveArray count]>0) {
            for (int i=0; i<[livearry count]; i++) {
                [GetExclusiveArray addObject:livearry[i]];
                NSString *offerName = [GetExclusiveArray[i] valueForKey:@"OpportunityName"];
                [opporArray addObject:offerName];
            }
            opportunityArray = GetExclusiveArray;
            
//            if (![NotifiedOpportunityId isEqualToString:@""]) {
//                [self checkNotifiedObject:NotifiedOpportunityId];
//            }
            
            //   availbleStatus.hidden=YES;
            [self.ExclusiveOfferTable reloadData];
        }
        else
        {
            for (int i=0; i<[livearry count]; i++) {
                [GetExclusiveArray addObject:livearry[i]];
                NSString *offerName = [GetExclusiveArray[i] valueForKey:@"OpportunityName"];
                [opporArray addObject:offerName];
            }
            opportunityArray = GetExclusiveArray;
//            if (![NotifiedOpportunityId isEqualToString:@""]) {
//                [self checkNotifiedObject:NotifiedOpportunityId];
//            }
            //  availbleStatus.hidden=YES;
            [self.ExclusiveOfferTable reloadData];
        }
        
        if ([GetExclusiveArray count]==0) {
            //availbleStatus.hidden=NO;
            self.ExclusiveOfferTable.hidden = YES;
            [self.ExclusiveOfferTable reloadData];
            
        }
        else
        {
            
            
        }
    }
    
    else if ([Key isEqualToString:@"Expired"])
    {
        expiredBtn.tag = 1;
        
        [self setButtonimage:expiredBtn];
        
        expiredarray =[GetExlusiveOffers valueForKey:@"ListExpire"];
        if ([GetExclusiveArray count]>0) {
            for (int i=0; i<[expiredarray count]; i++) {
                [GetExclusiveArray addObject:expiredarray[i]];
                NSString *offerName = [GetExclusiveArray[i] valueForKey:@"OpportunityName"];
                [opporArray addObject:offerName];
            }
            opportunityArray = GetExclusiveArray;
        }
        else{
            for (int i=0; i<[expiredarray count]; i++) {
                [GetExclusiveArray addObject:expiredarray[i]];
                NSString *offerName = [GetExclusiveArray[i] valueForKey:@"OpportunityName"];
                [opporArray addObject:offerName];
            }
            opportunityArray = GetExclusiveArray;
            //            if (![NotifiedOpportunityId isEqualToString:@""]) {
            //                [self checkNotifiedObject:NotifiedOpportunityId];
            //            }
        }
        // availbleStatus.hidden=YES;
        [self.ExclusiveOfferTable reloadData];
    }
    
    else if ([Key isEqualToString:@"Live+Expired"])
    {
        liveBtn.tag =0;
        expiredBtn.tag = 0;
        
        
        livearry = [GetExlusiveOffers valueForKey:@"Listongoing"];
        if ([GetExclusiveArray count]>0) {
            for (int i=0; i<[livearry count]; i++) {
                [GetExclusiveArray addObject:livearry[i]];
                NSString *offerName = [GetExclusiveArray[i] valueForKey:@"OpportunityName"];
                [opporArray addObject:offerName];
            }
            opportunityArray = GetExclusiveArray;
        }
        else
        {
            for (int i=0; i<[livearry count]; i++) {
                [GetExclusiveArray addObject:livearry[i]];
                NSString *offerName = [GetExclusiveArray[i] valueForKey:@"OpportunityName"];
                [opporArray addObject:offerName];
            }
            opportunityArray = GetExclusiveArray;
            //            if (![NotifiedOpportunityId isEqualToString:@""]) {
            //                [self checkNotifiedObject:NotifiedOpportunityId];
            //            }
            
        }
        
        expiredarray =[GetExlusiveOffers valueForKey:@"ListExpire"];
        if ([GetExclusiveArray count]>0) {
            for (int i=0; i<[expiredarray count]; i++) {
                [GetExclusiveArray addObject:expiredarray[i]];
                NSString *offerName = [GetExclusiveArray[i] valueForKey:@"OpportunityName"];
                [opporArray addObject:offerName];
            }
            opportunityArray = GetExclusiveArray;
            //            if (![NotifiedOpportunityId isEqualToString:@""]) {
            //                [self checkNotifiedObject:NotifiedOpportunityId];
            //            }
        }
        else{
            for (int i=0; i<[expiredarray count]; i++) {
                [GetExclusiveArray addObject:expiredarray[i]];
                NSString *offerName = [GetExclusiveArray[i] valueForKey:@"OpportunityName"];
                [opporArray addObject:offerName];
            }
            opportunityArray = GetExclusiveArray;
            //            if (![NotifiedOpportunityId isEqualToString:@""]) {
            //                [self checkNotifiedObject:NotifiedOpportunityId];
            //            }
        }
        [self setButtonimage:liveBtn];
        [self setButtonimage:expiredBtn];
        // availbleStatus.hidden=YES;
        
        [self.ExclusiveOfferTable reloadData];
        
    }
    else
    {
        livearry = [GetExlusiveOffers valueForKey:@"Listongoing"];
        if ([GetExclusiveArray count]>0) {
            for (int i=0; i<[livearry count]; i++) {
                [GetExclusiveArray addObject:livearry[i]];
                NSString *offerName = [GetExclusiveArray[i] valueForKey:@"OpportunityName"];
                [opporArray addObject:offerName];
            }
            opportunityArray = GetExclusiveArray;
            //            if (![NotifiedOpportunityId isEqualToString:@""]) {
            //                [self checkNotifiedObject:NotifiedOpportunityId];
            //            }
            // availbleStatus.hidden=YES;
            [self.ExclusiveOfferTable reloadData];
        }
        else
        {
            for (int i=0; i<[livearry count]; i++) {
                [GetExclusiveArray addObject:livearry[i]];
                NSString *offerName = [GetExclusiveArray[i] valueForKey:@"OpportunityName"];
                [opporArray addObject:offerName];
            }
            opportunityArray = GetExclusiveArray;
            //            if (![NotifiedOpportunityId isEqualToString:@""]) {
            //                [self checkNotifiedObject:NotifiedOpportunityId];
            //            }
        }
        
        if ([GetExclusiveArray count]==0) {
            // availbleStatus.hidden=NO;
            self.ExclusiveOfferTable.hidden = YES;
            [self.ExclusiveOfferTable reloadData];
            
            
        }
        else
        {
            //
        }
        [self.ExclusiveOfferTable reloadData];
        
    }
}



-(void)liveBtnClick:(UIButton*)sender
{
    @try {
       
        
       // taglabel =0;
        liveTapped = (UIButton*)sender;
        
        
        spinner = [[UIActivityIndicatorView alloc]
                   initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
        spinner.frame = CGRectMake(0, 0, 320, 560); // CGPointMake(160, 240);
        spinner.color = [UIColor blueColor];
        spinner.backgroundColor = [UIColor lightTextColor];
        spinner.transform = CGAffineTransformMakeScale(2, 2);
        // spinner.hidesWhenStopped = YES;
        [self.view addSubview:spinner];
        spinner.transform = CGAffineTransformMakeScale(2, 2);
        
        [spinner startAnimating];
        
        // how we stop refresh from freezing the main UI thread
        
        dispatch_async(
                       dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^{
                           
                           
                           
                           // back to the main thread for the UI call
                           dispatch_async(dispatch_get_main_queue(), ^{
                               
                               
                               [spinner startAnimating];
                           });
                           dispatch_async(dispatch_get_main_queue(), ^{
                               
                               
                               if (liveTapped.tag == 0) {
                                   if ([Key isEqualToString:@"Live"]) {
                                       Key = @"Live";
                                   }
                                   else if ([Key isEqualToString:@"Expired"])
                                   {
                                       Key = @"Live+Expired";
                                   }
                                   
                                   livearry = [GetExlusiveOffers valueForKey:@"Listongoing"];
                                   if ([GetExclusiveArray count]>0) {
                                       for (int i=0; i<[livearry count]; i++) {
                                           [GetExclusiveArray addObject:livearry[i]];
                                           NSString *offerName = [GetExclusiveArray[i] valueForKey:@"OpportunityName"];
                                           [opporArray addObject:offerName];
                                       }
                                       //  availbleStatus.hidden=YES;
                                       opportunityArray = GetExclusiveArray;
                                   }
                                   else
                                   {
                                       for (int i=0; i<[livearry count]; i++) {
                                           [GetExclusiveArray addObject:livearry[i]];
                                           NSString *offerName = [GetExclusiveArray[i] valueForKey:@"OpportunityName"];
                                           [opporArray addObject:offerName];
                                       }
                                       opportunityArray = GetExclusiveArray;
                                       
                                   }
                                   [self setButtonimage:sender];
                                   
                                   
                               }
                               else if (liveTapped.tag == 1)
                               {
                                   
                                   if ([Key isEqualToString:@"Live+Expired"])
                                   {
                                       Key = @"Expired";
                                   }
                                   else if ([Key isEqualToString:@"Live"])
                                   {
                                       Key = @"";
                                   }
                                   else if ([Key isEqualToString:@"Expired"])
                                   {
                                       Key = @"Expired";
                                   }
                                   [self setButtonimage:sender];
                                   upcomingarry =[GetExlusiveOffers valueForKey:@"Listongoing"];
                                   if ([GetExclusiveArray count]>0) {
                                       for (int i=0; i<[upcomingarry count]; i++) {
                                           [GetExclusiveArray removeObject:upcomingarry[i]];
                                           
                                           NSString *offerName = [upcomingarry[i] valueForKey:@"OpportunityName"];
                                           [opporArray removeObject:offerName];
                                       }
                                       //   availbleStatus.hidden=YES;
                                       opportunityArray = GetExclusiveArray;
                                   }
                               }
                               
                               [self.ExclusiveOfferTable reloadData];
                               [spinner stopAnimating];
                               
                           });
                       });
        
        
        
        
        //[opportunityTable reloadData];
        
    }
    @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
}


-(void)expiredBtnClick:(UIButton*)sender
{
    
    @try {
//        table.hidden = YES;
//        
//        [searchText resignFirstResponder];
        liveTapped = (UIButton*)sender;
        
        spinner = [[UIActivityIndicatorView alloc]
                   initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
        spinner.frame = CGRectMake(0, 0, 320, 560); // CGPointMake(160, 240);
        spinner.color = [UIColor blueColor];
        spinner.backgroundColor = [UIColor lightTextColor];
        spinner.transform = CGAffineTransformMakeScale(2, 2);
        // spinner.hidesWhenStopped = YES;
        [self.view addSubview:spinner];
        spinner.transform = CGAffineTransformMakeScale(2, 2);
        
        [spinner startAnimating];
        
        // how we stop refresh from freezing the main UI thread
        
        dispatch_async(
                       dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^{
                           
                           
                           // back to the main thread for the UI call
                           dispatch_async(dispatch_get_main_queue(), ^{
                               
                               [spinner startAnimating];
                           });
                           dispatch_async(dispatch_get_main_queue(), ^{
                               
                               if (liveTapped.tag == 0) {
                                   
                                   if ([Key isEqualToString:@"Expired"]) {
                                       Key = @"Expired";
                                   }
                                   else if ([Key isEqualToString:@"Live"])
                                   {
                                       Key = @"Live+Expired";
                                   }
                                   
                                   
                                   
                                   expiredarray =[GetExlusiveOffers valueForKey:@"ListExpire"];
                                   if ([GetExclusiveArray count]>0) {
                                       for (int i=0; i<[expiredarray count]; i++) {
                                           [GetExclusiveArray addObject:expiredarray[i]];
                                           NSString *offerName = [GetExclusiveArray[i] valueForKey:@"OpportunityName"];
                                           [opporArray addObject:offerName];
                                       }
                                       // availbleStatus.hidden=YES;
                                       opportunityArray = GetExclusiveArray;
                                   }
                                   else{
                                       for (int i=0; i<[expiredarray count]; i++) {
                                           [GetExclusiveArray addObject:expiredarray[i]];
                                           NSString *offerName = [GetExclusiveArray[i] valueForKey:@"OpportunityName"];
                                           [opporArray addObject:offerName];
                                       }
                                       
                                       opportunityArray = GetExclusiveArray;
                                   }
                                   
                               }
                               else  if (liveTapped.tag == 1)
                               {
                                   
                                   if ([Key isEqualToString:@"Live+Expired"])
                                   {
                                       Key = @"Live";
                                   }
                                   else if ([Key isEqualToString:@"Expired"])
                                   {
                                       Key = @"";
                                   }
                                   else if ([Key isEqualToString:@"Live"])
                                   {
                                       Key = @"Live";
                                   }
                                   
                                   expiredarray =[GetExlusiveOffers valueForKey:@"ListExpire"];
                                   if ([GetExclusiveArray count]>0) {
                                       for (int i=0; i<[expiredarray count]; i++) {
                                           [GetExclusiveArray removeObject:[expiredarray objectAtIndex:i]];
                                           NSString *offerName = [[expiredarray objectAtIndex:i] valueForKey:@"OpportunityName"];
                                           [opporArray removeObject:offerName];
                                       }
                                       
                                       opportunityArray = GetExclusiveArray;
                                   }
                               }
                               
                               [self setButtonimage:sender];
                               dispatch_async(dispatch_get_main_queue(), ^{
                                   [self.ExclusiveOfferTable reloadData];
                               });
                               
                               
                               [spinner stopAnimating];
                               
                           });
                       });
    }
    @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
    
    // [self setButtonimage:sender];
}


-(void)setButtonimage:(UIButton*)sender
{
    @try
    {
        
        
        liveTapped = (UIButton*)sender;
        CGSize sizex =CGSizeMake(18, 18);
        if (liveTapped.tag == 1) {
            liveTapped.tag = 0;
            
            UIImage *eximg = [UIImage imageNamed:@"uncheck.png"];
            
            
            eximg=   [mTimecalculator image:eximg scaledToSize:sizex];
            
            
            [sender  setImage:eximg forState:UIControlStateNormal];
        }
        else if (liveTapped.tag == 0)
            
        {
            liveTapped.tag = 1;
            
            UIImage *eximg = [UIImage imageNamed:@"check.png"];
            CGSize siz =CGSizeMake(18, 18);
            eximg=   [mTimecalculator image:eximg scaledToSize:siz];
            
            
            eximg =  [eximg imageWithTint:_toolBar.backgroundColor];
            
            eximg=   [mTimecalculator image:eximg scaledToSize:sizex];
            
            
            [sender  setImage:eximg forState:UIControlStateNormal];
            
            // [sender  setImage:[UIImage imageNamed: @"check.png"] forState:UIControlStateNormal];
            
            
            if ([GetExclusiveArray count]>0) {
                
                //availbleStatus.hidden=YES;
                self.ExclusiveOfferTable.hidden= NO;
            }
            else
            {
                
                //   availbleStatus.hidden=NO;
                self.ExclusiveOfferTable.hidden= YES;
            }
            
        }
    }
    @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
}





- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
 
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
   return 190;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
  
    if ([GetExclusiveArray count]>0) {
        
        [self.helpSection setHidden:YES];
        //   return 1;
        return [GetExclusiveArray count];
        
    }
    
    else  if ([GetExclusiveArray count] == 0)
    {
        
        [self.helpSection setHidden:NO];
        return 0;
    }
    
    
    
      return [GetExclusiveArray count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    @try {
        
        
        
                    Exclusive_Cell *cell = (Exclusive_Cell *)[tableView dequeueReusableCellWithIdentifier:@"Exclusive_Cell"];
                    
                    //OpportunityCell *cell =(OpportunityCell *) [tableView dequeueReusableCellWithIdentifier:simpleTableIdentifier forIndexPath:indexPath];
                    
                    if (cell == nil)
                    {
                        NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"Exclusive_Cell" owner:self options:nil];
                        cell = [nib objectAtIndex:0];
                    }
        
                    NSDictionary *ExclusiveOpp = [GetExclusiveArray objectAtIndex:indexPath.row];
                    
                    //
                    NSIndexPath *indexPath = [NSIndexPath indexPathForRow:1 inSection: 1];
                    
                    [tableView selectRowAtIndexPath:indexPath animated:NO scrollPosition:UITableViewScrollPositionNone];
                    
                    
                    [cell.shareBtn addTarget:self action:@selector(shareData:) forControlEvents:UIControlEventTouchUpInside];
                    cell.shareBtn.imageView.alpha=0.5;
        
        cell.opportunity.text = [ExclusiveOpp valueForKey:@"OpportunityName"];
        cell.description.text = [ExclusiveOpp valueForKey:@"OpportunityDescription"];
        cell.Location.text = [ExclusiveOpp valueForKey:@"AreaName"];
        cell.categoryType.text=[ExclusiveOpp valueForKey:@"SubCategory"];
          cell.offerpostBy.text=[ExclusiveOpp valueForKey:@"UserName"];
                    
        NSString *imageName = [NSString stringWithFormat:@"%@",[ExclusiveOpp valueForKey:@"PhotoName"]];;
        NSArray *imageAry = [imageName componentsSeparatedByString:@","];
        NSString *ImageURL = [NSString stringWithFormat:@"%@%@",baseImageURL, [imageAry objectAtIndex:0]];
        
        if ([[imageAry objectAtIndex:0] isEqualToString:@""]) {
            
            imageName = [NSString stringWithFormat:@"%@",[ExclusiveOpp valueForKey:@"CategoryImage"]];;
            ImageURL = [NSString stringWithFormat:@"%@%@",baseImageURL, imageName];
            
            NSURL *imageURL = [NSURL URLWithString:ImageURL];
            NSString *key = [ImageURL MD5Hash];
            NSData *getData = [FTWCache objectForKey:key];
            if (getData) {
                UIImage *image = [UIImage imageWithData:getData];
                cell.OpportunityImage.image  = image;
            }
            else {
                cell.OpportunityImage.image  = [UIImage imageNamed:@"img_def"];
                dispatch_queue_t queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_HIGH, 0ul);
                dispatch_async(queue, ^{
                    NSData *newData = [NSData dataWithContentsOfURL:imageURL];
                    [FTWCache setObject:newData forKey:key];
                    UIImage *image = [UIImage imageWithData:newData];
                    dispatch_sync(dispatch_get_main_queue(), ^{
                        cell.OpportunityImage.image  = image;
                        
                    });
                });
            }
            
        }
        
        else {
            
            NSURL *imageURL = [NSURL URLWithString:ImageURL];
            NSString *key = [ImageURL MD5Hash];
            NSData *getData = [FTWCache objectForKey:key];
            if (getData) {
                UIImage *image = [UIImage imageWithData:getData];
                cell.OpportunityImage.image  = image;
            }
            else {
                cell.OpportunityImage.image  = [UIImage imageNamed:@"img_def"];
                dispatch_queue_t queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_HIGH, 0ul);
                dispatch_async(queue, ^{
                    NSData *newData = [NSData dataWithContentsOfURL:imageURL];
                    [FTWCache setObject:newData forKey:key];
                    UIImage *image = [UIImage imageWithData:newData];
                    dispatch_sync(dispatch_get_main_queue(), ^{
                        cell.OpportunityImage.image  = image;
                        
                    });
                });
            }
            
        }
        UITapGestureRecognizer *singleTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(ImageTap:)];
        singleTap.numberOfTapsRequired = 1;
        [cell.OpportunityImage setUserInteractionEnabled:YES];
        [cell.OpportunityImage addGestureRecognizer:singleTap];

        
        if ([[ExclusiveOpp valueForKey:@"Category"] isEqualToString:FOOD] || [[ExclusiveOpp valueForKey:@"Category"] isEqualToString:@"Sale"]) {
            
            if ([[ExclusiveOpp valueForKey:@"Delivery"] isEqualToString:@"Home Delivery Available"]) {
              cell.delivery.text= @"Free";
            }
            else
                cell.delivery.text= @"NA";
            
            NSMutableAttributedString *actual=[[NSMutableAttributedString alloc]initWithString:[NSString stringWithFormat:@"%@ %@",CURRENCY_SYMBOL,[ExclusiveOpp valueForKey:@"ActualPrice"]]];
            [actual addAttribute:NSStrikethroughStyleAttributeName value:[NSNumber numberWithInt:2] range:NSMakeRange(0,[actual length])];
            
            cell.actualprice.attributedText = actual;
            
            cell.price.text =[NSString stringWithFormat:@"%@ %@",CURRENCY_SYMBOL,[ExclusiveOpp valueForKey:@"Price"]];
            
            
            NSString *availacnt =[ExclusiveOpp valueForKey:@"Available"];
            int count = [availacnt intValue];
            if(count<0)
            {
                count = 0;
            }
            else count = count;
            cell.Avialable.text =[NSString stringWithFormat:@"Available:%d",count];
            
            
            //cell.Avialable.text= [NSString stringWithFormat:@"Available: %@",[ExclusiveOpp valueForKey:@"Available"]];
        }
        
        else  if ([[ExclusiveOpp valueForKey:@"Category"] isEqualToString:HEALTH] || [[ExclusiveOpp valueForKey:@"Category"] isEqualToString:@"Banking & Financial"] || [[ExclusiveOpp valueForKey:@"Category"] isEqualToString:@"Professional Services"])
        {
        
            [cell.deliveryLbl setHidden:YES];
             [cell.delivery setHidden:YES];
             [cell.price setHidden:YES];
             [cell.priceLbl setHidden:YES];
            [cell.actualprice setHidden:YES];
            [cell.Avialable setHidden:YES];
            [cell.Timer setHidden:NO];
            CGRect labelFrame = [cell.Timer frame];
            labelFrame.origin.x = 121; // set to whatever you want
            labelFrame.origin.y = 83;
            [cell.Timer setFrame:labelFrame];
           // [cell.Timer set]
        }
        
        
        else if ([[ExclusiveOpp valueForKey:@"Category"] isEqualToString:@"RealEstate"] || [[ExclusiveOpp valueForKey:@"Category"] isEqualToString:@"Meetings"] || [[ExclusiveOpp valueForKey:@"Category"] isEqualToString:@"Travel"])
        
        {
            NSString *availacnt =[ExclusiveOpp valueForKey:@"Available"];
            int count = [availacnt intValue];
            if(count<0)
            {
                count = 0;
            }
            else count = count;
            cell.Avialable.text =[NSString stringWithFormat:@"Available:%d",count];

            
            
//           cell.Avialable.text= [NSString stringWithFormat:@"Available: %@",[ExclusiveOpp valueForKey:@"Available"]];
            [cell.deliveryLbl setHidden:YES];
            [cell.delivery setHidden:YES];
            
            if ([[ExclusiveOpp valueForKey:@"Category"] isEqualToString:@"RealEstate"]) {
                cell.actualprice.text= @"Value";
                 [cell.actualprice setTextColor:[UIColor colorWithRed:237.0/256 green:65.0/256.0 blue:53.0/256.0 alpha:1]];
                [cell.priceLbl setHidden:YES];
                cell.price.text = [NSString stringWithFormat:@"%@ %@",CURRENCY_SYMBOL,[ExclusiveOpp valueForKey:@"Price"]];
            }
            
            else   if ([[ExclusiveOpp valueForKey:@"Category"] isEqualToString:@"Meetings"] || [[ExclusiveOpp valueForKey:@"Category"] isEqualToString:@"Travel"]) {
                cell.actualprice.text= @"Fee";
                [cell.actualprice setTextColor:[UIColor colorWithRed:237.0/256 green:65.0/256.0 blue:53.0/256.0 alpha:1]];
                [cell.priceLbl setHidden:YES];
                cell.price.text = [NSString stringWithFormat:@"%@ %@",CURRENCY_SYMBOL,[ExclusiveOpp valueForKey:@"Price"]];
            }
            
            if ([[ExclusiveOpp valueForKey:@"Category"] isEqualToString:@"Travel"]) {
                NSArray *offername = [[ExclusiveOpp valueForKey:@"OpportunityName"] componentsSeparatedByString:@"to"];
                
                NSArray *first = [[offername objectAtIndex:0] componentsSeparatedByString:@","];
                NSArray *second = [[offername objectAtIndex:1] componentsSeparatedByString:@","];
                cell.opportunity.text =[NSString stringWithFormat:@"From : %@  To : %@",[first objectAtIndex:0],[second objectAtIndex:0]];
                [cell.opportunity setFont:[UIFont fontWithName:@"Roboto-Bold" size:14]];
            }
            
            
        }
        
         else if ([[ExclusiveOpp valueForKey:@"Category"] isEqualToString:@"Jobs"] || [[ExclusiveOpp valueForKey:@"Category"] isEqualToString:@"Sports"])
         {
             NSString *availacnt =[ExclusiveOpp valueForKey:@"Available"];
             int count = [availacnt intValue];
             if(count<0)
             {
                 count = 0;
             }
             else count = count;
             cell.Avialable.text =[NSString stringWithFormat:@"Available:%d",count];

             
             
            // cell.Avialable.text= [NSString stringWithFormat:@"Available: %@",[ExclusiveOpp valueForKey:@"Available"]];
             [cell.deliveryLbl setHidden:YES];
             [cell.delivery setHidden:YES];
             [cell.price setHidden:YES];
             [cell.priceLbl setHidden:YES];
             [cell.actualprice setHidden:YES];
           

         }
        
        // OFFER TIMER
        
        if ([[ExclusiveOpp valueForKey:@"OppStatus"] isEqualToString:@"Live"]) {
            NSString *satrtDate = [NSString stringWithFormat:@"%@",[ExclusiveOpp valueForKey:@"EndDate"]];
            
            NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
            [dateFormatter setDateFormat:@"yyyy-MM-dd'T'HH:mm:ss"];
            NSTimeZone *gmt = [NSTimeZone timeZoneWithAbbreviation:@"UTC"];
            [dateFormatter setTimeZone:gmt];
            NSDate *date5 = [dateFormatter dateFromString:satrtDate];
            
            NSDictionary *startOffer;
            if (date5!=nil) {
                startOffer= [mTimePreference remaningTime:[NSDate date] endDate:date5];
            }
            else{
                
                NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
                [dateFormatter setDateFormat:@"yyyy-MM-dd'T'HH:mm:ss.SSS"];
                
                NSTimeZone *gmt = [NSTimeZone timeZoneWithAbbreviation:@"UTC"];
                [dateFormatter setTimeZone:gmt];
                NSDate *date5 = [dateFormatter dateFromString:satrtDate];
                startOffer= [mTimePreference remaningTime:[NSDate date] endDate:date5];
                
            }
            
            
            int Remaingtyime = [[startOffer valueForKey:@"Time"] intValue];
            int hour = [[startOffer valueForKey:@"Hour"] intValue];
            int seconds = [[startOffer valueForKey:@"Seconds"] intValue];
            if (seconds!=0) {
                Remaingtyime = Remaingtyime+(seconds/60);
            }
            if(Remaingtyime!=0)
            {
                
                Remaingtyime = Remaingtyime+(hour*60);//+minutes;
                
                
                
                
                NSString *userBlock =[NSString stringWithFormat:@"%@",[ExclusiveOpp valueForKey:@"BlockId"]];
                if (![userBlock isEqualToString:@"0"] && [[ExclusiveOpp valueForKey:@"OppStatus"] isEqualToString:@"Live"]) {
                    cell.blockBtn.tag= 1;
                    
                    
                    if ([[ExclusiveOpp valueForKey:@"BlockText"] isEqualToString:@"UnBlock"]) {
                        [cell.blockBtn setImage:[UIImage imageNamed:blockIcon] forState:UIControlStateNormal];
                        
                    }
                    else if([[ExclusiveOpp valueForKey:@"BlockText"] isEqualToString:@"Blocked"])
                    {
                        [cell.blockBtn setImage:[UIImage imageNamed:stopIcon] forState:UIControlStateNormal];
                        
                    }
                    
                    else if([[ExclusiveOpp valueForKey:@"BlockText"] isEqualToString:@"Claimed"])
                    {
                        [cell.blockBtn setImage:[UIImage imageNamed:claimIcon] forState:UIControlStateNormal];
                        cell.blockBtn.userInteractionEnabled = NO;
                        
                        
                    }
                    
                    //   [self.bLockBtn setBackgroundColor:[UIColor yellowColor]];
                    
                    
                }
                else if([userBlock isEqualToString:@"0"] && [[ExclusiveOpp valueForKey:@"OppStatus"] isEqualToString:@"Live"])
                {
                    //  [self.bLockBtn setBackgroundColor:[UIColor greenColor]];
                    [cell.blockBtn setImage:[UIImage imageNamed:blockIcon] forState:UIControlStateNormal];
                    
                    
                }
                else if ([[ExclusiveOpp valueForKey:@"OppStatus"] isEqualToString:@"Expired"])
                {
                    [cell.blockBtn setImage:[UIImage imageNamed:notifyIcon] forState:UIControlStateNormal];
                    
                    if([[ExclusiveOpp valueForKey:@"BlockText"] isEqualToString:@"Claimed"])
                    {
                        [cell.blockBtn setImage:[UIImage imageNamed:claimIcon] forState:UIControlStateNormal];
                        cell.blockBtn.userInteractionEnabled = NO;
                        
                    }
                    else if ([[ExclusiveOpp valueForKey:@"BlockText"] isEqualToString:@"Notify"])
                    {
                        [cell.blockBtn setImage:[UIImage imageNamed:notifedIcon] forState:UIControlStateNormal];
                        //cell.blockBtn.enabled = NO;
                    }
                    
                    
                }
                
                
                [cell.blockBtn addTarget:self action:@selector(Block:) forControlEvents:UIControlEventTouchUpInside];
                //[cell addSubview:blockBtn];
                
                
                
                TimeCoutDown = [[MZTimerLabel alloc] initWithLabel:cell.Timer andTimerType:MZTimerLabelTypeTimer];
                [TimeCoutDown setCountDownTime:Remaingtyime*60];
                [TimeCoutDown start];
            }
            
            NSString *RegisterID =   [mPref objectForKey:USERREGISTERID];
            if (RegisterID == [ExclusiveOpp valueForKey:@"UserRegisterId"])
            {
                cell.blockBtn.hidden= YES;
                
            }
            
        }
        else if ([[ExclusiveOpp valueForKey:@"OppStatus"] isEqualToString:@"Expired"])
        {
            
            NSString *RegisterID =   [mPref objectForKey:USERREGISTERID];
            if (RegisterID == [ExclusiveOpp valueForKey:@"UserRegisterId"])
            {
                cell.blockBtn.hidden= YES;
                
            }
            
            else  if ([[ExclusiveOpp valueForKey:@"Category"] isEqualToString:HEALTH] || [[ExclusiveOpp valueForKey:@"Category"] isEqualToString:@"Banking & Financial"] || [[ExclusiveOpp valueForKey:@"Category"] isEqualToString:@"Professional Services"])
            {
            
            cell.actualprice.text = @"Expired!!";
            }
            else  cell.Timer.text = @"Expired!!";
            //CGSize siz =CGSizeMake(63, 45);
            // UIImage  *image=   [mTimecalculator image:[UIImage imageNamed:notifyIcon] scaledToSize:siz];
            
            if (![[ExclusiveOpp valueForKey:@"BlockText"] isEqualToString:@"Notify"]) {
                [cell.blockBtn setImage:[UIImage imageNamed:notifyIcon] forState:UIControlStateNormal];
            }
            
            if ([[ExclusiveOpp valueForKey:@"BlockText"] isEqualToString:@"Notify"])
            {
                [cell.blockBtn setImage:[UIImage imageNamed:notifedIcon] forState:UIControlStateNormal];
                //cell.blockBtn.enabled = NO;
            }
            
            
            [cell.blockBtn addTarget:self action:@selector(Block:) forControlEvents:UIControlEventTouchUpInside];
        }
        
        return cell;
        
    }
    @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
}



-(IBAction)back:(id)sender
{
    Home *mHome= [[Home alloc]initWithNibName:HOMEDASHBOARD bundle:nil];
    [self presentViewController:mHome animated:YES completion:nil];
    
   // [self dismissViewControllerAnimated:YES completion:nil];
}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
    
    @try {
            [mPref setValue:Key forKey:@"Key"];
            
            NSDictionary *SelectedItem = [GetExclusiveArray objectAtIndex:indexPath.row];
            // [self saveViewOpprtunity:SelectedItem];
        
        NSString *category = [SelectedItem valueForKey:@"Category"];
            
            
            //
            //                                       Details_FoodAndSales *mDetails = [[Details_FoodAndSales alloc]initWithNibName:@"Details_FoodAndSales" bundle:nil];
            
            
            if([category isEqualToString:FOOD]||[category isEqualToString:SALES] ){
                
                
                //if ([[category valueForKey:FOOD] isEqualToString:FOOD] || [[category valueForKey:SALES] isEqualToString:SALES]) {
                
                
                Details_FoodAndSales *mDetails = [Details_FoodAndSales alloc];
                mDetails.SetSelectedOpportunity =SelectedItem;
                mDetails.Pagekey= @"Exclusive";
                Details_FoodAndSales *mDetailFoodandsale =[mDetails initWithNibName:@"Details_FoodAndSales" bundle:nil];
                [self presentViewController:mDetailFoodandsale animated:YES completion:nil];
            }
            
            //  }
            
            else if([category isEqualToString:PROFESSIONALHELP] || [category isEqualToString:BANKING])
            {
                
                Details_Events_Help_Banking *mDetails = [Details_Events_Help_Banking alloc];
                mDetails.SetSelectedOpportunity =SelectedItem;
                mDetails.setSelectedCategory =category;
                mDetails.Pagekey= @"Exclusive";
                Details_Events_Help_Banking *mDetailFoodandsale =[mDetails initWithNibName:@"Details_Events_Help_Banking" bundle:nil];
                [self presentViewController:mDetailFoodandsale animated:YES completion:nil];
            }
            
            else   if([category isEqualToString:TRAVELS]){
                
                
                //if ([[category valueForKey:FOOD] isEqualToString:FOOD] || [[category valueForKey:SALES] isEqualToString:SALES]) {
                
                
                Details_Travels *mDetails = [Details_Travels alloc];
                mDetails.SetSelectedOpportunity =SelectedItem;
                mDetails.Pagekey= @"Exclusive";
                Details_Travels *mDetailFoodandsale =[mDetails initWithNibName:@"Details_Travels" bundle:nil];
                [self presentViewController:mDetailFoodandsale animated:YES completion:nil];
            }
            
            else if ([category isEqualToString:REALESTATE])
            {
                
                
                Details_RealEstate *mDetails = [Details_RealEstate alloc];
                mDetails.SetSelectedOpportunity =SelectedItem;
                mDetails.Pagekey= @"Exclusive";
                Details_RealEstate *mDetailFoodandsale =[mDetails initWithNibName:@"Details_RealEstate" bundle:nil];
                [self presentViewController:mDetailFoodandsale animated:YES completion:nil];
                
                
            }
            
            
            else if ([category isEqualToString:JOBS] ||[category isEqualToString:SPORTS]|| [category isEqualToString:MEETINGS])
            {
                
                
                Details_GameandJobs *mDetails = [Details_GameandJobs alloc];
                mDetails.SetSelectedOpportunity =SelectedItem;
                mDetails.Pagekey= @"Exclusive";
                Details_GameandJobs *mDetailFoodandsale =[mDetails initWithNibName:@"Details_GameandJobs" bundle:nil];
                [self presentViewController:mDetailFoodandsale animated:YES completion:nil];
                
            }
            else if ( [category isEqualToString:HEALTH])
            {
                Details_Health *mDetails = [Details_Health alloc];
                mDetails.SetSelectedOpportunity =SelectedItem;
                mDetails.Pagekey= @"Exclusive";
                Details_Health *mDetailFoodandsale =[mDetails initWithNibName:@"Details_Health" bundle:nil];
                [self presentViewController:mDetailFoodandsale animated:YES completion:nil];
                
            }
            
        
        
    }
    @catch (NSException *exception) {
        
    }
    @finally {
        
    }
}


-(void)ImageTap:(UIPinchGestureRecognizer *)recognizer{
    
    @try {
        
        
        UIImageView *tableGridImage = (UIImageView*)recognizer.view;
        [self customimageAlert:tableGridImage];
        
        
        
    } @catch (NSException *exception) {
        
    } @finally {
        
    }
    
    //ImageAlert = [CustomIOSAlertView ]
}


-(void)customimageAlert:(UIImageView*)tableGridImage
{
    @try {
        
        
        ImageAlert=[[CustomIOSAlertView alloc] init];
        UIView  *imageView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 300, 200)];
        [ImageAlert setContainerView:imageView];
        [ImageAlert setButtonTitles:[NSMutableArray arrayWithObjects:@"", nil]];
        
        [ImageAlert setDelegate:self];
        
        
        // You may use a Block, rather than a delegate.
        [ImageAlert setOnButtonTouchUpInside:^(CustomIOSAlertView *alertView, int buttonIndex) {
            NSLog(@"Block: Button at position %d is clicked on alertView %d.", buttonIndex, (int)[alertView tag]);
            [alertView close];
        }];
        
        [ImageAlert setUseMotionEffects:true];
        
        UIButton *cancel = [[UIButton alloc]initWithFrame:CGRectMake(275, 0, 20, 20)];
        
        [cancel setImage:[UIImage imageNamed:@"ic_close"] forState:UIControlStateNormal];
        [cancel addTarget:self action:@selector(cancel:) forControlEvents:UIControlEventTouchUpInside];
        
        
        UIImageView *VendorProfile = [[UIImageView alloc]initWithImage:tableGridImage.image];
        VendorProfile.frame = CGRectMake(0, 20, 300, 230);
        [imageView addSubview:cancel];
        [imageView addSubview:VendorProfile];
        
        [ImageAlert show];
        ImageAlert.tag = 2;
    }
    @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
}


-(void)cancel:(UIButton*)sender
{
    [ImageAlert close];
}
-(void)Block:(UIButton*)sender
{
    
    
    @try {
        
        if (isOnlineStatus) {
            
            
            spinner = [[UIActivityIndicatorView alloc]
                       initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
            spinner.frame = CGRectMake(0, 0, 320, 560); // CGPointMake(160, 240);
            spinner.color = [UIColor blueColor];
            spinner.backgroundColor = [UIColor lightTextColor];
            spinner.transform = CGAffineTransformMakeScale(2, 2);
            // spinner.hidesWhenStopped = YES;
            [self.view addSubview:spinner];
            spinner.transform = CGAffineTransformMakeScale(2, 2);
            
            [spinner startAnimating];
            
            // how we stop refresh from freezing the main UI thread
            
            dispatch_async(
                           dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^{
                               
                               // back to the main thread for the UI call
                               dispatch_async(dispatch_get_main_queue(), ^{
                                   [spinner startAnimating];
                               });
                               dispatch_async(dispatch_get_main_queue(), ^{
                                   NSUserDefaults *prefss = [NSUserDefaults standardUserDefaults];
                                   
                                   CGPoint buttonPosition = [sender convertPoint:CGPointZero toView:self.ExclusiveOfferTable];
                                   
                                   
                                   
                                   NSIndexPath *indexPath = [self.ExclusiveOfferTable indexPathForRowAtPoint:buttonPosition];
                                   
                                   
                                   
                                   NSDictionary *BlockedItem = [GetExclusiveArray objectAtIndex:indexPath.row];
                                   NSString *RegisterID =   [prefss objectForKey:USERREGISTERID];
                                   
                                   if (RegisterID!=[BlockedItem valueForKey:@"UserRegisterId"] && RegisterID!=nil) {
                                       
                                       
                                       NSInteger availablecoutn = [[BlockedItem valueForKey:@"Available"] intValue];
                                       
                                       if (availablecoutn >= 1) {
                                           
                                           if([[BlockedItem valueForKey:@"OppStatus"] isEqualToString:@"Expired"])
                                           {
                                               UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"Right Place Right Time"
                                                                                                              message:@"Sorry! It's expired. Please click on notify to get notified in future."
                                                                                                       preferredStyle:UIAlertControllerStyleAlert];
                                               
                                               UIAlertAction* ok = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault
                                                                                          handler:^(UIAlertAction * action) {
                                                                                              
                                                                                              [self blockorNotify:buttonPosition];
                                                                                              
                                                                                          }];
                                               UIAlertAction* cancel = [UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleDefault
                                                                                              handler:^(UIAlertAction * action) {
                                                                                                  [alert dismissViewControllerAnimated:YES completion:nil];
                                                                                                  
                                                                                                  
                                                                                              }];
                                               
                                               [alert addAction:ok];
                                               [alert addAction:cancel];
                                               [self presentViewController:alert animated:YES completion:nil];
                                           }
                                           else
                                           {
                                               [self blockorNotify:buttonPosition];
                                               
                                           }
                                           
                                       }
                                       else
                                       {
                                           
                                           [self blockorNotify:buttonPosition];
                                           
                                           
                                       }
                                       
                                   }
                                   
                                   else if (RegisterID == [BlockedItem valueForKey:@"UserRegisterId"])
                                   {
                                       UIAlertController * login=   [UIAlertController
                                                                     alertControllerWithTitle:@"RPRT"
                                                                     message:@"Unable to Reserve the Opportunities"
                                                                     preferredStyle:UIAlertControllerStyleAlert];
                                       
                                       UIAlertAction* yesButton = [UIAlertAction
                                                                   actionWithTitle:@"OK"
                                                                   style:UIAlertActionStyleDefault
                                                                   handler:^(UIAlertAction * action)
                                                                   {
                                                                       [login dismissViewControllerAnimated:YES completion:nil];
                                                                       
                                                                       //[self dismissViewControllerAnimated:alert completion:nil];
                                                                   }];
                                       
                                       [login addAction:yesButton];
                                       
                                       
                                       //[self dismissViewControllerAnimated:YES completion:nil];
                                       [self presentViewController:login animated:YES completion:nil];
                                   }
                                   
                                   else if(RegisterID ==nil) {
                                       UIAlertController * alert=   [UIAlertController
                                                                     alertControllerWithTitle:@"RPRT"
                                                                     message:@"Please Register/Login"
                                                                     preferredStyle:UIAlertControllerStyleAlert];
                                       
                                       UIAlertAction* yesButton = [UIAlertAction
                                                                   actionWithTitle:@"OK"
                                                                   style:UIAlertActionStyleDefault
                                                                   handler:^(UIAlertAction * action)
                                                                   {
                                                                       [mPref setObject:@"List" forKey:@"PageName"];
                                                                       
                                                                       self.popViewController = [[PopUpViewController alloc] initWithNibName:@"PopUpViewController" bundle:nil];
                                                                       [self.popViewController setTitle:@"This is a popup view"];
                                                                       
                                                                       [self.popViewController showInView:self.view withImage:[UIImage imageNamed:@"rprt_usinfo.png"] withMessage:@"You just triggered a great popup window" animated:YES];
                                                                       
                                                                       
                                                                       
//                                                                       Login * mLogin = [[ Login alloc] initWithNibName:LOGIN bundle:nil];
//                                                                       [self presentViewController:mLogin animated:YES completion:nil];
                                                                       
                                                                       //[self dismissViewControllerAnimated:alert completion:nil];
                                                                   }];
                                       
                                       UIAlertAction* cancelBtn = [UIAlertAction
                                                                   actionWithTitle:@"Cancel"
                                                                   style:UIAlertActionStyleDefault
                                                                   handler:^(UIAlertAction * action)
                                                                   {
                                                                       
                                                                       [self dismissViewControllerAnimated:alert completion:nil];
                                                                   }];
                                       
                                       
                                       
                                       [alert addAction:yesButton];
                                       [alert addAction:cancelBtn];
                                       
                                       
                                       [self presentViewController:alert animated:YES completion:nil];
                                       
                                   }
                                   
                                   [spinner stopAnimating];
                                   
                               });
                           });
        }
        else if (!isOnlineStatus)
        {
            [self showAlertPop:@"No internet connection" expObj:nil];
        }
        
    }
    @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
}

-(void)blockorNotify:(CGPoint)buttonPosition
{
    @try {
        
        if (isOnlineStatus) {
            
            NSIndexPath *indexPath = [self.ExclusiveOfferTable indexPathForRowAtPoint:buttonPosition];
            NSDictionary *BlockedItem = [GetExclusiveArray objectAtIndex:indexPath.row];
             NSString *category = [BlockedItem valueForKey:@"Category"];
            NSString *RegisterID =   [mPref objectForKey:USERREGISTERID];
            NSMutableDictionary *dic = [[NSMutableDictionary alloc]init];
            NSString *uniqueIdentifier = [[[UIDevice currentDevice] identifierForVendor] UUIDString];
            [dic setValue:[BlockedItem valueForKey:@"OpportunityID"] forKey:@"OpportunityId"];
            //[dic setValue:[BlockedItem valueForKey:@"KeyValue"] forKey:@"KeyValue"];
            
            if ([[BlockedItem valueForKey:@"OppStatus"] isEqualToString:@"Expired"])
            {
                [dic setValue:@"Notify" forKey:@"BlockText"];
                [dic setValue:@"0" forKey:@"BlockId"];
                [dic setValue:@"0" forKey:@"Quantity"];
            }
            
            
            else if ([[BlockedItem valueForKey:@"BlockId"] intValue] ==0 && [[BlockedItem valueForKey:@"OppStatus"] isEqualToString:@"Live"]) {
                [dic setValue:@"Blocked" forKey:@"BlockText"];
                [dic setValue:@"0" forKey:@"BlockId"];
                [dic setValue:@"1" forKey:@"Quantity"];
                if([category isEqualToString:HEALTH] || [category isEqualToString:REALESTATE] || [category isEqualToString:PROFESSIONALHELP] ||
                   [category isEqualToString:BANKING])
                {
                    [dic setValue:@"0" forKey:@"Quantity"];
                }
                
            }
            
            else if ([[BlockedItem valueForKey:@"BlockId"] intValue] !=0 && [[BlockedItem valueForKey:@"OppStatus"] isEqualToString:@"Live"])
            {
                
                if ([[BlockedItem valueForKey:@"BlockText"] isEqualToString:@"UnBlock"]) {
                    
                    [dic setValue:@"Blocked" forKey:@"BlockText"];
                    [dic setValue:[BlockedItem valueForKey:@"BlockId"] forKey:@"BlockId"];
                    [dic setValue:@"1" forKey:@"Quantity"];
                    if([category isEqualToString:HEALTH] || [category isEqualToString:REALESTATE] || [category isEqualToString:PROFESSIONALHELP] ||
                       [category isEqualToString:BANKING])
                    {
                        [dic setValue:@"0" forKey:@"Quantity"];
                    }
                    
                }
                else if ([[BlockedItem valueForKey:@"BlockText"] isEqualToString:@"Blocked"])
                {
                    [dic setValue:@"UnBlock" forKey:@"BlockText"];
                    [dic setValue:[BlockedItem valueForKey:@"BlockId"] forKey:@"BlockId"];
                    [dic setValue:@"0" forKey:@"Quantity"];
                    
                }
            }
            
            
            
            
            [dic setValue:uniqueIdentifier forKey:@"DeviceId"];
            [dic setValue:RegisterID forKey:@"BlockedUserId"];
            //
            [dic setValue:@""  forKey:@"ClaimedTime"];
            [dic setValue:@"" forKey:@"TransactionComplete"];
            NSString *keyValue = [NSString stringWithFormat:@"RPRT-%@-%@-%@",[BlockedItem valueForKey:@"OpportunityID"],RegisterID,[BlockedItem valueForKey:@"UserRegisterId"]];
            [dic setValue:keyValue forKey:@"KeyValue"];
            
            // NSString *OfferName =[NSString stringWithFormat:@"The selected %@ was blocked", [BlockedItem valueForKey:@"VendorName"]];
            NSDictionary *blockeditemResponse =[mwebService SaveBlockeditem:dic];
            if ((blockeditemResponse!=nil)) {
                
                NSString * erroeMessage =[blockeditemResponse valueForKey:@"ErrorMessage"];
                
                if ( ( ![erroeMessage isEqual:[NSNull null]] ) && ( [erroeMessage length] != 0 ) ) {
                    [self showAlertPop:erroeMessage expObj:nil];
                }
                
                if (( [erroeMessage isEqual:[NSNull null]])) {
                    
                    
                    if ([[blockeditemResponse valueForKey:@"BlockText"] isEqualToString:@"Blocked"]) {
                        [self showAlertPop:@"Your request is placed, please be on time!!" expObj:nil];
                        
                    }
                    else if ([[blockeditemResponse valueForKey:@"BlockText"] isEqualToString:@"UnBlock"]) {
                        [self showAlertPop:@"Your Opportunities request is cancelled!" expObj:nil];
                        
                    }
                    
                    else if ([[blockeditemResponse valueForKey:@"BlockText"] isEqualToString:@"Notify"])
                    {
                        [self showAlertPop:@"This Opportunities will Notify you" expObj:nil];
                    }
                    
                }
                
                
                
                
                CGFloat imageSize = ceilf(self.view.bounds.size.width * 0.6f);
                UIImageView *imageView = [[UIImageView alloc] initWithFrame:CGRectMake(floorf(self.view.bounds.size.width * 0.5f - imageSize * 0.5f), floorf(self.view.bounds.size.height * 0.5f - imageSize * 0.5f), imageSize, imageSize)];
                // [viewController.view addSubview:imageView];
                
                [NSTimer scheduledTimerWithTimeInterval:1.0
                                                 target:self
                                               selector:@selector(doSomethingWhenTimeIsUp)
                                               userInfo:nil
                                                repeats:NO];
                
                imageView.image = [UIImage mdQRCodeForString:[blockeditemResponse valueForKey:@"keyValue"] size:imageView.bounds.size.width fillColor:[UIColor darkGrayColor]];
                
            }
        }
        else if (!isOnlineStatus)
        {
            [self showAlertPop:@"No internet connection" expObj:nil];
        }
        
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
    
}


-(NSDictionary*)SaveBlockeditem:(NSDictionary*)BlockedItemParams {
    
    @try {
        NSString *DeviceId=[NSString stringWithFormat:@"%@",[BlockedItemParams valueForKey:@"DeviceId"]];
        NSString *BlockID =[NSString stringWithFormat:@"%@",[BlockedItemParams valueForKey:@"BlockedUserId"]];
        NSString *Oppid =[NSString stringWithFormat:@"%@",[BlockedItemParams valueForKey:@"OpportunityId"]];
        NSString *blockText =[NSString stringWithFormat:@"%@",[BlockedItemParams valueForKey:@"BlockText"]];
        NSString *blockid =[NSString stringWithFormat:@"%@",[BlockedItemParams valueForKey:@"BlockId"]];
        NSString *keyValue = [NSString stringWithFormat:@"%@",[BlockedItemParams valueForKey:@"KeyValue"]];
        NSString *quality =[NSString stringWithFormat:@"%@",[BlockedItemParams valueForKey:@"Quantity"]];
        NSString *claimedTime =[NSString stringWithFormat:@"%@",[BlockedItemParams valueForKey:@"ClaimedTime"]];
        NSString *TransactionComplete =[NSString stringWithFormat:@"%@",[BlockedItemParams valueForKey:@"TransactionComplete"]];
        
        NSDictionary *claimedDetails=@{@"BlockId":blockid,
                                       @"BlockedUserId":BlockID,
                                       @"OpportunityId":Oppid,
                                       @"BlockText":blockText,
                                       @"KeyValue":keyValue,
                                       @"DeviceId":DeviceId,
                                       @"Quantity":quality,
                                       @"ClaimedTime":claimedTime,
                                       @"TransactionComplete":TransactionComplete
                                       };
        NSDictionary *response=  [mwebService GetWebServiceResponse:claimedDetails URl:BLOCKORNOTIFYOPPORTUNITIES];
        
        NSMutableDictionary *m = [response mutableCopy];
        
        [m setValue:[response valueForKey:@"BlockText"] forKey:@"keyValue"];
        
        return m;
    }
    @catch (NSException *exception) {
        
    }
    @finally {
        
    }
}

-(void)doSomethingWhenTimeIsUp
{
    @try {
        [self viewDidLoad];
        
    }
    @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
}


-(NSDictionary*)getMyblocks
{
    @try {
        
        if (isOnlineStatus) {
            
            
            
            if ([mPref valueForKey:USERREGISTERID] !=nil) {
                
                NSString *ids = [mPref valueForKey:USERREGISTERID];
                NSDictionary   *GetBlocks = [[Web_Services GetSharedInstance]GetOpportinityReview:ids MethodName:GETRESERVEDOPPORTUNITIESBYUSERID];
                
                return GetBlocks;
                
            }
            else
            {
                return 0;
            }
        }
        else if (!isOnlineStatus)
        {
            [self showAlertPop:@"No internet connection" expObj:nil];
        }
        
        
    }
    @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
}
-(IBAction)floatButton:(id)sender
{
    spinner = [[UIActivityIndicatorView alloc]
               initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
    spinner.frame = CGRectMake(0, 0, 320, 560); // CGPointMake(160, 240);
    spinner.color = [UIColor blueColor];
    spinner.backgroundColor = [UIColor lightTextColor];
    spinner.transform = CGAffineTransformMakeScale(2, 2);
    // spinner.hidesWhenStopped = YES;
    [self.view addSubview:spinner];
    spinner.transform = CGAffineTransformMakeScale(2, 2);
    
    [spinner startAnimating];
    
    // how we stop refresh from freezing the main UI thread
    
    dispatch_async(
                   dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^{
                       
                       // back to the main thread for the UI call
                       dispatch_async(dispatch_get_main_queue(), ^{
                           [spinner startAnimating];
                       });
                       dispatch_async(dispatch_get_main_queue(), ^{
                           if ([mPref valueForKey:USERREGISTERID] !=nil)
                           {
                               [self GotoPost];
                           }
                           else
                           {
                               [mPref setObject:@"Post" forKey:@"PageName"];
                               
                               self.popViewController = [[PopUpViewController alloc] initWithNibName:@"PopUpViewController" bundle:nil];
                               [self.popViewController setTitle:@"This is a popup view"];
                               
                               [self.popViewController showInView:self.view withImage:[UIImage imageNamed:@"rprt_usinfo.png"] withMessage:@"You just triggered a great popup window" animated:YES];
                           

                               
                               
//                               Login *mLogin = [[Login alloc]initWithNibName:LOGIN bundle:nil];
//                               [self presentViewController:mLogin animated:YES completion:nil];
                           }
                           [spinner stopAnimating];
                           
                       });
                   });
}

-(void)GotoPost
{
    @try {
        
        if (isOnlineStatus) {
            
            
            
            NSString *ModuleId =[mPref valueForKey:MODULEID];
            
            if ([ModuleId isEqualToString:@"33"]) {
                Post_Food * mPosting = [[ Post_Food alloc] initWithNibName:PFOOD bundle:nil];
                [self presentViewController:mPosting animated:YES completion:nil];
                
            }
            else if ([ModuleId isEqualToString:@"34"])
            {
                // [mPref setValue:ModuleId forKey:MODULEID];
                Post_Sales * mPosting = [[ Post_Sales alloc] initWithNibName:PSALES bundle:nil];
                [self presentViewController:mPosting animated:YES completion:nil];
            }
            else if ([ModuleId isEqualToString:@"37"])
            {
                Post_Professional * mPosting = [[ Post_Professional alloc] initWithNibName:PPROFESSIONAL bundle:nil];
                [self presentViewController:mPosting animated:YES completion:nil];
            }
            else if ([ModuleId isEqualToString:@"38"])
            {
                Post_Sports * mPosting = [[ Post_Sports alloc] initWithNibName:PSPORTS bundle:nil];
                [self presentViewController:mPosting animated:YES completion:nil];
            }
            else if ([ModuleId isEqualToString:@"36"])
            {
                Post_Jobs * mPosting = [[ Post_Jobs alloc] initWithNibName:PJOBS bundle:nil];
                [self presentViewController:mPosting animated:YES completion:nil];
            }
            else if ([ModuleId isEqualToString:@"39"])
            {
                Post_Meetings * mPosting = [[ Post_Meetings alloc] initWithNibName:PMEETINGS bundle:nil];
                [self presentViewController:mPosting animated:YES completion:nil];
            }
            
            else if ([ModuleId isEqualToString:@"40"])
            {
                Post_Travels * mPosting = [[ Post_Travels alloc] initWithNibName:PTRAVELS bundle:nil];
                [self presentViewController:mPosting animated:YES completion:nil];
            }
            else if ([ModuleId isEqualToString:@"41"])
            {
                Post_RealEstate * mPosting = [[ Post_RealEstate alloc] initWithNibName:PREALESTATE bundle:nil];
                [self presentViewController:mPosting animated:YES completion:nil];
            }
            
            else if ([ModuleId isEqualToString:@"42"])
            {
                Post_banking_Finance * mPosting = [[ Post_banking_Finance alloc] initWithNibName:PBANKINGANDFINANCE bundle:nil];
                [self presentViewController:mPosting animated:YES completion:nil];
            }
            
            else if ([ModuleId isEqualToString:@"43"])
            {
                Post_Health * mPosting = [[ Post_Health alloc] initWithNibName:PHEALTH bundle:nil];
                [self presentViewController:mPosting animated:YES completion:nil];
            }
            
            else
            {
                self.popViewController = [[PopUpViewController alloc] initWithNibName:@"PopUpViewController" bundle:nil];
                [self.popViewController setTitle:@"This is a popup view"];
                
                [self.popViewController showInView:self.view withImage:[UIImage imageNamed:@"rprt_usinfo.png"] withMessage:@"You just triggered a great popup window" animated:YES];
                
                
//                Login * mLogin= [[ Login alloc] initWithNibName:LOGIN bundle:nil];
//                [self presentViewController:mLogin animated:YES completion:nil];
            }
        }
        else if (!isOnlineStatus)
        {
            [self showAlertPop:@"No internet connection" expObj:nil];
        }
        
    }
    @catch (NSException *exception) {
        
    }
    @finally {
        
    }
}

-(NSString*)emailMessageText:(NSDictionary*)opporDetails
{
    
    
    NSString *satrtDate = [NSString stringWithFormat:@"%@",[opporDetails valueForKey:@"EndDate"]];
    
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"yyyy-MM-dd'T'HH:mm:ss"];
    NSTimeZone *gmt = [NSTimeZone timeZoneWithAbbreviation:@"UTC"];
    [dateFormatter setTimeZone:gmt];
    NSDate *date5 = [dateFormatter dateFromString:satrtDate];
    
    NSDictionary *startOffer;
    if (date5!=nil) {
        startOffer= [mTimePreference remaningTime:[NSDate date] endDate:date5];
    }
    else{
        
        NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
        [dateFormatter setDateFormat:@"yyyy-MM-dd'T'HH:mm:ss.SSS"];
        
        NSTimeZone *gmt = [NSTimeZone timeZoneWithAbbreviation:@"UTC"];
        [dateFormatter setTimeZone:gmt];
        NSDate *date5 = [dateFormatter dateFromString:satrtDate];
        startOffer= [mTimePreference remaningTime:[NSDate date] endDate:date5];
        
    }
    
    int Remaingtyime = [[startOffer valueForKey:@"Time"] intValue];
    int hour = [[startOffer valueForKey:@"Hour"] intValue];
    int seconds = [[startOffer valueForKey:@"Seconds"] intValue];
    
    if (seconds!=0) {
        Remaingtyime = Remaingtyime+(seconds/60);
    }
    if(Remaingtyime!=0)
    {
        
        Remaingtyime = Remaingtyime+(hour*60);
    }
    
    NSString *duration= [NSString stringWithFormat:@"%dh:%dm:%ds",[[startOffer valueForKey:@"Hour"] intValue], [[startOffer valueForKey:@"Time"] intValue],[[startOffer valueForKey:@"Seconds"] intValue]];
    NSString *opportunityname=[opporDetails valueForKey:@"OpportunityName"];
    NSString *areName=[opporDetails valueForKey:@"AreaName"];
    NSString *vendorName=[opporDetails valueForKey:@"UserName"];
    NSString *contactNumber = [opporDetails valueForKey:@"VendorMobile"];
    NSString *watsspptext;
    NSString *category = [opporDetails valueForKey:@"Category"];
    if ([category isEqualToString:FOOD]) {
        
        
        if (Remaingtyime==0) {
            watsspptext = [NSString stringWithFormat:@"Hi,\n%@ has posted an Opportunities \"%@\" at %@.\nContact No: %@ \n\nFor further details download the app\n Play store: http://bit.ly/2fdqw6N\n App store: http://apple.co/2fdvEaV \n\nThanks,\nTeam Right Place Right Time",vendorName,opportunityname,areName,contactNumber];
        }
        else
        {
            watsspptext = [NSString stringWithFormat:@"Hi,\n%@ has posted an Opportunities \"%@\" at %@. Time left is %@ \nContact No: %@.\n\nFor further details download the app\n Play store: http://bit.ly/2fdqw6N\n App store: http://apple.co/2fdvEaV\n\nThanks,\nTeam Right Place Right Time",vendorName,opportunityname,areName,duration,contactNumber];
        }
    }
    
    if ([category isEqualToString:SALES]) {
        
        if (Remaingtyime==0) {
            watsspptext = [NSString stringWithFormat:@"Hi,\n%@ has posted an Opportunities \"%@\" at %@.\nContact No:  %@ \n\nFor further details download the app\n Play store: http://bit.ly/2fdqw6N\n App store: http://apple.co/2fdvEaV\n\nThanks,\nTeam Right Place Right Time",vendorName,opportunityname,areName,contactNumber];
        }
        else
            watsspptext = [NSString stringWithFormat:@"Hi,\n%@ has posted an Opportunities \"%@\" at %@.Time left is %@\nContact No: %@ \n\nFor further details download the app\n Play store: http://bit.ly/2fdqw6N\n App store: http://apple.co/2fdvEaV\n\nThanks,\nTeam Right Place Right Time",vendorName,opportunityname,areName,duration,contactNumber];
        
    }
    if ([category isEqualToString:REALESTATE]) {
        
        NSString *property=[opporDetails valueForKey:@"SubCategory"];
        
        NSArray *subcat = [[opporDetails valueForKey:@"OpportunityKeywords"] componentsSeparatedByString:@","];
        
        NSString *share =[NSString stringWithFormat:@"%@",[subcat objectAtIndex:0]];
        
        NSString *areaName=[opporDetails valueForKey:@"AreaName"];
        NSString *vendorName=[opporDetails valueForKey:@"UserName"];
        
        
        if (Remaingtyime==0) {
            watsspptext = [NSString stringWithFormat:@"Hi,\n%@ is available for %@ at %@. Contact %@ at %@ for more details \n\n For further details download the app \n Play store: http://bit.ly/2fdqw6N\n App store: http://apple.co/2fdvEaV\n\nThanks,\nTeam Right Place Right Time",property,share,areaName,vendorName,contactNumber];
        }
        else
            watsspptext = [NSString stringWithFormat:@"Hi,\n%@ is available for %@ at %@. Contact %@ at   before %@ \nContact No:%@ \n\n For further details download the app \n Play store: http://bit.ly/2fdqw6N\n App store: http://apple.co/2fdvEaV\n\nThanks,\nTeam Right Place Right Time",property,share,areaName,vendorName,duration,contactNumber];
        
    }
    if ([category isEqualToString:JOBS]) {
        
        if (Remaingtyime==0) {
            watsspptext = [NSString stringWithFormat:@"Hi,\n%@ has posted a Job requirement. \"%@\" at %@. \nContact No: %@  \n\nFor further details download the app \n Play store: http://bit.ly/2fdqw6N\n App store: http://apple.co/2fdvEaV\n\nThanks,\nTeam Right Place Right Time",vendorName,opportunityname,areName,contactNumber];
        }
        else
            watsspptext = [NSString stringWithFormat:@"Hi,\n%@ has posted a Job requirement. \"%@\" at %@. Time left to apply is %@\nContact No: %@. \n\nFor further details download the app \n Play store: http://bit.ly/2fdqw6N\n App store: http://apple.co/2fdvEaV\n\nThanks,\nTeam Right Place Right Time",vendorName,opportunityname,areName,duration,contactNumber];
        
    }
    if ([category isEqualToString:TRAVELS]) {
        
        NSString *vehicletype = [opporDetails valueForKey:@"SubCategory"];
        NSArray *addres = [[opporDetails valueForKey:@"OpportunityName"] componentsSeparatedByString:@"to"];
        NSString *source = [addres objectAtIndex:0];
        NSString *destination =[addres objectAtIndex:1];
        NSString *seats = [opporDetails valueForKey:@"Available"];
        NSString *contactperson = [opporDetails valueForKey:@"UserName"];
        NSString *contactNumber = [opporDetails valueForKey:@"VendorMobile"];
        
        watsspptext = [NSString stringWithFormat:@"Hi,\nA %@ is going from %@ to %@ and there are %@ available.\nContact %@ at %@ for more details.\n\n For further details download the app \n Play store: http://bit.ly/2fdqw6N\n App store: http://apple.co/2fdvEaV\n\nThanks,\nTeam Right Place Right Time",vehicletype,source,destination,seats,contactperson,contactNumber];
        
    }
    if ([category isEqualToString:BANKING]) {
        
        
        if (Remaingtyime==0) {
            watsspptext = [NSString stringWithFormat:@"Hi,\n%@ has posted an Opportunities \"%@\" at %@.\nContact No:  %@ \n\nFor further details download the app\n Play store: http://bit.ly/2fdqw6N\n App store: http://apple.co/2fdvEaV\n\nThanks,\nTeam Right Place Right Time",vendorName,opportunityname,areName,contactNumber];
        }
        else
            
            watsspptext = [NSString stringWithFormat:@"Hi,\n%@ has posted an Opportunities \"%@\" at %@. Opportunities available till %@.\nContact No:  %@. \n\nFor further details download the app\n Play store: http://bit.ly/2fdqw6N\n App store: http://apple.co/2fdvEaV\n\nThanks,\nTeam Right Place Right Time",vendorName,opportunityname,areName,duration,contactNumber];
        
    }
    if ([category isEqualToString:MEETINGS]) {
        if (Remaingtyime==0) {
            watsspptext = [NSString stringWithFormat:@"Hi,\n%@ has posted an event \"%@\" at %@.\nContact No: %@ \n\nFor further details download the app  \n Play store: http://bit.ly/2fdqw6N\n App store: http://apple.co/2fdvEaV\n\nThanks,\nTeam Right Place Right Time",vendorName,opportunityname,areName,contactNumber];
        }
        else
            watsspptext = [NSString stringWithFormat:@"Hi,%@ has posted an event \"%@\" at %@.  Opportunities available till %@.\nContact No: %@\n\n For further details download the app  \n Play store: http://bit.ly/2fdqw6N\n App store: http://apple.co/2fdvEaV\n\nThanks,\nTeam Right Place Right Time",vendorName,opportunityname,areName,duration,contactNumber];
        
    }
    if ([category isEqualToString:PROFESSIONALHELP]) {
        NSString *experttype=[opporDetails valueForKey:@"SubCategory"];
        watsspptext = [NSString stringWithFormat:@"Hi,\n%@ is requesting for %@, \"%@\" at %@.\nContact No: %@ \n\nFor further details download the app \n Play store: http://bit.ly/2fdqw6N\n App store: http://apple.co/2fdvEaV\n\nThanks,\nTeam Right Place Right Time",vendorName,experttype,opportunityname,areName,contactNumber];
        
    }
    if ([category isEqualToString:SPORTS]) {
        NSString *sporttype=[opporDetails valueForKey:@"SubCategory"];
        
        watsspptext = [NSString stringWithFormat:@"Hi,\n%@ is looking for %@ players, \"%@\" at %@.\nContact No:  %@ \n\n For further details download the app\n Play store: http://bit.ly/2fdqw6N \n App store: http://apple.co/2fdvEaV\n\nThanks,\nTeam Right Place Right Time",vendorName,sporttype,opportunityname,areName,contactNumber];
        
    }
    
    if ([category isEqualToString:HEALTH]) {
        NSString *type=[opporDetails valueForKey:@"SubCategory"];
        watsspptext = [NSString stringWithFormat:@"Hi,\n%@ is requesting for %@, \"%@\" at %@. \nContact No: %@ \n\n For further details download the app\n Play store: http://bit.ly/2fdqw6N\n App store: http://apple.co/2fdvEaV\n\nThanks,\nTeam Right Place Right Time",vendorName,type,opportunityname,areName,contactNumber];
        
    }
    return watsspptext;
}



-(NSString*)whatsappMessageText:(NSDictionary*)opporDetails
{
    
    NSString *satrtDate = [NSString stringWithFormat:@"%@",[opporDetails valueForKey:@"EndDate"]];
    
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"yyyy-MM-dd'T'HH:mm:ss"];
    NSTimeZone *gmt = [NSTimeZone timeZoneWithAbbreviation:@"UTC"];
    [dateFormatter setTimeZone:gmt];
    NSDate *date5 = [dateFormatter dateFromString:satrtDate];
    
    NSDictionary *startOffer;
    if (date5!=nil) {
        startOffer= [mTimePreference remaningTime:[NSDate date] endDate:date5];
    }
    else{
        
        NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
        [dateFormatter setDateFormat:@"yyyy-MM-dd'T'HH:mm:ss.SSS"];
        
        NSTimeZone *gmt = [NSTimeZone timeZoneWithAbbreviation:@"UTC"];
        [dateFormatter setTimeZone:gmt];
        NSDate *date5 = [dateFormatter dateFromString:satrtDate];
        startOffer= [mTimePreference remaningTime:[NSDate date] endDate:date5];
        
    }
    
    int Remaingtyime = [[startOffer valueForKey:@"Time"] intValue];
    int hour = [[startOffer valueForKey:@"Hour"] intValue];
    int seconds = [[startOffer valueForKey:@"Seconds"] intValue];
    
    if (seconds!=0) {
        Remaingtyime = Remaingtyime+(seconds/60);
    }
    if(Remaingtyime!=0)
    {
        
        Remaingtyime = Remaingtyime+(hour*60);
    }
    
    NSString *duration= [NSString stringWithFormat:@"%dh:%dm:%ds",[[startOffer valueForKey:@"Hour"] intValue], [[startOffer valueForKey:@"Time"] intValue],[[startOffer valueForKey:@"Seconds"] intValue]];
    NSString *opportunityname=[opporDetails valueForKey:@"OpportunityName"];
    NSString *areName=[opporDetails valueForKey:@"AreaName"];
    NSString *vendorName=[opporDetails valueForKey:@"UserName"];
    NSString *contactNumber = [opporDetails valueForKey:@"VendorMobile"];
    NSString *watsspptext;
    
       NSString *category = [opporDetails valueForKey:@"Category"];
    if ([category isEqualToString:FOOD]) {
        
        
        if (Remaingtyime==0) {
            watsspptext = [NSString stringWithFormat:@" %@ has posted an Opportunities \"%@\" at %@.\nContact No: %@ \n\nFor further details download the app\n Play store: http://bit.ly/2fdqw6N\n App store: http://apple.co/2fdvEaV",vendorName,opportunityname,areName,contactNumber];
        }
        else
        {
            watsspptext = [NSString stringWithFormat:@" %@ has posted an Opportunities \"%@\" at %@.\nContact No: %@. Time left is %@ \n\nFor further details download the app\n Play store: http://bit.ly/2fdqw6N\n App store: http://apple.co/2fdvEaV",vendorName,opportunityname,areName,contactNumber,duration];
        }
    }
    
    if ([category isEqualToString:SALES]) {
        
        if (Remaingtyime==0) {
            watsspptext = [NSString stringWithFormat:@" %@ has posted an Opportunities \"%@\" at %@.\nContact No:  %@ \n\nFor further details download the app\n Play store: http://bit.ly/2fdqw6N\n App store: http://apple.co/2fdvEaV",vendorName,opportunityname,areName,contactNumber];
        }
        else
            watsspptext = [NSString stringWithFormat:@" %@ has posted an Opportunities \"%@\" at %@.\nContact No: %@ Time left is %@ \n\nFor further details download the app\n Play store: http://bit.ly/2fdqw6N\n App store: http://apple.co/2fdvEaV",vendorName,opportunityname,areName,contactNumber,duration];
        
    }
    if ([category isEqualToString:REALESTATE]) {
        
        NSString *property=[opporDetails valueForKey:@"SubCategory"];
        
        NSArray *subcat = [[opporDetails valueForKey:@"OpportunityKeywords"] componentsSeparatedByString:@","];
        
        NSString *share =[NSString stringWithFormat:@"%@",[subcat objectAtIndex:0]];
        
        NSString *areaName=[opporDetails valueForKey:@"AreaName"];
        NSString *vendorName=[opporDetails valueForKey:@"UserName"];
        
        
        if (Remaingtyime==0) {
            watsspptext = [NSString stringWithFormat:@"%@ is available for %@ at %@. Contact %@ at %@ for more details \n\n For further details download the app \n Play store: http://bit.ly/2fdqw6N\n App store: http://apple.co/2fdvEaV",property,share,areaName,vendorName,contactNumber];
        }
        else
            watsspptext = [NSString stringWithFormat:@"%@ is available for %@ at %@. Contact %@ at %@ for more details before %@ \n\n For further details download the app \n Play store: http://bit.ly/2fdqw6N\n App store: http://apple.co/2fdvEaV",property,share,areaName,vendorName,contactNumber,duration];
        
    }
    if ([category isEqualToString:JOBS]) {
        
        if (Remaingtyime==0) {
            watsspptext = [NSString stringWithFormat:@" %@ has posted a Job requirement. \"%@\" at %@. \nContact No: %@  \n\nFor further details download the app \n Play store: http://bit.ly/2fdqw6N\n App store: http://apple.co/2fdvEaV",vendorName,opportunityname,areName,contactNumber];
        }
        else
            watsspptext = [NSString stringWithFormat:@" %@ has posted a Job requirement. \"%@\" at %@.\nContact No: %@. Time left to apply is %@ \n\nFor further details download the app \n Play store: http://bit.ly/2fdqw6N\n App store: http://apple.co/2fdvEaV",vendorName,opportunityname,areName,contactNumber,duration];
        
    }
    if ([category isEqualToString:TRAVELS]) {
        
        NSString *vehicletype = [opporDetails valueForKey:@"SubCategory"];
        NSArray *addres = [[opporDetails valueForKey:@"OpportunityName"] componentsSeparatedByString:@"to"];
        NSString *source = [addres objectAtIndex:0];
        NSString *destination =[addres objectAtIndex:1];
        NSString *seats = [opporDetails valueForKey:@"Available"];
        NSString *contactperson = [opporDetails valueForKey:@"UserName"];
        NSString *contactNumber = [opporDetails valueForKey:@"VendorMobile"];
        
        watsspptext = [NSString stringWithFormat:@"A %@ is going from %@ to %@ and there are %@ available. Contact %@ at %@ for more details.\n\n For further details download the app \n Play store: http://bit.ly/2fdqw6N\n App store: http://apple.co/2fdvEaV",vehicletype,source,destination,seats,contactperson,contactNumber];
        
    }
    if ([category isEqualToString:BANKING]) {
        
        
        if (Remaingtyime==0) {
            watsspptext = [NSString stringWithFormat:@" %@ has posted an Opportunities \"%@\" at %@.\nContact No:  %@ \n\nFor further details download the app\n Play store: http://bit.ly/2fdqw6N\n App store: http://apple.co/2fdvEaV",vendorName,opportunityname,areName,contactNumber];
        }
        else
            
            watsspptext = [NSString stringWithFormat:@" %@ has posted an Opportunities \"%@\" at %@.\nContact No:  %@. Opportunities available till %@ \n\nFor further details download the app\n Play store: http://bit.ly/2fdqw6N\n App store: http://apple.co/2fdvEaV",vendorName,opportunityname,areName,contactNumber,duration];
        
    }
    if ([category isEqualToString:MEETINGS]) {
        if (Remaingtyime==0) {
            watsspptext = [NSString stringWithFormat:@"%@ has posted an event \"%@\" at %@.\nContact No: %@ \n\nFor further details download the app  \n Play store: http://bit.ly/2fdqw6N\n App store: http://apple.co/2fdvEaV",vendorName,opportunityname,areName,contactNumber];
        }
        else
            watsspptext = [NSString stringWithFormat:@"%@ has posted an event \"%@\" at %@.\nContact No: %@  Opportunities available till %@.\n\n For further details download the app  \n Play store: http://bit.ly/2fdqw6N\n App store: http://apple.co/2fdvEaV",vendorName,opportunityname,areName,contactNumber,duration];
        
    }
    if ([category isEqualToString:PROFESSIONALHELP]) {
        NSString *experttype=[opporDetails valueForKey:@"SubCategory"];
        watsspptext = [NSString stringWithFormat:@"%@ is requesting for %@, \"%@\" at %@.\nContact No: %@ \n\nFor further details download the app \n Play store: http://bit.ly/2fdqw6N\n App store: http://apple.co/2fdvEaV",vendorName,experttype,opportunityname,areName,contactNumber];
        
    }
    if ([category isEqualToString:SPORTS]) {
        NSString *sporttype=[opporDetails valueForKey:@"SubCategory"];
        
        watsspptext = [NSString stringWithFormat:@"%@ is looking for %@ players, \"%@\" at %@.\nContact No:  %@ \n\n For further details download the app\n Play store: http://bit.ly/2fdqw6N \n App store: http://apple.co/2fdvEaV",vendorName,sporttype,opportunityname,areName,contactNumber];
        
    }
    
    if ([category isEqualToString:HEALTH]) {
        NSString *type=[opporDetails valueForKey:@"SubCategory"];
        watsspptext = [NSString stringWithFormat:@"%@ is requesting for %@, \"%@\" at %@. \nContact No: %@ \n\n For further details download the app\n Play store: http://bit.ly/2fdqw6N\n App store: http://apple.co/2fdvEaV",vendorName,type,opportunityname,areName,contactNumber];
        
    }
    return watsspptext;
}


-(void)shareData:(id)sender
{
    CGPoint buttonPosition = [sender convertPoint:CGPointZero toView:self.ExclusiveOfferTable];
    
    NSIndexPath *indexPath = [self.ExclusiveOfferTable indexPathForRowAtPoint:buttonPosition];
    
    NSDictionary *BlockedItem = [GetExclusiveArray objectAtIndex:indexPath.row];
    
    UIAlertController * view=   [UIAlertController
                                 alertControllerWithTitle:@"Rigth Place Right Time"
                                 message:@"Select Sharing option"
                                 preferredStyle:UIAlertControllerStyleActionSheet];
    
    UIAlertAction* watsapp = [UIAlertAction
                              actionWithTitle:@"Share via Whatsapp"
                              style:UIAlertActionStyleDefault
                              handler:^(UIAlertAction * action)
                              {
                                  
                                  
                                  
                                  NSString *ursl =  [mTimecalculator whatspandSMSText:BlockedItem];//[NSString stringWithFormat:@"A new opportunity is posted at %@ \n%@ \nIf you do not have the app, please download it from Apple:https://itunes.apple.com/in/app/right-place-right-time/id1145309259?mt=8",areName,Addres];
                                  
                                  ursl =    (NSString*)CFBridgingRelease(CFURLCreateStringByAddingPercentEscapes(NULL,(CFStringRef) ursl, NULL,CFSTR("!*();:@&=+$,/?%#[]"),kCFStringEncodingUTF8));
                                  
                                  NSString * urlWhats = [NSString stringWithFormat:@"whatsapp://send?text=%@",ursl];
                                  NSURL * whatsappURL = [NSURL URLWithString:urlWhats];
                                  if ([[UIApplication sharedApplication] canOpenURL: whatsappURL]) {
                                      
                                      UIApplication *application = [UIApplication sharedApplication];
                                      [application openURL:whatsappURL options:@{} completionHandler:nil];

                                      
                                    //  [[UIApplication sharedApplication] openURL: whatsappURL];
                                  } else {
                                      [self showAlertPop:@"Unable to share opportunity." expObj:nil];
                                      // can not share with whats app
                                  }
                                  
                              }];
    UIAlertAction* email = [UIAlertAction
                            actionWithTitle:@"Share via E-mail"
                            style:UIAlertActionStyleDefault
                            handler:^(UIAlertAction * action)
                            {
                                NSString *ursl = [mTimecalculator emailText:BlockedItem];
                                
                                NSString *cat =[BlockedItem valueForKey:@"Category"];
                                if ([cat isEqualToString:@"Professional Services"]) {
                                    cat= @"Expert Help";
                                }
                                else if ([cat isEqualToString:MEETINGS])
                                    cat= @"Events & Entertainments";
                                
                                NSString *subjectt = [NSString stringWithFormat:@"Right Place Right Time : %@",cat];
                                
                                if ([MFMailComposeViewController canSendMail]) {
                                    MFMailComposeViewController *mailController = [[MFMailComposeViewController alloc] init];
                                    [mailController setMailComposeDelegate:self];
                                    [mailController setSubject:subjectt];
                                    [mailController setToRecipients:@[@"email1", @"email2"]];
                                    [mailController setMessageBody:ursl isHTML:NO];
                                    [self presentViewController:mailController animated:YES completion:nil];
                                }
                                
                                [view dismissViewControllerAnimated:YES completion:nil];
                                
                            }];
    
    
    UIAlertAction* sms = [UIAlertAction
                          actionWithTitle:@"Share via iMessage"
                          style:UIAlertActionStyleDefault
                          handler:^(UIAlertAction * action)
                          {
                              
                              NSString *ursl =[mTimecalculator whatspandSMSText:BlockedItem];// [NSString stringWithFormat:@"A new opportunity is posted at %@ \n%@ \nIf you do not have the app, please download it from Apple:https://itunes.apple.com/in/app/right-place-right-time/id1145309259?mt=8",areName,Addres];
                              
                              if ([MFMessageComposeViewController canSendText]) {
                                  MFMessageComposeViewController *messageController = [[MFMessageComposeViewController alloc] init];
                                  [messageController setMessageComposeDelegate:self];
                                  [messageController setRecipients:nil];
                                  [messageController setBody:ursl];
                                  [self presentViewController:messageController animated:NO completion:nil];
                              }
                              
                              [view dismissViewControllerAnimated:YES completion:nil];
                              
                          }];
    
    UIAlertAction* cancel = [UIAlertAction
                             actionWithTitle:@"Cancel"
                             style:UIAlertActionStyleDefault
                             handler:^(UIAlertAction * action)
                             {
                                 [view dismissViewControllerAnimated:YES completion:nil];
                                 
                             }];
    [watsapp setValue:[[UIImage imageNamed:@"whatsapp.png"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal] forKey:@"image"];
    [email setValue:[[UIImage imageNamed:@"email.png"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal] forKey:@"image"];
    [sms setValue:[[UIImage imageNamed:@"sms.png"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal] forKey:@"image"];
    
    
    [view addAction:watsapp];
    [view addAction:email];
    [view addAction:sms];
    [view addAction:cancel];
    [self presentViewController:view animated:YES completion:nil];
    
    
}
- (void)mailComposeController:(MFMailComposeViewController*)controller didFinishWithResult:(MFMailComposeResult)result error:(NSError*)error {
    [self dismissViewControllerAnimated:YES completion:nil];
}

// Then implement the delegate method
- (void)messageComposeViewController:(MFMessageComposeViewController *)controller didFinishWithResult:(MessageComposeResult)result {
    [self dismissViewControllerAnimated:YES completion:nil];
}



/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/


- (void) showAlertPop:(NSString*)alertText  expObj:(NSException*) exp{
    if(exp != nil)
    {
        NSLog(@"%@", exp.description);
    }
    NSLog(@"The Exception is %@",exp.description);
    UIAlertController *myAlertController =[mwebService  alert:alertText];
    [self presentViewController:myAlertController animated:YES completion:nil];
}

-(IBAction)searchEvent:(id)sender
{
    @try {
        
        search = [[UISearchBar alloc]initWithFrame:CGRectMake(self.checkview.frame.origin.x, self.checkview.frame.origin.y, self.checkview.frame.size.width, self.checkview.frame.size.height)];
        search.delegate = self;
        search.placeholder = @"Enter Search String";
        search.showsScopeBar = YES;
        search.showsCancelButton = YES;
        [self.view addSubview:search];
        
        
        UIPanGestureRecognizer *panRecognizer = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(hidekeyboard)];
        [panRecognizer setMinimumNumberOfTouches:1];
        [self.view addGestureRecognizer:panRecognizer];
        
        [UIView animateWithDuration:1 animations:^{
            
            [search layoutIfNeeded];
        } completion:^(BOOL finished) {
            
            [UIView animateWithDuration:1 animations:^{
                
                [search layoutIfNeeded];
            }];
            
        }];
        [self.checkview setHidden:YES];
        
    } @catch (NSException *exception) {
        
    } @finally {
        
    }
}

- (void)searchBarCancelButtonClicked:(UISearchBar *)searchBar{
    [searchBar resignFirstResponder];
    [searchBar setShowsCancelButton:NO animated:YES];
    [search setHidden:YES];
    [self.checkview setHidden:NO];
}

-(void)hidekeyboard
{
    [search resignFirstResponder];
    //    [search setHidden:YES];
    //  [checkview setHidden:NO];
}
- (void)searchBarTextDidBeginEditing:(UISearchBar *)searchBar {
    isSearching = YES;
}

- (void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)seachtext {
    NSLog(@"Text change - %d",isSearching);
    
    //Remove all objects first.
    // [filteredContentList removeAllObjects];
    
    if([seachtext length] != 0) {
        isSearching = YES;
        [self seachOffer:seachtext];
    }
    else if([seachtext length]==0)
    {
        GetExclusiveArray = opportunityArray;
        [self.ExclusiveOfferTable reloadData];
    }
    else {
        isSearching = NO;
    }
    // [self.tblContentList reloadData];
}

- (void)seachOffer:(NSString *)substring {
    @try {
        // Put anything that starts with this substring into the autocompleteUrls array
        // The items in this array is what will show up in the table view
        NSPredicate *predicate = [NSPredicate predicateWithFormat:@"SELF contains [cd] %@", substring];
        NSArray  *results = [opporArray filteredArrayUsingPredicate:predicate];
        if ([results count]!=0) {
            
            NSMutableArray *array = [[NSMutableArray alloc]init];
            
            
            for (int i=0; i<[results count]; i++) {
                NSString  *str= [results objectAtIndex:i];
                
                for (int j=0; j<[GetExclusiveArray count]; j++) {
                    NSString *str2 = [[GetExclusiveArray objectAtIndex:j]  valueForKey:@"OpportunityName"];
                    if ([str isEqualToString:str2]) {
                        [array addObject:[GetExclusiveArray objectAtIndex:j]];
                    }
                }
                
            }
            
            NSOrderedSet *orderedSet = [NSOrderedSet orderedSetWithArray:array];
            GetExclusiveArray = [orderedSet mutableCopy];
            
            
            
            
            // GetRetailerOpp = array;
            
            [self.ExclusiveOfferTable reloadData];
            
        }
        //[autoComplete reloadData];
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
}

- (void)searchBarSearchButtonClicked :(UISearchBar *)searchBar {
    NSLog(@"Search Clicked");
    
    [searchBar resignFirstResponder];
    //[searchBar setHidden:YES];
    //[checkview setHidden:NO];
    //[self searchTableList];
}

@end
