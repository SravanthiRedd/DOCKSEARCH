//
//  Exclusive_Cell.m
//  RPRT
//
//  Created by sravanthi Gumma on 07/09/1938 Saka.
//  Copyright © 1938 Saka DevpointSolutions. All rights reserved.
//

#import "Exclusive_Cell.h"

@implementation Exclusive_Cell
@synthesize opportunity = opprtunity;
@synthesize description = description;
@synthesize view1 = view1;
@synthesize view2 = view2;
@synthesize Avialable = Avialable;
@synthesize delivery = delivery;
@synthesize actualprice =actualprice;
@synthesize price = price;
@synthesize categoryType = categoryType;
@synthesize blockBtn = blockBtn;
@synthesize deliveryLbl= deliveryLbl;
@synthesize priceLbl = priceLbl;
@synthesize offerpostBy = offerpostBy;
- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}
-(void)layoutSubviews{
 
    self.view1.layer.shadowColor = [UIColor grayColor].CGColor;
    self.view1.layer.borderColor = [UIColor colorWithRed:175.0/256.0 green:175.0/256.0 blue:175.0/256.0 alpha:1].CGColor;
    self.view1.layer.borderWidth=0.5f;
    self.view1.layer.shadowOffset = CGSizeMake(1.0, 1.0);
    self.view1.layer.shadowOpacity = 0.7;
    self.view1.layer.cornerRadius = 4.0;
  
    self.OpportunityImage.layer.cornerRadius = self.OpportunityImage.frame.size.width/2;
    self.OpportunityImage.layer.masksToBounds = YES;
}
-(id)initWithCoder:(NSCoder *)aDecoder{
    return [super initWithCoder:aDecoder];
}
- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
