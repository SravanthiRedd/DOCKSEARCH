//
//  CustomImageFlowLayout.h
//  ZDT_InstaTutorial
//
//  Created by Sztanyi Szabolcs on 13/10/15.
//  Copyright © 2015 Zappdesigntemplates. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CustomImageFlowLayout : UICollectionViewFlowLayout

@end
