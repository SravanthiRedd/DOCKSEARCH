//
//  CustomImageFlowLayout.m
//  ZDT_InstaTutorial
//
//  Created by Sztanyi Szabolcs on 13/10/15.
//  Copyright © 2015 Zappdesigntemplates. All rights reserved.
//

#import "CustomImageFlowLayout.h"

@implementation CustomImageFlowLayout

- (instancetype)init
{
    self = [super init];
    if (self)
    {
        self.minimumLineSpacing = 0;
        self.minimumInteritemSpacing = 0;
        self.scrollDirection = UICollectionViewScrollDirectionVertical;
        self.collectionView.frame = CGRectMake(0, 60, 300, 250);
    }
    return self;
}

- (CGSize)itemSize
{
    
  //  NSInteger numberOfColumns = 3;
    
    //CGFloat itemWidth = (CGRectGetWidth(self.collectionView.frame) - (numberOfColumns - 1)) / numberOfColumns;
  //  return CGSizeMake(itemWidth, itemWidth);
    
    
    NSInteger numberOfColumns = 3;

    CGFloat itemWidth = (CGRectGetWidth(self.collectionView.frame) - (numberOfColumns - 3)) / numberOfColumns;
    //itemWidth=itemWidth+0.5;
    return CGSizeMake(itemWidth, 93);
}

@end
