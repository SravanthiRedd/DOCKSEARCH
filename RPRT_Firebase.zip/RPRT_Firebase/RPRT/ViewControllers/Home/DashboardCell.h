//
//  DashboardCell.h
//  RPRT
//
//  Created by sravanthi Gumma on 08/03/16.
//  Copyright © 2016 DevpointSolutions. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DashboardCell : UITableViewCell
@property (nonatomic, strong) IBOutlet UILabel *OpportunityName;
@property (nonatomic, strong)IBOutlet UIImageView *Image;
@property (nonatomic, strong)IBOutlet UILabel *Address;
@property (nonatomic, strong)IBOutlet UILabel *Timer;
@end
