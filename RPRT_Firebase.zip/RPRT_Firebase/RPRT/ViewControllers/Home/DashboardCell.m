//
//  DashboardCell.m
//  RPRT
//
//  Created by sravanthi Gumma on 08/03/16.
//  Copyright © 2016 DevpointSolutions. All rights reserved.
//

#import "DashboardCell.h"

@implementation DashboardCell
@synthesize OpportunityName = OpportunityName;
@synthesize Image = Image;
@synthesize Address = Address;
@synthesize Timer = Timer;
- (void)awakeFromNib {
    // Initialization code
    
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
