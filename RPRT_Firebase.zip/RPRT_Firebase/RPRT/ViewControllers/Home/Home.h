//
//  Home.h
//  RPRT
//
//  Created by sravanthi Gumma on 05/02/16.
//  Copyright © 2016 DevpointSolutions. All rights reserved.
//


#import "NumberOfOffers.h"
#import "Preferences.h"
#import "CurrentLocation.h"
#import "Retailer_Offer.h"
#import "Opportunity_List_New.h"
#import "DashboardCell.h"
#import "MZTimerLabel.h"
#import "Post_Food.h"
#import "Post_Jobs.h"
#import "Post_Meetings.h"
#import "Post_Professional.h"
#import "Post_Sales.h"
#import "Post_Sports.h"
#import "Post_Travels.h"
#import "Post_RealEstate.h"
#import "Post_banking&Finance.h"
#import "Post_Health.h"
#import "VCFloatingActionButton.h"
#import "Constances.h"
#import "AppDelegate.h"
#import "Custom_OppCell.h"
#import "Excluseive_Offer.h"
#import "Store_Details.h"
#import "Home_CollectionCell.h"
#import "Popup.h"
#import "MyLocation.h"
#import "ViewPager.h"




@protocol HomeDelegate <NSObject>

@optional
- (void)movePanelLeft;
- (void)movePanelRight;
@required
- (void)movePanelToOriginalPosition;
@end

@interface Home : UIViewController<UITableViewDataSource,UITableViewDelegate,MZTimerLabelDelegate,UITextFieldDelegate,floatMenuDelegate,UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout,UISearchBarDelegate,UIScrollViewDelegate,UIPageViewControllerDataSource>

@property (strong, nonatomic) UIPageViewController *pageController;
@property (nonatomic, assign) id<HomeDelegate> delegate;
@property (nonatomic, strong) IBOutlet UIButton *leftButton;

@property (weak, nonatomic) IBOutlet UIButton *Radious;
@property(weak,nonatomic)IBOutlet UITextField *searchText;


@property(nonatomic,strong) NSMutableDictionary  *addreDic;

@property (weak, nonatomic) IBOutlet UIView *Contentview;
@property (weak, nonatomic) IBOutlet UIScrollView *scrollview;
@property (weak,nonatomic) IBOutlet UIView *searctextView;

@property (weak, nonatomic) IBOutlet UIScrollView *PhotoScroll;
@property (weak, nonatomic) IBOutlet UIPageControl *pageControl;


@property (weak, nonatomic) IBOutlet UIButton *SearchBtn;

-(void)pagechangeforPostOffer;


@property(weak,nonatomic) IBOutlet UICollectionView *CatCollectionView;

@property (weak, nonatomic) IBOutlet UIButton *favoriteBtn;
@property (weak, nonatomic) IBOutlet UIButton *notificationBtn;
@property (weak, nonatomic) IBOutlet UILabel *notifBadge;


@property (weak, nonatomic) IBOutlet UIImageView *favoriteImage;
-(IBAction)addtofavorite:(id)sender;


@property(nonatomic,weak) IBOutlet UISearchBar *searhBar;

@property(nonatomic,weak) IBOutlet UIView *SEARCHBARVIEW;




@end
