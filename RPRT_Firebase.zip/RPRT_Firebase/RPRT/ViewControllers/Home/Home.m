//
//  Home.m
//  RPRT
//
//  Created by sravanthi Gumma on 05/02/16.
//  Copyright © 2016 DevpointSolutions. All rights reserved.
//

#import "Home.h"
#import "Opportunity_List_New.h"
#import "ScanCode.h"
#import "NotigicationCell.h"
#import "CustomImageFlowLayout.h"
#import "PopUpViewController.h"
#import "TimeCalculator.h"
#import "Customer_Request.h"
#import "MyContacts.h"
#import "EditOpp.h"
#import "My_Notifications.h"
@interface Home ()<CLLocationManagerDelegate,CustomIOSAlertViewDelegate,PopupDelegate,UITextViewDelegate>
{
   
    NumberOfOffers *numberofoffers;
    UIView *contentView;
    UIView *RadiousView;
    MZTimerLabel *TimeCoutDown;
    Web_Services *mWebservice;
    NSUserDefaults *mPref;
    NSString *SlideMenuTag;
    TimeCalculator *mConverter;
   
    NSString *SideMenu;
    NSString *Category;
    NSString *ModuleID;
    UIActivityIndicatorView *spinner;
    NSMutableArray *GetAllOpportunities;
    
    NSMutableArray *autocompleteUrls;
    GeoCodeLocation *geoCode;
    CurrentLocation *LatLog;
    NSString *seachLatLong ;
    CLLocationCoordinate2D *crentLoc;
    NSMutableDictionary *locatioLatLon;
    CLLocationCoordinate2D center;
    NSString *seachlatlong;
    UITableView *table;
    NSArray * radiousArray;
    Preferences *mPreferences;
    CurrentLocation *location;
    CLLocationManager *locationManager;
    //Boolean *sideMenuTag;
    NSMutableArray *favoriteAddress;
    
    CustomIOSAlertView *foveriteAlert;
    
    NSMutableArray *FavoLocations;
    UITableView *favTable;
    UITextField *searchText1;
    UITableView *alertLocationTable;
    NSArray *dashBoardImg;
    NSArray *DashCatArray;
    NSArray *CollectioCatArray;
    NSArray *CatCntArray;
    UITableView *notificationTable;
    NSString *NotificationKey;
    CustomIOSAlertView *customAlert;
    NSMutableArray *GetbannersArray;
    NSMutableArray *ImageArry;
    NSMutableArray *NotificationsArray;
    UIRefreshControl *refreshController;
    NSDictionary *InviteObject;
    CustomIOSAlertView *InviteAlert;
    UITextView *requesttext;
    
}

//@property (weak, nonatomic) IBOutlet UIButton *showPopupBtn;
@property (strong, nonatomic) PopUpViewController *popViewController;


@property (strong, nonatomic) VCFloatingActionButton *FloatBtn;

@property (strong, nonatomic) IBOutlet UITableView *autoComplete;
@end

@implementation Home
@synthesize delegate,Radious,searchText,FloatBtn;

@synthesize PhotoScroll,pageControl,autoComplete;

-(void)backgroundServiceCalling
{
    
    @try {
        
        locatioLatLon = [[NSMutableDictionary alloc]init];
        [locatioLatLon setValue:geoCode.Latitude forKey:LATITUDE];
        [locatioLatLon setValue:geoCode.Longitude forKey:LONGITUDE];
       // NSString *Latlon = [NSString stringWithFormat:@"%@,%@",geoCode.Latitude,geoCode.Longitude];
        
        [self GetCategoryDeatils];
        NSLog(@"TEST1");
        
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
    
}


-(void)handleTimer:(NSTimer *)timer
{
    if (geoCode==nil) {
        
        locationManager = [[CLLocationManager alloc] init];
        locationManager.delegate = self;
        [locationManager setDesiredAccuracy:kCLLocationAccuracyBest];
        if ([[[UIDevice currentDevice] systemVersion] floatValue] >= 8) {
            [locationManager requestAlwaysAuthorization];
        }
        if ([[[UIDevice currentDevice] systemVersion] floatValue] >= 9.2) {
            //locationManager.allowsBackgroundLocationUpdates = YES;
            [locationManager requestWhenInUseAuthorization];
        }
        [locationManager startUpdatingLocation];
        
        NSTimer   *timer = [NSTimer scheduledTimerWithTimeInterval:1.0
                                                            target: self
                                                          selector: @selector(handleTimer1:)
                                                          userInfo: nil
                                                           repeats: NO];
        
        NSLog(@"%@",timer);
        
    }
}

-(void)handleTimer1:(NSTimer*)timer
{
    CLLocation *mLocation = [locationManager location];
    center = [mLocation coordinate];
    geoCode = [LatLog getCurrentLocation:&(center)];
    
    if (geoCode!=nil) {
        
       
        
        searchText.text = [NSString stringWithFormat:@"%@,%@,%@,%@",geoCode.Address1,geoCode.Address2,geoCode.Address3,geoCode.AreaName];
       // [self backgroundServiceCalling];
        
    }

}

- (void)viewDidLoad {
    [super viewDidLoad];
    
        @try {
            
            
            
             autoComplete.hidden = YES;
             self.scrollview.bounces = NO;
            favoriteAddress = [[NSMutableArray alloc]init];
            self.SEARCHBARVIEW.hidden= YES;
            self.searctextView.layer.cornerRadius = 45/2;
            ImageArry = [[NSMutableArray alloc]init];
            mConverter = [TimeCalculator GetSharedInstance];
           // geoCode = [GeoCodeLocation GetSharedInstance];
            
            self.searctextView.layer.masksToBounds = false;
            self.searctextView.layer.shadowColor = [UIColor blackColor].CGColor;
            self.searctextView.layer.shadowOffset = CGSizeMake(0, 1);
            self.searctextView.layer.shadowOpacity = 0.2;
            self.searctextView.layer.cornerRadius = 5;
            
            notificationTable =[[UITableView alloc]initWithFrame:CGRectMake(0, 10, 300, 250) style:UITableViewStylePlain];
            notificationTable.delegate= self;
            notificationTable.dataSource= self;
            notificationTable.hidden= YES;
             notificationTable.separatorStyle = UITableViewCellSeparatorStyleNone;
            //[self.Contentview addSubview:notificationTable];

            dashBoardImg= [NSArray arrayWithObjects:@"banner.png",@"banner.png", nil];
            NotificationKey= @"";
            SlideMenuTag = @"Show";
            mPref = [NSUserDefaults standardUserDefaults];
            mWebservice = [Web_Services GetSharedInstance];
            
             location = [CurrentLocation alloc];
             mPreferences = [Preferences GetSharedInstance];
           
            GetbannersArray = [mWebservice GetBanner];
            
            [self setSizeSliding];
            
            [self.CatCollectionView registerClass:[Home_CollectionCell class] forCellWithReuseIdentifier:@"Home_CollectionCell"];
            
            self.CatCollectionView.collectionViewLayout = [[CustomImageFlowLayout alloc] init];
            
            
            refreshController = [[UIRefreshControl alloc] init];
            refreshController.tintColor = [UIColor grayColor];
            [refreshController addTarget:self action:@selector(refershControlAction) forControlEvents:UIControlEventValueChanged];
            [self.CatCollectionView addSubview:refreshController];
            self.CatCollectionView.alwaysBounceVertical = YES;
            
            
            DashCatArray = [NSMutableArray arrayWithObjects:@"new_food.png",@"new_sales.png",@"new_jobs.png",@"new_realestate.png",@"new_banking.png",@"new_events.png",@"new_travel.png",@"new_sports.png",@"new_help.png",@"new_health.png",@"Educations_dis.png",@"hotel_dis.png", nil];
            
            
            CollectioCatArray = [NSArray arrayWithObjects:@"Food",@"Sales",@"Jobs",@"Real Estate",@"Banking & Financial",@"Events & Entertainments",@" Travel",@"Sports",@"Expert Help",@"Health",@"Education",@"Hotels", nil];
            
            [mPref setValue:nil forKey:@"SaveNotifications"];
            
            //[self.view setBackgroundColor:[UIColor colorWithRed:235.0/256.0 green:232.0/256.0 blue:232.0/256.0 alpha:1]];
           // [self.CatCollectionView setBackgroundColor:[UIColor colorWithRed:235.0/256.0 green:232.0/256.0 blue:232.0/256.0 alpha:1]];
            if ([mPref valueForKey:@"StoredAddress"]) {
           
                
                NSString *address =[mPref valueForKey:@"StoredAddress"];
                
                
                center   =  [[CurrentLocation GetSharedInstance]getLocationFromAddressString:address];
                geoCode = [location geoCodeArea:&center.latitude Longitude:&center.longitude];
                 searchText.text =address;
                
                [self GetCategoryDeatils];
                 NSLog(@"TEST2");
                
                
                // self.categoryCollectionView.frame = CGRectMake(7, 70, 360, 100);
            
                
                CatCntArray = [NSArray arrayWithObjects:numberofoffers.food,numberofoffers.sales,numberofoffers.jobs,numberofoffers.realEstate,numberofoffers.bankandFinancial,numberofoffers.meetings,numberofoffers.travel,numberofoffers.sports,numberofoffers.professional,numberofoffers.health,@"",@"", nil];
                
                [self.view setBackgroundColor:[UIColor whiteColor]];


                
            }
            else
            {
                
                crentLoc = [location getCurrentLatLog];
              
                    NSTimer   *timer = [NSTimer scheduledTimerWithTimeInterval:5.0
                                                                        target: self
                                                                      selector: @selector(handleTimer:)
                                                                      userInfo: nil
                                                                       repeats: NO];
                
                NSLog(@"%@",timer);
                
                    LatLog = [CurrentLocation alloc];
                     geoCode = [LatLog getCurrentLocation:crentLoc];
                if (geoCode!=nil) {
                      [self GetCategoryDeatils];
                     NSLog(@"TEST3");
                    [self.CatCollectionView registerClass:[Home_CollectionCell class] forCellWithReuseIdentifier:@"Home_CollectionCell"];
                    // self.categoryCollectionView.frame = CGRectMake(7, 70, 360, 100);
                    self.CatCollectionView.collectionViewLayout = [[CustomImageFlowLayout alloc] init];
                    
                    
                    DashCatArray = [NSMutableArray arrayWithObjects:@"new_food.png",@"new_sales.png",@"new_jobs.png",@"new_realestate.png",@"new_banking.png",@"new_events.png",@"new_travel.png",@"new_sports.png",@"new_help.png",@"new_health.png",@"Educations_dis.png",@"hotel_dis.png", nil];
                    
                    
                    CollectioCatArray = [NSArray arrayWithObjects:@"Food",@"Sales",@"Jobs",@"Real Estate",@"Banking & Financial",@"Events & Entertainments",@" Travel",@"Sports",@"Expert Help",@"Health",@"Education",@"Hotels", nil];
                    
                    CatCntArray = [NSArray arrayWithObjects:numberofoffers.food,numberofoffers.sales,numberofoffers.jobs,numberofoffers.realEstate,numberofoffers.bankandFinancial,numberofoffers.meetings,numberofoffers.travel,numberofoffers.sports,numberofoffers.professional,numberofoffers.health,numberofoffers.education,numberofoffers.hotel, nil];

                    
                    searchText.text = [NSString stringWithFormat:@"%@,%@,%@,%@",geoCode.Address1,geoCode.Address2,geoCode.Address3,geoCode.AreaName];
                    if ([searchText.text isEqualToString:@""]) {
                        [self viewDidLoad];
                    }
                    
                }
            }
            
            if (![mPref valueForKey:USERREGISTERID]) {
                //self.notificationBtn.hidden= YES;
                //self.notifBadge.hidden= YES;
                // self.scanQRCodeBtn.hidden = YES;
                //self.favoriteBtn.hidden= YES;
                //self.favoriteImage.hidden= YES;
                CGRect frameRect = searchText.frame;
                frameRect.size.width = 265; // <-- Specify the height you want here.
                searchText.frame = frameRect;
                
            }
                
                
           
        CALayer *borderTypeCat = [CALayer layer];
        //CGFloat borderWidth = 1;
        borderTypeCat.borderColor = [UIColor lightGrayColor].CGColor;
        //borderTypeCat.borderColor = [UIColor lightGrayColor].CGColor;
        borderTypeCat.frame = CGRectMake(0, Radious.frame.size.height - 1, Radious.frame.size.width, Radious.frame.size.height);
        borderTypeCat.borderWidth = 1;//
        [Radious.layer addSublayer:borderTypeCat];
        Radious.layer.masksToBounds = YES;
        searchText.layer.borderColor = [UIColor colorWithRed:237.0/255.0 green:237.0/255.0 blue:237.0/255.0 alpha:1].CGColor;//.CGColor;
        searchText.layer.borderWidth = 1;
      
                NSString *path = [[NSBundle mainBundle] pathForResource:CATEGORY ofType:@"plist"];
                NSMutableDictionary *dict = [NSMutableDictionary dictionaryWithContentsOfFile:path];
                radiousArray = [[NSArray alloc] init];
                
                radiousArray= [dict valueForKey:@"Radious"];
                
                
            [self RadiousBtnTitle];
               
          
          //  [self.scanQRCodeBtn setImage:[UIImage imageNamed:@"scanner.png"] forState:UIControlStateNormal];
            
           
            
            if ([searchText.text isEqualToString:@""]) {
                NSTimer   *timer = [NSTimer scheduledTimerWithTimeInterval:5.0
                                                                    target: self
                                                                  selector: @selector(handleTimer:)
                                                                  userInfo: nil
                                                                   repeats: NO];
                 NSLog(@"%@",timer);
            }
            
            [self.notificationBtn addTarget:self action:@selector(UserNotiFication:) forControlEvents:UIControlEventTouchUpInside];
            
            if(![mPref valueForKey:USERREGISTERID])
            {
            self.popViewController = [[PopUpViewController alloc] initWithNibName:@"PopUpViewController" bundle:nil];
            [self.popViewController setTitle:@"This is a popup view"];
            
            [self.popViewController showInView:self.view withImage:[UIImage imageNamed:@"rprt_usinfo.png"] withMessage:@"You just triggered a great popup window" animated:YES];
            }
            
           
            
            
    } @catch (NSException *exception) {
       // [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {

    }

    // Do any additional setup after loading the view from its nib.
}

-(void)viewDidDisappear:(BOOL)animated
{
     [self addGesturetoScroolView];
}



-(void)changePage:(UIPageControl*)page
{
    NSLog(@"pageChanged");
}


-(void)changeImg:(id)sender
{
    UIGestureRecognizer *recognizer = (UIGestureRecognizer*)sender;
    UIImageView *imageView = (UIImageView *)recognizer.view;
    
    NSDictionary *selectedbanner = [GetbannersArray objectAtIndex:imageView.tag];
    NSString *banerType =[selectedbanner valueForKey:@"BannerType"];
    
    if([banerType isEqualToString:@"Food"])
    {
        [self Pagenavigation:FOOD andModuleId:@"33"];
    }
    if([banerType isEqualToString:@"Sale"])
    {
        [self Pagenavigation:SALES andModuleId:@"34"];
    }
    if([banerType isEqualToString:@"Job"])
    {
        [self Pagenavigation:JOBS andModuleId:@"36"];
    }
    if([banerType isEqualToString:@"Travel"])
    {
        [self Pagenavigation:TRAVELS andModuleId:@"40"];
    }
    if([banerType isEqualToString:@"Events"])
    {
        [self Pagenavigation:MEETINGS andModuleId:@"39"];
    }
    if([banerType isEqualToString:@"Sports"])
    {
        [self Pagenavigation:SPORTS andModuleId:@"38"];
    }
    if([banerType isEqualToString:@"Banking"])
    {
        [self Pagenavigation:BANKING andModuleId:@"42"];
    }

    
    
  //  [imageView setImage:[UIImage imageNamed:@"anyImage.png"]];
}


-(void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    int cardIndex = (int)(scrollView.contentOffset.x / scrollView.frame.size.width);
    pageControl.currentPage = cardIndex;
    
}



//-(void)updateLivetagcounts:(NSMutableDictionary*)addreDic
//{
//   
//    @try {
//        if (isOnlineStatus) {
//    NSMutableArray *numberoffers = [mWebservice GetData:addreDic];
//    NSMutableDictionary *getnumOff = [[NSMutableDictionary alloc]init];
//    if (numberoffers.count>0) {
//        for(int i=0;i<numberoffers.count;i++)
//        {
//            [getnumOff setValue:[numberoffers[i] valueForKey:@"OfferCount"] forKey:[numberoffers[i] valueForKey:CATEGORY]];
//        }
//        
//    }
//    numberofoffers = [[NumberOfOffers GetSharedInstance]initOffers:getnumOff];
//            NSLog(@"%@",numberofoffers);
//            
//    [self OngoingOffers];
//    
//   // searchText.text = [NSString stringWithFormat:@"%@,%@,%@,%@",geoCode.Address1,geoCode.Address2,geoCode.Address3,geoCode.AreaName];
//    seachlatlong =[NSString stringWithFormat:@"%@,%@",geoCode.Latitude,geoCode.Longitude];
//    NSString *offertag =[NSString stringWithFormat:@"%@",numberofoffers.food];
//    [self setLabelBadget:foodCount count:numberofoffers.food];
//    offertag =[NSString stringWithFormat:@"%@",numberofoffers.professional];
//    [self setLabelBadget:professionalCount count:numberofoffers.professional];
//    offertag =[NSString stringWithFormat:@"%@",numberofoffers.sales];
//    [self setLabelBadget:salesCount count:numberofoffers.sales];
//    offertag =[NSString stringWithFormat:@"%@",numberofoffers.sports];
//    [self setLabelBadget:sportscount count:numberofoffers.sports];
//    offertag =[NSString stringWithFormat:@"%@",numberofoffers.jobs];
//    [self setLabelBadget:jobs count:numberofoffers.jobs];
//    offertag =[NSString stringWithFormat:@"%@",numberofoffers.meetings];
//    [self setLabelBadget:meetings count:numberofoffers.meetings];
//        
//    offertag =[NSString stringWithFormat:@"%@",numberofoffers.travel];
//    [self setLabelBadget:travels count:numberofoffers.travel];
//        
//    offertag =[NSString stringWithFormat:@"%@",numberofoffers.realEstate];
//    [self setLabelBadget:realEstate count:numberofoffers.realEstate];
//    offertag =[NSString stringWithFormat:@"%@",numberofoffers.bankandFinancial];
//    [self setLabelBadget:bankandFinancial count:numberofoffers.bankandFinancial];
//    
//    offertag =[NSString stringWithFormat:@"%@",numberofoffers.health];
//    [self setLabelBadget:health count:numberofoffers.health];
//   
//        }
//       else if (!isOnlineStatus) {
//           [self showAlertPop:@"No Internet Connection" expObj:nil];
//        }
//    } @catch (NSException *exception) {
//        [self showAlertPop:@"Error while fetching data." expObj:exception];
//    } @finally {
//        
//    
//    }
//}


- (IBAction)selectClicked:(id)sender {
   
    @try {
        
        table = [[UITableView alloc]initWithFrame:CGRectMake(Radious.frame.origin.x+3, Radious.frame.origin.y+108, Radious.frame.size.width+18,250) style:UITableViewStylePlain];
        
        table.delegate = self;
        table.dataSource = self;
        table.scrollEnabled=NO;
        [self.view addSubview:table];
        [table reloadData];

        
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];

    } @finally {
        
    }
    
}

-(void)setLabelBadget:(UILabel*) labelName count:(NSString *) count{
  
    @try {
        
        NSString *stcountb = [NSString stringWithFormat:@"%@",count];
        
        
        if ([stcountb isEqualToString:@"0"]) {
             labelName.text =[NSString stringWithFormat:@""];
              labelName.backgroundColor = [UIColor clearColor];
        }
        else
        {
            labelName.text =[NSString stringWithFormat:@"%@",stcountb];
            //labelName.layer.masksToBounds = YES;
            labelName.layer.cornerRadius = labelName.frame.size.width/2;
            //labelName.textAlignment = NSTextAlignmentCenter;
            labelName.backgroundColor = [UIColor redColor];
            labelName.layer.cornerRadius=15;
            labelName.layer.masksToBounds = YES;
        }
        
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
}



-(void)OngoingOffers
{
    @try {
        
    
     [mPref setValue:@"" forKey:MODULEID];
        autoComplete.hidden = YES;
   
    
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }

}
- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string {
    @try {
        if(textField == searchText)
        {
        autoComplete.hidden = NO;
         table.hidden = YES;
        
        if ([searchText.text isEqualToString:@""]) {
            autoComplete.hidden= YES;
        }
        
        else  if (![searchText.text isEqualToString:@""]) {
        
        NSString *substring = [NSString stringWithString:searchText.text];
        substring = [substring
                     stringByReplacingCharactersInRange:range withString:string];
        [self searchAutocompleteEntriesWithSubstring:substring];
             [autoComplete reloadData];
            
        return YES;
        }
        }
        else
        {
            autoComplete.hidden = YES;
            table.hidden = YES;
            alertLocationTable.hidden= NO;
            
            if ([searchText1.text isEqualToString:@""]) {
                autoComplete.hidden= YES;
            }
            
            else  if (![searchText1.text isEqualToString:@""]) {
                
                
                NSString *substring = [NSString stringWithString:searchText1.text];
                substring = [substring
                             stringByReplacingCharactersInRange:range withString:string];
                [self searchAutocompleteEntriesWithSubstring:substring];
                
                [alertLocationTable reloadData];
                return YES;
            }
        }
        return YES;
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
}
- (void)searchAutocompleteEntriesWithSubstring:(NSString *)substring {
    @try {
        // Put anything that starts with this substring into the autocompleteUrls array
        // The items in this array is what will show up in the table view
        
        
        NSString* urlpath;
        if (![substring isEqual:@""])
            //https://maps.googleapis.com/maps/api/place/autocomplete/json?key=AIzaSyBsB3SN513YgmJxs-md1zA2zWPgktPhczU&input=am
            //AIzaSyBsB3SN513YgmJxs-md1zA2zWPgktPhczU&input=am
        {
            
                if (isOnlineStatus) {
            
            //urlpath = [NSString stringWithFormat:@"https://maps.googleapis.com/maps/api/place/autocomplete/json?key=AIzaSyBsB3SN513YgmJxs-md1zA2zWPgktPhczU&input=%@",substring];
                    //AIzaSyAM5zyy3xsgRWpye3fmXLEK1Hm18E_tj98
            urlpath = [NSString stringWithFormat:@"https://maps.googleapis.com/maps/api/place/autocomplete/json?key=AIzaSyAM5zyy3xsgRWpye3fmXLEK1Hm18E_tj98&input=%@",substring];
            
            //AIzaSyAVwhwILDa3_cka-sjZ3U3xZo-OCS0mADI
        
            NSString *escapedUrlString = [urlpath stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet URLFragmentAllowedCharacterSet]];
            
            NSURL *RPRTUrlpath = [NSURL URLWithString:escapedUrlString];
            
            NSData *myData = [NSData dataWithContentsOfURL:RPRTUrlpath];
            
            NSError* error1;
            
            NSDictionary    * autocompleteUrls1 = [NSJSONSerialization
                                                   JSONObjectWithData:myData
                                                   options:kNilOptions
                                                   error:&error1];
            NSString  *prediction = [autocompleteUrls1 valueForKey:@"predictions"];
            autocompleteUrls = [prediction valueForKey:@"description"];
                    if ([autocompleteUrls count]>0) {
                        autoComplete.hidden=NO;
                        [autoComplete reloadData];

                    }
                    
                }
            else if (!isOnlineStatus)
            {
                  [self showAlertPop:@"No Internet Connection." expObj:nil];
                
            }
            
        }
        else  if ([substring isEqual:@""])
            
        {
           
        }
        
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
        return 1;
}

-(void)UserNotiFication:(UIButton*)sender
{
    
    NSData  *VendorData =    [mPref valueForKey:@"SaveNotifications"];
    NSDictionary *notificationData =   (NSDictionary*) [NSKeyedUnarchiver unarchiveObjectWithData:VendorData];
  
        NotificationsArray =[notificationData valueForKey:@"Notifications"];
    
    
    
    
    //notificationBtn
    
    [notificationTable reloadData];
    
    NSLog(@"%@",numberofoffers.Notifications);
    
    [notificationTable setHidden:NO];
    [self customimageAlert];
    self.notifBadge.hidden=YES;
    
    
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    @try {
        
        if (tableView == autoComplete) {
            return  [autocompleteUrls count];
        
        }
       else if (tableView == alertLocationTable) {
            return  [autocompleteUrls count];
            
        }
        else if (tableView == table)
        {
            return 5;
        }
        else if(tableView==favTable)
            
        {
            return  [favoriteAddress count];
        }
    
        if (tableView == notificationTable) {
          
            return [NotificationsArray count];
        }
    
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }

}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (tableView == notificationTable) {
     return 90;
    }
    else
        return 50;
    
    
    
   // return 150;
}
// This will tell your UITableView what data to put in which cells in your table.
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    @try {
        
        if (tableView == autoComplete) {
            
        static NSString *CellIdentifier = @"Cell";
        // Reuse and create cell
        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
        if (cell == nil) {
            cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
        }
     NSString *Addreline = [autocompleteUrls objectAtIndex:indexPath.row];
        cell.textLabel.text = Addreline;
        return cell;
    }
       
         else  if (tableView == notificationTable) {
            
            static NSString *CellIdentifier = @"NotigicationCell";
            // Reuse and create cell
            NotigicationCell *cell =(NotigicationCell*) [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
            if (cell == nil) {
                NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"NotigicationCell" owner:self options:nil];
                cell = [nib objectAtIndex:0];
            }
                tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
               
            NSDictionary *notifiObj = [NotificationsArray objectAtIndex:indexPath.row];
            cell.notificationMesz.text = [notifiObj valueForKey:@"NotificationMessage"];
               NSString *NotificationType = [notifiObj valueForKey:@"NotificationType"];
               if ([NotificationType isEqualToString:@"Store Like"]) {
                   cell.notificationIcon.image = [UIImage imageNamed:@"like_notify.png"];
               }
               else if ([NotificationType isEqualToString:@"Reserve"])
               {
                cell.notificationIcon.image = [UIImage imageNamed:@"reserved_notify.png"];
               }
               else if ([NotificationType isEqualToString:@"Interested"]) {
                   cell.notificationIcon.image = [UIImage imageNamed:@"intersted_notify.png"];
               }
               else if ([NotificationType isEqualToString:@"Added"] ||[NotificationType isEqualToString:@"Customer Added"] || [NotificationType isEqualToString:@"New Customer"])
               {
                   cell.notificationIcon.image = [UIImage imageNamed:@"added_notify.png"];
               }
               
               else if ([NotificationType isEqualToString:@"Store Request"])
               {
                   cell.notificationIcon.image = [UIImage imageNamed:@"like_notify.png"];
               }
               else if ([NotificationType isEqualToString:@"Connected"])
               {
                   cell.notificationIcon.image = [UIImage imageNamed:@"added_notify.png"];
               }
               else if ([NotificationType isEqualToString:@"Connect"])
               {
                   cell.notificationIcon.image = [UIImage imageNamed:@"added_notify.png"];
               }
              else if([NotificationType isEqualToString:@"Customer Invite"])
              {
                  cell.notificationIcon.image = [UIImage imageNamed:@"added_notify.png"];
              }
              else if ([NotificationType isEqualToString:@"Customer Add"])
              {
                  cell.notificationIcon.image = [UIImage imageNamed:@"added_notify.png"];
              }
             
             
             //NotificationType = Connected;
             
             
             [cell.AcceptBtn addTarget:self action:@selector(AcceptBtn:) forControlEvents:UIControlEventTouchUpInside];
               [cell.RejectBtnBtn addTarget:self action:@selector(RejectBtnBtn:) forControlEvents:UIControlEventTouchUpInside];
             
             
             cell.AcceptBtn.hidden= YES;
             cell.RejectBtnBtn.hidden= YES;
             
              NSString *ShowInvite = [NSString stringWithFormat:@"%@",[notifiObj valueForKey:@"ShowInvite"]];
             
             
          
             
               NSString *ShowAcceptReject = [NSString stringWithFormat:@"%@",[notifiObj valueForKey:@"ShowAcceptReject"]];
             if ([ShowInvite isEqualToString:@"0"] && [ShowAcceptReject isEqualToString:@"0"]) {
                    cell.accepttedDate.frame = CGRectMake(cell.AcceptBtn.frame.origin.x, cell.AcceptBtn.frame.origin.y, cell.accepttedDate.frame.size.width, cell.accepttedDate.frame.size.height);
             }
             
             
             
             
             if ([ShowInvite isEqualToString:@"1"]) {
                  cell.AcceptBtn.hidden= NO;
                 [cell.AcceptBtn setTitle:@"Invite" forState:UIControlStateNormal];
                 cell.RejectBtnBtn.hidden= YES;
                 cell.accepttedDate.frame = CGRectMake(cell.RejectBtnBtn.frame.origin.x, cell.RejectBtnBtn.frame.origin.y, cell.accepttedDate.frame.size.width, cell.accepttedDate.frame.size.height);
                 
                 
             }
             
           
              if ([ShowAcceptReject isEqualToString:@"1"])
             {
                  cell.AcceptBtn.hidden= NO;
                 [cell.AcceptBtn setTitle:@"Accept" forState:UIControlStateNormal];
                 cell.RejectBtnBtn.hidden= NO;

             }
             
             NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
             [dateFormatter setDateFormat:@"yyyy-MM-dd'T'HH:mm:ss.SSS"];
             NSTimeZone *gmt = [NSTimeZone timeZoneWithAbbreviation:@"UTC"];
             [dateFormatter setTimeZone:gmt];
             NSDate *date5 = [dateFormatter dateFromString:[notifiObj valueForKey:@"CreatedDate"]];
             
             if (date5==nil) {
                 NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
                 [dateFormatter setDateFormat:@"yyyy-MM-dd'T'HH:mm:ss.SSS"];
                 NSTimeZone *gmt = [NSTimeZone timeZoneWithAbbreviation:@"UTC"];
                 [dateFormatter setTimeZone:gmt];
                 date5 = [dateFormatter dateFromString:[notifiObj valueForKey:@"CreatedDate"]];
                 
                 if (date5==nil) {
                     NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
                     [dateFormatter setDateFormat:@"yyyy-MM-dd'T'HH:mm:ss"];
                     NSTimeZone *gmt = [NSTimeZone timeZoneWithAbbreviation:@"UTC"];
                     [dateFormatter setTimeZone:gmt];
                     date5 = [dateFormatter dateFromString:[notifiObj valueForKey:@"CreatedDate"]];
                 }
                 

             }
             
             NSDateFormatter *dateFormatter1 = [[NSDateFormatter alloc] init];
             [dateFormatter1 setDateFormat:@"yyyy-MM-dd'T'HH:mm:ss"];
             NSTimeZone *gmt1 = [NSTimeZone timeZoneWithAbbreviation:@"GMT"];
             [dateFormatter setTimeZone:gmt1];
             NSString *date = [dateFormatter1 stringFromDate:date5];
             
             date  = [date stringByReplacingOccurrencesOfString:@"T" withString:@" "];
             cell.accepttedDate.text = date;
             
            return cell;
        }
        
        else   if (tableView == alertLocationTable) {
            
            
            
            static NSString *CellIdentifier = @"Cell";
            // Reuse and create cell
            UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
            if (cell == nil) {
                cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
            }
            NSString *Addreline = [autocompleteUrls objectAtIndex:indexPath.row];
            cell.textLabel.text = Addreline;
            return cell;
        }
        else if(tableView == table)
        {
            static NSString *CellIdentifier = @"Cell";
            // Reuse and create cell
            UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
            if (cell == nil) {
                cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
            }
              NSString *Addreline = [[radiousArray objectAtIndex:indexPath.row] valueForKey:@"Value"];;
            cell.textLabel.text = Addreline;
              cell.textLabel.textAlignment = NSTextAlignmentLeft;
            return cell;
        }
        else if(tableView == favTable)
        {
            static NSString *CellIdentifier = @"Cell";
            // Reuse and create cell
            UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
            if (cell == nil) {
                cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
            }
             tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
            NSDictionary *dic = [favoriteAddress objectAtIndex:indexPath.row];
            
            NSString *Addreline = [NSString stringWithFormat:@"%@,%@,%@",[dic valueForKey:@"Address1"],[dic valueForKey:@"Address2"],[dic valueForKey:@"AreaName"]];
            
            cell.textLabel.text = Addreline;
            cell.textLabel.textAlignment = NSTextAlignmentLeft;
            cell.textLabel.numberOfLines=2;
            cell.textLabel.textColor= [UIColor colorWithRed:43.0/256.0 green:145.0/256.0 blue:175.0/256.0 alpha:1];
            UIButton *cancelBtn = [[UIButton alloc]initWithFrame:CGRectMake(300, 10, 24, 24)];
            [cancelBtn setImage:[UIImage imageNamed:@"delete.png"] forState:UIControlStateNormal];
            [cancelBtn addTarget:self action:@selector(deleteFavlLocation:) forControlEvents:UIControlEventTouchUpInside];
            [cell addSubview:cancelBtn];
            
            UIView *lineView = [[UIView alloc]initWithFrame:CGRectMake(1, 48, favTable.frame.size.width-2, 1)];
            lineView.backgroundColor= [UIColor lightTextColor];
            [cell addSubview:lineView];
            
            
            
            return cell;
        }
        
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
  
       
       @try {
           
           
           spinner = [[UIActivityIndicatorView alloc]
                      initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
           spinner.frame = CGRectMake(0, 0, 320, 560); // CGPointMake(160, 240);
           spinner.color = [UIColor blueColor];
           spinner.backgroundColor = [UIColor lightTextColor];
           spinner.transform = CGAffineTransformMakeScale(2, 2);
           // spinner.hidesWhenStopped = YES;
           [self.view addSubview:spinner];
           spinner.transform = CGAffineTransformMakeScale(2, 2);
           
           [spinner startAnimating];
           
           // how we stop refresh from freezing the main UI thread
           
           dispatch_async(
                          dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^{
                              
                              // back to the main thread for the UI call
                              dispatch_async(dispatch_get_main_queue(), ^{
                                  [spinner startAnimating];
                              });
                              dispatch_async(dispatch_get_main_queue(), ^{
                                  
                                  if (tableView == autoComplete) {
                                      
                                   table.hidden = YES;
                                  
                                      NSString *selectedAdress = [autocompleteUrls objectAtIndex:indexPath.row];
                                      
                                      [mPref setValue:selectedAdress forKey:@"StoredAddress"];
                                      
                                      searchText.text = selectedAdress;
                                      autoComplete.hidden= YES;
                                      [searchText resignFirstResponder];
                                      [self viewDidLoad];
                                      
                                  }
                                  if (tableView== alertLocationTable) {
                                      NSString *selectedAdress = [autocompleteUrls objectAtIndex:indexPath.row];
                                      
                                      [mPref setValue:selectedAdress forKey:@"StoredAddress"];
                                      
                                      searchText1.text = selectedAdress;
                                      searchText.text = selectedAdress;
                                      alertLocationTable.hidden= YES;
                                      [searchText1 resignFirstResponder];
                                      [self viewDidLoad];
                                  }
                                  
                                  
                                  else if (tableView == table)
                                  {
                                      table.hidden= YES;
                                     NSString   *selectedRadius =[[radiousArray objectAtIndex:indexPath.row] valueForKey:@"Radious"];
                                      [mPref setValue:selectedRadius forKey:@"TempRadius"];
                                       [self StoreRadios:selectedRadius];
                                      
                                      
                                      
                                  }
                                  else if(tableView== favTable)

                                  {
                                     
                                      NSDictionary *selectedFavAddress = [favoriteAddress objectAtIndex:indexPath.row ];
                                      
                                      NSString *selectedAdress =[NSString stringWithFormat:@"%@,%@,%@,%@,%@,%@",[selectedFavAddress valueForKey:@"Address1"],[selectedFavAddress valueForKey:@"Address2"],[selectedFavAddress valueForKey:@"Address3"],[selectedFavAddress valueForKey:@"AreaName"],[selectedFavAddress valueForKey:@"City"],[selectedFavAddress valueForKey:@"State"]];
                                    
                                      [mPref setValue:selectedAdress forKey:@"StoredAddress"];
                                      
                                      [self viewDidLoad];
                                       searchText.text = selectedAdress;
                                       [foveriteAlert close];
                                      
                                  }
                                  
                                  else if (tableView== notificationTable)
                                  {
                                      
                                      NSDictionary *NotificationObj = [NotificationsArray objectAtIndex:indexPath.row];
                                       [customAlert close];
                                      
                                      if ([[NotificationObj valueForKey:@"NotificationType"]  isEqualToString:@"Store Request"]) {
                                          
                                          
                                          //[customAlert close];
                                          Customer_Request *mCustomer_Request = [[Customer_Request alloc]initWithNibName:@"Customer_Request" bundle:nil];
                                          mCustomer_Request.StoreInfo=NotificationObj;
                                          
                                            [self presentViewController:mCustomer_Request animated:YES completion:nil];
                                          
                                      }
                                      else if ([[NotificationObj valueForKey:@"NotificationType"]  isEqualToString:@"Added"])
                                      {
                                          MyContacts *mContacts = [[MyContacts alloc]initWithNibName:@"MyContacts" bundle:nil];
                                          mContacts.CustomerObj =NotificationObj;
                                          [self presentViewController:mContacts animated:YES completion:nil];
                                      }
                                      else if ([[NotificationObj valueForKey:@"NotificationType"]  isEqualToString:@"Store Like"])
                                      {
                                          MyContacts *mContacts = [[MyContacts alloc]initWithNibName:@"MyContacts" bundle:nil];
                                          mContacts.CustomerObj =NotificationObj;
                                          [self presentViewController:mContacts animated:YES completion:nil];
                                      }
                                      else if ([[NotificationObj valueForKey:@"NotificationType"] isEqualToString:@"Reserve"] ||[[NotificationObj valueForKey:@"NotificationType"] isEqualToString:@"Intrested"]  )
                                      {
                                          //OppId
                                          
                                          NSString *OopId = [NotificationObj valueForKey:@"OppId"];
                                          
                                          
                                          NSDictionary *SeleetdOpp = [mWebservice GetOpportunityByID:OopId MethodName:@"GetOpportunityByID"];
                                          
                                          
                                          EditOpp *mEditOpp =[[EditOpp alloc]initWithNibName:@"EditOpp" bundle:nil];
                                          mEditOpp.ReserveKey= [NotificationObj valueForKey:@"NotificationType"];
                                          mEditOpp.selectedOpportunity = SeleetdOpp;
                                          [self presentViewController:mEditOpp animated:YES completion:nil];
                                          
                                      }
                                      
                                      NSLog(@"NotificationType");
                                  }
                                  
                                  [spinner stopAnimating];
                                  
                              });
                          });
       } @catch (NSException *exception) {
           [self showAlertPop:@"Error while fetching data." expObj:exception];
       } @finally {
           
       }

}

-(void)saveViewOpprtunity:(NSDictionary*)Offer
{
    @try {
        
    
    //NSUserDefaults *prefss = [NSUserDefaults standardUserDefaults];
    //NSString *userID =   [prefss objectForKey:@"SaveUserID"];
    
    NSMutableDictionary *dic = [[NSMutableDictionary alloc]init];
    [dic setObject:[Offer valueForKey:@"OpportunityID"] forKey:@"OpportunityID"];
    [dic setObject:@"0" forKey:@"UserID"];
    [mWebservice SaveUserViewedOpportunities:dic];
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)addGesturetoScroolView

{
    self.Contentview.userInteractionEnabled = YES;
    
  //  self.Contentview.isUserInteractionEnabled=YES;
    
    
    UISwipeGestureRecognizer *swipeLeft = [[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(upSwipe:)];
    [swipeLeft setDirection: UISwipeGestureRecognizerDirectionRight ];
    [self.Contentview addGestureRecognizer:swipeLeft];
    
    
    UISwipeGestureRecognizer *swipeRight = [[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(downSwipe:)];
    [swipeRight setDirection: UISwipeGestureRecognizerDirectionLeft ];
    [self.Contentview addGestureRecognizer:swipeRight];
    
    //swipeLeft=nil;
}

-(void)SideMenuTap:(UIGestureRecognizer*)gesture
{
    [self slideShowHideMenu];
    NSLog(@"Test Robot1111");
    /// SlideMenuTag = @"Show";
    gesture.enabled = NO;
}



-(void)downSwipe:(UISwipeGestureRecognizer *)gesture
{
    
    NSLog(@"Detected");
    
    [UIView animateWithDuration:0.1
                          delay:0.1
                        options: UIViewAnimationOptionCurveEaseOut
                     animations:^{
                         SlideMenuTag = @"Show";
                         LeftPanelViewController *tlc = [self.childViewControllers lastObject];
                         
                         [tlc didMoveToParentViewController:nil];
                         [tlc.view removeFromSuperview];
                         [tlc removeFromParentViewController];
                         
                            [self.Contentview setAlpha:1];
                       
                         self.notificationBtn.userInteractionEnabled = true;
                         self.SearchBtn.userInteractionEnabled = true;
                          self.PhotoScroll.userInteractionEnabled = true;
                         self.CatCollectionView.userInteractionEnabled= true;
                         [self GetCategoryDeatils];
                          NSLog(@"TEST4");

//                         LeftPanelViewController *tlc = [[LeftPanelViewController alloc]initWithNibName:LEFTPANEL bundle:nil];
//                         [tlc.view setFrame:CGRectMake(0, 65, 225, self.view.frame.size.height)];
//                         
//                         //                         if ([SlideMenuTag isEqualToString:@"Show"])
//                         //                         {
//                         
//                         
//                         [self addChildViewController:tlc];
//                         [self.view addSubview:tlc.view];
//                         [tlc didMoveToParentViewController:self];
//                         
//                         [UIView animateWithDuration:0.3 animations:^{
//                             [tlc.view setFrame:CGRectMake(0, 65, 225, self.view.frame.size.height)];
//                         }];
                         //}
                         
                     }
                     completion:^(BOOL finished){}];
}
-(void)upSwipe:(UISwipeGestureRecognizer *)gesture
{
    
    //NSLog(@"Detected");
    
    [UIView animateWithDuration:0.1
                          delay:0.1
                        options: UIViewAnimationOptionCurveEaseOut
                     animations:^{
                         

                         
                         
                         LeftPanelViewController *tlc = [[LeftPanelViewController alloc]initWithNibName:LEFTPANEL bundle:nil];
                         [tlc.view setFrame:CGRectMake(0, 65, 225, self.view.frame.size.height)];
                         
                         if ([SlideMenuTag isEqualToString:@"Show"])
                         {
                             SlideMenuTag = @"Hide";
                             tlc.view.layer.shadowColor = [UIColor grayColor].CGColor;
                             tlc.view.layer.borderColor = [UIColor colorWithRed:175.0/256.0 green:175.0/256.0 blue:175.0/256.0 alpha:1].CGColor;
                             tlc.view.layer.borderWidth=0.5f;
                             tlc.view.layer.shadowOffset = CGSizeMake(1.0, 1.0);
                             // tlc.view.layer.shadowOpacity = 0.7;
                             // self.notificationView.layer.cornerRadius = 4.0;
                             [self addChildViewController:tlc];
                             [self.view addSubview:tlc.view];
                             self.Contentview.backgroundColor = [UIColor blackColor];
                               [self.Contentview setAlpha:0.1];
                            
                             self.notificationBtn.userInteractionEnabled = false;
                             self.SearchBtn.userInteractionEnabled = false;
                              self.PhotoScroll.userInteractionEnabled = false;
                             self.CatCollectionView.userInteractionEnabled= false;
                             
                               [self viewTap];
                             [tlc didMoveToParentViewController:self];
                             
                         }
                     }
                     completion:^(BOOL finished){}];
}

-(IBAction)btnMovePanelRight:(id)sender {
    @try {
        [self.searchText resignFirstResponder];
    
    [self slideShowHideMenu];
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }

}

-(void)viewTap
{
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(SideMenuTap:)];
       // [swipeRight setDirection: UISwipeGestureRecognizerDirectionLeft ];
    
        [self.Contentview addGestureRecognizer:tap];

    NSLog(@"Test Robot");
}

- (void)slideShowHideMenu {
    
    @try {
        
        
      //
        LeftPanelViewController *tlc = [[LeftPanelViewController alloc]initWithNibName:LEFTPANEL bundle:nil];
        [tlc.view setFrame:CGRectMake(0, 65, 250, self.view.frame.size.height)];
        
        if ([SlideMenuTag isEqualToString:@"Show"])
         {
           
             tlc.view.layer.shadowColor = [UIColor grayColor].CGColor;
             tlc.view.layer.borderColor = [UIColor colorWithRed:175.0/256.0 green:175.0/256.0 blue:175.0/256.0 alpha:1].CGColor;
             tlc.view.layer.borderWidth=0.5f;
             tlc.view.layer.shadowOffset = CGSizeMake(3.0, 5.0);
             
             
             [self addChildViewController:tlc];
             [self.view addSubview:tlc.view];
             [tlc didMoveToParentViewController:self];
             self.Contentview.backgroundColor = [UIColor blackColor];
             [self.Contentview setAlpha:0.1];
           
             self.notificationBtn.userInteractionEnabled = false;
             self.SearchBtn.userInteractionEnabled = false;
              self.PhotoScroll.userInteractionEnabled = false;
             self.CatCollectionView.userInteractionEnabled= false;
             
             [self viewTap];
             SlideMenuTag = @"Hide";
        }
        else
            if ([SlideMenuTag isEqualToString:@"Hide"])
             {
                 SlideMenuTag = @"Show";
                 
                 [UIView animateWithDuration:0.1 animations:^{
                     [tlc.view setFrame:CGRectMake(0, 65, 0, 0)];
                     LeftPanelViewController *tlc = [self.childViewControllers lastObject];
                     
                     [tlc didMoveToParentViewController:nil];
                   
                     self.notificationBtn.userInteractionEnabled = true;
                     self.SearchBtn.userInteractionEnabled = true;
                      self.PhotoScroll.userInteractionEnabled = true;
                     self.CatCollectionView.userInteractionEnabled= true;
                     
                       [self.Contentview setAlpha:1];
                     [tlc.view removeFromSuperview];
                     [tlc removeFromParentViewController];
                      [self GetCategoryDeatils];
                      NSLog(@"TEST5");
                      //[self viewDidLoad];

                 }];
             }
        
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
   
}

- (void)homePageButtonClick {
    @try {
        
        if (isOnlineStatus) {
            
    [mPref setValue:@"Live+Expired" forKey:@"Key"];
    [mPref setValue:Category forKey:CATEGORY];
    [mPref setValue:ModuleID forKey:MODULEID];
        Opportunity_List_New * mOpportunity_list = [[ Opportunity_List_New alloc] initWithNibName:OPPORTUNITYLISTNEW bundle:nil];
            [self presentViewController:mOpportunity_list animated:YES completion:nil];
        }
        else
        {
            [self showAlertPop:@"No internet connection" expObj:nil];

        }
        } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }

}

-(void)StoreRadios:(NSString*)radious {
    @try {
        
        
       // [mPref valueForKey:@"Radious"]
       
        //[Radious setTitle:radious forState:UIControlStateNormal];
        
        [[Preferences GetSharedInstance]StoreRadious:radious];
         [self RadiousBtnTitle];
         [self viewDidLoad];
        
    }
    @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    }
    @finally {
        
    }
}

-(IBAction)back:(id)sender {
    @try {
        
        UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"RPRT"
                                                                       message:@"Are you sure you want to exit"
                                                                preferredStyle:UIAlertControllerStyleAlert];
        
        UIAlertAction* ok = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault
                                                              handler:^(UIAlertAction * action) {
                                                              exit(0);
                                                              }];
        
        
        UIAlertAction* cancel = [UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleDefault
                                                              handler:^(UIAlertAction * action) {
                                                                 
                                                              }];
        
        [alert addAction:ok];
        [alert addAction:cancel];
        
        
        [self presentViewController:alert animated:YES completion:nil]; // 6
    
    
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
}
- (void) showAlertPop:(NSString*)alertText expObj:(NSException*) exp{
    @try {
        
    if(exp != nil)
    {
        NSLog(@"%@", exp.description);
    }
    UIAlertController *myAlertController =[mWebservice  alert:alertText];
    [self presentViewController:myAlertController animated:YES completion:nil];
    }
    @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    }
    @finally {
        
    }

}
-(void)Pagenavigation:(NSString*)category andModuleId:(NSString*)moduleID
{
    @try {
        
         table.hidden = YES;
        
         [mPref setValue:moduleID forKey:MODULEID];
   
    spinner = [[UIActivityIndicatorView alloc]
               initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
    spinner.frame = CGRectMake(0, 0, 320, 560); // CGPointMake(160, 240);
    spinner.color = [UIColor blueColor];
    spinner.backgroundColor = [UIColor lightTextColor];
    spinner.transform = CGAffineTransformMakeScale(2, 2);
    // spinner.hidesWhenStopped = YES;
    [self.view addSubview:spinner];
    spinner.transform = CGAffineTransformMakeScale(2, 2);
    
    [spinner startAnimating];
    
    // how we stop refresh from freezing the main UI thread
    
    dispatch_async(
                   dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^{
                       
                       // back to the main thread for the UI call
                       dispatch_async(dispatch_get_main_queue(), ^{
                           [spinner startAnimating];
                       });
                       dispatch_async(dispatch_get_main_queue(), ^{
                           Category = category;
                           ModuleID = moduleID;
                           
                           [self homePageButtonClick];
                           [spinner stopAnimating];
                           
                       });                   });
    }
    @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    }
    @finally {
        
    }

}

-(void)pagechangeforPostOffer
{
    @try {
        
        if (isOnlineStatus) {
        

        NSString *Modulid = [mPref valueForKey:MODULEID];
        
        if ([Modulid isEqualToString:@"33"]) {
            [mPref setValue:@"33" forKey:MODULEID];
            Post_Food * mPosting = [[ Post_Food alloc] initWithNibName:PFOOD bundle:nil];
            [self presentViewController:mPosting animated:YES completion:nil];

        }
        else if ([Modulid isEqualToString:@"34"])
        {
            [mPref setValue:@"34" forKey:MODULEID];
            Post_Sales * mPosting = [[ Post_Sales alloc] initWithNibName:PSALES bundle:nil];
            [self presentViewController:mPosting animated:YES completion:nil];
        }
        else if ([Modulid isEqualToString:@"37"])
        {
            [mPref setValue:@"37" forKey:MODULEID];
            Post_Professional * mPosting = [[ Post_Professional alloc] initWithNibName:PPROFESSIONAL bundle:nil];
            [self presentViewController:mPosting animated:YES completion:nil];
        }
        else if ([Modulid isEqualToString:@"38"])
        {
            [mPref setValue:@"38" forKey:MODULEID];
            Post_Sports * mPosting = [[ Post_Sports alloc] initWithNibName:PSPORTS bundle:nil];
            [self presentViewController:mPosting animated:YES completion:nil];
        }
        else if ([Modulid isEqualToString:@"36"])
        {
            [mPref setValue:@"36" forKey:MODULEID];
            
            Post_Jobs * mPosting = [[ Post_Jobs alloc] initWithNibName:PJOBS bundle:nil];
            [self presentViewController:mPosting animated:YES completion:nil];
        }
        else if ([Modulid isEqualToString:@"39"])
        {
            [mPref setValue:@"39" forKey:MODULEID];
            Post_Meetings * mPosting = [[ Post_Meetings alloc] initWithNibName:PMEETINGS bundle:nil];
            [self presentViewController:mPosting animated:YES completion:nil];
        }
        
        else if ([Modulid isEqualToString:@"40"])
        {
              [mPref setValue:@"40" forKey:MODULEID];
            Post_Travels * mPosting = [[ Post_Travels alloc] initWithNibName:PTRAVELS bundle:nil];
            [self presentViewController:mPosting animated:YES completion:nil];
        }
        else if ([Modulid isEqualToString:@"41"])
        {
              [mPref setValue:@"41" forKey:MODULEID];
            Post_RealEstate * mPosting = [[ Post_RealEstate alloc] initWithNibName:PREALESTATE bundle:nil];
            [self presentViewController:mPosting animated:YES completion:nil];
        }
        else if ([Modulid isEqualToString:@"42"])
        {
            [mPref setValue:@"42" forKey:MODULEID];
            Post_banking_Finance * mPosting = [[ Post_banking_Finance alloc] initWithNibName:PBANKINGANDFINANCE bundle:nil];
            [self presentViewController:mPosting animated:YES completion:nil];
        }

            
        else
        {
            [mPref setValue:@"33" forKey:MODULEID];
            Post_Food * mPosting = [[ Post_Food alloc] initWithNibName:PFOOD bundle:nil];
            [self presentViewController:mPosting animated:YES completion:nil];
        }
            
        }
        else if (!isOnlineStatus)
        {
             [self showAlertPop:@"The internet is down." expObj:nil];
        }
        
    }
    @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    }
    @finally {
        
    }

}

#pragma mark -LoadFloatingButton


-(void)Loginpagechange
{
    @try {
        
        if (isOnlineStatus) {
         
        [mPref setValue:@"" forKey:@"PageName"];
        [mPref setValue:@"Home" forKey:@"PageName"];
            self.popViewController = [[PopUpViewController alloc] initWithNibName:@"PopUpViewController" bundle:nil];
            [self.popViewController setTitle:@"This is a popup view"];
            
            [self.popViewController showInView:self.view withImage:[UIImage imageNamed:@"rprt_usinfo.png"] withMessage:@"You just triggered a great popup window" animated:YES];
            
            
//        Login * mLogin = [[ Login alloc] initWithNibName:LOGIN bundle:nil];
//        [self presentViewController:mLogin animated:YES completion:nil];
        }
        else if (!isOnlineStatus)
        {
            [self showAlertPop:@"The internet is down." expObj:nil];
        }
        }
    @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    }
    @finally {
        
    }
}

-(IBAction)goButton:(id)sender
{
    @try {
        
         table.hidden = YES;
        if (isOnlineStatus) {
            
        
        
    spinner = [[UIActivityIndicatorView alloc]
               initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
    spinner.frame = CGRectMake(0, 0, 320, 560); // CGPointMake(160, 240);
    spinner.color = [UIColor blueColor];
    spinner.backgroundColor = [UIColor lightTextColor];
    spinner.transform = CGAffineTransformMakeScale(2, 2);
    // spinner.hidesWhenStopped = YES;
    [self.view addSubview:spinner];
    spinner.transform = CGAffineTransformMakeScale(2, 2);
    
    [spinner startAnimating];
    
    // how we stop refresh from freezing the main UI thread
    
    dispatch_async(
                   dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^{
                       
                       // back to the main thread for the UI call
                       dispatch_async(dispatch_get_main_queue(), ^{
                           [spinner startAnimating];
                       });
                       dispatch_async(dispatch_get_main_queue(), ^{

                           [mPref setValue:@"Home" forKey:@"Page"];
                           
                               Map *mMap= [Map alloc];
                               mMap.SetOpportunities =GetAllOpportunities;
                               
                               Map *mMapview =
                               [mMap initWithNibName:MAP bundle:nil];
                               [self presentViewController:mMapview animated:YES completion:nil];
                           
                             [spinner stopAnimating];
                           
                       });
                   });
        }
        else if (!isOnlineStatus)
        {
            [self showAlertPop:@"The internet is down." expObj:nil];
        }
    }
    @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    }
    @finally {
        
    }
}

- (IBAction)hideKeyBoardKeyWord:(id)sender {
    
    @try {
        autoComplete.hidden= YES;
        
        if ([searchText isFirstResponder]) {
            [searchText resignFirstResponder];
        }
    }
    @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    }
    @finally {
        
    }
    
}

-(void)RadiousBtnTitle
{
    @try {
        NSString *btnTitle;
        
        
        if ([mPref valueForKey:@"TempRadius"] ==nil) {
            NSData *registerObjj = [mPref valueForKey:@"SaveRegisterDetails"];
            
            if (registerObjj!=nil) {
                NSDictionary *myDictionary =   (NSDictionary*) [NSKeyedUnarchiver unarchiveObjectWithData:registerObjj];
                
                btnTitle = [myDictionary valueForKey:@"DefaultRadius"];
                
                if (btnTitle==nil) {
                    NSString *btnTitle1 = [mPref valueForKey:@"Radious"];
                    if (btnTitle1==nil) {
                        btnTitle1 = @"1000";
                        btnTitle= btnTitle1;
                    }
                    else{
                        btnTitle = btnTitle1;
                    }
                    
                }
            }
            
            else
            {
                NSString *btnTitle1 = [mPref valueForKey:@"Radious"];
                if (btnTitle1==nil) {
                    btnTitle1 = @"1000";
                    btnTitle= btnTitle1;
                }
                btnTitle = btnTitle1;
                
            }

        }
        else
            btnTitle =[mPref valueForKey:@"TempRadius"];
       // [mPref setValue:nil forKey:@"TempRadius"];
        
        
        
        
        
        
        btnTitle = [NSString stringWithFormat:@"%@",btnTitle];
        
        
        if ([btnTitle isEqualToString:@"500"]) {
            btnTitle = @"0.5 Km";
        }
        else if ([btnTitle isEqualToString:@"1000"]) {
            btnTitle = @"1 Km";
        }
        else if ([btnTitle isEqualToString:@"3000"]) {
            btnTitle = @"3 Km";
        }
        else if ([btnTitle isEqualToString:@"5000"]) {
            btnTitle = @"5 Km";
        }
        else if ([btnTitle isEqualToString:@"10000"]) {
            btnTitle = @"10 Km";
        }
        else if (btnTitle==nil)
            btnTitle= @"0.5 Km";
        
        else if([btnTitle isEqualToString:@"(null)"])
        {
             btnTitle = @"0.5 Km";
            [mPref setValue:@"500" forKey:@"Radious"];
        }
        
        [Radious setTitle:btnTitle forState:UIControlStateNormal];
        
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
        
    } @finally {
        
    }
}

-(void) viewDidLayoutSubviews {
    
    @try {
        [super viewDidLayoutSubviews];
        [self.scrollview layoutIfNeeded];
        self.scrollview.contentSize=self.Contentview.bounds.size;
        UIGraphicsBeginImageContext(self.view.frame.size);
        UIImage *image = UIGraphicsGetImageFromCurrentImageContext();
        UIGraphicsEndImageContext();
        self.Contentview.backgroundColor = [UIColor colorWithPatternImage:image];
    } @catch (NSException *exception) {
       [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
}

-(NSDictionary*)updateUserLocation
{
    @try {
        if (geoCode!=nil) {
            [self GetCategoryDeatils];
        }
        return nil;
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
}

-(IBAction)addtofavorite:(id)sender
{
    
    
    spinner = [[UIActivityIndicatorView alloc]
               initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
    spinner.frame = CGRectMake(0, 0, 320, 560); // CGPointMake(160, 240);
    spinner.color = [UIColor blueColor];
    spinner.backgroundColor = [UIColor lightTextColor];
    spinner.transform = CGAffineTransformMakeScale(2, 2);
    // spinner.hidesWhenStopped = YES;
    [self.view addSubview:spinner];
    spinner.transform = CGAffineTransformMakeScale(2, 2);
    
    [spinner startAnimating];
    
    // how we stop refresh from freezing the main UI thread
    
    dispatch_async(
                   dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^{
                       
                       // back to the main thread for the UI call
                       dispatch_async(dispatch_get_main_queue(), ^{
                           [spinner startAnimating];
                       });
                       dispatch_async(dispatch_get_main_queue(), ^{
                           
                            favoriteAddress = [mWebservice GetFavAddress:[mPref valueForKey:USERREGISTERID]];
                           [self showAddedFavorites];
                           
                           [spinner stopAnimating];
                           
                       });                   });

    
    
    
    
}

-(void)customAlertforFavorites:(NSString*)alertString
{
    
    @try {
        
    UIAlertController *errorAlert =[UIAlertController alertControllerWithTitle:@"Right Place Right Time"
                                                                       message:alertString
                                                                preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction* defaultAction = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault
                                                          handler:^(UIAlertAction * action) {
                                                              spinner = [[UIActivityIndicatorView alloc]
                                                                         initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
                                                              spinner.frame = CGRectMake(0, 0, 320, 560); // CGPointMake(160, 240);
                                                              spinner.color = [UIColor blueColor];
                                                              spinner.backgroundColor = [UIColor lightTextColor];
                                                              spinner.transform = CGAffineTransformMakeScale(2, 2);
                                                              // spinner.hidesWhenStopped = YES;
                                                              [self.view addSubview:spinner];
                                                              spinner.transform = CGAffineTransformMakeScale(2, 2);
                                                              
                                                              [spinner startAnimating];
                                                              
                                                              // how we stop refresh from freezing the main UI thread
                                                              
                                                              dispatch_async(
                                                                             dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^{
                                                                                 
                                                                                 // back to the main thread for the UI call
                                                                                 dispatch_async(dispatch_get_main_queue(), ^{
                                                                                     [spinner startAnimating];
                                                                                 });
                                                                                 dispatch_async(dispatch_get_main_queue(), ^{
                                                              
                                                              
                                                              
                                                              favoriteAddress = [mWebservice GetFavAddress:[mPref valueForKey:USERREGISTERID]];
                                                              [self showAddedFavorites];
                                                                                     [spinner stopAnimating];
                                                                                 });
                                                                             });
                                                              
                                                          }];
    
    [errorAlert addAction:defaultAction];
    [self presentViewController:errorAlert animated:YES completion:nil];
        
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
    
}

-(void)showAddedFavorites
{
    foveriteAlert=[[CustomIOSAlertView alloc] init];
    UIView  *alertView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 325, 250)];
    [foveriteAlert setContainerView:alertView];
    [foveriteAlert setButtonTitles:[NSMutableArray arrayWithObjects:@"", nil]];
    
    [foveriteAlert setDelegate:self];
    
    
    // You may use a Block, rather than a delegate.
    
    
    
    
    [foveriteAlert setOnButtonTouchUpInside:^(CustomIOSAlertView *alertView, int buttonIndex) {
        NSLog(@"Block: Button at position %d is clicked on alertView %d.", buttonIndex, (int)[alertView tag]);
        [alertView close];
    }];
    
    [foveriteAlert setUseMotionEffects:true];
    
    UIButton *cancel = [[UIButton alloc]initWithFrame:CGRectMake(300, 5, 24, 24)];
    
    [cancel setImage:[UIImage imageNamed:@"ic_close"] forState:UIControlStateNormal];
    [cancel addTarget:self action:@selector(cancel:) forControlEvents:UIControlEventTouchUpInside];
    
    UILabel *label = [[UILabel alloc]initWithFrame:CGRectMake(10, 5, 200, 25)];
    label.text = @"Favorite Locations";
    
    label.font= [UIFont fontWithName:@"Roboto-Medium" size:16];// i.e. [[self titleLabel] setFont:[UIFont systemFontOfSize:36]];
    [alertView addSubview:label];
    
    UIView *lineview = [[UIView alloc]initWithFrame:CGRectMake(0, 30, 325, 1)];
    lineview.backgroundColor = [UIColor lightGrayColor];
    [alertView addSubview:lineview];

    searchText1 = [[UITextField alloc] initWithFrame:CGRectMake(2, 35, 260, 40)];
    searchText1.borderStyle = UITextBorderStyleRoundedRect;
    searchText1.font = [UIFont systemFontOfSize:15];
    searchText1.placeholder = @"enter text";
    searchText1.text = searchText.text;
    searchText1.autocorrectionType = UITextAutocorrectionTypeNo;
    searchText1.keyboardType = UIKeyboardTypeDefault;
    searchText1.returnKeyType = UIReturnKeyDone;
    searchText1.clearButtonMode = UITextFieldViewModeWhileEditing;
    searchText1.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
    searchText1.delegate = self;
    [alertView addSubview:searchText1];
    
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    [button addTarget:self
               action:@selector(addtoFav:)
     forControlEvents:UIControlEventTouchUpInside];
    [button setTitle:@"Add" forState:UIControlStateNormal];
    button.frame = CGRectMake(265,35, 50, 40);
    button.backgroundColor =[UIColor colorWithRed:0 green:186.0/256.0 blue:210./256.0 alpha:1];
    [alertView addSubview:button];
    
    favTable= [[UITableView alloc]initWithFrame:CGRectMake(2, 80, 321, 200) style:UITableViewStylePlain];
    favTable.separatorStyle = UITableViewCellSeparatorStyleNone;
    
    favTable.delegate= self;
    favTable.dataSource = self;
    
    [alertView addSubview:favTable];
   
    [alertView addSubview:cancel];
    
    //alertview AutoComplete TableView
    
     alertLocationTable = [[UITableView alloc]initWithFrame:CGRectMake(2, searchText1.frame.origin.y+30, favTable.frame.size.width, 100)];
    alertLocationTable.delegate = self;
    alertLocationTable.dataSource = self;
    alertLocationTable.hidden= YES;
    [alertView addSubview:alertLocationTable];
    
    [foveriteAlert show];
    foveriteAlert.tag = 2;
}

-(void)cancel:(UIButton*)senders
{
    [foveriteAlert close];
    [customAlert close];
}

-(void)addtoFav:(UIButton*)sender
{
    if ([mPref valueForKey:USERREGISTERID]) {
        
    
        NSMutableDictionary *addre = [[NSMutableDictionary alloc]init];
        NSString *latlong = [NSString stringWithFormat:@"%@,%@",geoCode.Latitude,geoCode.Longitude];
        NSString *address = [NSString stringWithFormat:@"%@,%@,%@,%@,%@,%@,%@",geoCode.Address1,geoCode.Address2,geoCode.Address3,geoCode.AreaName,geoCode.City,geoCode.State,geoCode.Country];
        [addre setValue:latlong forKey:@"LatLong"];
         [addre setValue:address forKey:@"Address"];
        favoriteAddress = [[NSMutableArray alloc]init];
    
        favoriteAddress = [mWebservice GetFavAddress:[mPref valueForKey:USERREGISTERID]];
    
        if ([favoriteAddress count]==5) {
    
            [self customAlertforFavorites:@"Alredy have 5 favorite locations"];
    
        }
        else if ([favoriteAddress count]<5)
        {
    
        if (geoCode!=nil) {
            NSDictionary *favLoaction = @{@"VendorAddressID":@"0",
                                          @"AddressName":[NSString stringWithFormat:@"%@",geoCode.AddresName],
                                          @"Address1":[NSString stringWithFormat:@"%@",geoCode.Address1],
                                          @"Address2":[NSString stringWithFormat:@"%@",geoCode.Address2],
                                          @"Address3":[NSString stringWithFormat:@"%@",geoCode.Address3],
                                          @"AreaName":[NSString stringWithFormat:@"%@",geoCode.AreaName],
                                          @"City":[NSString stringWithFormat:@"%@",geoCode.City],
                                          @"State":[NSString stringWithFormat:@"%@",geoCode.State],
                                          @"Country":[NSString stringWithFormat:@"%@",geoCode.Country],
                                          @"Latitude":[NSString stringWithFormat:@"%@",geoCode.Latitude],
                                          @"Longitude":[NSString stringWithFormat:@"%@",geoCode.Longitude],
                                          @"UserRegisterId":[NSString stringWithFormat:@"%@",[mPref valueForKey:USERREGISTERID]],
                                          @"IsFavourite":@"true"
                                          };
           NSMutableArray *response= [mWebservice SaveFavouriteAddress:favLoaction];
           // NSLog(@"%@",response);
    
            if ([[[response objectAtIndex:0] valueForKey:@"City"] isEqualToString:@"Error"]) {
    
                NSString *errostring = [[response objectAtIndex:0] valueForKey:@"AreaName"];
                [self customAlertforFavorites:errostring];
    
            }
            else
            {
             favoriteAddress = [mWebservice GetFavAddress:[mPref valueForKey:USERREGISTERID]];
                
                [favTable reloadData];
     
            }
    
    }
    }
    }
    else
    {
        self.popViewController = [[PopUpViewController alloc] initWithNibName:@"PopUpViewController" bundle:nil];
        [self.popViewController setTitle:@"This is a popup view"];
        
        [self.popViewController showInView:self.view withImage:[UIImage imageNamed:@"rprt_usinfo.png"] withMessage:@"You just triggered a great popup window" animated:YES];
    

    
    
//        Login *mlogin = [[Login alloc]initWithNibName:LOGIN bundle:nil];
//        [self presentViewController:mlogin animated:YES completion:nil];
    }

}

-(void)deleteFavlLocation:(UIButton*)sender
{
    @try {
    
    CGPoint buttonPosition = [sender convertPoint:CGPointZero toView:favTable];
    NSIndexPath *indexPath = [favTable indexPathForRowAtPoint:buttonPosition];
    NSDictionary *selectedFavAddress = [favoriteAddress objectAtIndex:indexPath.row];
    
   
        NSDictionary *favLoaction = @{@"VendorAddressID":[selectedFavAddress valueForKey:@"VendorAddressID"],
                                      @"AddressName":[selectedFavAddress valueForKey:@"AddressName"],
                                      @"Address1":[selectedFavAddress valueForKey:@"Address1"],
                                      @"Address2":[selectedFavAddress valueForKey:@"Address2"],
                                      @"Address3":[selectedFavAddress valueForKey:@"Address3"],
                                      @"AreaName":[selectedFavAddress valueForKey:@"AreaName"],
                                      @"City":[selectedFavAddress valueForKey:@"City"],
                                      @"State":[selectedFavAddress valueForKey:@"State"],
                                      @"Country":[selectedFavAddress valueForKey:@"Country"],
                                      @"Latitude":[selectedFavAddress valueForKey:@"Latitude"],
                                      @"Longitude":[selectedFavAddress valueForKey:@"Longitude"],
                                      @"UserRegisterId":[NSString stringWithFormat:@"%@",[mPref valueForKey:USERREGISTERID]],
                                      @"IsFavourite":@"false"
                                      };
        [mWebservice SaveFavouriteAddress:favLoaction];
        favoriteAddress = [mWebservice GetFavAddress:[mPref valueForKey:USERREGISTERID]];
        [favTable reloadData];
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }

    
}

-(void)GetCategoryDeatils
{
    if (geoCode!=nil) {
        if ( [NotificationKey isEqualToString:@""]) {
             NotificationKey= @"Key";
        }
        
        NSString *Username = [[UIDevice currentDevice] name];
        NSString *DeviceID = [[[UIDevice currentDevice] identifierForVendor] UUIDString];
        NSString *DeviceOS = [[UIDevice currentDevice] model];
        NSString *OsVersion= [[UIDevice currentDevice] systemVersion];
        NSString *GCM_Regid = [mPref valueForKey:@"FCMID"];
            if(GCM_Regid==nil) GCM_Regid = @"";
         NSString *AddressName = [NSString stringWithFormat:@"%@",geoCode.AddresName];
        NSString *Areaname = [NSString stringWithFormat:@"%@",geoCode.AreaName];
         NSString *Address1 = [NSString stringWithFormat:@"%@",geoCode.Address1];
         NSString *Address2 = [NSString stringWithFormat:@"%@",geoCode.Address2];
         NSString *Address3 = [NSString stringWithFormat:@"%@",geoCode.Address3];
         NSString *City = [NSString stringWithFormat:@"%@",geoCode.City];
         NSString *State = [NSString stringWithFormat:@"%@",geoCode.State];
         NSString *Country = [NSString stringWithFormat:@"%@",geoCode.Country];
         NSString *Latitude = [NSString stringWithFormat:@"%@",geoCode.Latitude];
         NSString *Longitude = [NSString stringWithFormat:@"%@",geoCode.Longitude];
        NSString *Radius;
        NSString *UserRegID;
        if ([mPref valueForKey:USERREGISTERID]) {
            UserRegID =[mPref valueForKey:USERREGISTERID];
        }
        else UserRegID= @"0";
        
       // mPref = [NSUserDefaults standardUserDefaults];
        //NSString *radious;
        if ([mPref valueForKey:@"Radious"]==nil) {
            Radius = @"1000";
            
        }
        else
            Radius =[mPref valueForKey:@"Radious"];
        NSData *registerObj = [mPref valueForKey:@"SaveRegisterDetails"];
        
        if (registerObj!=nil) {
            NSDictionary *myDictionary =   (NSDictionary*) [NSKeyedUnarchiver unarchiveObjectWithData:registerObj];
            if (Radius==nil) {
                
                Radius = [myDictionary valueForKey:@"DefaultRadius"];
                
                if (Radius==nil) {
                    Radius = @"1000";
                }
            }
        
    }
        
        NSDictionary *ProcessObj = @{@"UserInfoId":@"0",
                                     @"DeviceId":DeviceID,
                                     @"UserNme":Username,
                                     @"AddressName":AddressName,
                                     @"Address1":Address1,
                                     @"Address2":Address2,
                                     @"Address3":Address3,
                                     @"AreaName":Areaname,
                                     @"City":City,
                                     @"State":State,
                                     @"Country":Country,
                                     @"RowStatus":@"A",
                                     @"Latitude":Latitude,
                                     @"Longitude":Longitude,
                                     @"CreatedDate":@"",
                                     @"ModifiedDate":@"",
                                     @"UserID":@"0",
                                     @"UserSelectedCat":@"0",
                                     @"GCM_Regid":GCM_Regid,
                                     @"UserName":@"",
                                     @"PhoneNo":@"",
                                     @"Email":@"",
                                     @"UserType":@"0",
                                     @"CreatedBy":Username,
                                     @"IsPrimary":@"true",
                                     @"DeviceOS":DeviceOS,
                                     @"OsVersion":OsVersion,
                                     @"UserRegisterID":UserRegID,
                                     @"Radius":Radius
                                     };
        
        
        NSDictionary *Response = [mWebservice ProcessLogin:ProcessObj];
        
        if (Response!=nil) {
            
            NSMutableArray *numberoffers =[Response valueForKey:@"Categories"];
            
            
            NSMutableDictionary *getnumOff = [[NSMutableDictionary alloc]init];
            if (numberoffers.count>0) {
                for(int i=0;i<numberoffers.count;i++)
                {
                    NSCharacterSet *quoteCharset = [NSCharacterSet characterSetWithCharactersInString:@"\""];
                    NSString *trimmedString = [[numberoffers[i] valueForKey:CATEGORY] stringByTrimmingCharactersInSet:quoteCharset];
                    
                    [getnumOff setValue:[numberoffers[i] valueForKey:@"OfferCount"] forKey:trimmedString];
                }
                
            }
            [getnumOff setValue:@"0" forKey:@"Hotel"];
              [getnumOff setValue:@"0" forKey:@"Education"];
            [getnumOff setValue:[Response valueForKey:@"ExclusiveOffersCount"] forKey:@"ExclusiveOffersCount"];
             [getnumOff setValue:[Response valueForKey:@"NewCustomersCount"] forKey:@"NewCustomersCount"];
         [getnumOff setValue:[Response valueForKey:@"Notifications"] forKey:@"Notifications"];
            
            numberofoffers = [[NumberOfOffers GetSharedInstance]initOffers:getnumOff];
            
            
               CatCntArray = [NSArray arrayWithObjects:numberofoffers.food,numberofoffers.sales,numberofoffers.jobs,numberofoffers.realEstate,numberofoffers.bankandFinancial,numberofoffers.meetings,numberofoffers.travel,numberofoffers.sports,numberofoffers.professional,numberofoffers.health,numberofoffers.education,numberofoffers.hotel, nil];
            [self.CatCollectionView reloadData];
           
            
            if ([numberofoffers.Notifications count]>0) {
                
                NSData  *VendorData =    [mPref valueForKey:@"SaveNotifications"];
                NSDictionary *notificationData =   (NSDictionary*) [NSKeyedUnarchiver unarchiveObjectWithData:VendorData];
                NSMutableArray *NotifiArray = [[NSMutableArray alloc]init];
                if (notificationData==nil) {
                    
                    for (int i= 0; i<[numberofoffers.Notifications count]; i++) {
                        NSDictionary *notifiObj =[numberofoffers.Notifications objectAtIndex:i];
                        [NotifiArray addObject:notifiObj];
                    }
                    
                    
                    NSDictionary *notifObje = @{@"Notifications":NotifiArray};
                     [mPreferences StoreNotifications:notifObje];
                }
                else
                {
                    NotifiArray =[notificationData valueForKey:@"Notifications"];
                    
                    for (int i= 0; i<[numberofoffers.Notifications count]; i++) {
                        NSDictionary *notifiObj =[numberofoffers.Notifications objectAtIndex:i];
                        [NotifiArray addObject:notifiObj];
                    }
                    
                    NSDictionary *notifObje = @{@"Notifications":NotifiArray};
                    [mPreferences StoreNotifications:notifObje];
                    
                }
                
                //    [mPreference SaveRegisterDeatils:registerDatavia];
                
                
                self.notifBadge.hidden= NO;
                self.notifBadge.text= [NSString stringWithFormat:@"%ld",(unsigned long)[numberofoffers.Notifications count]];
                self.notifBadge.textColor = [UIColor whiteColor];
                self.notifBadge.textAlignment = NSTextAlignmentCenter;
//                self.notifBadge.layer.masksToBounds = YES;
//                self.notifBadge.layer.cornerRadius = self.notifBadge.frame.size.height/2;
//                self.notifBadge.backgroundColor = [UIColor redColor];
                
                self.notifBadge.layer.cornerRadius = self.notifBadge.frame.size.width/2;
                //labelName.textAlignment = NSTextAlignmentCenter;
                self.notifBadge.backgroundColor = [UIColor redColor];
                self.notifBadge.layer.cornerRadius=10;
                self.notifBadge.layer.masksToBounds = YES;
                [notificationTable reloadData];
                
            }
            

            
        }
        }

}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    return DashCatArray.count;
}

// The cell that is returned must be retrieved from a call to -dequeueReusableCellWithReuseIdentifier:forIndexPath:
- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{  static NSString *cellIdentifier = @"Home_CollectionCell";
    
    Home_CollectionCell *cell = (Home_CollectionCell *)[collectionView dequeueReusableCellWithReuseIdentifier:cellIdentifier forIndexPath:indexPath];
    cell.categoryImage.image =[UIImage imageNamed:[DashCatArray objectAtIndex:indexPath.row]];
    cell.Categoryname.text=[CollectioCatArray objectAtIndex:indexPath.row];
   // cell.CatCnt.text = [CatCntArray objectAtIndex:indexPath.row];
    if([CatCntArray count]>0)
    {
    NSString *stcountb = [NSString stringWithFormat:@"%@",[CatCntArray objectAtIndex:indexPath.row]];
    
    
    if ([stcountb isEqualToString:@"0"] ||  [stcountb isEqualToString:@""]) {
        cell.CatCnt.text =[NSString stringWithFormat:@""];
        cell.CatCnt.backgroundColor = [UIColor clearColor];
        cell.CatCnt.hidden= YES;
    }
    else
    {
        cell.CatCnt.hidden= NO;
        cell.CatCnt.text =[NSString stringWithFormat:@"%@",stcountb];
        //labelName.layer.masksToBounds = YES;
        cell.CatCnt.layer.cornerRadius = cell.CatCnt.frame.size.width/2;
        //labelName.textAlignment = NSTextAlignmentCenter;
        cell.CatCnt.backgroundColor = [UIColor redColor];
        cell.CatCnt.layer.cornerRadius=15;
        cell.CatCnt.layer.masksToBounds = YES;
    }
    
    }
    
    
    //cell.text.text = @"name";
    
    return cell;
}
- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    switch (indexPath.row) {
        case 0:
             [self Pagenavigation:FOOD andModuleId:@"33"];
            break;
        case 1:
             [self Pagenavigation:SALES andModuleId:@"34"];
            break;
        case 2:
              [self Pagenavigation:JOBS andModuleId:@"36"];
            break;
        case 3:
             [self Pagenavigation:REALESTATE andModuleId:@"41"];
            break;
        case 4:
             [self Pagenavigation:BANKING andModuleId:@"42"];
            break;
        case 5:
           [self Pagenavigation:MEETINGS andModuleId:@"39"];
            break;
        case 6:
             [self Pagenavigation:TRAVELS andModuleId:@"40"];
            break;
        case 7:
           [self Pagenavigation:SPORTS andModuleId:@"38"];
            break;
        case 8:
          [self Pagenavigation:PROFESSIONALHELP andModuleId:@"37"];
            break;
        case 9:
           [self Pagenavigation:HEALTH andModuleId:@"43"];
            break;
            
        default:
            break;
    }
    
}

-(void)customimageAlert
{
    @try {
        
        
        customAlert=[[CustomIOSAlertView alloc] init];
        UIView  *alert = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 340, 500)];
        alert.backgroundColor = [UIColor colorWithRed:238.0/256.0 green:242.0/256.0 blue:249.0/256.0 alpha:1];
        [customAlert setContainerView:alert];
        [customAlert setButtonTitles:[NSMutableArray arrayWithObjects:@"", nil]];
        
        [customAlert setDelegate:self];
        
        
        // You may use a Block, rather than a delegate.
        [customAlert setOnButtonTouchUpInside:^(CustomIOSAlertView *alertView, int buttonIndex) {
            NSLog(@"Block: Button at position %d is clicked on alertView %d.", buttonIndex, (int)[alertView tag]);
             [alertView close];
            My_Notifications *mNotifications =[[My_Notifications alloc]initWithNibName:@"My_Notifications" bundle:nil];
            [self presentViewController:mNotifications animated:YES completion:nil];
            
           //
        }];
        
        [customAlert setUseMotionEffects:true];
        UIView *titleView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, 340, 50)];
        titleView.backgroundColor = [UIColor whiteColor];
        
        
        UILabel *title = [[UILabel alloc]initWithFrame:CGRectMake(15, 5, 300, 40)];
        title.text = @"Your Notifications";
        [title setFont:[UIFont fontWithName:@"Roboto-Medium" size:20]];
        //[UIFont fontWithName:@"RalewayMedium" size:22]
        
        
        
        UILabel *notificationLbel= [[UILabel alloc]initWithFrame:CGRectMake(15, 150, 300, 40)];
        notificationLbel.text= @"No notifications as yet!!";
        notificationLbel.font= [UIFont fontWithName:@"Roboto-Medium" size:20];
        notificationLbel.textColor= [UIColor blueColor];
        if ([NotificationsArray count]==0) {
            [alert addSubview:notificationLbel];
          //  [[UIApplication sharedApplication].keyWindow bringSubviewToFront:alert];
            notificationTable.hidden=YES;
        }
        
        UIButton *cancel = [[UIButton alloc]initWithFrame:CGRectMake(300, 10, 28, 28)];
       // cancel.backgroundColor = [UIColor lightGrayColor];
        [cancel setImage:[UIImage imageNamed:@"ic_close"] forState:UIControlStateNormal];
        [cancel addTarget:self action:@selector(cancel:) forControlEvents:UIControlEventTouchUpInside];
        notificationTable.frame = CGRectMake(0, 50, 340, 450);
        notificationTable.backgroundColor = [UIColor colorWithRed:238.0/256.0 green:242.0/256.0 blue:249.0/256.0 alpha:1];
        customAlert.backgroundColor =[UIColor colorWithRed:238.0/256.0 green:242.0/256.0 blue:249.0/256.0 alpha:1];
        UIButton *viewAllBtn=[[UIButton alloc]initWithFrame:CGRectMake(0, 500, 340, 50)];
        [viewAllBtn setTitle:@"View All" forState:UIControlStateNormal];
        [viewAllBtn addTarget:self action:@selector(ViewAll:) forControlEvents:UIControlEventTouchUpInside];
        viewAllBtn.titleLabel.font = [UIFont fontWithName:@"Oswald-Regular" size:18];
        viewAllBtn.backgroundColor= [UIColor blueColor];
        viewAllBtn.layer.cornerRadius=4;
        [alert addSubview:viewAllBtn];
        [alert bringSubviewToFront:viewAllBtn];
        
        [titleView addSubview:cancel];
        [titleView addSubview:title];
        [alert addSubview:titleView];
        [alert addSubview:notificationTable];
        
        [customAlert show];
        customAlert.tag = 2;
    }
    @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
}

-(void)ViewAll:(UIButton*)sender
{
    My_Notifications *mNotifications =[[My_Notifications alloc]initWithNibName:@"My_Notifications" bundle:nil];
    [self presentViewController:mNotifications animated:YES completion:nil];
    
}

-(IBAction)SearchBtn:(id)sender
{
    [self.SEARCHBARVIEW setHidden:NO];
    [self.searhBar becomeFirstResponder];
}

-(void)searchBarCancelButtonClicked:(UISearchBar *)searchBar
{
     [self.SEARCHBARVIEW setHidden:YES];
    [self.searhBar resignFirstResponder];
}

-(void)searchBarSearchButtonClicked:(UISearchBar *)searchBar
{
     [self.SEARCHBARVIEW setHidden:YES];
     [self.searhBar resignFirstResponder];
}

-(IBAction)refrehBtn:(id)sender
{
    locationManager = [[CLLocationManager alloc] init];
    locationManager.delegate = self;
    [locationManager setDesiredAccuracy:kCLLocationAccuracyBest];
    if ([[[UIDevice currentDevice] systemVersion] floatValue] >= 8) {
        [locationManager requestAlwaysAuthorization];
    }
    if ([[[UIDevice currentDevice] systemVersion] floatValue] >= 9.2) {
        [locationManager requestWhenInUseAuthorization];
    }
    [locationManager startUpdatingLocation];
    CLLocation *mLocation = [locationManager location];
    center = [mLocation coordinate];
    
    geoCode = [location geoCodeArea:&center.latitude Longitude:&center.longitude];
    searchText.text = [NSString stringWithFormat:@"%@,%@",geoCode.Address1,geoCode.Address2];
    [mPref setValue:nil forKey:@"StoredAddress"];

    
}
-(void)AcceptBtn:(UIButton*)sender
{
    CGPoint buttonPosition = [sender convertPoint:CGPointZero toView:notificationTable];
    NSIndexPath *indexPath = [notificationTable indexPathForRowAtPoint:buttonPosition];
    NSDictionary *selectedFavAddress = [NotificationsArray objectAtIndex:indexPath.row];
    
    NSString *ShowInvite = [NSString stringWithFormat:@"%@",[selectedFavAddress valueForKey:@"ShowInvite"]];
     NSString *ShowAcceptReject = [NSString stringWithFormat:@"%@",[selectedFavAddress valueForKey:@"ShowAcceptReject"]];
    //ShowAcceptReject
     NSString *NotificationId = [NSString stringWithFormat:@"%@",[selectedFavAddress valueForKey:@"NotificationId"]];
    
    if([ShowInvite isEqualToString:@"1"])
    {
        
        [self showinvitePopup:selectedFavAddress];
        
        //NSData * data = [mPref valueForKey:@""];
        
//        NSData  *VendorData =    [mPref valueForKey:@"SaveRegisterDetails"];
//       NSDictionary *myDictionary =   (NSDictionary*) [NSKeyedUnarchiver unarchiveObjectWithData:VendorData];
//        NSLog(@"%@",myDictionary);
//        //[ [myDictionary  valueForKey:@"BusinessDeatils"] valueForKey:@"ContactPerson"]
//        
//        NSString *InviteMessage= [NSString stringWithFormat:@"%@ would like to add you as a Customer, Customer's can enjoy extra benefits!!",[ [myDictionary  valueForKey:@"BusinessDeatils"] valueForKey:@"ContactPerson"]];
//        
//        [mWebservice SendInvite:NotificationId inviteMessage:InviteMessage];
    }
    else if ([ShowAcceptReject isEqualToString:@"1"])
    {
        spinner = [[UIActivityIndicatorView alloc]
                   initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
        spinner.frame = CGRectMake(0, 0, 320, 560); // CGPointMake(160, 240);
        spinner.color = [UIColor blueColor];
        spinner.backgroundColor = [UIColor lightTextColor];
        spinner.transform = CGAffineTransformMakeScale(2, 2);
        // spinner.hidesWhenStopped = YES;
        [self.view addSubview:spinner];
        spinner.transform = CGAffineTransformMakeScale(2, 2);
        
        [spinner startAnimating];
        
        // how we stop refresh from freezing the main UI thread
        
        dispatch_async(
                       dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^{
                           
                           // back to the main thread for the UI call
                           dispatch_async(dispatch_get_main_queue(), ^{
                               [spinner startAnimating];
                           });
                           dispatch_async(dispatch_get_main_queue(), ^{
        
        [mWebservice AcceptReject:NotificationId acceptReject:@"true"];
                               [spinner stopAnimating];
                           });
                       });
        
        
        
    }
    
}

-(void)RejectBtnBtn:(UIButton*)sender
{
    
    spinner = [[UIActivityIndicatorView alloc]
               initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
    spinner.frame = CGRectMake(0, 0, 320, 560); // CGPointMake(160, 240);
    spinner.color = [UIColor blueColor];
    spinner.backgroundColor = [UIColor lightTextColor];
    spinner.transform = CGAffineTransformMakeScale(2, 2);
    // spinner.hidesWhenStopped = YES;
    [self.view addSubview:spinner];
    spinner.transform = CGAffineTransformMakeScale(2, 2);
    
    [spinner startAnimating];
    
    // how we stop refresh from freezing the main UI thread
    
    dispatch_async(
                   dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^{
                       
                       // back to the main thread for the UI call
                       dispatch_async(dispatch_get_main_queue(), ^{
                           [spinner startAnimating];
                       });
                       dispatch_async(dispatch_get_main_queue(), ^{
    
    CGPoint buttonPosition = [sender convertPoint:CGPointZero toView:notificationTable];
    NSIndexPath *indexPath = [notificationTable indexPathForRowAtPoint:buttonPosition];
    NSDictionary *selectedFavAddress = [NotificationsArray objectAtIndex:indexPath.row];
    
     NSString *NotificationId = [NSString stringWithFormat:@"%@",[selectedFavAddress valueForKey:@"NotificationId"]];
       [mWebservice AcceptReject:NotificationId acceptReject:@"false"];
                           
                           
                           [spinner stopAnimating];
                       });
                   });
    
}


-(void)refershControlAction
{
    [mPref setValue:nil forKey:@"SaveNotifications"];
    [refreshController endRefreshing];
    [self GetCategoryDeatils];
    
}


-(void)showinvitePopup:(NSDictionary*)inviteObject1
{
    
    InviteObject =inviteObject1;
    NSData  *VendorData =    [mPref valueForKey:@"SaveRegisterDetails"];
    NSDictionary *myDictionary =   (NSDictionary*) [NSKeyedUnarchiver unarchiveObjectWithData:VendorData];
    NSLog(@"%@",myDictionary);
    //[ [myDictionary  valueForKey:@"BusinessDeatils"] valueForKey:@"ContactPerson"]
    
    NSString *regName ;
   if ([[mPref valueForKey:LOGINTYPE] isEqualToString:@"Business"]) {
       regName=[myDictionary valueForKey:@"RegUserName"];
    }
    else if ([[mPref valueForKey:LOGINTYPE] isEqualToString:@"Individual"])
         regName=[[myDictionary  valueForKey:@"BusinessDeatils"] valueForKey:@"ContactPerson"];
    
    
    
    NSString *InviteMessage= [NSString stringWithFormat:@"%@ would like to add you as a Customer, Customer's can enjoy extra benefits!!",regName];
    
    
    
    InviteAlert=[[CustomIOSAlertView alloc] init];
    UIView  *replyView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 300, 250)];
    [InviteAlert setContainerView:replyView];
    [InviteAlert setButtonTitles:[NSMutableArray arrayWithObjects:@"", nil]];
    
    [InviteAlert setDelegate:self];
    
    
    // You may use a Block, rather than a delegate.
    [InviteAlert setOnButtonTouchUpInside:^(CustomIOSAlertView *alertView, int buttonIndex) {
        NSLog(@"Block: Button at position %d is clicked on alertView %d.", buttonIndex, (int)[alertView tag]);
        [alertView close];
    }];
    
    [InviteAlert setUseMotionEffects:true];
    
    
    UILabel *requestTitle = [[UILabel alloc]initWithFrame:CGRectMake(5, 5, 200, 20)];
    requestTitle.text = @"Right Place Right Time";
    [requestTitle setFont:[UIFont fontWithName:@"Roboto-Medium" size:14]];
    
   
    [replyView addSubview:requestTitle];
    
    UILabel *requestName = [[UILabel alloc]initWithFrame:CGRectMake(5, 30, 100, 20)];
    requestName.text = @"Request :";
    [requestName setFont:[UIFont fontWithName:@"Roboto-Medium" size:18]];
    [replyView addSubview:requestName];
    
    requesttext = [[UITextView alloc]initWithFrame:CGRectMake(5, 50, 290, 140)];
    requesttext.delegate= self;
    requesttext.layer.borderColor = [UIColor lightTextColor].CGColor;
    requesttext.text= InviteMessage;
    [replyView addSubview:requesttext];
    
    UIButton *sendBtn = [[UIButton alloc] initWithFrame:CGRectMake(160, 200, 140, 40)];
    [sendBtn setTitle:@"OK" forState:UIControlStateNormal];
    [sendBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [sendBtn addTarget:self action:@selector(sendBtn:) forControlEvents:UIControlEventTouchUpInside];
    sendBtn.backgroundColor =[UIColor colorWithRed:144.0/256.0 green:147.0/256.0 blue:167.0/256.0 alpha:1];
    [replyView addSubview:sendBtn];
    
    UIButton *Cancel = [[UIButton alloc] initWithFrame:CGRectMake(10, 200, 140, 40)];
    [Cancel setTitle:@"Cancel" forState:UIControlStateNormal];
    [Cancel setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [Cancel addTarget:self action:@selector(Cancel:) forControlEvents:UIControlEventTouchUpInside];
    Cancel.backgroundColor =[UIColor colorWithRed:144.0/256.0 green:147.0/256.0 blue:167.0/256.0 alpha:1];
    [replyView addSubview:Cancel];
    
    
    // [replyView addSubview:cancel];
    
    [InviteAlert show];
    replyView.tag = 2;
    
    
}

-(void)sendBtn:(UIButton*)sender
{
    
    spinner = [[UIActivityIndicatorView alloc]
               initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
    spinner.frame = CGRectMake(0, 0, 320, 560); // CGPointMake(160, 240);
    spinner.color = [UIColor blueColor];
    spinner.backgroundColor = [UIColor lightTextColor];
    spinner.transform = CGAffineTransformMakeScale(2, 2);
    // spinner.hidesWhenStopped = YES;
    [self.view addSubview:spinner];
    spinner.transform = CGAffineTransformMakeScale(2, 2);
    
    [spinner startAnimating];
    
    // how we stop refresh from freezing the main UI thread
    
    dispatch_async(
                   dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^{
                       
                       // back to the main thread for the UI call
                       dispatch_async(dispatch_get_main_queue(), ^{
                           [spinner startAnimating];
                       });
                       dispatch_async(dispatch_get_main_queue(), ^{
    
    NSString *NotificationId = [NSString stringWithFormat:@"%@",[InviteObject valueForKey:@"NotificationId"]];
    
    [mWebservice SendInvite:NotificationId inviteMessage:requesttext.text];
    [InviteAlert close];
                           
                           [self GetCategoryDeatils];
                           NSData  *VendorData =    [mPref valueForKey:@"SaveNotifications"];
                           NSDictionary *notificationData =   (NSDictionary*) [NSKeyedUnarchiver unarchiveObjectWithData:VendorData];
                           
                           NotificationsArray =[notificationData valueForKey:@"Notifications"];
                           

                           [notificationTable reloadData];
                           
   // [self viewDidLoad];
                           [spinner stopAnimating];
                           
                       });
                   });
    
}

-(void)Cancel:(UIButton*)sender
{
    [InviteAlert close];
}


#pragma -UIViewPagerController Code
-(void) setSizeSliding
{
    
    self.pageController = [[UIPageViewController alloc] initWithTransitionStyle:UIPageViewControllerTransitionStyleScroll navigationOrientation:UIPageViewControllerNavigationOrientationHorizontal options:nil];
    
    self.pageController.dataSource = self;
    
    
    //self.pageControl.frame = CGRectMake(0, self.PhotoScroll.frame.origin.y, self.PhotoScroll.frame.size.width, self.PhotoScroll.frame.size.height);
    //[[self view] bounds]
    [[self.pageController view] setFrame:CGRectMake(0, self.PhotoScroll.frame.origin.y, self.PhotoScroll.frame.size.width, self.PhotoScroll.frame.size.height+40)];
    
    ViewPager *initialViewController = [self viewControllerAtIndex:0];
    initialViewController.view.frame= CGRectMake(0, 0, 365, 217);
    
    NSArray *viewControllers = [NSArray arrayWithObject:initialViewController];
    
    [self.pageController setViewControllers:viewControllers direction:UIPageViewControllerNavigationDirectionForward animated:NO completion:nil];
    
    [self addChildViewController:self.pageController];
    [[self Contentview] addSubview:[self.pageController view]];
    [self.pageController didMoveToParentViewController:self];
    
    pageControl = [UIPageControl appearanceWhenContainedIn:[initialViewController class], nil];
    pageControl.pageIndicatorTintColor = [UIColor whiteColor];
    pageControl.currentPageIndicatorTintColor = [UIColor whiteColor];
  //  pageControl.backgroundColor = [UIColor clearColor];
    //[parentView bringSubviewToFront:childView];
   // pageControl.frame= CGRectMake(100, 200, 150, 50);
    
}

- (ViewPager *)viewControllerAtIndex:(NSUInteger)index {
    
    ViewPager *childViewController = [[ViewPager alloc] initWithNibName:@"ViewPager" bundle:nil];
    childViewController.index = index;
    NSArray *mageCount = [GetbannersArray  valueForKey:@"BannerImageName"];
   // NSMutableArray   *Images = [NSMutableArray arrayWithCapacity:[mageCount count]];
    childViewController.imagename= [mageCount objectAtIndex:index];
    return childViewController;
    
}

- (UIViewController *)pageViewController:(UIPageViewController *)pageViewController viewControllerBeforeViewController:(UIViewController *)viewController {
    
    NSUInteger index = [(ViewPager *)viewController index];
    
    if (index == 0) {
        return nil;
    }
    
    // Decrease the index by 1 to return
    index--;
    
    return [self viewControllerAtIndex:index];
    
}

- (UIViewController *)pageViewController:(UIPageViewController *)pageViewController viewControllerAfterViewController:(UIViewController *)viewController {
    
    NSUInteger index = [(ViewPager *)viewController index];
    
    index++;
    
    if (index == 7) {
        return nil;
    }
    
    return [self viewControllerAtIndex:index];
    
}

- (NSInteger)presentationCountForPageViewController:(UIPageViewController *)pageViewController {
    // The number of items reflected in the page indicator.
    return 7;
}

- (NSInteger)presentationIndexForPageViewController:(UIPageViewController *)pageViewController {
    // The selected item reflected in the page indicator.
    return 0;
}








@end
