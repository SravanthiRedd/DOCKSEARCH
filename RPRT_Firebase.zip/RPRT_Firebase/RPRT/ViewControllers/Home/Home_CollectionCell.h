//
//  Home_CollectionCell.h
//  DocNest
//
//  Created by sravanthi Gumma on 19/08/1938 Saka.
//  Copyright © 1938 Saka Devpoint. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Home_CollectionCell : UICollectionViewCell
@property(weak,nonatomic) IBOutlet UIImageView *categoryImage;
@property(weak,nonatomic) IBOutlet UILabel *Categoryname;
@property(weak,nonatomic) IBOutlet UILabel *CatCnt;
@property(weak,nonatomic) IBOutlet UIView *CustView;;
@end
