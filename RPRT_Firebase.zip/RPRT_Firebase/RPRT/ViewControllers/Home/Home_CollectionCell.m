//
//  Home_CollectionCell.m
//  DocNest
//
//  Created by sravanthi Gumma on 19/08/1938 Saka.
//  Copyright © 1938 Saka Devpoint. All rights reserved.
//

#import "Home_CollectionCell.h"

@implementation Home_CollectionCell

@synthesize categoryImage = categoryImage;
@synthesize Categoryname =Categoryname;
@synthesize CatCnt= CatCnt;

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

-(void)layoutSubviews{
   // self.CustView.layer.shadowColor = [UIColor grayColor].CGColor;
   // self.CustView.layer.borderColor = [UIColor colorWithRed:175.0/256.0 green:175.0/256.0 blue:175.0/256.0 alpha:1].CGColor;
   // self.CustView.layer.borderWidth=0.5f;
    //self.CustView.layer.shadowOffset = CGSizeMake(1.0, 1.0);
    //self.CustView.layer.shadowOpacity = 0.7;
   // self.CustView.layer.cornerRadius = 1.0;
    
    
    UIView *view = [[UIView alloc] init];
    view.translatesAutoresizingMaskIntoConstraints = NO;
    view.layer.borderWidth = 0.5f;
    view.layer.borderColor = [UIColor colorWithRed:175.0/256.0 green:175.0/256.0 blue:175.0/256.0 alpha:1].CGColor;
    //view.backgroundColor = [UIColor blackColor];
    [self.CustView addSubview:view];
    
    [self addConstraint:[NSLayoutConstraint constraintWithItem:view attribute:NSLayoutAttributeBottom relatedBy:NSLayoutRelationEqual toItem:self attribute:NSLayoutAttributeBottom multiplier:1.0 constant:1.0]];
    [self addConstraint:[NSLayoutConstraint constraintWithItem:view attribute:NSLayoutAttributeWidth relatedBy:NSLayoutRelationEqual toItem:self attribute:NSLayoutAttributeWidth multiplier:1.0 constant:1.0]];
    [self addConstraint:[NSLayoutConstraint constraintWithItem:view attribute:NSLayoutAttributeHeight relatedBy:NSLayoutRelationEqual toItem:self attribute:NSLayoutAttributeHeight multiplier:1.0 constant:1.0]];
    [self addConstraint:[NSLayoutConstraint constraintWithItem:view attribute:NSLayoutAttributeCenterX relatedBy:NSLayoutRelationEqual toItem:self attribute:NSLayoutAttributeCenterX multiplier:1.0 constant:1.0]];
    
   
}


- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        
        // Initialization code
        NSArray *arrayOfViews = [[NSBundle mainBundle] loadNibNamed:@"Home_CollectionCell" owner:self options:nil];
        
//        if ([arrayOfViews count] < 1) {
//            return nil;
//        }
//        
//        if (![[arrayOfViews objectAtIndex:0] isKindOfClass:[UICollectionViewCell class]]) {
//            return nil;
//        }
//        
        self = [arrayOfViews objectAtIndex:0];
        
    }
    
    return self;
    
}

@end
