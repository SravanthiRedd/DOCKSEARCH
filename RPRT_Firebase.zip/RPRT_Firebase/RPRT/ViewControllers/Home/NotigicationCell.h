//
//  NotigicationCell.h
//  RPRT
//
//  Created by sravanthi Gumma on 10/09/1938 Saka.
//  Copyright © 1938 Saka DevpointSolutions. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NotigicationCell : UITableViewCell
@property (nonatomic,weak) IBOutlet UILabel *notificationMesz;
@property (nonatomic,weak) IBOutlet UIImageView *notificationIcon;
@property (nonatomic,weak) IBOutlet UIView *notificationView;

@property(nonatomic,weak) IBOutlet UIButton *AcceptBtn;
@property(nonatomic,weak) IBOutlet UIButton *RejectBtnBtn;
@property (nonatomic,weak) IBOutlet UILabel *accepttedDate;

@end
