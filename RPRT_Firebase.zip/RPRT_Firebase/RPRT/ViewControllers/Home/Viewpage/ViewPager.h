//
//  ViewPager.h
//  RPRT
//
//  Created by sravanthi Gumma on 27/10/1938 Saka.
//  Copyright © 1938 Saka DevpointSolutions. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewPager : UIViewController
@property (assign, nonatomic) NSInteger index;
@property(strong,nonatomic)NSString *imagename;
@property (strong, nonatomic) IBOutlet UIImageView *bannerImage;
@property(strong,nonatomic) IBOutlet UIPageControl *pageControl;
@end
 
