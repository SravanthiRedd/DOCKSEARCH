//
//  ViewPager.m
//  RPRT
//
//  Created by sravanthi Gumma on 27/10/1938 Saka.
//  Copyright © 1938 Saka DevpointSolutions. All rights reserved.
//

#import "ViewPager.h"
#import "Home.h"
@interface ViewPager ()

@end

@implementation ViewPager
@synthesize pageControl;
- (void)viewDidLoad {
    [super viewDidLoad];
    
   // pageControl = [[UIPageControl alloc] init]; //SET a property of UIPageControl
      
    if (![self.imagename isEqual:@""])
                    {
                        NSMutableString* aString = [NSMutableString stringWithFormat:@"%@%@",baseImageURL,self.imagename];
        
                        NSURL *imageURL = [NSURL URLWithString:aString];
                        NSString *key = [aString MD5Hash];
                        NSData *getData = [FTWCache objectForKey:key];
                        if (getData) {
                            //image =
        self.bannerImage.image= [UIImage imageWithData:getData];
                          //  [Images addObject:image];
        
                        }
                        else {
                            //cell.OpportunityImage.image  = [UIImage imageNamed:@"img_def"];
                            dispatch_queue_t queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_HIGH, 0ul);
                            dispatch_async(queue, ^{
                                NSData *newData = [NSData dataWithContentsOfURL:imageURL];
                                [FTWCache setObject:newData forKey:key];
                                //UIImage *image = [UIImage imageWithData:newData];
                                dispatch_sync(dispatch_get_main_queue(), ^{
                                    //[Images addObject:image];
                                      self.bannerImage.image= [UIImage imageWithData:newData];
                                });
                            });
                        }
        
                    }
    
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
