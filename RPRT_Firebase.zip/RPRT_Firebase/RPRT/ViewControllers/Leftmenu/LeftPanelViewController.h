//
//  LeftPanelViewController.h
//  RPRT
//
//  Created by sravanthi Gumma on 08/01/16.
//  Copyright © 2016 DevpointSolutions. All rights reserved.
//


#import "MainCellLeft.h"
#import "Home.h"
#import "AppDelegate.h"
#import "FTWViewController.h"
#import "Opportunity_List_New.h"
#import "Terms.h"
#import "Pricacy_Policy.h"
#import "Settings.h"
#import "MyContacts.h"
@protocol LeftPanelViewControllerDelegate <NSObject>

@optional

@required
- (void)animalSelected:(NSString*)ModuleID;
- (void)drawerHome;
-(void)LoadCheckBoxs;
@end



@interface LeftPanelViewController : UIViewController
{
    NSMutableArray *Images;
    UITableView *loginTypetable;
}

@property (nonatomic, assign) id<LeftPanelViewControllerDelegate> delegate;
@property (nonatomic, strong) IBOutlet UITableView *myTableView;
@property (nonatomic, copy, readwrite) NSMutableArray *arrayOfList;
@property (nonatomic, strong) IBOutlet UILabel *userMailID;

@property (nonatomic, strong) IBOutlet UILabel *RegiterType;

@property (nonatomic, strong) IBOutlet UILabel *userName;
@property (nonatomic, strong) IBOutlet UIImageView *imageview;
@property (nonatomic,weak) IBOutlet UIView *userTypeView;
@property (nonatomic,weak) IBOutlet UILabel *loginType;
@property (nonatomic,weak) IBOutlet UIImageView *dropDown;
-(IBAction)Post:(id)sender;


@end
