//
//  LeftPanelViewController.m
//  RPRT
//
//  Created by sravanthi Gumma on 08/01/16.
//  Copyright © 2016 DevpointSolutions. All rights reserved.
//

#import "LeftPanelViewController.h"
#import "RegisterWithGoogle.h"
#import "hep.h"
#import "ScanCode.h"
#import "Store_List.h"
#import "Sale_Registration.h"
#import "My_Store.h"
#import "PopUpViewController.h"
#import "My_Notifications.h"

#ifdef __IPHONE_6_0
# define LINE_BREAK_WORD_WRAP NSLineBreakByWordWrapping
#else
# define LINE_BREAK_WORD_WRAP UILineBreakModeWordWrap
#endif

@interface LeftPanelViewController ()<CustomIOSAlertViewDelegate,UITableViewDelegate,UITableViewDataSource>
{
    NumberOfOffers *mNumOfOffers;
    NSUserDefaults *mPref;
    Web_Services *mWebservice;
    NSString *SideMenu;
    NSString *Category;
    NSString *ModuleID;
    CustomIOSAlertView *ImageAlert;
   // UIImageView * imageview;
    UIImage *image;
    UIActivityIndicatorView *spinner;
    NSString *GetExclusiveCount;
    NSArray *loginTypeArray;
    NSDictionary *myDictionary;
}
@property (nonatomic, copy)  NSDictionary *setCache;
@property (strong, nonatomic) PopUpViewController *popViewController;
@end

@implementation LeftPanelViewController
//@synthesize oppDelegate ;
#pragma mark -
#pragma mark View Did Load/Unload

- (void)viewDidLoad {
    
   
        
    
  [super viewDidLoad];
  @try {
      GetExclusiveCount =@"";
      
      myDictionary= [[NSDictionary alloc]init];
       loginTypeArray= [NSArray arrayWithObjects:@"Individual",@"Business", nil];
      
      
      //self.view.backgroundColor = [UIColor whiteColor];
      loginTypetable = [[UITableView alloc]initWithFrame:CGRectMake(self.userTypeView.frame.origin.x+80, self.userTypeView.frame.origin.y+100, self.userTypeView.frame.size.width, 100) style:UITableViewStylePlain];
      loginTypetable.delegate = self;
      loginTypetable.dataSource = self;
      loginTypetable.hidden= YES;
      [self.view addSubview:loginTypetable];
      
      
      
      self.userName.userInteractionEnabled= YES;
      UITapGestureRecognizer *tapGesture =
      [[UITapGestureRecognizer alloc] initWithTarget:self
                                              action:@selector(Edit)];
      [self.userName addGestureRecognizer:tapGesture];

      self.imageview.layer.cornerRadius = self.imageview.frame.size.width/2;
      self.imageview.layer.borderWidth = 3.0f;
      self.imageview.layer.borderColor =[UIColor whiteColor].CGColor;
      
      self.imageview.clipsToBounds= YES;
      
      if (isOnlineStatus) {

      
    
          
      
      self.setCache = [[NSMutableDictionary alloc] init];
      mNumOfOffers = [NumberOfOffers GetSharedInstance];
      mPref = [NSUserDefaults standardUserDefaults];
      mWebservice = [Web_Services GetSharedInstance];

          
         // NSDictionary *vendordate;
          NSString * getuserRegister = [mPref valueForKey:USERREGISTERID];
          if (getuserRegister==nil) {
              myDictionary=nil;
              self.userName.text = @"User Name";
              image = [UIImage imageNamed:@"userw.png"];
              self.imageview.image  = image;
              self.userTypeView.hidden= YES;
              
              self.userTypeView.hidden= YES;
              self. RegiterType.hidden= YES;
              self.dropDown.hidden= YES;

              
              
          }
          else
          {
         // vendordate = [mWebservice GetUsersRegisterBYID:getuserRegister];
          
              
       NSData  *VendorData =    [mPref valueForKey:@"SaveRegisterDetails"];
        myDictionary =   (NSDictionary*) [NSKeyedUnarchiver unarchiveObjectWithData:VendorData];
              if (myDictionary==nil) {
                  self.userName.text =  @"User Name";
                 

              }
              else self.userName.text  =  [myDictionary valueForKey:@"RegUserName"];
              
              if ([[mPref valueForKey:LOGINTYPE] isEqualToString:@"Business"]) {
                  self.loginType.text=  @"Business";
                  self.RegiterType.text = [NSString stringWithFormat:@"Logged in as Business"];
                
              }
              else if ([[mPref valueForKey:LOGINTYPE] isEqualToString:@"Individual"]) {
                   self.loginType.text=  @"Individual";
                   self.RegiterType.text = [NSString stringWithFormat:@"Logged in as Individual"];
                  self.userName.text =[myDictionary valueForKey:@"RegUserName"];
              }
              
              else if ([myDictionary valueForKey:@"BusinessRegisterID"]==nil) {
                   self.userTypeView.hidden= YES;
              }
              else if ([[myDictionary valueForKey:@"BusinessRegisterID"] isEqualToString:@""]) {
                  self.userTypeView.hidden= YES;
                  [mPref setValue:@"Individual" forKey:LOGINTYPE];
              }
              else if (![[myDictionary valueForKey:@"BusinessRegisterID"] isEqualToString:@""]) {
                  self.userTypeView.hidden= NO;
                  [mPref setValue:@"Business" forKey:LOGINTYPE];
              }
             if ([[NSString stringWithFormat:@"%@",[myDictionary valueForKey:@"BusinessRegisterID"]] isEqualToString:@""]) {
             
                 self.userTypeView.hidden= YES;
                 [mPref setValue:@"Individual" forKey:LOGINTYPE];
             }
              
              NSMutableAttributedString *text = [self.userName.attributedText mutableCopy];
              [text addAttribute:NSUnderlineStyleAttributeName value:@(NSUnderlineStyleSingle) range:NSMakeRange(0, text.length)];
              self.userName.attributedText = text;
              
              
              
          if (myDictionary!=nil) {
            
              
         
          UITapGestureRecognizer *singleTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(ImageTap)];
          singleTap.numberOfTapsRequired = 1;
          [self.imageview setUserInteractionEnabled:YES];
          [self.imageview addGestureRecognizer:singleTap];
              
              
              UITapGestureRecognizer *loginTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(loginTap)];
              loginTap.numberOfTapsRequired = 1;
              [self.userTypeView setUserInteractionEnabled:YES];
              [self.userTypeView addGestureRecognizer:loginTap];
   
              NSArray *imagearray;
                 if ([[mPref valueForKey:LOGINTYPE] isEqualToString:@"Business"])
                     {
                         NSString *images = [ [myDictionary  valueForKey:@"BusinessDeatils"] valueForKey:@"PhotoName"];
                         self.userName.text = [ [myDictionary  valueForKey:@"BusinessDeatils"] valueForKey:@"ContactPerson"];
                         imagearray =[images componentsSeparatedByString:@","];
                     }
                     else  if ([[mPref valueForKey:LOGINTYPE] isEqualToString:@"Individual"])
                     {
                         NSString *images = [ [myDictionary  valueForKey:@"IndividualDeatils"] valueForKey:@"PhotoName"];
                        self.userName.text =[myDictionary valueForKey:@"RegUserName"];
                         
                         imagearray =[images componentsSeparatedByString:@","];
                     }
              
              
//              [myDictionary  valueForKey:@"BusinessDeatils"];
//              [myDictionary valueForKey:@"IndividualDeatils"];
              
              
              
              
//              NSArray *imagearray =[[myDictionary valueForKey:@"PhotoName"] componentsSeparatedByString:@","];
              
          NSString *ImageURL = [NSString stringWithFormat:@"%@%@",baseImageURL, [imagearray objectAtIndex:0]];
          
          NSURL *imageURL = [NSURL URLWithString:ImageURL];
          NSString *key = [ImageURL MD5Hash];
          NSData *getData = [FTWCache objectForKey:key];
          if (getData) {
             image = [UIImage imageWithData:getData];
              self.imageview.image  = image;
          }
          else {
              self.imageview.image  = [UIImage imageNamed:@"img_def"];
              dispatch_queue_t queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_HIGH, 0ul);
              dispatch_async(queue, ^{
                  NSData *newData = [NSData dataWithContentsOfURL:imageURL];
                  [FTWCache setObject:newData forKey:key];
                  image = [UIImage imageWithData:newData];
                  dispatch_sync(dispatch_get_main_queue(), ^{
                      self.imageview.image  = image;
                      
                  });
              });
          }
          
     
      }
      else
      {
           self.userName.text = @"User Name";
          image = [UIImage imageNamed:@"userw.png"];
          self.imageview.image  = image;
      }
     
      self.imageview.image = image;
    
      
              
      }
    
           [self setupArray];
     
 
  }
      else if (!isOnlineStatus)
      {
          [self showAlertPop:@"The internet is down." expObj:nil];
          
      }
      
  
  }
    @catch (NSException *exception) {
        [self showAlertPop:@"Error in Data parsing." expObj:exception];
    }
}
-(void)loginTap
{
    loginTypetable.hidden= NO;
    [loginTypetable reloadData];
}


- (void)viewDidUnload {
  [super viewDidUnload];
}

#pragma mark -
#pragma mark View Will/Did Appear

- (void)viewWillAppear:(BOOL)animated {
  [super viewWillAppear:animated];
}

#pragma mark -
#pragma mark View Will/Did Disappear

- (void)viewWillDisappear:(BOOL)animated {
  [super viewWillDisappear:animated];
}

- (void)setupArray
{
    @try {
        
        
        if ([[mPref valueForKey:LOGINTYPE] isEqualToString:@"Business"]) {
            
            NSString *path = [[NSBundle mainBundle] pathForResource:@"SideMenu" ofType:@"plist"];
            NSMutableDictionary *dict = [NSMutableDictionary dictionaryWithContentsOfFile:path];
            NSMutableArray *leftMenuItems = [dict valueForKey:@"BusinessLeftMenu"];
            Images=[dict valueForKey:@"BusinessLeftmenuImages"];
             // [leftMenuItems replaceObjectAtIndex:6 withObject:@"My Business"];
           
            
            [leftMenuItems replaceObjectAtIndex:6 withObject:@"My Business Circles"];
            [Images replaceObjectAtIndex:6 withObject:@"store.png"];
            self.arrayOfList = [NSMutableArray arrayWithArray:leftMenuItems];
            
       
        }
        else if ([[mPref valueForKey:LOGINTYPE] isEqualToString:@"Individual"] ) {
            
            NSString *path = [[NSBundle mainBundle] pathForResource:@"SideMenu" ofType:@"plist"];
            NSMutableDictionary *dict = [NSMutableDictionary dictionaryWithContentsOfFile:path];
            NSMutableArray *leftMenuItems = [dict valueForKey:@"IndividualMenu"];
            Images=[dict valueForKey:@"IndividualLeftMenuImages"];
           
            int regval = [[myDictionary valueForKey:@"BusinessRegisterID"] intValue];
            
            if (regval>0) {
                [leftMenuItems replaceObjectAtIndex:6 withObject:@"My Business"];
                [Images replaceObjectAtIndex:6 withObject:@"store.png"];
            }
             self.arrayOfList = [NSMutableArray arrayWithArray:leftMenuItems];
            
        }
        else if(![mPref valueForKey:USERREGISTERID] && myDictionary==nil)
        {
            NSString *path = [[NSBundle mainBundle] pathForResource:CATEGORY ofType:@"plist"];
            NSMutableDictionary *dict = [NSMutableDictionary dictionaryWithContentsOfFile:path];
            NSArray *leftMenuItems = [dict valueForKey:@"LeftMenuItems"];
            Images=[dict valueForKey:@"LeftMenuImages"];
            self.arrayOfList = [NSMutableArray arrayWithArray:leftMenuItems];

        }
       
        
//        NSString *path = [[NSBundle mainBundle] pathForResource:CATEGORY ofType:@"plist"];
//        NSMutableDictionary *dict = [NSMutableDictionary dictionaryWithContentsOfFile:path];
//        NSArray *leftMenuItems = [dict valueForKey:@"LeftMenuItems"];
//        Images=[dict valueForKey:@"LeftMenuImages"];
//        self.arrayOfList = [NSMutableArray arrayWithArray:leftMenuItems];
//        
//        if ([mPref valueForKey:USERREGISTERID]) {
//            
//            if (![[NSString stringWithFormat:@"%@",[myDictionary valueForKey:@"BusinessRegisterID"]] isEqualToString:@""]) {
//                [Images removeObjectAtIndex:0];
//                [Images removeObjectAtIndex:5];
//                [self.arrayOfList removeObjectAtIndex:0];
//                [self.arrayOfList removeObjectAtIndex:5];
//            }
//            else
//            {
//            [Images removeObjectAtIndex:6];
//            [self.arrayOfList removeObjectAtIndex:6];
//            }
//        }
//        else  if ([mPref valueForKey:USERREGISTERID]== nil)
//        {
//            [Images removeObjectAtIndex:0];
//            [self.arrayOfList removeObjectAtIndex:0];
//        }
        
        
        [self.myTableView reloadData];
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error in Data parsing." expObj:exception];
    } @finally {

    }

}

-(void)cancel:(UIButton*)sender
{
    [ImageAlert close];
}

-(void)ImageTap{
    
    @try {
        
    ImageAlert=[[CustomIOSAlertView alloc] init];
    UIView  *imageView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 300, 200)];
    [ImageAlert setContainerView:imageView];
    [ImageAlert setButtonTitles:[NSMutableArray arrayWithObjects:@"", nil]];
    
    [ImageAlert setDelegate:self];
    
    
    // You may use a Block, rather than a delegate.
    [ImageAlert setOnButtonTouchUpInside:^(CustomIOSAlertView *alertView, int buttonIndex) {
        NSLog(@"Block: Button at position %d is clicked on alertView %d.", buttonIndex, (int)[alertView tag]);
        [alertView close];
    }];
    
    [ImageAlert setUseMotionEffects:true];
    
    UIButton *cancel = [[UIButton alloc]initWithFrame:CGRectMake(275, 0, 20, 20)];
   
    [cancel setImage:[UIImage imageNamed:@"ic_close"] forState:UIControlStateNormal];
    [cancel addTarget:self action:@selector(cancel:) forControlEvents:UIControlEventTouchUpInside];
    
    
    UIImageView *VendorProfile = [[UIImageView alloc]initWithImage:image];
    VendorProfile.frame = CGRectMake(0, 20, 300, 230);
    [imageView addSubview:cancel];
    [imageView addSubview:VendorProfile];
    
    [ImageAlert show];
    ImageAlert.tag = 2;
        
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error in Data parsing." expObj:exception];
    } @finally {
        
    }

    
//ImageAlert = [CustomIOSAlertView ]
}

#pragma mark -
#pragma mark UITableView Datasource/Delegate

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    @try {
        if(tableView == loginTypetable)
        {
            return [loginTypeArray count];
        }
    else return [self.arrayOfList count];
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error in Data parsing." expObj:exception];
    } @finally {
        
    }
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 45;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    @try {
        
        if (tableView==loginTypetable) {
            static NSString *CellIdentifier = @"Cell";
            // Reuse and create cell
            UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
            if (cell == nil) {
                cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
            }
          //  NSDictionary     *type = [loginTypeArray objectAtIndex:indexPath.row];
            cell.textLabel.text = [loginTypeArray objectAtIndex:indexPath.row];
            return cell;
 
        }
        else
        {
       // static NSString *simpleTableIdentifier = @"MainCellLeft";
        MainCellLeft *cell = (MainCellLeft *)[tableView dequeueReusableCellWithIdentifier:LEFTMENUCELL];
        if (cell == nil)
        {
            NSArray *nib = [[NSBundle mainBundle] loadNibNamed:LEFTMENUCELL owner:self options:nil];
            cell = [nib objectAtIndex:0];
        }
       // tableView.backgroundColor = [UIColor blackColor];
        cell.title.text = _arrayOfList[indexPath.row];
        UILabel *tagcount = [[UILabel alloc]initWithFrame:CGRectMake(185, 15, 20, 20)];
        tagcount.layer.masksToBounds = YES;
        [tagcount setTextColor:[UIColor whiteColor]];
        tagcount.layer.cornerRadius = 8;
        tagcount.textAlignment = NSTextAlignmentCenter;
        tagcount.backgroundColor = [UIColor colorWithRed:33.0/255.0 green:150.0/255.0 blue:243.0/255.0 alpha:1.0];
        
        
        NSString *imagename= [Images objectAtIndex:indexPath.row];
        cell.Image.image= [UIImage imageNamed:imagename];
            
            
            
            NSString *Name = _arrayOfList[indexPath.row];
            
            
            if ([Name isEqualToString:@"My Activities"]) {
                
            }
            else if ([Name isEqualToString:@"My Customers"] || [Name isEqualToString:@"My Friends"])
            {
                NSString *offertag =[NSString stringWithFormat:@"%@",mNumOfOffers.NewCustomersCount];
                tagcount.frame =CGRectMake(185, 10, 40, 25);
                if ([offertag isEqualToString:@"(null)"]) {
                    tagcount.text = @"";
                    tagcount.hidden=YES;
                }
                else if([offertag isEqualToString:@"0"]) tagcount.hidden=YES;
                
                else{
                    tagcount.hidden=NO;
                    tagcount.text = [NSString stringWithFormat:@"%@",mNumOfOffers.NewCustomersCount];
                   // [cell addSubview:tagcount];
                }
  
            }
            else if ([Name isEqualToString:@"My Exclusive Opportunities"])
            {
                NSString *offertag =[NSString stringWithFormat:@"%@",mNumOfOffers.ExclusiveOffersCount];
                tagcount.frame =CGRectMake(185, 10, 40, 25);
                if ([offertag isEqualToString:@"(null)"]) {
                    tagcount.text = @"";
                    tagcount.hidden=YES;
                }
                else if([offertag isEqualToString:@"0"]) tagcount.hidden=YES;
                
                else{
                    tagcount.hidden=NO;
                    tagcount.text = [NSString stringWithFormat:@"%@",mNumOfOffers.ExclusiveOffersCount];
                    //[cell addSubview:tagcount];
                }

            }
            
            else if ([Name isEqualToString:@"Login"])
            {
                if ([mPref valueForKey:USERREGISTERID] == nil) {
                    
                    
                    cell.title.text= @"Login";
                    cell.Image.image= [UIImage imageNamed:@"nav_login.png"];
                    
                    
                }
        }
            
        cell.selectionStyle = UITableViewCellSelectionStyleBlue;
        return cell;
        }
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error in Data parsing." expObj:exception];
    } @finally {
        
    }
}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    @try {
        
        spinner = [[UIActivityIndicatorView alloc]
                   initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
        spinner.frame = CGRectMake(0, 0, 320, 560); // CGPointMake(160, 240);
        spinner.color = [UIColor blueColor];
        spinner.backgroundColor = [UIColor lightTextColor];
        spinner.transform = CGAffineTransformMakeScale(2, 2);
        // spinner.hidesWhenStopped = YES;
        [self.view addSubview:spinner];
        spinner.transform = CGAffineTransformMakeScale(2, 2);
        
        [spinner startAnimating];
        
        // how we stop refresh from freezing the main UI thread
        
        dispatch_async(
                       dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^{
                           
                           // back to the main thread for the UI call
                           dispatch_async(dispatch_get_main_queue(), ^{
                               [spinner startAnimating];
                           });
                           dispatch_async(dispatch_get_main_queue(), ^{
                             
                               if (tableView == loginTypetable) {
                                   NSString *userType = [loginTypeArray objectAtIndex:indexPath.row];
                                   NSString *userRegistedID ;
                                   if ([userType isEqualToString:@"Individual"]) {
                                       userRegistedID = [myDictionary valueForKey:@"IndividualRegisterID"];
                                       self.loginType.text= @"Individual";
                                       [mPref setValue:@"Individual" forKey:LOGINTYPE];
                                       [mPref setValue:userRegistedID forKey:USERREGISTERID];
                                   }
                                   else if ([userType isEqualToString:@"Business"])
                                   {
                                        userRegistedID = [myDictionary valueForKey:@"BusinessRegisterID"];
                                       self.loginType.text= @"Business";
                                        [mPref setValue:@"Business" forKey:LOGINTYPE];
                                        [mPref setValue:userRegistedID forKey:USERREGISTERID];
                                   }
                                   loginTypetable.hidden=YES;
                                   [self viewDidLoad];
                                 
                                   
                               }
else
{
                               
                               
    NSString *Name = self.arrayOfList[indexPath.row];
    
    
    
    
    
    
    
    if([Name isEqualToString:@"Nearby Stores"])
    {
        
        
        
        Store_List * mstore= [[ Store_List alloc] initWithNibName:@"Store_List" bundle:nil];
        mstore.StoreLikes= @"All";
        [self presentViewController:mstore animated:YES completion:nil];
    }
    
    if ([Name isEqualToString:@"My Business Circles"]) {
        //
        Store_List * mstore= [[ Store_List alloc] initWithNibName:@"Store_List" bundle:nil];
        mstore.StoreLikes= @"Connect";
        [self presentViewController:mstore animated:YES completion:nil];
        
        
        //ListType
    }
    
    
    if ([Name isEqualToString:@"My Activities"] || [Name isEqualToString:@"My Activites"]) {
        @try {
            
            if ([mPref valueForKey:USERREGISTERID] == nil) {
                self.popViewController = [[PopUpViewController alloc] initWithNibName:@"PopUpViewController" bundle:nil];
                [self.popViewController setTitle:@"This is a popup view"];
                
                [self.popViewController showInView:self.view withImage:[UIImage imageNamed:@"rprt_usinfo.png"] withMessage:@"You just triggered a great popup window" animated:YES];
                
                
//                Login * mLogin = [[ Login alloc] initWithNibName:LOGIN bundle:nil];
//                [self presentViewController:mLogin animated:YES completion:nil];
                
            }
            else
            {
                Retailer_Offer * mRetailer_Offer = [[ Retailer_Offer alloc] initWithNibName:RETAILER bundle:nil];
                [self presentViewController:mRetailer_Offer animated:YES completion:nil];
            }
            
        } @catch (NSException *exception) {
            [self showAlertPop:@"Error while fetching data." expObj:exception];
        } @finally {
            
        }

    }
    
    else if ([Name isEqualToString:@"My Notifications"])
    {
        My_Notifications *mNotifications = [[My_Notifications alloc]initWithNibName:@"My_Notifications" bundle:nil];
        [self presentViewController:mNotifications animated:YES completion:nil];
    }
    
    
    else if ([Name isEqualToString:@"Register My Business"])
    {
        NSData  *VendorData =    [mPref valueForKey:@"SaveRegisterDetails"];
        myDictionary =   (NSDictionary*) [NSKeyedUnarchiver unarchiveObjectWithData:VendorData];
        if (myDictionary==nil) {
            myDictionary=nil;
        }
        
        
        //  else myDictionary = [mWebservice GetUsersRegisterBYID:getuserRegister];
        
        NSDictionary *regres =  [mWebservice GetUsersRegisterBYID:[mPref valueForKey:USERREGISTERID]];
        
       
        
        NSMutableDictionary *dictionary = [myDictionary mutableCopy];
        [dictionary setValue:[regres valueForKey:@"Password"] forKey:@"Password"];
        [dictionary setValue:[regres valueForKey:@"RegEmail"] forKey:@"RegEmail"];
        [dictionary setValue:[regres valueForKey:@"PhoneNo"] forKey:@"PhoneNo"];
        
        
        if (dictionary != nil) {
            
               // if([[mPref valueForKey:LOGINTYPE] isEqualToString:@"Business"])
               // {
                    Sale_Registration *mSReg  =[[Sale_Registration alloc]initWithNibName:@"Sale_Registration" bundle:nil];
                    mSReg.EditRegisted = dictionary;
                    
                    [self presentViewController:mSReg animated:YES completion:nil];
//                }
//                else
//                {
//                    RegisterWithGoogle *mRegisterWithGoogler = [RegisterWithGoogle alloc];
//                    mRegisterWithGoogler.EditRegisted = dictionary;
//                    RegisterWithGoogle *mRegistatrionGoogle =
//                    [mRegisterWithGoogler initWithNibName:@"RegistrationWithGoogle" bundle:nil];
//                    [self presentViewController:mRegistatrionGoogle animated:YES completion:nil];
//                }
            
        }
    
    
    }
    
    
    else if ([Name isEqualToString:@"My Customers"] || [Name isEqualToString:@"My Friends"])
    {
        @try {
            
            if ([mPref valueForKey:USERREGISTERID] == nil) {
                
                self.popViewController = [[PopUpViewController alloc] initWithNibName:@"PopUpViewController" bundle:nil];
                [self.popViewController setTitle:@"This is a popup view"];
                
                [self.popViewController showInView:self.view withImage:[UIImage imageNamed:@"rprt_usinfo.png"] withMessage:@"You just triggered a great popup window" animated:YES];
            }
            else
            {
                
                MyContacts *mContatcs = [[MyContacts alloc]initWithNibName:@"MyContacts" bundle:nil];
                mContatcs.pageTitleString=Name;
                [self presentViewController:mContatcs animated:YES completion:nil];
            }
            
        } @catch (NSException *exception) {
            [self showAlertPop:@"Error while fetching data." expObj:exception];
        } @finally {
            
        }

    }
    else if ([Name isEqualToString:@"My Exclusive Opportunities"])
    {
        @try {
            
            if ([mPref valueForKey:USERREGISTERID] == nil) {
                self.popViewController = [[PopUpViewController alloc] initWithNibName:@"PopUpViewController" bundle:nil];
                [self.popViewController setTitle:@"This is a popup view"];
                
                [self.popViewController showInView:self.view withImage:[UIImage imageNamed:@"rprt_usinfo.png"] withMessage:@"You just triggered a great popup window" animated:YES];
                
//                Login * mLogin = [[ Login alloc] initWithNibName:LOGIN bundle:nil];
//                [self presentViewController:mLogin animated:YES completion:nil];
                
            }
            else
            {
                
                Excluseive_Offer *mExcluseive_Offer = [[Excluseive_Offer alloc]initWithNibName:@"Excluseive_Offer" bundle:nil];
                [self presentViewController:mExcluseive_Offer animated:YES completion:nil];
            }
            
        } @catch (NSException *exception) {
            [self showAlertPop:@"Error while fetching data." expObj:exception];
        } @finally {
            
        }

    }

    else if ([Name isEqualToString:@"Stores"])
    {
        
        My_Store * mMy_Store= [[ My_Store alloc] initWithNibName:@"My_Store" bundle:nil];
        [self presentViewController:mMy_Store animated:YES completion:nil];
        
//        Store_List * mstore= [[ Store_List alloc] initWithNibName:@"Store_List" bundle:nil];
//        [self presentViewController:mstore animated:YES completion:nil];
    }
    else if([Name isEqualToString:@"My Notifications"])
    {
         [self showAlertPop:@"Not Available." expObj:nil];
    }

    else if ([Name isEqualToString:@"Scan Code"])
    {
        @try {
            if ([mPref valueForKey:USERREGISTERID] == nil) {
                [mPref setObject:@"ScanCode" forKey:@"PageName"];
                self.popViewController = [[PopUpViewController alloc] initWithNibName:@"PopUpViewController" bundle:nil];
                [self.popViewController setTitle:@"This is a popup view"];
                
                [self.popViewController showInView:self.view withImage:[UIImage imageNamed:@"rprt_usinfo.png"] withMessage:@"You just triggered a great popup window" animated:YES];
                
                
//                Login * mLogin = [[ Login alloc] initWithNibName:LOGIN bundle:nil];
//                [self presentViewController:mLogin animated:YES completion:nil];
                
            }
            else
            {
                ScanCode * mQRcodeScanner= [[ ScanCode alloc] initWithNibName:VIEWCONTROLLER bundle:nil];
                [self presentViewController:mQRcodeScanner animated:YES completion:nil];
            }
            
            
            
        } @catch (NSException *exception) {
            [self showAlertPop:@"Error while fetching data." expObj:exception];
        } @finally {
            
        }

    }
    
    else if ([Name isEqualToString:@"Terms of use"])
    {
        Terms * mTerms= [[ Terms alloc] initWithNibName:@"Terms" bundle:nil];
        [self presentViewController:mTerms animated:YES completion:nil];
    }

    else if ([Name isEqualToString:@"Privacy Policy"])
    {
        Pricacy_Policy * mpolicy= [[ Pricacy_Policy alloc] initWithNibName:@"Pricacy_Policy" bundle:nil];
        [self presentViewController:mpolicy animated:YES completion:nil];
    }
    else if ([Name isEqualToString:@"Help"])
    {
        NSString * urlWhats = [NSString stringWithFormat:@"http://www.rightplacerighttime.in/"];
        
        NSURL *whatsappURL = [NSURL URLWithString:urlWhats];
        if ([[UIApplication sharedApplication] canOpenURL: whatsappURL]) {
            UIApplication *application = [UIApplication sharedApplication];
            [application openURL:whatsappURL options:@{} completionHandler:nil];

            //[[UIApplication sharedApplication] openURL: whatsappURL];
        }

    }
    
    else if ([Name isEqualToString:@"My Stores"])
    {
        Store_List * mstore= [[ Store_List alloc] initWithNibName:@"Store_List" bundle:nil];
        mstore.StoreLikes = @"Store Like";
       // mstore.ListType= @"Store Like";
        [self presentViewController:mstore animated:YES completion:nil];
        
        
        //My_Store * mMy_Store= [[ My_Store alloc] initWithNibName:@"My_Store" bundle:nil];
        //[self presentViewController:mMy_Store animated:YES completion:nil];
    }
    
     else if ([Name isEqualToString:@"My Business"])
        {
            NSString *userRegiserID = [mPref valueForKey:USERREGISTERID];
            NSString *storeID = [myDictionary valueForKey:@"BusinessRegisterID"];
            
            NSString *userRegID = userRegiserID;
            if(userRegID==nil)
            {
                userRegID= @"0";
            }
            
            NSString *VenDorRedID=storeID;
            NSString *FinalId = [NSString stringWithFormat:@"%@/%@",VenDorRedID,userRegID];
            
            NSDictionary *getStoreResp =[ mWebservice GetStoreDetails:FinalId];
            
            Store_Details *mStoreDetails = [[Store_Details alloc]initWithNibName:@"Store_Details" bundle:nil];
            mStoreDetails.GetStoreDeatils =getStoreResp;
            [self presentViewController:mStoreDetails animated:YES completion:nil];
            
        }
    
    else if ([Name isEqualToString:@"Login"])
    {
        @try {
            
            //if ([mPref valueForKey:USERREGISTERID] == nil) {
             //   [[GIDSignIn sharedInstance] signOut];
            self.popViewController = [[PopUpViewController alloc] initWithNibName:@"PopUpViewController" bundle:nil];
            [self.popViewController setTitle:@"This is a popup view"];
            
            [self.popViewController showInView:self.view withImage:[UIImage imageNamed:@"rprt_usinfo.png"] withMessage:@"You just triggered a great popup window" animated:YES];
            
            
        } @catch (NSException *exception) {
            [self showAlertPop:@"Error while fetching data." expObj:exception];
        } @finally {
            
        }

    }
    

}
                               [spinner stopAnimating];
                               
                           });
                       });

    } @catch (NSException *exception) {
        
    } @finally {
        
    }
}

- (void) showAlertPop:(NSString*)alertText expObj:(NSException*) exp{
   
    if(exp != nil)
    {
        NSLog(@"%@", exp.description);
    }
    UIAlertController *myAlertController =[mWebservice  alert:alertText];
    [self presentViewController:myAlertController animated:YES completion:nil];
}

- (void)homePageButtonClick {

    @try {
    
        
        [mPref setValue:Category forKey:CATEGORY];
        [mPref setValue:ModuleID forKey:MODULEID];
        Opportunity_List_New * mOpportunity_list = [[ Opportunity_List_New alloc] initWithNibName:OPPORTUNITYLISTNEW bundle:nil];
        [self presentViewController:mOpportunity_list animated:YES completion:nil];
        
       

    } @catch (NSException *exception) {
        [self showAlertPop:@"Error in Data parsing." expObj:exception];
    } @finally {
        
    }

}

#pragma mark -
#pragma mark Default System Code

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self)
    {
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

-(IBAction)Post:(id)sender
{
    @try {
        
        if (isOnlineStatus) {
            
    NSData  *VendorData =    [mPref valueForKey:@"SaveLoginUserDetails"];
    myDictionary = (NSDictionary*) [NSKeyedUnarchiver unarchiveObjectWithData:VendorData];
    if (myDictionary !=nil) {
          [self GotoPost];
    }
    else
    {
        self.popViewController = [[PopUpViewController alloc] initWithNibName:@"PopUpViewController" bundle:nil];
        [self.popViewController setTitle:@"This is a popup view"];
        
        [self.popViewController showInView:self.view withImage:[UIImage imageNamed:@"rprt_usinfo.png"] withMessage:@"You just triggered a great popup window" animated:YES];
        
//        Login * mLogin = [[ Login alloc] initWithNibName:LOGIN bundle:nil];
//        [self presentViewController:mLogin animated:YES completion:nil];

    }
        }
        else if (!isOnlineStatus)
        {
            [self showAlertPop:@"The internet is down." expObj:nil];
            
        }
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error in Data parsing." expObj:exception];
    } @finally {
        
    }
}
-(void)Edit
{
    @try
    {
        if (isOnlineStatus) {
            
            spinner = [[UIActivityIndicatorView alloc]
                       initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
            spinner.frame = CGRectMake(0, 0, 320, 560); // CGPointMake(160, 240);
            spinner.color = [UIColor blueColor];
            spinner.backgroundColor = [UIColor lightTextColor];
            spinner.transform = CGAffineTransformMakeScale(2, 2);
            // spinner.hidesWhenStopped = YES;
            [self.view addSubview:spinner];
            spinner.transform = CGAffineTransformMakeScale(2, 2);
            
            [spinner startAnimating];
            
            // how we stop refresh from freezing the main UI thread
            
            dispatch_async(
                           dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^{
                               
                               // back to the main thread for the UI call
                               dispatch_async(dispatch_get_main_queue(), ^{
                                   [spinner startAnimating];
                               });
                               dispatch_async(dispatch_get_main_queue(), ^{
                                   

            
            
   NSString *getuserRegister  =    [mPref valueForKey:USERREGISTERID];
            
           //  NSMutableDictionary *myDictionary = [[NSMutableDictionary alloc]init];;
  
            if (getuserRegister!=nil) {
            
            NSData  *VendorData =    [mPref valueForKey:@"SaveRegisterDetails"];
            myDictionary =   (NSDictionary*) [NSKeyedUnarchiver unarchiveObjectWithData:VendorData];
            if (myDictionary==nil) {
                myDictionary=nil;
            }
            
            
          //  else myDictionary = [mWebservice GetUsersRegisterBYID:getuserRegister];
            
            NSDictionary *regres =  [mWebservice GetUsersRegisterBYID:getuserRegister];

         //   if ([[myDictionary valueForKey:USERREGISTERID] isEqualToString:getuserRegister]) {
                
                NSMutableDictionary *dictionary = [myDictionary mutableCopy];
                [dictionary setValue:[regres valueForKey:@"Password"] forKey:@"Password"];
                [dictionary setValue:[regres valueForKey:@"RegEmail"] forKey:@"RegEmail"];
                [dictionary setValue:[regres valueForKey:@"PhoneNo"] forKey:@"PhoneNo"];
 //RegEmail = "sravanthi.devpoint@gmail.com";
                
                 if (dictionary != nil) {
                  //   NSString *logintype = [dictionary valueForKey:@"LoginType"];
                     
                         if([[mPref valueForKey:LOGINTYPE] isEqualToString:@"Business"])
                         {
                             Sale_Registration *mSReg  =[[Sale_Registration alloc]initWithNibName:@"Sale_Registration" bundle:nil];
                             mSReg.EditRegisted = dictionary;
                             
                             [self presentViewController:mSReg animated:YES completion:nil];
                             
                         }
                         else
                         {
                         RegisterWithGoogle *mRegisterWithGoogler = [RegisterWithGoogle alloc];
                         mRegisterWithGoogler.EditRegisted = dictionary;
                         
                         RegisterWithGoogle *mRegistatrionGoogle =
                         [mRegisterWithGoogler initWithNibName:@"RegistrationWithGoogle" bundle:nil];
                         [self presentViewController:mRegistatrionGoogle animated:YES completion:nil];
                         }
                     
                 }
                
                
                
                
           // }
            
            
  //  NSDictionary *myDictionary = (NSDictionary*) [NSKeyedUnarchiver unarchiveObjectWithData:VendorData];
//    if (myDictionary != nil) {
//        
//        
////        NSMutableDictionary *registerDatavia = [[NSMutableDictionary alloc]init];
////        [registerDatavia setValue:@"facebook" forKey:@"LoginType"];
////        [registerDatavia setValue:[response valueForKey:USERREGISTERID] forKey:USERREGISTERID];
////        [mPref setObject:registerDatavia forKey:@"LoginType"];
//
//        
//       NSDictionary *loginTypes =  [mPref valueForKey:@"LoginType"];
//        
//        
//     
//
//        
//        
//        
//        NSString *logintype = [loginTypes valueForKey:@"LoginType"];
//        
//        if ([logintype isEqualToString:@"facebook"] || [logintype isEqualToString:@"google"]) {
//            
//            NSMutableDictionary *m = [myDictionary mutableCopy];
//            
//            [m setValue:[loginTypes valueForKey:@"LoginType"] forKey:@"LoginType"];
//            
//            
//          //  [myDictionary setObject:logintype forKey:@"LoginType"];// setObject:logintype forKey:@"LoginType"];
//            
//            RegisterWithGoogle *mRegisterWithGoogler = [RegisterWithGoogle alloc];
//            mRegisterWithGoogler.EditRegisted = m;
//            
//            RegisterWithGoogle *mRegistatrionGoogle =
//            [mRegisterWithGoogler initWithNibName:@"RegistrationWithGoogle" bundle:nil];
//            [self presentViewController:mRegistatrionGoogle animated:YES completion:nil];
//            
//        }
//        else
//        {
//           // [myDictionary setObject:@"Signup" forKey:@"LoginType"];
//
//        Registration *mRegister = [Registration alloc];
//        mRegister.RegisteredObject = myDictionary;
//        
//        Registration *mRegistatrion =
//        [mRegister initWithNibName:REGISTRATION bundle:nil];
//        [self presentViewController:mRegistatrion animated:YES completion:nil];
//        }
                
                
               
                
                
    }
    
    else{

        self.popViewController = [[PopUpViewController alloc] initWithNibName:@"PopUpViewController" bundle:nil];
        [self.popViewController setTitle:@"This is a popup view"];
        
        [self.popViewController showInView:self.view withImage:[UIImage imageNamed:@"rprt_usinfo.png"] withMessage:@"You just triggered a great popup window" animated:YES];

    }
                                    [spinner stopAnimating];
                               });
                           });
                           
        }
        else if (!isOnlineStatus)
        {
            [self showAlertPop:@"The internet is down." expObj:nil];
            
        }
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error in Data parsing." expObj:exception];
    } @finally {
        
    }
}
-(void)GotoPost
{
    @try {
        
        if (isOnlineStatus) {
            
        
        NSString *ModuleId =[mPref valueForKey:MODULEID];
        
        if ([ModuleId isEqualToString:@"33"]) {
            Post_Food * mPosting = [[ Post_Food alloc] initWithNibName:PFOOD bundle:nil];
            [self presentViewController:mPosting animated:YES completion:nil];
            
        }
        else if ([ModuleId isEqualToString:@"34"])
        {
            Post_Sales * mPosting = [[ Post_Sales alloc] initWithNibName:PSALES bundle:nil];
            [self presentViewController:mPosting animated:YES completion:nil];
        }
        else if ([ModuleId isEqualToString:@"37"])
        {
            Post_Professional * mPosting = [[ Post_Professional alloc] initWithNibName:PPROFESSIONAL bundle:nil];
            [self presentViewController:mPosting animated:YES completion:nil];
        }
        else if ([ModuleId isEqualToString:@"38"])
        {
            Post_Sports * mPosting = [[ Post_Sports alloc] initWithNibName:PSPORTS bundle:nil];
            [self presentViewController:mPosting animated:YES completion:nil];
        }
        else if ([ModuleId isEqualToString:@"36"])
        {
            Post_Jobs * mPosting = [[ Post_Jobs alloc] initWithNibName:PJOBS bundle:nil];
            [self presentViewController:mPosting animated:YES completion:nil];
        }
        else if ([ModuleId isEqualToString:@"39"])
        {
            Post_Meetings * mPosting = [[ Post_Meetings alloc] initWithNibName:PMEETINGS bundle:nil];
            [self presentViewController:mPosting animated:YES completion:nil];
        }
        
        else if ([ModuleId isEqualToString:@"40"])
        {
            Post_Travels * mPosting = [[ Post_Travels alloc] initWithNibName:PTRAVELS bundle:nil];
            [self presentViewController:mPosting animated:YES completion:nil];
        }
        else if ([ModuleId isEqualToString:@"41"])
        {
            Post_RealEstate * mPosting = [[ Post_RealEstate alloc] initWithNibName:PREALESTATE bundle:nil];
            [self presentViewController:mPosting animated:YES completion:nil];
        }
            
        else if ([ModuleId isEqualToString:@"42"])
        {
            Post_banking_Finance *mPost = [[Post_banking_Finance alloc]initWithNibName:PBANKINGANDFINANCE bundle:nil];
        
            [self presentViewController:mPost animated:YES completion:nil];
        }
            
        
        else
        {
            [mPref setValue:@"33" forKey:MODULEID];
            Post_Food * mPosting = [[ Post_Food alloc] initWithNibName:PFOOD bundle:nil];
            [self presentViewController:mPosting animated:YES completion:nil];
        }
        }
        else if (!isOnlineStatus)
        {
            [self showAlertPop:@"The internet is down." expObj:nil];
            
        }
        
        
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error in Data parsing." expObj:exception];
    } @finally {
        
    }
}

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    [self viewDidLoad];
}


@end
