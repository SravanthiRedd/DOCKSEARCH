//
//  MainViewController.h
//  RPRT
//
//  Created by sravanthi Gumma on 08/01/16.
//  Copyright © 2016 DevpointSolutions. All rights reserved.
//


#import "LeftPanelViewController.h"

#define CENTER_TAG 1
#define LEFT_PANEL_TAG 2
#define CORNER_RADIUS 4
#define SLIDE_TIMING .25
#define PANEL_WIDTH 155

@interface MainViewController : UIViewController

-(void)movePanelRight ;
- (void)movePanelToOriginalPosition;

@property (nonatomic, assign) BOOL showingLeftPanel;
@property (nonatomic, assign) BOOL showingRightPanel;
@property (nonatomic, assign) BOOL showPanel;
@property (nonatomic, assign) CGPoint preVelocity;
@end