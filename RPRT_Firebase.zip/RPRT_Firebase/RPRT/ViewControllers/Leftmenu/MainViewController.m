//
//  MainViewController.m
//  RPRT
//
//  Created by sravanthi Gumma on 08/01/16.
//  Copyright © 2016 DevpointSolutions. All rights reserved.
//


#import "MainViewController.h"

@interface MainViewController () <HomeDelegate,UIGestureRecognizerDelegate>
{
    Web_Services *mWebService;
}
@property(nonatomic, strong) Home *centerViewController;

@property(nonatomic, strong) LeftPanelViewController *leftPanelViewController;

@end

@implementation MainViewController

#pragma mark -
#pragma mark View Did Load/Unload

- (void)viewDidLoad {
    @try {
        
  [super viewDidLoad];
    mWebService = [Web_Services GetSharedInstance];
  [self setupView];
    }
    @catch (NSException *exception) {
         [self showAlertPop:@"Error while fetching data." exceptionVal:exception];
    }
    @finally {
        
    }
}

- (void)viewDidUnload {
  [super viewDidUnload];
}

#pragma mark -
#pragma mark View Will/Did Appear

- (void)viewWillAppear:(BOOL)animated {
  [super viewWillAppear:animated];
}

- (void)viewDidAppear:(BOOL)animated {
  [super viewDidAppear:animated];
}

#pragma mark -
#pragma mark View Will/Did Disappear

- (void)viewWillDisappear:(BOOL)animated {
  [super viewWillDisappear:animated];
}

- (void)viewDidDisappear:(BOOL)animated {
  [super viewDidDisappear:animated];
}



#pragma mark -
#pragma mark Setup View

- (void)setupView {

  @try {
      
      
  //    NSLog(@"uniqueIdentifier: %@", [[UIDevice currentDevice] uniqueIdentifier]);
      NSLog(@"name: %@", [[UIDevice currentDevice] name]);
      NSLog(@"systemName: %@", [[UIDevice currentDevice] systemName]);
      NSLog(@"systemVersion: %@", [[UIDevice currentDevice] systemVersion]);
      NSLog(@"model: %@", [[UIDevice currentDevice] model]);
      NSLog(@"localizedModel: %@", [[UIDevice currentDevice] localizedModel]);
      
      
      
    
       self.centerViewController = [[Home alloc] initWithNibName:HOMEDASHBOARD1 bundle:nil];
       self.centerViewController.view.tag = CENTER_TAG;
    self.centerViewController.delegate = self;
    [self.view addSubview:self.centerViewController.view];
    [self addChildViewController:self.centerViewController];
    [self.centerViewController didMoveToParentViewController:self];

    [self setupGestures];

  } @catch (NSException *exception) {
     [self showAlertPop:@"Error while fetching data." exceptionVal:exception];
  }
    @finally {
        
    }
}

- (void)showCenterViewWithShadow:(BOOL)value withOffset:(double)offset {
  @try {

    if (value) {
      [self.centerViewController.view.layer setCornerRadius:CORNER_RADIUS];
        [self.centerViewController.view.layer setShadowColor:[UIColor whiteColor].CGColor];
        [self.centerViewController.view.layer setShadowOpacity:0.8];
        
      [self.centerViewController.view.layer
          setShadowOffset:CGSizeMake(offset, offset)];

    } else {
      [self.centerViewController.view.layer setCornerRadius:0.0f];
      [self.centerViewController.view.layer
          setShadowOffset:CGSizeMake(offset, offset)];
    }

  } @catch (NSException *exception) {
     [self showAlertPop:@"Error while fetching data." exceptionVal:exception];
  }@finally {
      
  }
}

- (void)resetMainView {
  @try {

    // remove left and  views, and reset variables, if needed
    if (_leftPanelViewController != nil) {
      [self.leftPanelViewController.view removeFromSuperview];
      self.leftPanelViewController = nil;
      
      self.centerViewController.leftButton.tag = 1;
      self.showingLeftPanel = NO;
    }
    [self showCenterViewWithShadow:NO withOffset:0];
  } @catch (NSException *exception) {
     [self showAlertPop:@"Error while fetching data." exceptionVal:exception];
  }@finally {
      
  }
}

-(void)movePanelRight {
    @try {
        
    UIView *childView = [self getLeftView];
    [self.view sendSubviewToBack:childView];
    
    [UIView animateWithDuration:SLIDE_TIMING delay:0 options:UIViewAnimationOptionBeginFromCurrentState animations:^{
        self.centerViewController.view.frame = CGRectMake(self.view.frame.size.width - PANEL_WIDTH, 0, self.view.frame.size.width, self.view.frame.size.height);
    }
                     completion:^(BOOL finished) {
                         if (finished) {
                             self.centerViewController.leftButton.tag = 0;
                         }
                     }];
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." exceptionVal:exception];
    }@finally {
        
    }
}

- (UIView *)getLeftView {

  @try {

    // init view if it doesn't already exist
    if (_leftPanelViewController == nil) {
      // this is where you define the view for the left panel
      self.leftPanelViewController =
          [[LeftPanelViewController alloc] initWithNibName:LEFTPANEL
                                                    bundle:nil];
      self.leftPanelViewController.view.tag = LEFT_PANEL_TAG;
      self.leftPanelViewController.delegate = self.centerViewController;
      [self.view addSubview:self.leftPanelViewController.view];
      [self addChildViewController:_leftPanelViewController];
      [_leftPanelViewController didMoveToParentViewController:self];
      _leftPanelViewController.view.frame = CGRectMake(
          0, 0, self.view.frame.size.width, self.view.frame.size.height);
    }
      
// 13 - 15
      
    self.showingLeftPanel = YES;

    // setup view shadows
    [self showCenterViewWithShadow:YES withOffset:-2];

    UIView *view = self.leftPanelViewController.view;
    return view;
  } @catch (NSException *exception) {
      [self showAlertPop:@"Error while fetching data." exceptionVal:exception];
  }@finally {
      
  }
}

- (UIView *)getRightView {
    @try {
        
        self.showingRightPanel = NO;
        
        // setup view shadows
        [self showCenterViewWithShadow:YES withOffset:2];
        
        /// UIView *view = self.rightPanelViewController.view;
        return NULL;
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." exceptionVal:exception];
    }
}

#pragma mark -
#pragma mark Swipe Gesture Setup/Actions

#pragma mark - setup

- (void)setupGestures {
  @try {

    UIPanGestureRecognizer *panRecognizer =
        [[UIPanGestureRecognizer alloc] initWithTarget:self
                                                action:@selector(movePanel:)];
    [panRecognizer setMinimumNumberOfTouches:1];
    [panRecognizer setMaximumNumberOfTouches:1];
    [panRecognizer setDelegate:self];

    [self.centerViewController.view addGestureRecognizer:panRecognizer];
  }
    @catch (NSException *exception) {
        [self showAlertPop:@"Invalid UserName." exceptionVal:exception];
    }
    @finally {
        
    }
}

- (void)movePanel:(id)sender {
  @try {

    [[[(UITapGestureRecognizer *)sender view] layer] removeAllAnimations];

    CGPoint translatedPoint =
        [(UIPanGestureRecognizer *)sender translationInView:self.view];
    CGPoint velocity =
        [(UIPanGestureRecognizer *)sender velocityInView:[sender view]];

    if ([(UIPanGestureRecognizer *)sender state] ==
        UIGestureRecognizerStateBegan) {
      UIView *childView; // = nil;

      if (velocity.x > 0) {
        if (!_showingRightPanel) {
          childView = [self getLeftView];
          [self.view sendSubviewToBack:childView];
          [[sender view]
              bringSubviewToFront:[(UIPanGestureRecognizer *)sender view]];
        }
      } else {
        if (!_showingLeftPanel) {
          //childView = [self getLeftView];
        }
      }
      // make sure the view we're working with is front and center
        
//        [self.view sendSubviewToBack:childView];
//        [[sender view]
//         bringSubviewToFront:[(UIPanGestureRecognizer *)sender view]];
    }

    if ([(UIPanGestureRecognizer *)sender state] ==
        UIGestureRecognizerStateEnded) {
        
      if (velocity.x > 0) {
          
        // NSLog(@"gesture went ");
      } else {
        // NSLog(@"gesture went left");
      }

      if (!_showPanel) {
        [self movePanelToOriginalPosition];
      } else {
        if (_showingLeftPanel) {
          //[self movePanel];
            [self movePanelRight];
        } else if (_showingRightPanel) {
          [self movePanelLeft];
        }
      }
    }

    if ([(UIPanGestureRecognizer *)sender state] ==
        UIGestureRecognizerStateChanged) {
      if (velocity.x > 0) {
        NSLog(@"gesture went ");
          
          _showPanel = fabs([sender view].center.x -
                            self.centerViewController.view.frame.size.width / 2) >
          self.centerViewController.view.frame.size.width / 2;
          
          // allow dragging only in x coordinates by only updating the x
          // coordinate with translation position
          [sender view].center = CGPointMake(
                                             [sender view].center.x + translatedPoint.x, [sender view].center.y);
          [(UIPanGestureRecognizer *)sender setTranslation:CGPointMake(0, 0)
                                                    inView:self.view];

      } else if (velocity.x < 0) {
        NSLog(@"gesture went left");
      }
       
      // are we more than halfway, if so, show the panel when done dragging by
      // setting this value to YES (1)

      // if you needed to check for a change in direction, you could use this
      // code to do so
      if (velocity.x * _preVelocity.x + velocity.y * _preVelocity.y > 0) {
        NSLog(@"same direction");
      } else {
        NSLog(@"opposite direction");
      }

      _preVelocity = velocity;
    }
  }
    @catch (NSException *exception) {
        [self showAlertPop:@"Invalid UserName." exceptionVal:exception];
    }
    @finally {
        
    }

}

#pragma mark -
#pragma mark Delegate Actions

- (void)movePanelLeft {

  @try {

      UIView *childView = [self getRightView];
      [self.view sendSubviewToBack:childView];

    [UIView animateWithDuration:SLIDE_TIMING
        delay:0
        options:UIViewAnimationOptionBeginFromCurrentState
        animations:^{
          self.centerViewController.view.frame = CGRectMake(
              -self.view.frame.size.width + PANEL_WIDTH, 0,
              self.view.frame.size.width, self.view.frame.size.height);
        }
        completion:^(BOOL finished) {
          if (finished) {

           
          }
        }];
  } @catch (NSException *exception) {
      [self showAlertPop:@"Error while fetching data." exceptionVal:exception];
  }@finally {
      
  }
}

- (void)movePanelToOriginalPosition {

  @try {

    [UIView animateWithDuration:SLIDE_TIMING
        delay:0
        options:UIViewAnimationOptionBeginFromCurrentState
        animations:^{
          self.centerViewController.view.frame = CGRectMake(
              0, 0, self.view.frame.size.width, self.view.frame.size.height);
        }
        completion:^(BOOL finished) {
          if (finished) {
            [self resetMainView];
          }
        }];
  } @catch (NSException *exception) {
      [self showAlertPop:@"Error while fetching data." exceptionVal:exception];
  }
    @finally {
        
    }
}

#pragma mark -
#pragma mark Default System Code

- (id)initWithNibName:(NSString *)nibNameOrNil
               bundle:(NSBundle *)nibBundleOrNil {
  self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
  if (self) {
  }
  return self;
}

- (void)didReceiveMemoryWarning {
  [super didReceiveMemoryWarning];
}

- (void) showAlertPop:(NSString*)alertText exceptionVal:(NSException*)ex {
    //mWeservice
    UIAlertController *myAlertController =[mWebService  alert:alertText];
    [self presentViewController:myAlertController animated:YES completion:nil];
    if(ex != nil)
    {
        NSLog(@"%@", ex.description);
    }
}

@end
