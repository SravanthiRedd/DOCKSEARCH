//
//  Pricacy_Policy.h
//  RPRT
//
//  Created by sravanthi Gumma on 29/09/16.
//  Copyright © 2016 DevpointSolutions. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Pricacy_Policy : UIViewController

@end
