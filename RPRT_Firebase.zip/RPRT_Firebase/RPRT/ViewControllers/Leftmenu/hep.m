//
//  hep.m
//  RPRT
//
//  Created by sravanthi Gumma on 27/07/1938 Saka.
//  Copyright © 1938 Saka DevpointSolutions. All rights reserved.
//

#import "hep.h"

@interface hep ()<UIWebViewDelegate>
 @property (strong, nonatomic) IBOutlet UIWebView *web;
@end

@implementation hep

@synthesize web;

- (void)viewDidLoad {
    [super viewDidLoad];
    web = [[UIWebView alloc] init];
    [web setDelegate:self];
    
    NSString *urlAddress = @"www.google.com";
    NSURL *url = [NSURL URLWithString:urlAddress];
    NSURLRequest *requestObj = [NSURLRequest requestWithURL:url];
    [web loadRequest:requestObj];
   
  
}

-(IBAction)back:(id)sender
{
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
