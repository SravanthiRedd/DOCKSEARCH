//
//  RegisterWithGoogle.h
//  RPRT
//
//  Created by sravanthi Gumma on 16/09/16.
//  Copyright © 2016 DevpointSolutions. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Preferences.h"
@interface RegisterWithGoogle : UIViewController<UIScrollViewDelegate>
{
    NSString *encodecImage;
    NSDictionary *RegisterdObj;
    NSDictionary *editedDetils;
    UIActivityIndicatorView *spinner;
}
@property (weak, nonatomic) IBOutlet UIView *Contentview;
@property (weak, nonatomic) IBOutlet UIScrollView *scrollview;

@property (strong,nonatomic) IBOutlet UITextField *uName;

@property (strong,nonatomic) IBOutlet UITextField *emailID;
@property (strong,nonatomic) IBOutlet UITextField *mobileNumber;
@property (strong,nonatomic) IBOutlet UITextField *typelbl;
@property (strong,nonatomic) IBOutlet UITextField *conatctPersonName;

@property (strong,nonatomic) IBOutlet UIImageView *regUserImgView;


-(IBAction)hideKeyBoardMobileNumber:(id)sender;
-(IBAction)createAccount:(id)sender;


@property (weak, nonatomic) IBOutlet UIView *RegistationView;
@property (weak, nonatomic) IBOutlet UIView *UserNameView;
@property (weak, nonatomic) IBOutlet UIView *EmailView;
@property (weak, nonatomic) IBOutlet UIView *MobileNumberView;
@property (weak, nonatomic) IBOutlet UIView *contactpersonView;
@property (weak, nonatomic) IBOutlet UIView *NotificationView;
@property (weak, nonatomic) IBOutlet UIView *addressView;
@property (weak, nonatomic) IBOutlet UIView *radiusView;


@property(strong,nonatomic) NSDictionary *RegisteredObject;
@property(strong,nonatomic) NSDictionary *EditRegisted;


@property(weak,nonatomic) IBOutlet UIView *toolBarView;
@property (weak,nonatomic)  IBOutlet UIButton *btnRegister;

-(IBAction)selectCategory:(id)sender;
-(IBAction)seletcRadius:(id)sender;
-(IBAction)selectlocation:(id)sender;

@property(strong,nonatomic) UITableView *categoryTable;

@property(strong,nonatomic)IBOutlet UIButton *categoryBtn;
@property (weak,nonatomic) IBOutlet UITextField *addressField;
@property(weak,nonatomic)IBOutlet UIButton *radiusBtn;

@property (weak,nonatomic) IBOutlet UISwitch *notificationSwitch;

@property(weak,nonatomic) IBOutlet UIButton *cameraBtn;




@end
