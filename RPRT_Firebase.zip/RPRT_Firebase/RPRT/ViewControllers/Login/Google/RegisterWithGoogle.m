//
//  RegisterWithGoogle.m
//  RPRT
//
//  Created by sravanthi Gumma on 16/09/16.
//  Copyright © 2016 DevpointSolutions. All rights reserved.
//

#import "RegisterWithGoogle.h"
#import "Post_Food.h"
#import "Web_Services.h"
#import "Setting_Cell.h"
#import "Setting_Maps.h"
@interface RegisterWithGoogle ()<UIImagePickerControllerDelegate,UINavigationControllerDelegate,UITableViewDelegate,UITableViewDataSource,CustomIOSAlertViewDelegate,CustomIOSAlertViewDelegate,UISearchBarDelegate,UITextFieldDelegate>
{
    Web_Services *mWebService;
    UIView *contentView;
    NSUserDefaults *mPref;
    NSString *UserRegistedID;
    UITableView *autoComplete;
    NSArray *userTypes;
    NSDictionary *SelectedType;
    CustomIOSAlertView *categoryAlert;
    
    NSArray *categoryItems;
    BOOL isMultipleSelection;
    NSArray *radiusItems;
    UITableView *radTable;
    NSString *selectedRadius;
    NSDictionary *selectedCategories;
    NSString *UserSettingsID;
    GeoCodeLocation *geoCode;
    NSString *latLong;
    
    UITableView *autocompleAddressTable;
    NSMutableArray  *autocompleAddress;
    NSMutableArray *checkedCateIds;
    NSMutableArray *finalCheckedarry;
    
    
    CustomIOSAlertView *offertypeAlert;
    UISearchBar *offerTypeSearch;
    BOOL isSearching;
    NSString *LoginType;
    
}
@property(strong ,nonatomic)  NSMutableArray *checkedArray;


@end

@implementation RegisterWithGoogle

@synthesize RegistationView,UserNameView,EmailView,MobileNumberView;
@synthesize uName,emailID,mobileNumber,regUserImgView,toolBarView,btnRegister;

- (void)viewDidLoad {
    @try {
        
        [super viewDidLoad];
        
        
//        Reachability *networkReachability = [Reachability reachabilityForInternetConnection];
//        NetworkStatus networkStatus = [networkReachability currentReachabilityStatus];
//        if (networkStatus == NotReachable) {
//            
//            isOnlineStatus = NO;
//            
//        } else  if (networkStatus == ReachableViaWiFi) {
//            
//            isOnlineStatus = YES;
//        }
//        else if (networkStatus == ReachableViaWWAN) {
//            isOnlineStatus = YES;
//            
//        }
        
        if (isOnlineStatus) {
            
            
            
            UserRegistedID= @"0";
            
            mWebService = [Web_Services GetSharedInstance];
            mPref = [NSUserDefaults standardUserDefaults];
             self.checkedArray = [[NSMutableArray alloc]init];
            checkedCateIds = [[NSMutableArray alloc]init];
            finalCheckedarry = [[NSMutableArray alloc]init];
            encodecImage = @"";
            selectedRadius = @"";
            UserSettingsID = @"0";
            latLong= @"";
            LoginType= @"";
            
            NSString *path = [[NSBundle mainBundle] pathForResource:CATEGORY ofType:@"plist"];
            NSMutableDictionary *dict = [NSMutableDictionary dictionaryWithContentsOfFile:path];
            categoryItems = [dict valueForKey:@"Categories"];
            
            radiusItems = [dict valueForKey:@"Radious"];
            
           // [self setImageFrameCliekEvent];
            
            
             userTypes = [self getuserType];
            
            self.typelbl.text =[NSString stringWithFormat:@"%@",[[userTypes objectAtIndex:0] valueForKey:@"LookupValue"]];
            SelectedType = [userTypes objectAtIndex:0];
            
            self.contactpersonView.hidden = YES;
            
            //autocompleAddressTable =
            
            autocompleAddressTable = [[UITableView alloc] initWithFrame:
                                      CGRectMake(10, 200, 320, 150) style:UITableViewStylePlain];
            autocompleAddressTable.delegate = self;
            autocompleAddressTable.dataSource = self;
            //autoComplete.layer.borderWidth = 1.0;
            //autoComplete.layer.borderColor= [UIColor lightGrayColor].CGColor;
            autocompleAddressTable.scrollEnabled = YES;
            autocompleAddressTable.hidden = YES;
            [self.view addSubview:autocompleAddressTable];
            
            
            self.categoryTable = [[UITableView alloc]init];
            
            self.categoryTable.layer.borderColor = [UIColor colorWithRed:198.0/256.0 green:198.0/256.0 blue:198.0/256.0 alpha:1].CGColor;
            
            self.categoryTable.delegate= self;
            self.categoryTable.dataSource = self;
           
            
            radTable = [[UITableView alloc] init];//initWithFrame:CGRectMake(self.radiusBtn.frame.origin.x, self.radiusBtn.frame.origin.y+40, self.radiusBtn.frame.size.width, 200) style:UITableViewStylePlain];
            radTable.layer.borderColor = [UIColor colorWithRed:198.0/256.0 green:198.0/256.0 blue:198.0/256.0 alpha:1].CGColor;
            radTable.delegate = self;
            radTable.dataSource = self;
           // [radTable setHidden:YES];
            //[self.Contentview addSubview:radTable];
            
            
            
            // [self loadToolbar];
            CALayer *border = [CALayer layer];
            CGFloat borderWidth = 1;
            border.borderColor = [UIColor lightGrayColor].CGColor;
            border.borderWidth = borderWidth;//
            
            
            ///////self.RegistationView.layer.borderWidth = 1.0f;
            // self.RegistationView.layer.borderColor = [UIColor lightGrayColor].CGColor;
            
            
            [self setBorderToTextBox:UserNameView];
            [self setBorderToTextBox:EmailView];
            [self setBorderToTextBox:self.contactpersonView];
            [self setBorderToTextBox:RegistationView];
            [self setBorderToTextBox:self.NotificationView];
            [self setBorderToTextBox:self.addressView];
            [self setBorderToTextBox:self.radiusView];
            [self setBorderToTextBox:MobileNumberView];
            
            CALayer *borders = [CALayer layer];
            
            borders.borderColor = [UIColor colorWithRed:198.0/256.0 green:198.0/256.0 blue:198.0/256.0 alpha:1].CGColor;

            
            borders.frame = CGRectMake(-borderWidth, -borderWidth, self.categoryBtn.frame.size.width+borderWidth, self.categoryBtn.frame.size.height);
            borders.borderWidth = borderWidth;
            //border.cornerRadius = 8.f;
            [self.categoryBtn.layer addSublayer:borders];
            self.categoryBtn.layer.masksToBounds = YES;
            
            
            GeoCodeLocation *geocode = [GeoCodeLocation GetSharedInstance];
            
            self.addressField.text = [NSString stringWithFormat:@"%@,%@",geocode.Address1,geocode.AreaName];
            latLong=[NSString stringWithFormat:@"%@,%@",geocode.Latitude,geocode.Longitude];
            
            
            editedDetils = self.EditRegisted;
            
            if(editedDetils!=nil)
            {
                [self EditRegistedDetils];
            }
            
            if (RegisterdObj ==nil) {
                RegisterdObj = editedDetils;
            }

            
            if (checkedCateIds==nil)  {
                NSString *srt = [NSString stringWithFormat:@"33,34,36,37,38,39,40,41,42,43"];
                checkedCateIds = [[srt componentsSeparatedByString:@","] mutableCopy];
            }
            
        }
        else if (isOnlineStatus)
        {
            [self showAlertPop:@"the Network is down" expObj:nil];
        }
        
        
        [[NSNotificationCenter defaultCenter]
         addObserver:self
         selector:@selector(ToRegister:)
         name:@"ToRegister"
         object:nil];
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
}

-(void)EditRegistedDetils
{
    @try {
        
        
        NSString *userRedistedID = [mPref valueForKey:USERREGISTERID];
        
        
        [self setUserSetings:userRedistedID];
        
        NSDictionary *userProfile =[mWebService GetUsersRegisterBYID:userRedistedID];
        NSLog(@"%@",userProfile);
        
        uName.text = [userProfile valueForKey:@"RegUserName"];
        mobileNumber.text = [userProfile valueForKey:@"PhoneNo"];
        emailID.text = [userProfile valueForKey:@"RegEmail"];
        UserRegistedID =userRedistedID;
        self.addressField.text = [editedDetils valueForKey:@"DefaultAddress"];
        LoginType = [editedDetils valueForKey:@"LoginType"];
         
       // NSString *usertypename = [editedDetils valueForKey:@"LoggedUserType"];
        
        self.conatctPersonName.text = [editedDetils valueForKey:@"ContactPerson"];
        
        [btnRegister setTitle:@"UPDATE PROFILE" forState:UIControlStateNormal];
        btnRegister.titleLabel.font=[UIFont fontWithName:@"Roboto-Medium" size:15.0];
         [self.cameraBtn setImage:[UIImage imageNamed:@"Edit_photo.png"] forState:UIControlStateNormal];
        
        NSString *ImageURL = [NSString stringWithFormat:@"%@%@",baseImageURL, [userProfile valueForKey:@"PhotoName"]];
        if (![[userProfile valueForKey:@"PhotoName"] isKindOfClass:[NSNull class]]) {
            NSArray *imaArray = [ImageURL componentsSeparatedByString:@","];
            
            
            NSURL *imageURL = [NSURL URLWithString:[imaArray objectAtIndex:0]];
            NSString *key = [ImageURL MD5Hash];
            NSData *getData = [FTWCache objectForKey:key];
            regUserImgView.layer.cornerRadius = regUserImgView.frame.size.width/2;
            regUserImgView.layer.borderWidth = 3.0f;
            regUserImgView.layer.borderColor =[UIColor blueColor].CGColor;
            regUserImgView.clipsToBounds= YES;
            
            UIImage *image;
            if (getData) {
                image = [UIImage imageWithData:getData];
                regUserImgView.image  = image;
                encodecImage  =  [getData base64EncodedStringWithOptions:0];
            }
            else {
                regUserImgView.image  = [UIImage imageNamed:@"img_def"];
                dispatch_queue_t queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_HIGH, 0ul);
                dispatch_async(queue, ^{
                    NSData *newData = [NSData dataWithContentsOfURL:imageURL];
                    [FTWCache setObject:newData forKey:key];
                    UIImage  *image = [UIImage imageWithData:newData];
                    dispatch_sync(dispatch_get_main_queue(), ^{
                        regUserImgView.image  = image;
                        
                    });
                    encodecImage  =  [getData base64EncodedStringWithOptions:0];
                });
            }
        }
        
        
        
        
        
        //    UserId = 62;
        //    UserRegisterID = 104;
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
    
}

-(BOOL) textFieldShouldReturn:(UITextField *)textField{
    
    [textField resignFirstResponder];
     [self animateTextField:textField up:NO];
    return YES;
}



-(void)setUserSetings:(NSString*)userRegisterID
{
    @try {
        
  
    NSString *regID = [editedDetils valueForKey:@"IndividualRegisterID"];
    if (regID==nil) {
        regID = userRegisterID;
    }
    
    NSDictionary *getUserSettingsreponse = [mWebService GetUserSettings:regID];
        
        if (getUserSettingsreponse!=nil) {
            selectedRadius =[NSString stringWithFormat:@"%@",[getUserSettingsreponse valueForKey:@"DefaultRadius"]];
            UserSettingsID = [NSString stringWithFormat:@"%@",[getUserSettingsreponse valueForKey:@"UserSettingsID"]];
            self.addressField.text = [getUserSettingsreponse valueForKey:@"DefaultAddress"];
            latLong =[NSString stringWithFormat:@"%@",[getUserSettingsreponse valueForKey:@"LatLong"]];
            
            checkedCateIds = [[[getUserSettingsreponse valueForKey:@"NotifyCategories"] componentsSeparatedByString:@","] mutableCopy];
            finalCheckedarry= checkedCateIds;
            [self.radiusBtn setTitle:[NSString stringWithFormat:@"%@",selectedRadius] forState:UIControlStateNormal];
            
            [self.categoryBtn setTitle:[self selectedCategoryname:checkedCateIds] forState:UIControlStateNormal];
            
            [self.radiusBtn setTitle:[self selectedRadius:selectedRadius] forState:UIControlStateNormal];

        }
        
      } @catch (NSException *exception) {
           [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
    
}

-(void)loadRegistrationDetails:(NSDictionary*)registedObj
{
    
    uName.text = [registedObj valueForKey:@"FullName"];
    emailID.text = [registedObj valueForKey:@"EmailID"];
    
    //NSString *usertypename = [registedObj valueForKey:@"LoggedUserType"];
    
    //self.conatctPersonName.text = [editedDetils valueForKey:@"ContactPerson"];
    LoginType = [registedObj valueForKey:@"LoginType"];
    
//    for (int i=0; i<[userTypes count]; i++) {
//        if ([[[userTypes objectAtIndex:i] valueForKey:@"LookupValue"] isEqualToString:usertypename]) {
//            SelectedType = [userTypes objectAtIndex:i];
//            self.typelbl.text = usertypename;
//            
//        }
//    }
//    
//    if ([[SelectedType valueForKey:@"LookupValue"] isEqualToString:@"Individual"]) {
//        [self.contactpersonView setHidden:YES];
//        
//    }
//    else
//    {
//        [self.contactpersonView setHidden:NO];
//    }
    
    
    
if([registedObj valueForKey:@"ImageUrl"])
{
    [self.cameraBtn setImage:[UIImage imageNamed:@"Edit_photo.png"] forState:UIControlStateNormal];
    NSURL *imageURL = [NSURL URLWithString:[registedObj valueForKey:@"ImageUrl"]];
    NSString *key = [[registedObj valueForKey:@"ImageUrl"] MD5Hash];
    NSData *getData = [FTWCache objectForKey:key];
    regUserImgView.layer.cornerRadius = regUserImgView.frame.size.width/2;
    regUserImgView.layer.borderWidth = 3.0f;
    regUserImgView.layer.borderColor =[UIColor blueColor].CGColor;
    regUserImgView.clipsToBounds= YES;
    
    UIImage *image;
    if (getData) {
        image = [UIImage imageWithData:getData];
        regUserImgView.image  = image;
        
        //UIImage *image = [UIImage imageNamed:@"imageName.png"];
        NSData *imageData = [NSData dataWithData:UIImagePNGRepresentation(image)];
        encodecImage  =  [imageData base64EncodedStringWithOptions:0];
    }
    else {
        regUserImgView.image  = [UIImage imageNamed:@"img_def"];
        dispatch_queue_t queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_HIGH, 0ul);
        dispatch_async(queue, ^{
            NSData *newData = [NSData dataWithContentsOfURL:imageURL];
            [FTWCache setObject:newData forKey:key];
            UIImage  *image = [UIImage imageWithData:newData];
            dispatch_sync(dispatch_get_main_queue(), ^{
                regUserImgView.image  = image;
                NSData *imageData = [NSData dataWithData:UIImagePNGRepresentation(image)];
                encodecImage  =  [imageData base64EncodedStringWithOptions:0];
                
            });
           // encodecImage  =  [getData base64EncodedStringWithOptions:0];
        });
    }
    
}
    
     [self getuserType];
    
}

-(NSArray*)getuserType
{
    
    return [mWebService UserTypes];
}

-(void)RegisteredDetails
{
    @try {
        
        
        NSString *userRedistedID = [mPref valueForKey:USERREGISTERID];
        
        NSDictionary *userProfile =[mWebService GetUsersRegisterBYID:userRedistedID];
        
        
        
        uName.text = [userProfile valueForKey:@"RegUserName"];
        mobileNumber.text = [userProfile valueForKey:@"PhoneNo"];
       
        emailID.text = [userProfile valueForKey:@"RegEmail"];
        
        LoginType = [userProfile valueForKey:@"LoginType"];
        
        UserRegistedID = [userProfile valueForKey:USERREGISTERID];
        uName.enabled= NO;
        [btnRegister setTitle:@"UPDATE PROFILE" forState:UIControlStateNormal];
        btnRegister.titleLabel.font=[UIFont fontWithName:@"Roboto-Medium" size:15.0];
         [self.cameraBtn setImage:[UIImage imageNamed:@"Edit_photo.png"] forState:UIControlStateNormal];
        NSString *ImageURL = [NSString stringWithFormat:@"%@%@",baseImageURL, [userProfile valueForKey:@"PhotoName"]];
        
        NSURL *imageURL = [NSURL URLWithString:ImageURL];
        NSString *key = [ImageURL MD5Hash];
        NSData *getData = [FTWCache objectForKey:key];
        regUserImgView.layer.cornerRadius = regUserImgView.frame.size.width/2;
        regUserImgView.layer.borderWidth = 3.0f;
        regUserImgView.layer.borderColor =[UIColor blueColor].CGColor;
        regUserImgView.clipsToBounds= YES;
        
        UIImage *image;
        if (getData) {
            image = [UIImage imageWithData:getData];
            regUserImgView.image  = image;
         //   UIImage *image = [UIImage imageNamed:@"imageName.png"];
            NSData *imageData = [NSData dataWithData:UIImagePNGRepresentation(image)];
            
            encodecImage  =  [imageData base64EncodedStringWithOptions:0];
        }
        else {
            regUserImgView.image  = [UIImage imageNamed:@"img_def"];
            NSData *imageData = [NSData dataWithData:UIImagePNGRepresentation([UIImage imageNamed:@"img_def"])];
            encodecImage  =  [imageData base64EncodedStringWithOptions:0];
            dispatch_queue_t queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_HIGH, 0ul);
            dispatch_async(queue, ^{
                NSData *newData = [NSData dataWithContentsOfURL:imageURL];
                [FTWCache setObject:newData forKey:key];
                UIImage  *image = [UIImage imageWithData:newData];
                dispatch_sync(dispatch_get_main_queue(), ^{
                    regUserImgView.image  = image;
                    NSData *imageData = [NSData dataWithData:UIImagePNGRepresentation(image)];
                   
                    encodecImage  =  [imageData base64EncodedStringWithOptions:0];
                });
                //encodecImage  =  [getData base64EncodedStringWithOptions:0];
            });
        }
        
        
        
        //    UserId = 62;
        //    UserRegisterID = 104;
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
    
}

- (void) setBorderToTextBox:(UIView*)textBoxFeildName {
    @try {
        
        textBoxFeildName.layer.borderColor = [UIColor colorWithRed:198.0/256.0 green:198.0/256.0 blue:198.0/256.0 alpha:1].CGColor;
        textBoxFeildName.layer.borderWidth=1;
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
}

- (void)hideKeyboard {
    @try {
        
        [uName resignFirstResponder];
       
        [emailID resignFirstResponder];
        [mobileNumber resignFirstResponder];
        [mobileNumber resignFirstResponder];
        [self.conatctPersonName resignFirstResponder];
       
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
}

- (IBAction)hideKeyBoardConatctPerson:(id)sender {
    @try {
        
        
//                if (![self validEmail:emailID.text]) {
//                    [emailID resignFirstResponder];
//                }
        
        
        [self.conatctPersonName resignFirstResponder];
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    }
}
- (IBAction)hideKeyBoardaddresstext:(id)sender {
    @try {
        
       // [self.addressField resignFirstResponder];
        
        [autocompleAddressTable setHidden:YES];
        
        [autocompleAddressTable setHidden:YES];
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    }
}

- (IBAction)hideKeyBoardMobileNumber:(id)sender {
    @try {
        
        
        //        if (![self validEmail:emailID.text]) {
        //            [emailID resignFirstResponder];
        //        }
        
        
        [mobileNumber resignFirstResponder];
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    }
}

- (BOOL)validMobileNumber:(NSString *)mobilenumber {
    
    @try {
        
        NSString *phoneRegex = @"^((\\+)|(00))[0-9]{6,14}$";
        NSPredicate *phoneTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", phoneRegex];
        
        return [phoneTest evaluateWithObject:mobilenumber];
        
        
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    }
}

- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField {
    //[self myMethod];
    
   // autoComplete.hidden=YES;
    
    if (textField == self.typelbl) {
        
        [textField resignFirstResponder];
        [self getOffertype];
        autoComplete.hidden=NO;
        [autoComplete reloadData];
        return NO;
        
    }
    
    
    else if (textField == self.conatctPersonName)
    {
         [textField resignFirstResponder];
        return YES;
    }
    
    else if (textField == self.addressField)
    {
        [textField resignFirstResponder];
        return YES;
    }
    
    return YES;
    
   // return YES;
}

- (IBAction)textFieldDidBeginEditing:(id)textField {
    @try {
        
        [self animateTextField:textField up:YES];
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
}

- (IBAction)textFieldDidEndEditing:(id)textField {
    @try {
        
        [self animateTextField:textField up:NO];
        
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
}

- (void)animateTextField:(UITextField *)textField up:(BOOL)up {
    @try {
        
            
//            int animatedDistance;
//            //int moveUpValue = textField.frame.origin.y + textField.frame.size.height;
//            UIInterfaceOrientation orientation =
//            [[UIApplication sharedApplication] statusBarOrientation];
//            if (orientation == UIInterfaceOrientationPortrait ||
//                orientation == UIInterfaceOrientationPortraitUpsideDown) {
//                
//                if (textField== self.conatctPersonName || textField== self.conatctPersonName || textField== self.addressField) animatedDistance = 280 - (250 - 120 - 5);
//                
//               else  animatedDistance = 280 - (250 - 70 - 5);
//            } else {
//                
//                if (textField== self.conatctPersonName || textField== self.conatctPersonName || textField== self.addressField) animatedDistance = 162 - (320 - 80 - 5);
//
//              else  animatedDistance = 162 - (320 - 70 - 5);
//            }
//            
//            if (animatedDistance > 0) {
//                NSString *deviceType = [[UIDevice currentDevice] model];
//                
//                if ([deviceType isEqualToString:@"iPad"]) {
//                }
//                
//                const int movementDistance = animatedDistance;
//                const float movementDuration = 0.3f;
//                int movement = (up ? -movementDistance : movementDistance);
//                [UIView beginAnimations:nil context:nil];
//                [UIView setAnimationBeginsFromCurrentState:YES];
//                [UIView setAnimationDuration:movementDuration];
//                self.Contentview.frame = CGRectOffset(self.Contentview.frame, 0, movement);
//                [UIView commitAnimations];
//            }
//        

        int animatedDistance;
        //int moveUpValue = textField.frame.origin.y + textField.frame.size.height;
        UIInterfaceOrientation orientation =
        [[UIApplication sharedApplication] statusBarOrientation];
        if (orientation == UIInterfaceOrientationPortrait ||
            orientation == UIInterfaceOrientationPortraitUpsideDown) {
            
            if (up) {
                
                if (textField== self.conatctPersonName  || textField == self.addressField) animatedDistance=200;
                
                else
                    animatedDistance=280 - (250 - 50 - 5);
            }
            else
            {
                if (textField== self.conatctPersonName  || textField == self.addressField) animatedDistance=-150;
                else
                    animatedDistance = 162 - (320 - 80 - 5);
            }
            
            //            if (textField== self.conatctPersonName || textField == confirmPassword || textField == self.addressField)  animatedDistance = 280 - (250 - 200 - 5);
            
            //animatedDistance = 280 - (250 - 50 - 5);
        } else {
            //            if (textField== self.conatctPersonName|| textField == confirmPassword || self.addressField)  animatedDistance = 162 - (320 - 80 - 5);
            animatedDistance = 162 - (320 - 50 - 5);
        }
        
        if (animatedDistance > 0) {
            NSString *deviceType = [[UIDevice currentDevice] model];
            
            if ([deviceType isEqualToString:@"iPad"]) {
            }
            
            const int movementDistance = animatedDistance;
            const float movementDuration = 0.3f;
            int movement = (up ? -movementDistance : movementDistance);
            [UIView beginAnimations:nil context:nil];
            [UIView setAnimationBeginsFromCurrentState:YES];
            [UIView setAnimationDuration:movementDuration];
            self.Contentview.frame = CGRectOffset(self.Contentview.frame, 0, movement);
            [UIView commitAnimations];
        }
        
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    }
}



- (BOOL)touchesShouldBegin:(NSSet *)touches withEvent:(UIEvent *)event inContentView:(UIView *)view {
    return true;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event {
    @try {
        
        
        
        
       
         if ([mobileNumber isFirstResponder]) {
            [mobileNumber resignFirstResponder];
            
            if (![self validMobileNumber:mobileNumber.text]) {
                [mobileNumber resignFirstResponder];
                
                //[self showAlertPop:@"Please capture profile photo." expObj:nil];
            }
        }
     
        
        
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    }
}

- (void) viewDidLayoutSubviews {
    @try {
        
        [ super viewDidLayoutSubviews];
        [self.scrollview layoutIfNeeded];
        
        self.scrollview.contentSize=self.Contentview.bounds.size;
        
        UIGraphicsBeginImageContext(self.view.frame.size);
        UIImage *image = UIGraphicsGetImageFromCurrentImageContext();
        UIGraphicsEndImageContext();
        
        self.Contentview.backgroundColor = [UIColor colorWithPatternImage:image];
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
    
}




- (IBAction)createAccount:(id)sender {
    
    
    @try
    {
        
        if (isOnlineStatus) {
            
            if ( [self textfieldValidation]) {
                
                spinner = [[UIActivityIndicatorView alloc]
                           initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
                spinner.frame = CGRectMake(0, 0, 375, 600); // CGPointMake(160, 240);
                spinner.color = [UIColor blueColor];
                spinner.backgroundColor = [UIColor lightTextColor];
                spinner.transform = CGAffineTransformMakeScale(2, 2);
                // spinner.hidesWhenStopped = YES;
                [self.view addSubview:spinner];
                spinner.transform = CGAffineTransformMakeScale(2, 2);
                
                [spinner startAnimating];
                
                // how we stop refresh from freezing the main UI thread
                
                dispatch_async(
                               dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^{
                                   
                                   // back to the main thread for the UI call
                                   dispatch_async(dispatch_get_main_queue(), ^{
                                       [spinner startAnimating];
                                   });
                                   dispatch_async(dispatch_get_main_queue(), ^{
                                       @try {
                                         //  if(![encodecImage isEqualToString:@""])
                                           //{
                                               
                                               //   if ( [self textfieldValidation]) {
                                               
                                             //  if ([self validateRegisteredPhoneNo]) {
                                                   
                                                   
                                                   NSUserDefaults *pref = [NSUserDefaults standardUserDefaults];
                                                   
                                                   NSString *SaveUserID = [pref objectForKey:@"SaveUserID"];
                                           if (SaveUserID==nil) {
                                               SaveUserID= @"0";
                                           }
                                                   UserRegistedID = [pref valueForKey:USERREGISTERID];
                                                   
                                                   if (UserRegistedID !=nil) {
                                                       
                                                   }
                                                   else if (UserRegistedID ==nil) {
                                                       UserRegistedID = @"0";
                                                   }
                                                   
                                                   NSLog(@"name: %@", [[UIDevice currentDevice] name]);
                                                   NSLog(@"systemName: %@", [[UIDevice currentDevice] systemName]);
                                                   NSLog(@"systemVersion: %@", [[UIDevice currentDevice] systemVersion]);
                                                   NSLog(@"model: %@", [[UIDevice currentDevice] model]);
                                                   NSLog(@"localizedModel: %@", [[UIDevice currentDevice] localizedModel]);
                                                    NSString *uniqueIdentifier = [[[UIDevice currentDevice] identifierForVendor] UUIDString];
                                           
                                           if (encodecImage==nil) {
                                               encodecImage= @"";
                                           }
                                                   
                                                   
                                                   NSDictionary *locationInput  = @{@"UserRegisterID":UserRegistedID,
                                                                                    @"UserID":@"0",
                                                                                    @"UserSelectedCat":@"Individual",
                                                                                    @"PhotoName":encodecImage,
                                                                                    @"LandLine":@"",
                                                                                    @"ContactPerson":uName.text,
                                                                                    @"Password":@"",
                                                                                    @"Time":@"60",
                                                                                    @"PhoneNo":mobileNumber.text,
                                                                                    @"RegUserName":uName.text,
                                                                                    @"RegEmail":emailID.text,
                                                                                    @"UserType":@"1",
                                                                                    @"DeviceOS":[[UIDevice currentDevice] model],
                                                                                    @"OsVersion":[[UIDevice currentDevice] systemVersion],
                                                                                    @"LoginType":LoginType,
                                                                                    @"DeviceId" :uniqueIdentifier
                                                                                    };
                                                   
                                                   NSDictionary *data = [mWebService SaveRegister:locationInput];
                                               
                                               NSDictionary *userSettingResponse = [self SaveuserSeetings:data];
                                           
                                           
                                       //    NSDictionary *loginObj;
                                           
                                           NSMutableArray *arryResponse =data;
                                           
                                           NSString *BusinessRegID; NSString *IndividualRegID;
                                           NSMutableDictionary *registerDatavia = [[NSMutableDictionary alloc]init];
                                           
                                           Preferences *mPreferences = [Preferences GetSharedInstance];

                                           
                                           
                                           if ([arryResponse count]==2) {
                                               
                                               
                                               BusinessRegID = [[arryResponse objectAtIndex:1] valueForKey:@"UserRegisterID"];
                                               IndividualRegID =[[arryResponse objectAtIndex:0] valueForKey:@"UserRegisterID"];
                                               
                                               NSDictionary *BusinessRecoed=@{@"StoreDescription":[[arryResponse objectAtIndex:1] valueForKey:@"StoreDescription"],
                                                                              @"ContactPerson":[[arryResponse objectAtIndex:1] valueForKey:@"ContactPerson"],
                                                                              @"BranchName":[[arryResponse objectAtIndex:1] valueForKey:@"BranchName"],
                                                                              @"PhotoName":[[arryResponse objectAtIndex:1] valueForKey:@"PhotoName"]
                                                                              };
                                               NSDictionary *IndividualRecoed=@{@"StoreDescription":[[arryResponse objectAtIndex:1] valueForKey:@"StoreDescription"],
                                                                                @"ContactPerson":[[arryResponse objectAtIndex:1] valueForKey:@"ContactPerson"],
                                                                                @"BranchName":[[arryResponse objectAtIndex:1] valueForKey:@"BranchName"],
                                                                                @"PhotoName":[[arryResponse objectAtIndex:0] valueForKey:@"PhotoName"]
                                                                                };
                                               
                                               
                                               [registerDatavia setValue:BusinessRecoed forKey:@"BusinessDeatils"];
                                               [registerDatavia setValue:IndividualRecoed forKey:@"IndividualDeatils"];

                                               
                                               
                                               
                                               [mPref setValue:@"Business" forKey:LOGINTYPE];
                                               [mPref setValue:BusinessRegID forKey:USERREGISTERID];
                                               [registerDatavia setValue:BusinessRegID forKey:@"UserRegisterID"];
                                               
                                               [registerDatavia setValue:[[arryResponse objectAtIndex:1] valueForKey:@"DefaultRadius"] forKey:@"DefaultRadius"];
                                               [registerDatavia setValue:[[arryResponse objectAtIndex:1] valueForKey:@"PhotoName"] forKey:@"PhotoName"];
                                               [registerDatavia setValue:[[arryResponse objectAtIndex:1] valueForKey:@"DefaultAddress"] forKey:@"DefaultAddress"];
                                               [registerDatavia setValue:[[arryResponse objectAtIndex:1] valueForKey:@"RegUserName"] forKey:@"RegUserName"];
                                               [registerDatavia setValue:[[arryResponse objectAtIndex:1] valueForKey:@"ContactPerson"] forKey:@"ContactPerson"];
                                               [registerDatavia setValue:[[arryResponse objectAtIndex:1] valueForKey:@"BranchName"] forKey:@"BranchName"];
                                               [registerDatavia setValue:[[arryResponse objectAtIndex:1] valueForKey:@"StoreDescription"] forKey:@"StoreDescription"];
                                               [registerDatavia setValue:[[arryResponse objectAtIndex:1] valueForKey:@"LoggedUserType"] forKey:@"LoggedUserType"];
                                               [registerDatavia setValue:[[arryResponse objectAtIndex:1] valueForKey:@"ContactPerson"] forKey:@"ContactPerson"];
                                               
                                               [registerDatavia setValue:[[arryResponse objectAtIndex:1] valueForKey:@"LoginType"] forKey:@"LoginType"];
                                               [registerDatavia setValue:BusinessRegID forKey:USERREGISTERID];
                                               [registerDatavia setValue:[[arryResponse objectAtIndex:1] valueForKey:@"DefaultRadius"] forKey:@"DefaultRadius"];
                                               [registerDatavia setValue:BusinessRegID forKey:@"BusinessRegisterID"];
                                               [registerDatavia setValue:IndividualRegID forKey:@"IndividualRegisterID"];
                                               [registerDatavia setValue:[userSettingResponse valueForKey:@"UserSettingsID"] forKey:@"UserSettingsID"];
                                               
                                               [mPreferences SaveRegisterDeatils:registerDatavia];
                                               
                                               // [mPref setObject:registerDatavia forKey:@"LoginType"];
                                               
                                               UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"Right Place Right Time"
                                                                                                              message:@"Registered Sucessfully!!"
                                                                                                       preferredStyle:UIAlertControllerStyleAlert];
                                               
                                               UIAlertAction* defaultAction = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault
                                                                                                     handler:^(UIAlertAction * action) {
                                                                                                         
                                                                                                         [self pagechangeforPostOffer];
                                                                                                         
                                                                                                         
                                                                                                     }];
                                               
                                               [alert addAction:defaultAction];
                                               
                                               [self presentViewController:alert animated:YES completion:nil];
                                               
                                               
                                           
                                           NSLog(@"SaveRegister responce is %@",data);
                                           
                                               
                                               
                                           }
                                           else
                                           {
                                               if ([arryResponse count]==1) {
                                                   BusinessRegID = @"";
                                               }
                                               else BusinessRegID = [[arryResponse objectAtIndex:1] valueForKey:@"UserRegisterID"];
                                               
                                               IndividualRegID =[[arryResponse objectAtIndex:0] valueForKey:@"UserRegisterID"];
                                               
                                               
//                                               NSDictionary *BusinessRecoed=@{@"StoreDescription":[[arryResponse objectAtIndex:1] valueForKey:@"StoreDescription"],
//                                                                              @"ContactPerson":[[arryResponse objectAtIndex:1] valueForKey:@"ContactPerson"],
//                                                                              @"BranchName":[[arryResponse objectAtIndex:1] valueForKey:@"BranchName"]
//                                                                              };
                                               NSDictionary *IndividualRecoed=@{@"StoreDescription":[[arryResponse objectAtIndex:0] valueForKey:@"StoreDescription"],
                                                                                @"ContactPerson":[[arryResponse objectAtIndex:0] valueForKey:@"ContactPerson"],
                                                                                @"BranchName":[[arryResponse objectAtIndex:0] valueForKey:@"BranchName"],
                                                                     @"PhotoName":[[arryResponse objectAtIndex:0] valueForKey:@"PhotoName"]
                                                                                };
                                               
                                               
                                               [registerDatavia setValue:nil forKey:@"BusinessDeatils"];
                                               [registerDatavia setValue:IndividualRecoed forKey:@"IndividualDeatils"];

                                               
                                               
                                               [mPref setValue:@"Individual" forKey:LOGINTYPE];
                                               [mPref setValue:IndividualRegID forKey:USERREGISTERID];
                                               [registerDatavia setValue:IndividualRegID forKey:@"UserRegisterID"];
                                               
                                               [registerDatavia setValue:[[arryResponse objectAtIndex:0] valueForKey:@"DefaultRadius"] forKey:@"DefaultRadius"];
                                               
                                               [registerDatavia setValue:[[arryResponse objectAtIndex:0] valueForKey:@"PhotoName"] forKey:@"PhotoName"];
                                               [registerDatavia setValue:[[arryResponse objectAtIndex:0] valueForKey:@"DefaultAddress"] forKey:@"DefaultAddress"];
                                               [registerDatavia setValue:[[arryResponse objectAtIndex:0] valueForKey:@"RegUserName"] forKey:@"RegUserName"];
                                               [registerDatavia setValue:[[arryResponse objectAtIndex:0] valueForKey:@"ContactPerson"] forKey:@"ContactPerson"];
                                               [registerDatavia setValue:[[arryResponse objectAtIndex:0] valueForKey:@"BranchName"] forKey:@"BranchName"];
                                               [registerDatavia setValue:[[arryResponse objectAtIndex:0] valueForKey:@"StoreDescription"] forKey:@"StoreDescription"];
                                               [registerDatavia setValue:[[arryResponse objectAtIndex:0] valueForKey:@"LoggedUserType"] forKey:@"LoggedUserType"];
                                               [registerDatavia setValue:[[arryResponse objectAtIndex:0] valueForKey:@"ContactPerson"] forKey:@"ContactPerson"];
                                               [registerDatavia setValue:[[arryResponse objectAtIndex:0] valueForKey:@"LoginType"] forKey:@"LoginType"];
                                               [registerDatavia setValue:BusinessRegID forKey:USERREGISTERID];
                                               [registerDatavia setValue:[[arryResponse objectAtIndex:0] valueForKey:@"DefaultRadius"] forKey:@"DefaultRadius"];
                                               [registerDatavia setValue:BusinessRegID forKey:@"BusinessRegisterID"];
                                               [registerDatavia setValue:IndividualRegID forKey:@"IndividualRegisterID"];
                                               [registerDatavia setValue:[userSettingResponse valueForKey:@"UserSettingsID"] forKey:@"UserSettingsID"];
                                               
                                               [mPreferences SaveRegisterDeatils:registerDatavia];
                                               
                                               // [mPref setObject:registerDatavia forKey:@"LoginType"];
                                               
                                               UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"Right Place Right Time"
                                                                                                              message:@"Registered Sucessfully!!"
                                                                                                       preferredStyle:UIAlertControllerStyleAlert];
                                               
                                               UIAlertAction* defaultAction = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault
                                                                                                     handler:^(UIAlertAction * action) {
                                                                                                         
                                                                                                         [self pagechangeforPostOffer];
                                                                                                         
                                                                                                         
                                                                                                     }];
                                               
                                               [alert addAction:defaultAction];
                                               
                                               [self presentViewController:alert animated:YES completion:nil];
                                               
                                               
                                           
                                           NSLog(@"SaveRegister responce is %@",data);
                                   }
                                           
                                          // }

                                           
                                           
                                           
                                           
                                           
                                           
//                                           if([data valueForKey:USERREGISTERID]!=nil)
//                                                   {
//                                                       
//                                                      // NSMutableArray *arryResponse = data;
//                                                       NSString *BusinessRegID;
//                                                       NSString *IndividualRegID;;
//                                                       
//                                                      
//                                                           IndividualRegID = [data valueForKey:@"UserRegisterID"];
//                                                           
//                                                           NSData  *VendorData =    [mPref valueForKey:@"SaveRegisterDetails"];
//                                                           NSDictionary *myDictionary =   (NSDictionary*) [NSKeyedUnarchiver unarchiveObjectWithData:VendorData];
//                                                           
//                                                           if(myDictionary ==nil && [myDictionary valueForKey:@"BusinessRegisterID"]==nil)
//                                                           {
//                                                               BusinessRegID =nil;
//                                                           }
//                                                           else
//                                                           BusinessRegID = [myDictionary valueForKey:@"BusinessRegisterID"];
//                                                       
//                                                       
//                                                       NSMutableDictionary *registerDatavia = [[NSMutableDictionary alloc]init];
//                                                       [registerDatavia setValue:[data valueForKey:@"LoginType"] forKey:@"LoginType"];
//                                                       [registerDatavia setValue:IndividualRegID forKey:USERREGISTERID];
//                                                       [registerDatavia setValue:[data valueForKey:@"DefaultRadius"] forKey:@"DefaultRadius"];
//                                                       
//                                                       [registerDatavia setValue:BusinessRegID forKey:@"BusinessRegisterID"];
//                                                       [registerDatavia setValue:IndividualRegID forKey:@"IndividualRegisterID"];
//                                                       [registerDatavia setValue:[data valueForKey:@"PhotoName"] forKey:@"PhotoName"];
//                                                       //[registerDatavia setValue: forKey:@"PhotoName"];
//                                                       [registerDatavia setValue:[data valueForKey:@"DefaultAddress"] forKey:@"DefaultAddress"];
//                                                       [registerDatavia setValue:[data valueForKey:@"RegUserName"] forKey:@"RegUserName"];
//                                                       [registerDatavia setValue:[data valueForKey:@"LoggedUserType"] forKey:@"LoggedUserType"];
//                                                       [registerDatavia setValue:[myDictionary valueForKey:@"ContactPerson"] forKey:@"ContactPerson"];
//                                                       [registerDatavia setValue:[myDictionary valueForKey:@"BranchName"] forKey:@"BranchName"];
//                                                       [registerDatavia setValue:[myDictionary valueForKey:@"StoreDescription"] forKey:@"StoreDescription"];
//                                                       [registerDatavia setValue:[userSettingResponse valueForKey:@"UserSettingsID"] forKey:@"UserSettingsID"];
//
//                            
//                                                       
//                                                       
//                                                       [mPreferences SaveRegisterDeatils:registerDatavia];
//                                                       
//                                                       [mPref setObject:registerDatavia forKey:@"LoginType"];
//                                                       
//                                                     //  Preferences *mPreferences = [Preferences GetSharedInstance];
//                                                       NSString *UserRegisterID  = [data valueForKey:USERREGISTERID];
//                                                       [mPreferences StoreSaveUserRegisterID:UserRegisterID];
//                                                      
//                                                       UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"Right Place Right Time"
//                                                                                                                      message:@"Registered Sucessfully!!"
//                                                                                                               preferredStyle:UIAlertControllerStyleAlert];
//                                                       
//                                                       UIAlertAction* defaultAction = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault
//                                                                                                             handler:^(UIAlertAction * action) {
//                                                                                                                 
//                                                                                                                 [self pagechangeforPostOffer];
//
//                                                                                                                 
//                                                                                                             }];
//                                                       
//                                                       [alert addAction:defaultAction];
//                                                       
//                                                       [self presentViewController:alert animated:YES completion:nil];
//                                                       
//                                                      
//                                                   }
//                                                   NSLog(@"SaveRegister responce is %@",data);
                                                  
                                                   
                                               //}
                                               // }
                                               
//                                           }
//                                           else{
//                                               
//                                               [self showAlertPop:@"Please capture profile photo." expObj:nil];
//                                               
//                                               
//                                           }
                                       } @catch (NSException *exception) {
                                           [self showAlertPop:@"Error while fetching data." expObj:exception];
                                           
                                       } @finally {
                                           
                                       }
                                       
                                       [spinner stopAnimating];
                                       
                                   });
                               });
            }
        }
        else if (isOnlineStatus)
        {
            [self showAlertPop:@"the Network is down" expObj:nil];
        }
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
    
}

-(BOOL)textfieldValidation
{
    @try {
        
         if (![emailID.text isEqualToString:@""]) {
            

        }
        
        if ([mobileNumber.text isEqualToString:@""]) {
            [self showAlertPop:@"please enter MobileNumber" expObj:nil];
            return NO;
        }
        
        else  if ([mobileNumber.text length] != 10 ) {
            [mobileNumber resignFirstResponder];
            
            [self showAlertPop:@"Invalid Phone OR enter 10 no. only." expObj:nil];
            return NO;
        }
        
        if([checkedCateIds count]==0)
        {
            [self showAlertPop:@"Select Atleast one category" expObj:nil];
            return NO;
        }
        
        if ([selectedRadius isEqualToString:@""]) {
            [self showAlertPop:@"Select radius" expObj:nil];
            return NO;
        }
        
        if ([self.addressField.text isEqualToString:@""]) {
            [self showAlertPop:@"Select address" expObj:nil];
            return NO;
        }
        
        if([checkedCateIds count]==0)
        {
            [self showAlertPop:@"Select Atleast one category" expObj:nil];
            return NO;
        }
        return YES;
        
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
    
}

- (void) showAlertPop:(NSString*)alertText  expObj:(NSException*) exp{
    if(exp != nil)
    {
        NSLog(@"%@", exp.description);
    }
    NSLog(@"The Exception is %@",exp.description);
    UIAlertController *myAlertController =[mWebService  alert:alertText];
    [self presentViewController:myAlertController animated:YES completion:nil];
}

-(void)setImageFrameCliekEvent
{
    @try {
        
        UITapGestureRecognizer *imagetap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(takePhoto)];
        imagetap.numberOfTapsRequired = 1;
        [regUserImgView setUserInteractionEnabled:YES];
        [regUserImgView addGestureRecognizer:imagetap];
        //[regUserImgView addGestureRecognizer:letterTapRecognizer];
        
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
    
}

- (IBAction)takePhoto:(id)sender {
    @try {
        
        UIAlertController * view=   [UIAlertController
                                     alertControllerWithTitle:@"Right Place Right Time"
                                     message:nil
                                     preferredStyle:UIAlertControllerStyleActionSheet];
        
        UIAlertAction* photo = [UIAlertAction
                                actionWithTitle:@"Take Photo"
                                style:UIAlertActionStyleDefault
                                handler:^(UIAlertAction * action)
                                {
                                    //Do some thing here
                                    [view dismissViewControllerAnimated:YES completion:nil];
                                    
                                    UIImagePickerController *picker = [[UIImagePickerController alloc] init];
                                    picker.delegate = self;
                                    picker.allowsEditing = YES;
                                    picker.sourceType = UIImagePickerControllerSourceTypeCamera;
                                    
                                    [self presentViewController:picker animated:YES completion:NULL];
                                    
                                    
                                    
                                }];
        UIAlertAction* gallery = [UIAlertAction
                                  actionWithTitle:@"Chose from Gallery"
                                  style:UIAlertActionStyleDefault
                                  handler:^(UIAlertAction * action)
                                  {
                                      UIImagePickerController *picker = [[UIImagePickerController alloc] init];
                                      picker.delegate = self;
                                      picker.allowsEditing = YES;
                                      picker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
                                      
                                      [self presentViewController:picker animated:YES completion:NULL];
                                      
                                      
                                      
                                      [view dismissViewControllerAnimated:YES completion:nil];
                                      
                                  }];
        
        UIAlertAction* cancel = [UIAlertAction
                                 actionWithTitle:@"Cancel"
                                 style:UIAlertActionStyleDefault
                                 handler:^(UIAlertAction * action)
                                 {
                                     [view dismissViewControllerAnimated:YES completion:nil];
                                     
                                 }];
        
        
        
        [view addAction:photo];
        [view addAction:gallery];
        [view addAction:cancel];
        [self presentViewController:view animated:YES completion:nil];
        
        
        
        
        //    UIImagePickerController *picker = [[UIImagePickerController alloc] init];
        //    picker.delegate = self;
        //    picker.allowsEditing = YES;
        //    picker.sourceType = UIImagePickerControllerSourceTypeCamera;
        //
        //    [self presentViewController:picker animated:YES completion:NULL];
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
}

- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info {
    @try {
        
        [self.cameraBtn setImage:[UIImage imageNamed:@"Edit_photo.png"] forState:UIControlStateNormal];
        
        UIImage *chosenImage = info[UIImagePickerControllerEditedImage];
        regUserImgView.layer.cornerRadius = regUserImgView.frame.size.width/2;
        regUserImgView.layer.borderWidth = 3.0f;
        regUserImgView.layer.borderColor =[UIColor blueColor].CGColor;
        regUserImgView.clipsToBounds= YES;
        regUserImgView.image = chosenImage;
        
        
        NSData *data = UIImagePNGRepresentation(chosenImage);
        encodecImage  =  [data base64EncodedStringWithOptions:0];
        
        
        [self.Contentview addSubview:regUserImgView];
        [picker dismissViewControllerAnimated:YES completion:NULL];
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
}

- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker {
    @try {
        
        [picker dismissViewControllerAnimated:YES completion:NULL];
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
    
}

-(IBAction)Back:(id)sender
{
    @try
    {
        
        [uName resignFirstResponder];
     
        [emailID resignFirstResponder];
        [mobileNumber resignFirstResponder];
        
        
        //  [self dismissModalViewControllerAnimated:NO];
        [self dismissViewControllerAnimated:YES completion:NULL];
        
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
}


#pragma mark - Toolbarbuttons

-(void)pagechangeforPostOffer
{
    @try {
        //[mPref setValue:HHOME forKey:@"SideMenu"];
        Home * mHome = [[ Home alloc] initWithNibName:HOMEDASHBOARD bundle:nil];
        [self presentViewController:mHome animated:YES completion:nil];
        
    }
    @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    }
    @finally {
        
    }
}

-(void)StoreRadios:(NSString*)rad
{
    @try {
        [[Preferences GetSharedInstance]StoreRadious:rad];
        Opportunity_List_New * mOpportunity_list = [[ Opportunity_List_New alloc] initWithNibName:OPPORTUNITYLISTNEW bundle:nil];
        [self presentViewController:mOpportunity_list animated:YES completion:nil];
    }
    @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    }
    @finally {
        
    }
}


-(BOOL)validateRegisteredEmail
{
    @try {
        
        if (isOnlineStatus) {
            
            if ([UserRegistedID isEqualToString: @"0"]) {
                
                
                NSDictionary *response = [mWebService CheckEmail:emailID.text];
                if (response!=nil) {
                    NSString *email = [response valueForKey:@"RegEmail"];
                    if ([email isEqualToString:@"Test"]) {
                        return YES;
                    }
                    else
                        return NO;
                    
                }
            }
            else
            {
                
                NSDictionary *response = [mWebService CheckEmail:emailID.text];
                if (response!=nil) {
                    NSString *email = [response valueForKey:@"RegEmail"];
                    
                    if ([email isEqualToString:emailID.text]) {
                        
                        return YES;
                    }
                    
                    else if (![email isEqualToString:emailID.text])
                    {
                        if ([email isEqualToString:@"Test"]) {
                            return YES;
                        }
                        else
                            return NO;
                    }
                    
                    
                    
                }
            }
        }
        
        else if (isOnlineStatus)
        {
            [self showAlertPop:@"the Network is down" expObj:nil];
        }
        
        
        
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
        
    } @finally {
        
    }
}

-(BOOL)validateRegisteredPhoneNo
{
    @try {
        
        if (isOnlineStatus) {
            
            if ([UserRegistedID isEqualToString: @"0"]) {
                
                NSDictionary *response = [mWebService checkPhoneNo:mobileNumber.text];
                if (response!=nil) {
                    
                    NSString *phone = [response valueForKey:@"PhoneNo"];
                    
                    if ([phone isEqualToString:@"Test"]) {
                        return YES;
                    }
                    else
                        return NO;
                    
                }
            }
            
            else
            {
                
                NSDictionary *response = [mWebService checkPhoneNo:mobileNumber.text];
                if (response!=nil) {
                    
                    NSString *phone = [response valueForKey:@"PhoneNo"];
                    
                    if ([mobileNumber.text isEqualToString:phone]) {
                        
                        
                        if ([phone isEqualToString:@"Test"]) {
                            return YES;
                        }
                        else
                            return YES;
                        
                    }
                    else if (![mobileNumber.text isEqualToString:phone])
                    {
                        
                        if ([phone isEqualToString:@"Test"]) {
                            return YES;
                        }
                        else
                            return YES;
                        
                    }
                    
                }
            }
            
            
            
        }
        else if (isOnlineStatus)
        {
            [self showAlertPop:@"the Network is down" expObj:nil];
        }
        
        
        
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
        
    } @finally {
        
    }
}


-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    @try {
        
        
        if (tableView == autoComplete) {
            
            return  [userTypes count];
        }
        
        if (self.categoryTable== tableView) {
            return [categoryItems count];
        }
        else if (radTable == tableView)
        {
            return  [radiusItems count];
        }
        
        else if (tableView == autocompleAddressTable)
            {
                return [autocompleAddress count];
            }
        
       
       // return [autocompleteAddress count];
    }
    @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    }
    @finally {
        
    }
    
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    return 50;
    
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    @try {
        
       // UITableViewCell *cell= nil;
        if (tableView == autoComplete) {
            static NSString *CellIdentifier = @"Cell";
            // Reuse and create cell
            UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
            if (cell == nil) {
                cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
            }
        NSDictionary     *type = [userTypes objectAtIndex:indexPath.row];
            cell.textLabel.text = [type valueForKey:@"LookupValue"];
            return cell;
            
        }
        
        if (tableView == self.categoryTable) {
            
            Setting_Cell *cell = (Setting_Cell *)[tableView dequeueReusableCellWithIdentifier:@"Setting_Cell"];
            if (cell == nil)
            {
                NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"Setting_Cell" owner:self options:nil];
                cell = [nib objectAtIndex:0];
            }
            // tableView.backgroundColor = [UIColor blackColor];
            
            
            
            cell.categoryName.text = [categoryItems[indexPath.row] valueForKey:@"CategoryName"];
            
            if ([checkedCateIds containsObject:[categoryItems[indexPath.row] valueForKey:@"CategoryID"]]) {
               cell.check.image=[UIImage imageNamed:@"aftercheck.png"];
            }
            else{
                 cell.check.image=[UIImage imageNamed:@"beforecheck.png"];
            }
            
            
//            if([self.checkedArray containsObject:indexPath]){
//                cell.check.image=[UIImage imageNamed:@"aftercheck.png"];
//                // cell.check.backgroundColor = [UIColor lightGrayColor];
//            } else
//                cell.check.image=[UIImage imageNamed:@"beforecheck.png"];//uncheck.png
            
            return cell;
        }
        
        else if (tableView == radTable)
        {
            static NSString *CellIdentifier = @"Cell";
            // Reuse and create cell
            UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
            if (cell == nil) {
                cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
            }
            NSString *Addreline = [[radiusItems objectAtIndex:indexPath.row] valueForKey:@"Value"];
            cell.textLabel.text = Addreline;
            return cell;
            
            
        }
        
        else if (tableView == autocompleAddressTable)
        {
            static NSString *CellIdentifier = @"Cell";
            // Reuse and create cell
            UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
            if (cell == nil) {
                cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
            }
            NSString *Addreline = [autocompleAddress objectAtIndex:indexPath.row];
            cell.textLabel.text = Addreline;
            return cell;

        }
        
        
        
    }
     @catch (NSException *exception) {
        
    } @finally {
        
    }


}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
    @try {
        
        if (tableView == autoComplete) {
            if (indexPath.row == 0) {
                 self.contactpersonView.hidden = YES;
            }
            else
            {
                 self.contactpersonView.hidden = NO;
            }
            
            
            NSDictionary *selctedCategory = [userTypes objectAtIndex:indexPath.row];
            SelectedType = selctedCategory;
            self.typelbl.text = [selctedCategory valueForKey:@"LookupValue"];
            self.conatctPersonName.placeholder = [NSString stringWithFormat:@"%@ name", [selctedCategory valueForKey:@"LookupValue"]];
           // [alertController dismissViewControllerAnimated:YES completion:nil];
            [offertypeAlert close];
            //autoComplete.hidden = YES;
            
            //[userTypes resignFirstResponder];
        }
        
        if (tableView == self.categoryTable) {
            
             NSString *catId = [[categoryItems objectAtIndex:indexPath.row] valueForKey:@"CategoryID"];
            if([self.checkedArray containsObject:indexPath]){
                [self.checkedArray removeObject:indexPath];
                [checkedCateIds removeObject:catId];
                
            } else {
                [checkedCateIds addObject:catId];
                [self.checkedArray addObject:indexPath];
            }
            [tableView reloadData];
            
        }
        else if (tableView == radTable)
        {
            selectedRadius =[[radiusItems objectAtIndex:indexPath.row] valueForKey:@"Radious"];
            // NSString   *selectedrad =[[radiusItems objectAtIndex:indexPath.row] valueForKey:@"Radious"];
            [self.radiusBtn setTitle:[[radiusItems objectAtIndex:indexPath.row] valueForKey:@"Value"] forState:UIControlStateNormal];
            [categoryAlert close];

            //[radTable setHidden:YES];
        }
        
        if (tableView == autocompleAddressTable) {
            
            autocompleAddressTable.hidden = YES;
            
            NSString *selectedAdress = [autocompleAddress objectAtIndex:indexPath.row];
            
            self.addressField.text = selectedAdress;
            [self.addressField resignFirstResponder];
            
            //-(CLLocationCoordinate2D) getLocationFromAddressString: (NSString*) addressStr
            
            CLLocationCoordinate2D coord = [[CurrentLocation alloc] getLocationFromAddressString:selectedAdress];
            
            latLong = [NSString stringWithFormat:@"%f,%f",coord.latitude,coord.longitude];
            
        }
        
    }
    @catch(NSException *ex)
    {
        
    }
    @finally
    {
        
    }
}

-(IBAction)selectCategory:(id)sender
{
    [self ImageTap];
}
-(IBAction)seletcRadius:(id)sender
{
    [self radiusTap];
    
}
-(IBAction)selectlocation:(id)sender
{
    
}
-(void)ImageTap{
    
    @try {
        
        categoryAlert=[[CustomIOSAlertView alloc] init];
        UIView  *imageView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 300, 400)];
        [categoryAlert setContainerView:imageView];
        [categoryAlert setButtonTitles:[NSMutableArray arrayWithObjects:@"", nil]];
        
        [categoryAlert setDelegate:self];
        
        
        // You may use a Block, rather than a delegate.
        [categoryAlert setOnButtonTouchUpInside:^(CustomIOSAlertView *alertView, int buttonIndex) {
            NSLog(@"Block: Button at position %d is clicked on alertView %d.", buttonIndex, (int)[alertView tag]);
            [alertView close];
        }];
        
        [categoryAlert setUseMotionEffects:true];
        
        UIButton *cancel = [[UIButton alloc]initWithFrame:CGRectMake(275, 0, 20, 20)];
        
        [cancel setImage:[UIImage imageNamed:@"ic_close"] forState:UIControlStateNormal];
        [cancel addTarget:self action:@selector(cancel:) forControlEvents:UIControlEventTouchUpInside];
        
        self.categoryTable.frame = CGRectMake(0, 20, 300, 400);
        [imageView addSubview:self.categoryTable];
        
        [imageView addSubview:cancel];
        
        
        [categoryAlert show];
        categoryAlert.tag = 2;
        
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error in Data parsing." expObj:exception];
    } @finally {
        
    }
    
    
    //ImageAlert = [CustomIOSAlertView ]
}

-(void)cancel:(UIButton*)sender
{
    [categoryAlert close];
    
     selectedCategories = [self selectedCategories];
    
       [self.categoryBtn setTitle: [NSString stringWithFormat:@"%@",[selectedCategories valueForKey:@"CategoryName"]] forState:UIControlStateNormal];
    [self.categoryBtn setTitle:[self selectedCategoryname:checkedCateIds] forState:UIControlStateNormal];
    
    
}

-(NSDictionary*)selectedCategories
{
    
    NSMutableArray *arryResponceData=[[NSMutableArray alloc]init];
    NSMutableArray *arryCatIDs=[[NSMutableArray alloc]init];
    
    
    
    for (int i=0; i<[self.checkedArray count]; i++) {
        NSIndexPath *path=[self.checkedArray objectAtIndex:i];
        NSString *res = [[categoryItems objectAtIndex:path.row] valueForKey:@"CategoryName"];
        
        [arryResponceData addObject:res];
        
        NSString *catId = [[categoryItems objectAtIndex:path.row] valueForKey:@"CategoryID"];
        [arryCatIDs addObject:catId];
        
        
    }
    
    NSMutableDictionary *category = [[NSMutableDictionary alloc]init];
    [category setValue:[arryResponceData componentsJoinedByString:@","]  forKey:@"CategoryName"];
    [category setValue:[arryCatIDs componentsJoinedByString:@","]  forKey:@"CategoryID"];
    
    
    //   NSString *categorystring =[arryResponceData componentsJoinedByString:@" & "];
    return category;
}


-(void)radiusTap{
    
    @try {
        
        categoryAlert=[[CustomIOSAlertView alloc] init];
        UIView  *imageView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 300, 300)];
        [categoryAlert setContainerView:imageView];
        [categoryAlert setButtonTitles:[NSMutableArray arrayWithObjects:@"", nil]];
        
        [categoryAlert setDelegate:self];
        
        
        // You may use a Block, rather than a delegate.
        [categoryAlert setOnButtonTouchUpInside:^(CustomIOSAlertView *alertView, int buttonIndex) {
            NSLog(@"Block: Button at position %d is clicked on alertView %d.", buttonIndex, (int)[alertView tag]);
            [alertView close];
        }];
        
        [categoryAlert setUseMotionEffects:true];
        
        UIButton *cancel = [[UIButton alloc]initWithFrame:CGRectMake(275, 0, 20, 20)];
        
        [cancel setImage:[UIImage imageNamed:@"ic_close"] forState:UIControlStateNormal];
        [cancel addTarget:self action:@selector(closeradius:) forControlEvents:UIControlEventTouchUpInside];
        
        radTable.frame = CGRectMake(0, 20, 300, 300);
        [imageView addSubview:radTable];
        
        [imageView addSubview:cancel];
        
        
        [categoryAlert show];
        categoryAlert.tag = 2;
        
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error in Data parsing." expObj:exception];
    } @finally {
        
    }
    
    
    //ImageAlert = [CustomIOSAlertView ]
}

-(void)closeradius:(UIButton*)sender
{
    [categoryAlert close];
    
   // selectedCategories = [self selectedCategories];
}


#pragma mark -AutoCompleted Address


- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string {
    @try {
        
        if (textField== self.addressField) {
            
        
        autoComplete.hidden = YES;
        autocompleAddressTable.hidden = YES;
        
        if ([self.addressField.text isEqualToString:@""]) {
            autocompleAddressTable.hidden= YES;
        }
        
        else  if (![self.addressField.text isEqualToString:@""]) {
            autocompleAddressTable.hidden= NO;
            
            NSString *substring = [NSString stringWithString:self.addressField.text];
            substring = [substring
                         stringByReplacingCharactersInRange:range withString:string];
            [self searchAutocompleteEntriesWithSubstring:substring];
            
            //return YES;
        }
        }
        return YES;
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
    
}
- (void)searchAutocompleteEntriesWithSubstring:(NSString *)substring {
    @try {
        // Put anything that starts with this substring into the autocompleteUrls array
        // The items in this array is what will show up in the table view
        
        
        NSString* urlpath;
        if (![substring isEqual:@""])
            //https://maps.googleapis.com/maps/api/place/autocomplete/json?key=AIzaSyBsB3SN513YgmJxs-md1zA2zWPgktPhczU&input=am
            //AIzaSyBsB3SN513YgmJxs-md1zA2zWPgktPhczU&input=am
        {
            
            if (isOnlineStatus) {
                
                urlpath = [NSString stringWithFormat:@"https://maps.googleapis.com/maps/api/place/autocomplete/json?key=AIzaSyAM5zyy3xsgRWpye3fmXLEK1Hm18E_tj98&input=%@",substring];
                
                
                //AIzaSyAVwhwILDa3_cka-sjZ3U3xZo-OCS0mADI
                
                NSString *escapedUrlString = [urlpath stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet URLFragmentAllowedCharacterSet]];
                
                NSURL *RPRTUrlpath = [NSURL URLWithString:escapedUrlString];
                
                NSData *myData = [NSData dataWithContentsOfURL:RPRTUrlpath];
                
                NSError* error1;
                
                NSDictionary    * autocompleteUrls1 = [NSJSONSerialization
                                                       JSONObjectWithData:myData
                                                       options:kNilOptions
                                                       error:&error1];
                NSString  *prediction = [autocompleteUrls1 valueForKey:@"predictions"];
                autocompleAddress = [prediction valueForKey:@"description"];
                
                [autocompleAddressTable reloadData];
            }
            else if (!isOnlineStatus)
            {
                [self showAlertPop:@"No Internet Connection." expObj:nil];
                
            }
            
        }
        else  if ([substring isEqual:@""])
            
        {
            
        }
        
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
}


-(NSDictionary*)SaveuserSeetings:(NSDictionary*)registerResponse

{
    NSMutableArray *fistObj =registerResponse;
    
    
    NSString *userRegistedId = [[fistObj objectAtIndex:0] valueForKey:USERREGISTERID];
    
    NSString *catIds =[checkedCateIds componentsJoinedByString:@","];//[selectedCategories valueForKey:@"CategoryID"];
    
    
    NSDate *currentDateInLocal = [NSDate date];
    
    NSDateFormatter *formatter = [[NSDateFormatter alloc]init];
    [formatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
    NSTimeZone *gmt = [NSTimeZone timeZoneWithAbbreviation:@"UTC"];
    [formatter setTimeZone:gmt];
    NSString *StartTimecon = [formatter stringFromDate:currentDateInLocal];
    
    NSDictionary *usersettingObj = @{@"UserSettingsID":UserSettingsID,
                                     @"UserID":userRegistedId,
                                     @"SendNotifications":@"true",
                                     @"NotifyCategories":catIds,
                                     @"DefaultRadius":selectedRadius,
                                     @"DefaultAddress":self.addressField.text,
                                     @"UserIdCreated":userRegistedId,
                                     @"CreatedDate":StartTimecon,
                                     @"UserIdModified":userRegistedId,
                                     @"ModifiedDate":StartTimecon,
                                     @"RowStatus":@"A",
                                     @"LatLong":latLong
                                     };
    NSDictionary *response = [mWebService SaveUserSettings:usersettingObj];
   
     return response ;
}


-(NSString*)selectedCategoryname:(NSMutableArray*)catIds
{
    NSMutableArray *catname= [[NSMutableArray alloc]init];
    for (int i=0; i<[catIds count]; i++) {
        
        for (int j=0; j<[categoryItems count]; j++) {
            
            if ([[[categoryItems objectAtIndex:j] valueForKey:@"CategoryID"] isEqualToString:[catIds objectAtIndex:i]]) {
            
                [catname addObject:[[categoryItems objectAtIndex:j] valueForKey:@"CategoryName"]];
                
            }
        }
        
      
    }
    
    
    return [catname componentsJoinedByString:@","];
}

-(NSString*)selectedRadius:(NSString*)radius
{
    
    radius =[NSString stringWithFormat:@"%@",radius];
    
    NSString *radio ;
    for (int i=0; i<[radiusItems count]; i++) {
        if ([[[radiusItems objectAtIndex:i] valueForKey:@"Radious"] isEqualToString:radius]) {
            radio =[[radiusItems  objectAtIndex:i] valueForKey:@"Value"];
            return radio;
        }
    }
    return radio;
}

- (IBAction)changeSwitch:(id)sender{
    
    if([sender isOn]){
        checkedCateIds = finalCheckedarry;
        [self.categoryTable reloadData];
        NSString *names=[self selectedCategoryname:checkedCateIds];
        if([checkedCateIds count]==0)
        {
            [self.categoryBtn setTitle:@"Select category" forState:UIControlStateNormal];
        }
        
        else [self.categoryBtn setTitle:names forState:UIControlStateNormal];
        
        NSLog(@"Switch is ON");
    } else{
        
        checkedCateIds =nil;
        [self.categoryTable reloadData];
        [self.categoryBtn setTitle:@"Select category" forState:UIControlStateNormal];
        NSLog(@"Switch is OFF");
    }
    
}

#pragma mark - UISearchbar Delegate

-(void)getOffertype
{
    
    @try {
        
        offertypeAlert=[[CustomIOSAlertView alloc] init];
        UIView  *alertView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 300, 400)];
        [offertypeAlert setContainerView:alertView];
        [offertypeAlert setButtonTitles:[NSMutableArray arrayWithObjects:@"", nil]];
        
        [offertypeAlert setDelegate:self];
        
        
        // You may use a Block, rather than a delegate.
        [offertypeAlert setOnButtonTouchUpInside:^(CustomIOSAlertView *alertView, int buttonIndex) {
            NSLog(@"Block: Button at position %d is clicked on alertView %d.", buttonIndex, (int)[alertView tag]);
            [alertView close];
        }];
        
        [offertypeAlert setUseMotionEffects:true];
        
        UIButton *cancel = [[UIButton alloc]initWithFrame:CGRectMake(275, 0, 20, 20)];
        
        [cancel setImage:[UIImage imageNamed:@"ic_close"] forState:UIControlStateNormal];
        [cancel addTarget:self action:@selector(cancelcategory:) forControlEvents:UIControlEventTouchUpInside];
        
//        offerTypeSearch = [[UISearchBar alloc]initWithFrame:CGRectMake(0, 20, alertView.frame.size.width, 40)];
//        offerTypeSearch.delegate= self;
//        offerTypeSearch.backgroundColor= [UIColor colorWithRed:198.0/256.0 green:198.0/256.0 blue:198.0/256.0 alpha:1];
        
        autoComplete = [[UITableView alloc]init];
        autoComplete.frame = CGRectMake(0, 60, 300, 380);
        autoComplete.hidden= NO;
        autoComplete.delegate= self;
        autoComplete.dataSource = self;
        [alertView addSubview:autoComplete];
        
       // [alertView addSubview: offerTypeSearch];
        [alertView addSubview:cancel];
        
        [offertypeAlert show];
        offertypeAlert.tag = 2;
        
        
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error in Data parsing." expObj:exception];
    } @finally {
        
    }
    
}

-(void)cancelcategory:(UIButton*)sender
{
    [offertypeAlert close];
}

//- (void)searchBarTextDidBeginEditing:(UISearchBar *)searchBar {
//    isSearching = YES;
//}
//
//- (void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)seachtext {
//    NSLog(@"Text change - %d",isSearching);
//    
//    //Remove all objects first.
//    // [filteredContentList removeAllObjects];
//    
//    if([seachtext length] != 0) {
//        isSearching = YES;
//        [self seachOffer:seachtext];
//    }
//    else if([seachtext length]==0)
//    {
//        GetSubCat = userTypes;
//        [typetableView reloadData];
//    }
//    else {
//        isSearching = NO;
//    }
//    // [self.tblContentList reloadData];
//}
//
//- (void)seachOffer:(NSString *)substring {
//    @try {
//        // Put anything that starts with this substring into the autocompleteUrls array
//        // The items in this array is what will show up in the table view
//        NSPredicate *predicate = [NSPredicate predicateWithFormat:@"SELF contains [cd] %@", substring];
//        results = [searchString filteredArrayUsingPredicate:predicate];
//        if ([results count]!=0) {
//            
//            NSMutableArray *array = [[NSMutableArray alloc]init];
//            
//            
//            for (int i=0; i<[results count]; i++) {
//                NSString  *str= [results objectAtIndex:i];
//                
//                for (int j=0; j<[GetSubCat count]; j++) {
//                    NSString *str2 = [[GetSubCat objectAtIndex:j]  valueForKey:@"TypeName"];
//                    if ([str isEqualToString:str2]) {
//                        [array addObject:[GetSubCat objectAtIndex:j]];
//                    }
//                }
//                
//            }
//            
//            NSOrderedSet *orderedSet = [NSOrderedSet orderedSetWithArray:array];
//            GetSubCat = [orderedSet mutableCopy];
//            
//            
//            
//            [typetableView reloadData];
//            
//        }
//        //[autoComplete reloadData];
//    } @catch (NSException *exception) {
//        [self showAlertPop:@"Error while fetching data." expObj:exception];
//    } @finally {
//        
//    }
//}
//
//- (void)searchBarSearchButtonClicked :(UISearchBar *)searchBar {
//    NSLog(@"Search Clicked");
//    
//    [searchBar resignFirstResponder];
//    //[searchBar setHidden:YES];
//    //[checkview setHidden:NO];
//    //[self searchTableList];
//}

-(IBAction)fromLocation:(id)sender
{
    Setting_Maps *mMapSettings = [[Setting_Maps alloc]initWithNibName:@"Setting_Maps" bundle:nil];
    mMapSettings.location= @"RegisterFromGoogle"; 
    [self presentViewController:mMapSettings animated:YES completion:nil];
    
}

-(void)ToRegister:(NSNotification*)notification
{
 
    NSDictionary *addres = notification.userInfo;
    self.addressField.text =[addres valueForKey:@"Address"];
    latLong =[addres valueForKey:@"LatLong"];
    
    //self.addressField.text = notification.userInfo;
}



@end
