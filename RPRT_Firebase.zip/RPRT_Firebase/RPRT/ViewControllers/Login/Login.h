//
//  Login.h
//  RPRT
//
//  Created by sravanthi Gumma on 08/01/16.
//  Copyright © 2016 DevpointSolutions. All rights reserved.
//

#import "Registration.h"
#import "MainViewController.h"
#import <Google/SignIn.h>
#import "RegisterWithGoogle.h"
#import <FBSDKLoginKit/FBSDKLoginKit.h>
//#import <FacebookSDK/FacebookSDK.h>

@interface Login : UIViewController<GIDSignInUIDelegate>
{
    NSString *userEmail;
    NSString *userPwd;
}
@property (strong, nonatomic) NSTimer *timer;
@property (weak, nonatomic) IBOutlet UITextField *username;
@property (weak, nonatomic) IBOutlet UITextField *password;

@property (weak, nonatomic) IBOutlet UIButton *Radious;
@property (weak,nonatomic)IBOutlet UIButton *Settings;
@property(weak,nonatomic) IBOutlet UIView *toolBarView;

@property (weak, nonatomic) IBOutlet GIDSignInButton *signInButton;
@property (weak, nonatomic) IBOutlet UIButton *signOutButton;
@property (weak, nonatomic) IBOutlet UIButton *disconnectButton;
@property (weak, nonatomic) IBOutlet UILabel *statusText;

/*FaceBook params*/
@property (strong, nonatomic) IBOutlet FBSDKLoginButton *loginButton;




//@property (weak, nonatomic) IBOutlet UILabel *statusText;
@end
