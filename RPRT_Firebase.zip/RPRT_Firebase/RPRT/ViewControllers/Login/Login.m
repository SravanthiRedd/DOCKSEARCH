//
//  Login.m
//  RPRT
//
//  Created by sravanthi Gumma on 08/01/16.
//  Copyright © 2016 DevpointSolutions. All rights reserved.
//

#import "Login.h"
#import "ScanCode.h"
#import "ForgotPassword.h"
//#import "Setting.h"
#import <FBSDKCoreKit/FBSDKCoreKit.h>
#import <FBSDKLoginKit/FBSDKLoginKit.h>
#import "Registration_Types.h"

@interface Login ()
{
    Web_Services *mWebService;
    Preferences *mPreferences;
    UIActivityIndicatorView *spinner;
    UIView *contentView;
    NSUserDefaults *mPref;
    NSString *RegisteredID;
    NSString * emaiId;
}
@property (weak, nonatomic) IBOutlet UIView *Contentview;
@property (weak, nonatomic) IBOutlet UIScrollView *scrollview;
@property (weak, nonatomic) IBOutlet UIView *usernameview;
@property (weak, nonatomic) IBOutlet UIView *passwordview;
@property (weak, nonatomic) IBOutlet UIView *Loginview;
@property (nonatomic, strong) AppDelegate *appDelegate;
@end

@implementation Login
@synthesize username,password,Settings,Radious,toolBarView,timer;

double timerInterval = 8;

- (NSTimer *) timer {
    if (!timer) {
        timer = [NSTimer timerWithTimeInterval:timerInterval target:self selector:@selector(onTick:) userInfo:nil repeats:NO];
    }
    return timer;
}



- (void)viewDidLoad {
    [super viewDidLoad];
    @try {
        
        
        [GIDSignIn sharedInstance].uiDelegate = self;
        
        [[NSNotificationCenter defaultCenter]
         addObserver:self
         selector:@selector(receiveToggleAuthUINotification:)
         name:@"ToggleAuthUINotification"
         object:nil];
        
        [self toggleAuthUI];
        [self statusText].text = @"Google Sign in\niOS Demo";
        
        
        [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent];
        
//        self.loginButton = [[FBSDKLoginButton alloc] init];
//        [self.loginButton addTarget:self  action:@selector(faceBookLogin:) forControlEvents:UIControlEventTouchUpInside];
//        
//        UIButton *myLoginButton=[UIButton buttonWithType:UIButtonTypeCustom];
//        myLoginButton.backgroundColor=[UIColor darkGrayColor];
//        myLoginButton.frame=CGRectMake(0,0,180,40);
//        myLoginButton.center = self.view.center;
//        [myLoginButton setTitle: @"My Login Button" forState: UIControlStateNormal];
//        
//        // Handle clicks on the button
//        [myLoginButton
//         addTarget:self
//         action:@selector(loginButtonClicked) forControlEvents:UIControlEventTouchUpInside];
//        
//        // Add the button to the view
//        [self.view addSubview:myLoginButton];
        
        
        // Optional: Place the button in the center of your view.
       // self.loginButton.center = self.view.center;
        //[self.view addSubview:self.loginButton];
        
        
        
        
        
        
        // Observe for the custom notification regarding the session state change.
//        [[NSNotificationCenter defaultCenter] addObserver:self
//                                                 selector:@selector(handleFBSessionStateChangeWithNotification:)
//                                                     name:@"SessionStateChangeNotification"
//                                                   object:nil];
        
        self.appDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
        
        
        
        
        //       FBSDKLoginButton *loginButton = [[FBSDKLoginButton alloc] init];
        //        loginButton.center = self.view.center;
        //        [self.Contentview addSubview:loginButton];
        
      //  [FBLoginView class];
      //  [FBProfilePictureView class];
        
        
        
        // [self.loginButto
        
        //[self loginWithFacebook];
        
        
//        Reachability *networkReachability = [Reachability reachabilityForInternetConnection];
//        NetworkStatus networkStatus = [networkReachability currentReachabilityStatus];
//        if (networkStatus == NotReachable) {
//            
//            isOnlineStatus = NO;
//            
//        } else  if (networkStatus == ReachableViaWiFi) {
//            
//            isOnlineStatus = YES;
//        }
//        else if (networkStatus == ReachableViaWWAN) {
//            isOnlineStatus = YES;
//            
//        }
        
        if (isOnlineStatus) {
            
            
            [self.Contentview setBackgroundColor:[UIColor colorWithRed:239.0/256.0 green:239.0/256.0 blue:239.0/256.0 alpha:1]];
            
            RegisteredID= @"0";
            
            mWebService = [Web_Services GetSharedInstance];
            mPreferences = [Preferences GetSharedInstance];
            mPref = [NSUserDefaults standardUserDefaults];
            
            // [self loadToolbar];
//            UIView *logibBG = [[UIView alloc]initWithFrame:CGRectMake(28, 244, 264, 108)];
//            //CGFloat borderwidth = 1.0f;
//            
//            // logibBG.frame = CGRectInset(self.view.frame, -2.0f, -2.0f);
//            logibBG.layer.borderWidth = 1.0f;
//            logibBG.backgroundColor = [UIColor whiteColor];
//            logibBG.layer.borderColor = [UIColor lightGrayColor].CGColor;// [UIColor brownColor].CGColor;
//            // [self.view addSubview:logibBG];
            
            self.usernameview.layer.borderWidth = 1.0f;
            self.usernameview.layer.borderColor = [UIColor colorWithRed:196.0/256.0 green:196.0/256.0 blue:196.0/256.0 alpha:1].CGColor;
            self.passwordview.layer.borderWidth = 1.0f;
            self.passwordview.layer.borderColor =[UIColor colorWithRed:196.0/256.0 green:196.0/256.0 blue:196.0/256.0 alpha:1].CGColor;
           // self.Loginview.layer.borderWidth = 1.0f;
            //self.Loginview.layer.borderColor = [UIColor lightGrayColor].CGColor;
            UITapGestureRecognizer *tapGesture =
            [[UITapGestureRecognizer alloc] initWithTarget:self
                                                    action:@selector(hideKeyboard)];
            tapGesture.cancelsTouchesInView = NO;
            NSUserDefaults *prefss = [NSUserDefaults standardUserDefaults];
            
            if ([prefss objectForKey:@"UserName"]) {
                userEmail = [prefss objectForKey:@"UserName"];
                username.text = userEmail;
            }
            if (![[prefss objectForKey:@"Password"] isEqual:@""] && [prefss objectForKey:@"Password"]!= NULL ) {
                
                userPwd = [prefss objectForKey:@"Password"];
                password.text = userPwd;
            }
            
            self.scrollview.bounces = NO;
            
            
        }
        else if (!isOnlineStatus)
        {
            [self showAlertPop:@"The internet is down." exceptionVal:nil];
            
        }
        // [self changeDemo:nil];
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." exceptionVal:exception];
    } @finally {
        
    }
    
}

-(IBAction)loginButtonClicked:(id)sender
{
    FBSDKLoginManager *login = [[FBSDKLoginManager alloc] init];
    [login
     logInWithReadPermissions: @[@"email",@"public_profile",@"user_friends"]
     fromViewController:self
     handler:^(FBSDKLoginManagerLoginResult *result, NSError *error) {
         if (error) {
             NSLog(@"Process error");
             [self loginWithFacebook];
         } else if (result.isCancelled) {
             NSLog(@"Canceled");
//             spinner = [[UIActivityIndicatorView alloc]
//                        initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
//             spinner.frame = CGRectMake(0, 0, 375, 600); // CGPointMake(160, 240);
//             spinner.color = [UIColor blueColor];
//             spinner.backgroundColor = [UIColor lightTextColor];
//             spinner.transform = CGAffineTransformMakeScale(2, 2);
//             // spinner.hidesWhenStopped = YES;
//             [self.view addSubview:spinner];
//             spinner.transform = CGAffineTransformMakeScale(2, 2);
//             
//             [spinner startAnimating];
//             
//             // how we stop refresh from freezing the main UI thread
//             
//             dispatch_async(
//                            dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^{
//                                
//                                // back to the main thread for the UI call
//                                dispatch_async(dispatch_get_main_queue(), ^{
//                                    [spinner startAnimating];
//                                });
//                                dispatch_async(dispatch_get_main_queue(), ^{
//             [self loginWithFacebook];
//                                    [spinner stopAnimating];
//                                });
//                            });
             
             NSLog(@"Cancelled");
         } else {
             spinner = [[UIActivityIndicatorView alloc]
                        initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
             spinner.frame = CGRectMake(0, 0, 375, 600); // CGPointMake(160, 240);
             spinner.color = [UIColor blueColor];
             spinner.backgroundColor = [UIColor lightTextColor];
             spinner.transform = CGAffineTransformMakeScale(2, 2);
             // spinner.hidesWhenStopped = YES;
             [self.view addSubview:spinner];
             spinner.transform = CGAffineTransformMakeScale(2, 2);
             
             [spinner startAnimating];
             
             // how we stop refresh from freezing the main UI thread
             
             dispatch_async(
                            dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^{
                                
                                // back to the main thread for the UI call
                                dispatch_async(dispatch_get_main_queue(), ^{
                                    [spinner startAnimating];
                                });
                                dispatch_async(dispatch_get_main_queue(), ^{
             [self loginWithFacebook];
                                    [spinner stopAnimating];
                                });
                            });
            // NSLog(@"Logged in");
             
         }
     }];
}




- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void) viewDidLayoutSubviews {
    
    @try {
        [ super viewDidLayoutSubviews];
        [self.scrollview layoutIfNeeded];
        self.scrollview.contentSize=self.Contentview.bounds.size;
        UIGraphicsBeginImageContext(self.view.frame.size);
      //  UIImage *image = UIGraphicsGetImageFromCurrentImageContext();
        UIGraphicsEndImageContext();
        self.Contentview.backgroundColor = [UIColor colorWithRed:239.0/256.0 green:239.0/256.0 blue:239.0/256.0 alpha:1];
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." exceptionVal:exception];
    } @finally {
        
    }
    
}

- (IBAction)textFieldDidBeginEditing:(id)textField {
    @try {
        
        [self animateTextField:textField up:YES];
    }
    @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." exceptionVal:exception];
    }
    @finally {
        
    }
}

- (IBAction)textFieldDidEndEditing:(id)textField {
    @try {
        
        [self animateTextField:textField up:NO];
    }
    @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." exceptionVal:exception];
    }
    @finally {
        
    }
}

- (IBAction)hideKeyBoardUserName:(id)sender {
    @try {
        if (![self validEmail:username.text]) {
            [username becomeFirstResponder];
            // [self showAlertPop:@" InvalidEmail." exceptionVal:nil];
        }
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." exceptionVal:exception];
    }
}

- (IBAction)hideKeyBoardPassWord:(id)sender {
    [password becomeFirstResponder];
}

- (IBAction)loginValidation:(id)sender {
    
    @try {
        
        
        if (isOnlineStatus) {
            
            
            spinner = [[UIActivityIndicatorView alloc]
                       initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
            spinner.frame = CGRectMake(0, 0, 320, 560); // CGPointMake(160, 240);
            spinner.color = [UIColor blueColor];
            spinner.backgroundColor = [UIColor lightTextColor];
            spinner.transform = CGAffineTransformMakeScale(2, 2);
            // spinner.hidesWhenStopped = YES;
            [self.view addSubview:spinner];
            spinner.transform = CGAffineTransformMakeScale(2, 2);
            
            [spinner startAnimating];
            
            // how we stop refresh from freezing the main UI thread
            
            dispatch_async(
                           dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^{
                               
                               // back to the main thread for the UI call
                               dispatch_async(dispatch_get_main_queue(), ^{
                                   [spinner startAnimating];
                               });
                               dispatch_async(dispatch_get_main_queue(), ^{
                                   @try {
                                       if ([username.text length] > 0 && [password.text length] > 0) {
                                           NSMutableDictionary *loginparams = [[NSMutableDictionary alloc]init];
                                           [loginparams setValue:username.text forKey:@"UserName"];
                                           [loginparams setValue:password.text forKey:@"Password"];
                                           NSDictionary *getLoginResponse = [mWebService UserLoginValidation:loginparams];
                                           if (getLoginResponse !=nil) {
                                               
                                               NSMutableDictionary *registerDatavia = [[NSMutableDictionary alloc]init];
                                               [registerDatavia setValue:@"Signup" forKey:@"LoginType"];
                                               [registerDatavia setValue:[getLoginResponse valueForKey:USERREGISTERID] forKey:USERREGISTERID];
                                               [registerDatavia setValue:[getLoginResponse valueForKey:@"DefaultRadius"] forKey:@"DefaultRadius"];
                                               [registerDatavia setValue:[getLoginResponse valueForKey:@"UserRegisterID"] forKey:@"UserRegisterID"];
                                               [registerDatavia setValue:[getLoginResponse valueForKey:@"PhotoName"] forKey:@"PhotoName"];
                                               [registerDatavia setValue:[getLoginResponse valueForKey:@"DefaultAddress"] forKey:@"DefaultAddress"];
                                               [registerDatavia setValue:[getLoginResponse valueForKey:@"RegUserName"] forKey:@"RegUserName"];
                                               [registerDatavia setValue:[getLoginResponse valueForKey:@"RegUserName"] forKey:@"RegUserName"];
                                               [registerDatavia setValue:[getLoginResponse valueForKey:@"LoggedUserType"] forKey:@"LoggedUserType"];
                                               [registerDatavia setValue:[getLoginResponse valueForKey:@"ContactPerson"] forKey:@"ContactPerson"];
                                               
                                               //  Preferences *mPreferences = [Preferences GetSharedInstance];
                                               
                                               [mPreferences SaveRegisterDeatils:registerDatavia];
                                               
                                               
                                               
                                               
                                               //[mPreferences StoreUserName:username.text];
                                               // [mPreferences StorePassword:password.text];
                                               NSString *UserRegisterID  = [getLoginResponse valueForKey:USERREGISTERID];
                                               [mPreferences StoreSaveUserRegisterID:UserRegisterID];
                                               
                                               [self PageChange:[mPref valueForKey:@"PageName"]];
                                               
                                           }
                                           else
                                           {
                                               [self showAlertPop:@"Invalid UserName/Password." exceptionVal:nil];
                                           }
                                       }
                                       else {
                                           [self showAlertPop:@"Invalid UserName/Password." exceptionVal:nil];
                                       }
                                   } @catch (NSException *exception) {
                                       [self showAlertPop:@"Error while fetching data." exceptionVal:exception];
                                   }                               [spinner stopAnimating];
                                   
                               });
                           });
        }
        else if (!isOnlineStatus)
        {
            [self showAlertPop:@"No internet connection" exceptionVal:nil];
            
        }
        
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." exceptionVal:exception];
    } @finally {
        
    }
    
}


-(void)PageChange:(NSString*)Pagename
{
    
    Home * mHome= [[ Home alloc] initWithNibName:HOMEDASHBOARD bundle:nil];
    [self presentViewController:mHome animated:YES completion:nil];
    
    
    
}



-(void)postPagenavigation
{
    @try {
        
        if (isOnlineStatus) {
            
            
            NSString *ModuleId =[mPref valueForKey:MODULEID];
            
            if ([ModuleId isEqualToString:@"33"]) {
                Post_Food * mPosting = [[ Post_Food alloc] initWithNibName:PFOOD bundle:nil];
                [self presentViewController:mPosting animated:YES completion:nil];
                
            }
            else if ([ModuleId isEqualToString:@"34"])
            {
                Post_Sales * mPosting = [[ Post_Sales alloc] initWithNibName:PSALES bundle:nil];
                [self presentViewController:mPosting animated:YES completion:nil];
            }
            else if ([ModuleId isEqualToString:@"37"])
            {
                Post_Professional * mPosting = [[ Post_Professional alloc] initWithNibName:PPROFESSIONAL bundle:nil];
                [self presentViewController:mPosting animated:YES completion:nil];
            }
            else if ([ModuleId isEqualToString:@"38"])
            {
                Post_Sports * mPosting = [[ Post_Sports alloc] initWithNibName:PSPORTS bundle:nil];
                [self presentViewController:mPosting animated:YES completion:nil];
            }
            else if ([ModuleId isEqualToString:@"36"])
            {
                Post_Jobs * mPosting = [[ Post_Jobs alloc] initWithNibName:PJOBS bundle:nil];
                [self presentViewController:mPosting animated:YES completion:nil];
            }
            else if ([ModuleId isEqualToString:@"39"])
            {
                Post_Meetings * mPosting = [[ Post_Meetings alloc] initWithNibName:PMEETINGS bundle:nil];
                [self presentViewController:mPosting animated:YES completion:nil];
            }
            
            else if ([ModuleId isEqualToString:@"40"])
            {
                Post_Travels * mPosting = [[ Post_Travels alloc] initWithNibName:PTRAVELS bundle:nil];
                [self presentViewController:mPosting animated:YES completion:nil];
            }
            else if ([ModuleId isEqualToString:@"41"])
            {
                Post_RealEstate * mPosting = [[ Post_RealEstate alloc] initWithNibName:PREALESTATE bundle:nil];
                [self presentViewController:mPosting animated:YES completion:nil];
            }
            
            else if ([ModuleId isEqualToString:@"42"]){
                Post_banking_Finance *mPost = [[Post_banking_Finance alloc]initWithNibName:PBANKINGANDFINANCE bundle:nil];
                
                [self presentViewController:mPost animated:YES completion:nil];
            }
            
            
            else
            {
                Post_Food * mPosting = [[ Post_Food alloc] initWithNibName:PFOOD bundle:nil];
                [self presentViewController:mPosting animated:YES completion:nil];
            }
        }
        else if (!isOnlineStatus)
        {
            [self showAlertPop:@"The internet is down." exceptionVal:nil];
            
        }
        
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." exceptionVal:exception];
    } @finally {
        
    }
}

- (IBAction)userRegistation:(id)sender {
    
    @try {
        
        if (isOnlineStatus) {
            
            
            Registration *mSearchResults = [[Registration alloc]initWithNibName:REGISTRATION bundle:nil];
            
            [self presentViewController:mSearchResults
                               animated:YES
                             completion:nil];
        }
        else if (!isOnlineStatus)
        {
            [self showAlertPop:@"The internet is down." exceptionVal:nil];
            
        }
        
    }
    @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." exceptionVal:exception];
    }
    @finally {
        
    }
    
}



- (void)setStackIconClosed:(BOOL)closed {
    
    @try {
        UIImageView *icon = [[contentView subviews] objectAtIndex:0];
        float angle = closed ? 0 : (M_PI * (135) / 180.0);
        [UIView animateWithDuration:0.3 animations:^{
            [icon.layer setAffineTransform:CGAffineTransformRotate(CGAffineTransformIdentity, angle)];
        }];
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." exceptionVal:exception];
    } @finally {
        
    }
    
}
- (void)animateTextField:(UITextField *)textField up:(BOOL)up {
    @try {
        int animatedDistance;
        int moveUpValue = textField.frame.origin.y + textField.frame.size.height;
        UIInterfaceOrientation orientation =
        [[UIApplication sharedApplication] statusBarOrientation];
        if (orientation == UIInterfaceOrientationPortrait ||
            orientation == UIInterfaceOrientationPortraitUpsideDown) {
            
            animatedDistance = 280 - (460 - moveUpValue - 5);
        } else {
            animatedDistance = 162 - (320 - moveUpValue - 5);
        }
        if (animatedDistance > 0) {
            NSString *deviceType = [[UIDevice currentDevice] model];
            
            if ([deviceType isEqualToString:@"iPad"]) {
            }
            const int movementDistance = animatedDistance;
            const float movementDuration = 0.3f;
            int movement = (up ? -movementDistance : movementDistance);
            [UIView beginAnimations:nil context:nil];
            [UIView setAnimationBeginsFromCurrentState:YES];
            [UIView setAnimationDuration:movementDuration];
            self.view.frame = CGRectOffset(self.view.frame, 0, movement);
            [UIView commitAnimations];
        }
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." exceptionVal:exception];
    }
}

- (void)hideKeyboard {
    @try {
        
        [username resignFirstResponder];
        [password resignFirstResponder];
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." exceptionVal:exception];
    } @finally {
        
    }
}

- (BOOL)touchesShouldBegin:(NSSet *)touches withEvent:(UIEvent *)event inContentView:(UIView *)view {
    return true;
}

- (BOOL)validEmail:(NSString *)emailString {
    @try {
        if ([emailString length] == 0) {
            return NO;
        }
        
        NSString *regExPattern =@"[A-Z0-9._%+-]+@(?:[A-Z0-9-])+[A-Z]{2,}";
        
        //        NSString *regExPattern =
        //        @"[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}";
        
        NSRegularExpression *regEx = [[NSRegularExpression alloc]
                                      initWithPattern:regExPattern
                                      options:NSRegularExpressionCaseInsensitive
                                      error:nil];
        NSUInteger regExMatches =
        [regEx numberOfMatchesInString:emailString
                               options:0
                                 range:NSMakeRange(0, [emailString length])];
        NSLog(@"%lu", (unsigned long)regExMatches);
        if (regExMatches == 0) {
            return NO;
        } else {
            return YES;
        }
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." exceptionVal:exception];
    }
}

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event {
    @try {
        if ([username isFirstResponder]) {
            [username resignFirstResponder];
            //            if (![self validEmail:username.text]) {
            //                [username becomeFirstResponder];
            //                [self showAlertPop:@" InvalidEmail." exceptionVal:nil];
            //            }
        } else if ([password isFirstResponder]) {
            [password resignFirstResponder];
        }
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." exceptionVal:exception];
    }
}

- (void)textFieldDidChange:(UITextField *)theTextField {
    @try {
        NSLog(@"text changed: %@", theTextField.text);
        NSLog(@"userEmail: %@", userEmail);
        if ([username.text isEqualToString:userEmail]) {
            password.text = userPwd;
        } else {
            password.text = @"";
        }
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." exceptionVal:exception];
    } @finally {
        
    }
    
}

-(IBAction)Back:(id)sender
{
    @try
    {
        spinner = [[UIActivityIndicatorView alloc]
                   initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
        spinner.frame = CGRectMake(0, 0, 375, 600); // CGPointMake(160, 240);
        spinner.color = [UIColor blueColor];
        spinner.backgroundColor = [UIColor lightTextColor];
        spinner.transform = CGAffineTransformMakeScale(2, 2);
        // spinner.hidesWhenStopped = YES;
        [self.view addSubview:spinner];
        spinner.transform = CGAffineTransformMakeScale(2, 2);
        
        [spinner startAnimating];
        
        // how we stop refresh from freezing the main UI thread
        
        dispatch_async(
                       dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^{
                           
                           // back to the main thread for the UI call
                           dispatch_async(dispatch_get_main_queue(), ^{
                               [spinner startAnimating];
                           });
                           dispatch_async(dispatch_get_main_queue(), ^{
                               //[mPref setValue:HOME forKey:@"SideMenu"];
                               Home * mOpportunity_list = [[ Home alloc] initWithNibName:HOMEDASHBOARD bundle:nil];
                               [self presentViewController:mOpportunity_list animated:YES completion:nil];
                               //[self dismissViewControllerAnimated:YES completion:NULL];
                               [spinner stopAnimating];
                               
                           });
                       });
    }
    @catch (NSException *exception) {
        
    }
    @finally {
        
    }
}


- (void) showAlertPop:(NSString*)alertText exceptionVal:(NSException*)ex {
    //mWeservice
    UIAlertController *myAlertController =[mWebService  alert:alertText];
    [self presentViewController:myAlertController animated:YES completion:nil];
    if(ex != nil)
    {
        NSLog(@"%@", ex.description);
    }
}

-(IBAction)forgotPassword:(id)sender
{
    
    ForgotPassword *mForgotPassword = [[ForgotPassword alloc
                                        ]initWithNibName:@"ForgotPassword" bundle:nil];
    [self presentViewController:mForgotPassword animated:YES completion:nil];
    
    
}

-(BOOL)validateRegisteredEmail
{
    @try {
        
        if (isOnlineStatus) {
            
            
            NSDictionary *response = [mWebService CheckEmail:username.text];
            if (response!=nil) {
                //  NSString *email = [response valueForKey:@"RegEmail"];
                
                // NSString *paswwordstrimg = [NSString stringWithFormat:@"Your password is"];
                
                [self showAlertPop:@"Please enter Emailid Or Mobile Number" exceptionVal:nil];
                
            }
        }
        else if (!isOnlineStatus)
        {
            [self showAlertPop:@"The internet is down." exceptionVal:nil];
            
        }
        
        
        
    } @catch (NSException *exception) {
        
        [self showAlertPop:@"Error while fetching data." exceptionVal:nil];
        
        
    } @finally {
        
    }
}

- (IBAction)didTapSignOut:(id)sender {
    [[GIDSignIn sharedInstance] signOut];
    // [START_EXCLUDE silent]
    [self toggleAuthUI];
    // [END_EXCLUDE]
}
// [END signout_tapped]

// Note: Disconnect revokes access to user data and should only be called in
//     scenarios such as when the user deletes their account. More information
//     on revocation can be found here: https://goo.gl/Gx7oEG.
// [START disconnect_tapped]
- (IBAction)didTapDisconnect:(id)sender {
    [[GIDSignIn sharedInstance] disconnect];
}
// [END disconnect_tapped]

// [START toggle_auth]
- (void)toggleAuthUI {
    if ([GIDSignIn sharedInstance].currentUser.authentication == nil) {
        // Not signed in
        [self statusText].text = @"Google Sign in\niOS Demo";
        self.signInButton.hidden = NO;
        self.signOutButton.hidden = YES;
        self.disconnectButton.hidden = YES;
    } else {
        // Signed in
        
        
        self.signInButton.hidden = NO;
        self.signOutButton.hidden = NO;
        self.disconnectButton.hidden = NO;
    }
}
// [END toggle_auth]

- (void)signIn:(GIDSignIn *)signIn didSignInForUser:(GIDGoogleUser *)user withError:(NSError *)error {
    // Perform any operations on signed in user here.
    NSString *userId = user.userID;                  // For client-side use only!
    NSString *idToken = user.authentication.idToken; // Safe to send to the server
    NSString *name = user.profile.name;
    NSString *email = user.profile.email;
    NSLog(@"Customer details: %@ %@ %@ %@", userId, idToken, name, email);
    // ...
}

- (UIStatusBarStyle)preferredStatusBarStyle {
    return UIStatusBarStyleLightContent;
}

- (void)dealloc {
    [[NSNotificationCenter defaultCenter]
     removeObserver:self
     name:@"ToggleAuthUINotification"
     object:nil];
    
}

- (void) receiveToggleAuthUINotification:(NSNotification *) notification {
    
    @try {
        
        spinner = [[UIActivityIndicatorView alloc]
                   initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
        spinner.frame = CGRectMake(0, 0, 320, 560); // CGPointMake(160, 240);
        spinner.color = [UIColor blueColor];
        spinner.backgroundColor = [UIColor lightTextColor];
        spinner.transform = CGAffineTransformMakeScale(2, 2);
        // spinner.hidesWhenStopped = YES;
        [self.view addSubview:spinner];
        spinner.transform = CGAffineTransformMakeScale(2, 2);
        
        [spinner startAnimating];
        
        // how we stop refresh from freezing the main UI thread
        
        dispatch_async(
                       dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^{
                           
                           // back to the main thread for the UI call
                           dispatch_async(dispatch_get_main_queue(), ^{
                               [spinner startAnimating];
                           });
                           dispatch_async(dispatch_get_main_queue(), ^{
                               
                               
                               
                               if ([[notification name] isEqualToString:@"ToggleAuthUINotification"]) {
                                   
                                   
                                   emaiId = [notification userInfo][@"EmailID"];
                                   NSString *logintype =[notification userInfo][@"LoginType"];
                                   NSString *uniqueIdentifier = [[[UIDevice currentDevice] identifierForVendor] UUIDString];
                                   NSMutableDictionary *emailinfo = [[NSMutableDictionary alloc]init];
                                   [emailinfo setValue:emaiId forKey:@"RegEmail"];
                                   [emailinfo setValue:logintype forKey:@"LoginType"];
                                   [emailinfo setValue:uniqueIdentifier forKey:@"DeviceId"];
                                   
                                   
                                   NSDictionary *response = [mWebService CheckUserAlreadyPresentNew:emailinfo];
                                   
                                   NSMutableArray *arryResponse =response;
                                   
                                   NSString *val = [NSString stringWithFormat:@"%@",[[arryResponse objectAtIndex:0] valueForKey:@"AlreadyPresent"]];
                                   
                                   if ([val isEqualToString:@"1"]) {
                                       
                                       //NSMutableArray *arryResponse =response;
                                       
                                       NSString *BusinessRegID; NSString *IndividualRegID;
                                      
                                               BusinessRegID = [[arryResponse objectAtIndex:0] valueForKey:@"UserRegisterID"];
                                       
                                               IndividualRegID = [[arryResponse objectAtIndex:1] valueForKey:@"UserRegisterID"];
                                       
                                       NSMutableDictionary *registerData = [[NSMutableDictionary alloc]init];
                                       [registerData setValue:@"google" forKey:@"LoginType"];
                                       [registerData setValue:BusinessRegID forKey:USERREGISTERID];
                                       [mPref setObject:registerData forKey:@"LoginType"];
                                       
                                       NSMutableDictionary *registerDatavia = [[NSMutableDictionary alloc]init];
                                       [registerDatavia setValue:[[arryResponse objectAtIndex:0] valueForKey:@"LoginType"] forKey:@"LoginType"];
                                        [mPref setValue:@"Business" forKey:LOGINTYPE];
                                       [registerDatavia setValue:BusinessRegID forKey:USERREGISTERID];
                                       [registerDatavia setValue:[[arryResponse objectAtIndex:0] valueForKey:@"DefaultRadius"] forKey:@"DefaultRadius"];
                                       [registerDatavia setValue:BusinessRegID forKey:@"BusinessRegisterID"];
                                       [registerDatavia setValue:IndividualRegID forKey:@"IndividualRegisterID"];
                                       [registerDatavia setValue:[[arryResponse objectAtIndex:0] valueForKey:@"DefaultRadius"] forKey:@"DefaultRadius"];
                                       [registerDatavia setValue:[[arryResponse objectAtIndex:0] valueForKey:@"UserRegisterID"] forKey:@"UserRegisterID"];
                                       [registerDatavia setValue:[[arryResponse objectAtIndex:0] valueForKey:@"PhotoName"] forKey:@"PhotoName"];
                                       [registerDatavia setValue:[[arryResponse objectAtIndex:0] valueForKey:@"DefaultAddress"] forKey:@"DefaultAddress"];
                                       [registerDatavia setValue:[[arryResponse objectAtIndex:0] valueForKey:@"RegUserName"] forKey:@"RegUserName"];
                                       [registerDatavia setValue:[[arryResponse objectAtIndex:0] valueForKey:@"ContactPerson"] forKey:@"ContactPerson"];
                                       [registerDatavia setValue:[[arryResponse objectAtIndex:0] valueForKey:@"BranchName"] forKey:@"BranchName"];
                                       [registerDatavia setValue:[[arryResponse objectAtIndex:0] valueForKey:@"StoreDescription"] forKey:@"StoreDescription"];
                                       
                                       [registerDatavia setValue:[[arryResponse objectAtIndex:0] valueForKey:@"LoggedUserType"] forKey:@"LoggedUserType"];
                                       [registerDatavia setValue:[[arryResponse objectAtIndex:0] valueForKey:@"ContactPerson"] forKey:@"ContactPerson"];
                                       
                                    
                                       [mPreferences SaveRegisterDeatils:registerDatavia];
                                       
                                     //  NSString *UserRegisterID  = [response valueForKey:USERREGISTERID];
                                       [mPreferences StoreSaveUserRegisterID:BusinessRegID];
                                       
                                       [self PageChange:[mPref valueForKey:@"PageName"]];

                                   }
 
                                   else if ([val isEqualToString:@"0"]){
                                       
                                       
                                       Registration_Types *mRegTypes = [[Registration_Types alloc]initWithNibName:@"Registration_Types" bundle:nil];
                                       
                                       mRegTypes.RegisteredObject =[notification userInfo];

                                       
                                       [self presentViewController:mRegTypes animated:YES completion:nil];
                                       
                                       
                                   }
                                   
                               }
                               [self toggleAuthUI];
                               [spinner stopAnimating];
                               
                           });
                       });
        
    } @catch (NSException *exception) {
        
    } @finally {
        
    }
}


-(void)loginWithFacebook
{
    @try {
        spinner = [[UIActivityIndicatorView alloc]
                   initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
        spinner.frame = CGRectMake(0, 0, 320, 560); // CGPointMake(160, 240);
        spinner.color = [UIColor blueColor];
        spinner.backgroundColor = [UIColor lightTextColor];
        spinner.transform = CGAffineTransformMakeScale(2, 2);
        // spinner.hidesWhenStopped = YES;
        [self.view addSubview:spinner];
        spinner.transform = CGAffineTransformMakeScale(2, 2);
        
        [spinner startAnimating];
        
        // how we stop refresh from freezing the main UI thread
        
        dispatch_async(
                       dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^{
                           
                           // back to the main thread for the UI call
                           dispatch_async(dispatch_get_main_queue(), ^{
                               [spinner startAnimating];
                           });
                           dispatch_async(dispatch_get_main_queue(), ^{
                               
                               if (![FBSDKAccessToken currentAccessToken])
                               {
                                   FBSDKLoginManager *login = [[FBSDKLoginManager alloc] init];
                                   
                                   [login logInWithReadPermissions:@[@"email",@"public_profile",@"user_friends"] handler:^(FBSDKLoginManagerLoginResult *result, NSError *error)
                                    {
                                        if (error)
                                        {
                                            UIAlertController * alert=   [UIAlertController
                                                                          alertControllerWithTitle:@"Error"
                                                                          message:error.localizedDescription
                                                                          preferredStyle:UIAlertControllerStyleAlert];
                                            
                                            
                                            UIAlertAction* okButton = [UIAlertAction
                                                                       actionWithTitle:@"ok"
                                                                       style:UIAlertActionStyleDefault
                                                                       handler:^(UIAlertAction * action)
                                                                       {
                                                                           [alert dismissViewControllerAnimated:YES completion:nil];
                                                                           
                                                                       }];
                                            
                                            [alert addAction:okButton];
                                            
                                            [self presentViewController:alert animated:YES completion:nil];
                                        }
                                        else if (result.isCancelled)
                                        {
                                            UIAlertController * alert=   [UIAlertController
                                                                          alertControllerWithTitle:@"facebook login status"
                                                                          message:@"you cancel the facebook login"
                                                                          preferredStyle:UIAlertControllerStyleAlert];
                                            
                                            UIAlertAction* okButton = [UIAlertAction
                                                                       actionWithTitle:@"ok"
                                                                       style:UIAlertActionStyleDefault
                                                                       handler:^(UIAlertAction * action)
                                                                       {
                                                                           [alert dismissViewControllerAnimated:YES completion:nil];
                                                                           
                                                                       }];
                                            
                                            [alert addAction:okButton];
                                            
                                            [self presentViewController:alert animated:YES completion:nil];
                                        }
                                        else
                                        {
                                            if ([result.grantedPermissions containsObject:@"email,public_profile,user_friends"]) {
                                                NSLog(@"working");
                                            }
                                        }
                                    }];
                               }
                               
                               
                               if([FBSDKAccessToken currentAccessToken])
                               {
                                   NSString *fbAccessToken = [FBSDKAccessToken currentAccessToken].tokenString;
                                   NSLog(@"access token is:%@",fbAccessToken);
                                   [[[FBSDKGraphRequest alloc] initWithGraphPath:@"me" parameters:@{@"fields": @"email,name,first_name,last_name,picture.width(100).height(100)"}]
                                    startWithCompletionHandler:^(FBSDKGraphRequestConnection *connection, id result, NSError *error) {
                                        if (!error) {
                                            emaiId=[result objectForKey:@"email"];
                                            NSString *namestr =[result objectForKey:@"name"];
                                            NSString *firstname = [result objectForKey:@"first_name"];
                                            NSString *lastnamestr = [result objectForKey:@"last_name"];
                                            NSString *imageStringOfLoginUser = [[[result valueForKey:@"picture"] valueForKey:@"data"] valueForKey:@"url"];
                                            
                                            NSString *uniqueIdentifier = [[[UIDevice currentDevice] identifierForVendor] UUIDString];
                                            NSMutableDictionary *emailinfo = [[NSMutableDictionary alloc]init];
                                            [emailinfo setValue:emaiId forKey:@"RegEmail"];
                                            [emailinfo setValue:@"facebook" forKey:@"LoginType"];
                                            [emailinfo setValue:uniqueIdentifier forKey:@"DeviceId"];
                                            
                                            NSDictionary *response = [mWebService CheckUserAlreadyPresentNew:emailinfo];
                                          
                                            NSMutableDictionary *registerDatavia = [[NSMutableDictionary alloc]init];
                                         
                                            
                                            
                                            NSMutableArray *arryResponse =response;
                                            
                                            NSString *val = [NSString stringWithFormat:@"%@",[[arryResponse objectAtIndex:0] valueForKey:@"AlreadyPresent"]];
                                            
                                            if ([val isEqualToString:@"1"]) {
                                                
                                                //NSMutableArray *arryResponse =response;
                                                
                                                NSString *BusinessRegID; NSString *IndividualRegID;
                                                
                                                BusinessRegID = [[arryResponse objectAtIndex:0] valueForKey:@"UserRegisterID"];
                                                
                                                IndividualRegID = [[arryResponse objectAtIndex:1] valueForKey:@"UserRegisterID"];
                                                
                                                NSMutableDictionary *registerData = [[NSMutableDictionary alloc]init];
                                                [registerData setValue:@"facebook" forKey:@"LoginType"];
                                                [registerData setValue:BusinessRegID forKey:USERREGISTERID];
                                                [mPref setObject:registerData forKey:@"LoginType"];
                                                
                                                 [mPref setValue:@"Business" forKey:LOGINTYPE];
                                                //NSMutableDictionary *registerDatavia = [[NSMutableDictionary alloc]init];
                                                [registerDatavia setValue:[[arryResponse objectAtIndex:0] valueForKey:@"LoginType"] forKey:@"LoginType"];
                                                [registerDatavia setValue:BusinessRegID forKey:USERREGISTERID];
                                                [registerDatavia setValue:[[arryResponse objectAtIndex:0] valueForKey:@"DefaultRadius"] forKey:@"DefaultRadius"];
                                                [registerDatavia setValue:BusinessRegID forKey:@"BusinessRegisterID"];
                                                [registerDatavia setValue:IndividualRegID forKey:@"IndividualRegisterID"];
                                                [registerDatavia setValue:[[arryResponse objectAtIndex:0] valueForKey:@"DefaultRadius"] forKey:@"DefaultRadius"];
                                                [registerDatavia setValue:[[arryResponse objectAtIndex:0] valueForKey:@"UserRegisterID"] forKey:@"UserRegisterID"];
                                                [registerDatavia setValue:[[arryResponse objectAtIndex:0] valueForKey:@"PhotoName"] forKey:@"PhotoName"];
                                                [registerDatavia setValue:[[arryResponse objectAtIndex:0] valueForKey:@"DefaultAddress"] forKey:@"DefaultAddress"];
                                                [registerDatavia setValue:[[arryResponse objectAtIndex:0] valueForKey:@"RegUserName"] forKey:@"RegUserName"];
                                                [registerDatavia setValue:[[arryResponse objectAtIndex:0] valueForKey:@"ContactPerson"] forKey:@"ContactPerson"];
                                                [registerDatavia setValue:[[arryResponse objectAtIndex:0] valueForKey:@"BranchName"] forKey:@"BranchName"];
                                                [registerDatavia setValue:[[arryResponse objectAtIndex:0] valueForKey:@"StoreDescription"] forKey:@"StoreDescription"];
                                                [registerDatavia setValue:[[arryResponse objectAtIndex:0] valueForKey:@"LoggedUserType"] forKey:@"LoggedUserType"];
                                                [registerDatavia setValue:[[arryResponse objectAtIndex:0] valueForKey:@"ContactPerson"] forKey:@"ContactPerson"];
                                                
                                                
                                                [mPreferences SaveRegisterDeatils:registerDatavia];
                                                
                                                //NSString *UserRegisterID  = [BusinessRegID valueForKey:USERREGISTERID];
                                                [mPreferences StoreSaveUserRegisterID:BusinessRegID];
                                                
                                                [self PageChange:[mPref valueForKey:@"PageName"]];
                                                
                                            }
                                            
                                            else if ([val isEqualToString:@"0"]){
                                                
                                                NSDictionary *signinResponse = @{@"FullName":namestr,
                                                                                 @"GivenNam":lastnamestr,
                                                                                 @"FamilyName":firstname,
                                                                                 @"EmailID":emaiId,
                                                                                 @"LoginType":@"facebook",
                                                                                 @"systemVersion": [[UIDevice currentDevice] systemVersion],
                                                                                 @"model":[[UIDevice currentDevice] model],
                                                                                 @"ImageUrl":imageStringOfLoginUser
                                                                                 };
                                                
                                                
                                                Registration_Types *mRegTypes = [[Registration_Types alloc]initWithNibName:@"Registration_Types" bundle:nil];
                                                
                                                mRegTypes.RegisteredObject =signinResponse;
                                                [self presentViewController:mRegTypes animated:YES completion:nil];
                                                
                                                
                                            }
                                            
                                            
                                            
                                            
                                            
                                            
//                                            NSString *val = [NSString stringWithFormat:@"%@",[response valueForKey:@"AlreadyPresent"]];
//                                            
//                                            NSMutableDictionary *registerDatavia = [[NSMutableDictionary alloc]init];
//                                            [registerDatavia setValue:@"facebook" forKey:@"LoginType"];
//                                            [registerDatavia setValue:[response valueForKey:USERREGISTERID] forKey:USERREGISTERID];
//                                            [mPref setObject:registerDatavia forKey:@"LoginType"];
//                                            
//                                            
//                                            
//                                            if ([val   isEqualToString:@"1"]) {
//                                                
//                                                NSMutableDictionary *registerDatavia = [[NSMutableDictionary alloc]init];
//                                                [registerDatavia setValue:[response valueForKey:@"LoginType"] forKey:@"LoginType"];
//                                                [registerDatavia setValue:[response valueForKey:USERREGISTERID] forKey:USERREGISTERID];
//                                                [registerDatavia setValue:[response valueForKey:@"DefaultRadius"] forKey:@"DefaultRadius"];
//                                                [registerDatavia setValue:[response valueForKey:@"UserRegisterID"] forKey:@"UserRegisterID"];
//                                                [registerDatavia setValue:[response valueForKey:@"PhotoName"] forKey:@"PhotoName"];
//                                                [registerDatavia setValue:[response valueForKey:@"DefaultAddress"] forKey:@"DefaultAddress"];
//                                                [registerDatavia setValue:[response valueForKey:@"RegUserName"] forKey:@"RegUserName"];
//                                                [registerDatavia setValue:[response valueForKey:@"LoggedUserType"] forKey:@"LoggedUserType"];
//                                                [registerDatavia setValue:[response valueForKey:@"ContactPerson"] forKey:@"ContactPerson"];
//                                                
//                                                
//                                                //Preferences *mPreferences = [Preferences GetSharedInstance];
//                                                
//                                                [mPreferences SaveRegisterDeatils:registerDatavia];
//                                                
//                                                
//                                                
//                                                NSString *UserRegisterID  = [response valueForKey:USERREGISTERID];
//                                                [mPreferences StoreSaveUserRegisterID:UserRegisterID];
//                                                
//                                                Registration_Types *mRegTypes = [[Registration_Types alloc]initWithNibName:@"Registration_Types" bundle:nil];
//                                                
//                                                mRegTypes.RegisteredObject =emailinfo;
//                                                
//                                                
//                                                [self presentViewController:mRegTypes animated:YES completion:nil];
//                                                
//                                                
//                                                //[self PageChange:[mPref valueForKey:@"PageName"]];
//                                            }
//                                            else{
//                                                
//                                                NSDictionary *signinResponse = @{@"FullName":namestr,
//                                                                                 @"GivenNam":lastnamestr,
//                                                                                 @"FamilyName":firstname,
//                                                                                 @"EmailID":emaiId,
//                                                                                 @"LoginType":@"facebook",
//                                                                                 @"systemVersion": [[UIDevice currentDevice] systemVersion],
//                                                                                 @"model":[[UIDevice currentDevice] model],
//                                                                                 @"ImageUrl":imageStringOfLoginUser
//                                                                                 };
//                                                
//                                                
//                                                Registration_Types *mRegTypes = [[Registration_Types alloc]initWithNibName:@"Registration_Types" bundle:nil];
//                                                
//                                                mRegTypes.RegisteredObject =signinResponse;
//                                                
//                                                
//                                                [self presentViewController:mRegTypes animated:YES completion:nil];\
//                                                
//                                                
//                                                
////                                                
////                                                RegisterWithGoogle  *mGoogle = [RegisterWithGoogle alloc];//initWithNibName:@"RegistrationWithGoogle" bundle:nil];
////                                                mGoogle.RegisteredObject =signinResponse;
////                                                RegisterWithGoogle  *mGoogleRegister  =  [mGoogle initWithNibName:@"RegistrationWithGoogle" bundle:nil];
////                                                [self presentViewController:mGoogleRegister animated:YES completion:nil];
//                                                
//                                                
//                                                
//                                                //                                                    NSDictionary *response = [mWebService CheckEmail:emaiId];
//                                                //                                                    if (response!=nil) {
//                                                //                                                        NSString *email = [response valueForKey:@"RegEmail"];
//                                                //                                                        if ([email isEqualToString:@"Test"]) {
//                                                //                                                            NSDictionary *signinResponse = @{@"FullName":namestr,
//                                                //                                                                                             @"GivenNam":lastnamestr,
//                                                //                                                                                             @"FamilyName":firstname,
//                                                //                                                                                             @"EmailID":emaiId,
//                                                //                                                                                             @"LoginType":@"facebook",
//                                                //                                                                                             @"systemVersion": [[UIDevice currentDevice] systemVersion],
//                                                //                                                                                             @"model":[[UIDevice currentDevice] model],
//                                                //                                                                                             @"ImageUrl":imageStringOfLoginUser
//                                                //                                                                                             };
//                                                //
//                                                //                                                            RegisterWithGoogle  *mGoogle = [RegisterWithGoogle alloc];//initWithNibName:@"RegistrationWithGoogle" bundle:nil];
//                                                //                                                            mGoogle.RegisteredObject =signinResponse;
//                                                //                                                            RegisterWithGoogle  *mGoogleRegister  =  [mGoogle initWithNibName:@"RegistrationWithGoogle" bundle:nil];
//                                                //                                                            [self presentViewController:mGoogleRegister animated:YES completion:nil];
//                                                //
//                                                //
//                                                //                                                        }
//                                                //                                                        else{
//                                                //
//                                                //                                                            NSMutableDictionary *loginparams = [[NSMutableDictionary alloc]init];
//                                                //                                                            [loginparams setValue:[response valueForKey:@"RegEmail"]  forKey:@"UserName"];
//                                                //                                                            [loginparams setValue:[response valueForKey:@"Password"] forKey:@"Password"];
//                                                //                                                            NSDictionary *getLoginResponse = [mWebService UserLoginValidation:loginparams];
//                                                //                                                            if (getLoginResponse !=nil) {
//                                                //
//                                                //                                                                //[mPreferences StoreUserName:username.text];
//                                                //                                                                // [mPreferences StorePassword:password.text];
//                                                //                                                                NSString *UserRegisterID  = [getLoginResponse valueForKey:USERREGISTERID];
//                                                //                                                                [mPreferences StoreSaveUserRegisterID:UserRegisterID];
//                                                //
//                                                //                                                                [self PageChange:[mPref valueForKey:@"PageName"]];
//                                                //
//                                                //                                                            }
//                                                //
//                                                //
//                                                //                                                        }
//                                                //
//                                                //                                                    }
//                                                
//                                                
//                                            }
                                            
                                            
                                            
                                            
                                            
                                            
                                            //NSDictionary *response = [mWebService CheckEmail:emaiId];
                                            //                 if (response!=nil) {
                                            //                     NSString *email = [response valueForKey:@"RegEmail"];
                                            //                     if ([email isEqualToString:@"Test"]) {
                                            //
                                            //                         NSDictionary *signinResponse = @{@"FullName":namestr,
                                            //                                                          @"GivenNam":lastnamestr,
                                            //                                                          @"FamilyName":firstname,
                                            //                                                          @"EmailID":emaiId,
                                            //                                                          @"LoginType":@"facebook",
                                            //                                                          @"systemVersion": [[UIDevice currentDevice] systemVersion],
                                            //                                                          @"model":[[UIDevice currentDevice] model],
                                            //                                                          @"ImageUrl":imageStringOfLoginUser
                                            //                                                          };
                                            //
                                            //                         RegisterWithGoogle  *mGoogle = [RegisterWithGoogle alloc];//initWithNibName:@"RegistrationWithGoogle" bundle:nil];
                                            //                         mGoogle.RegisteredObject =signinResponse;
                                            //                         RegisterWithGoogle  *mGoogleRegister  =  [mGoogle initWithNibName:@"RegistrationWithGoogle" bundle:nil];
                                            //                         [self presentViewController:mGoogleRegister animated:YES completion:nil];
                                            //
                                            //                     }
                                            //                     else
                                            //                     {
                                            //
                                            //                         NSMutableDictionary *loginparams = [[NSMutableDictionary alloc]init];
                                            //                         [loginparams setValue:[response valueForKey:@"RegEmail"]  forKey:@"UserName"];
                                            //                         [loginparams setValue:[response valueForKey:@"Password"] forKey:@"Password"];
                                            //                         NSDictionary *getLoginResponse = [mWebService UserLoginValidation:loginparams];
                                            //                         if (getLoginResponse !=nil) {
                                            //
                                            //                             //[mPreferences StoreUserName:username.text];
                                            //                             // [mPreferences StorePassword:password.text];
                                            //                             NSString *UserRegisterID  = [getLoginResponse valueForKey:USERREGISTERID];
                                            //                             [mPreferences StoreSaveUserRegisterID:UserRegisterID];
                                            //
                                            //                             [self PageChange:[mPref valueForKey:@"PageName"]];
                                            //
                                            //                         }
                                            //
                                            //                     }
                                            //
                                            //                 }
                                            
                                            //  [[NSUserDefaults standardUserDefaults] setObject:emailstr forKey:kfbUserID];
                                            [[NSUserDefaults standardUserDefaults]synchronize];
                                        }
                                        [self.navigationController popViewControllerAnimated:YES];
                                    }];
                               }
                               
                               [spinner stopAnimating];
                           });
                       });
        
    } @catch (NSException *exception) {
        
    } @finally {
        
    }
    
    
}

#pragma mark - Private method implementation

-(void)toggleHiddenState:(BOOL)shouldHide{
    NSLog(@"login");
}


#pragma mark - FBLoginView Delegate method implementation

//-(void)loginViewShowingLoggedInUser:(FBLoginView *)loginView{
//    
//    [self toggleHiddenState:NO];
//}
//
//
//-(void)loginViewFetchedUserInfo:(FBLoginView *)loginView user:(id<FBGraphUser>)user{
//    NSLog(@"%@", user);
//    
//}
//
//
//-(void)loginViewShowingLoggedOutUser:(FBLoginView *)loginView{
//    
//    
//    [self toggleHiddenState:YES];
//}
//
//
//-(void)loginView:(FBLoginView *)loginView handleError:(NSError *)error{
//    NSLog(@"%@", [error localizedDescription]);
//}
- (IBAction)toggleLoginState:(id)sender
{
    @try {
        
        if (isOnlineStatus) {
            
            FBSDKLoginButton *loginButton = [[FBSDKLoginButton alloc] init];
            loginButton.center = self.view.center;
            [self loginWithFacebook];
            
            spinner = [[UIActivityIndicatorView alloc]
                       initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
            spinner.frame = CGRectMake(0, 0, 320, 560); // CGPointMake(160, 240);
            spinner.color = [UIColor blueColor];
            spinner.backgroundColor = [UIColor lightTextColor];
            spinner.transform = CGAffineTransformMakeScale(2, 2);
            // spinner.hidesWhenStopped = YES;
            [self.view addSubview:spinner];
            spinner.transform = CGAffineTransformMakeScale(2, 2);
            
            [spinner startAnimating];
            
            // how we stop refresh from freezing the main UI thread
            
            dispatch_async(
                           dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^{
                               
                               // back to the main thread for the UI call
                               dispatch_async(dispatch_get_main_queue(), ^{
                                   [spinner startAnimating];
                               });
                               dispatch_async(dispatch_get_main_queue(), ^{
                                   
                                   
                                   
                                   [[NSRunLoop mainRunLoop] addTimer:self.timer forMode:NSRunLoopCommonModes];
                                   
                                   [spinner stopAnimating];
                               });
                           });
            
            
            
            
        }
        else
        {
            [self showAlertPop:@"No internet connection" exceptionVal:nil];
        }
        
        
    } @catch (NSException *exception) {
        
    } @finally {
        
    }
    
}



-(void)getFacebookDetils
{
    if([FBSDKAccessToken currentAccessToken])
    {
        NSString *fbAccessToken = [FBSDKAccessToken currentAccessToken].tokenString;
        NSLog(@"access token is:%@",fbAccessToken);
        [[[FBSDKGraphRequest alloc] initWithGraphPath:@"me" parameters:@{@"fields": @"email,name,first_name,last_name,picture.width(100).height(100)"}]
         startWithCompletionHandler:^(FBSDKGraphRequestConnection *connection, id result, NSError *error) {
             if (!error) {
                 emaiId=[result objectForKey:@"email"];
                 NSString *namestr =[result objectForKey:@"name"];
                 NSString *firstname = [result objectForKey:@"first_name"];
                 NSString *lastnamestr = [result objectForKey:@"last_name"];
                 NSString *imageStringOfLoginUser = [[[result valueForKey:@"picture"] valueForKey:@"data"] valueForKey:@"url"];
                 
                 NSString *uniqueIdentifier = [[[UIDevice currentDevice] identifierForVendor] UUIDString];
                 NSMutableDictionary *emailinfo = [[NSMutableDictionary alloc]init];
                 [emailinfo setValue:emaiId forKey:@"RegEmail"];
                 [emailinfo setValue:@"facebook" forKey:@"LoginType"];
                 [emailinfo setValue:uniqueIdentifier forKey:@"DeviceId"];
                 
                 NSDictionary *response = [mWebService CheckUserAlreadyPresentNew:emailinfo];
                 //NSString *val = [NSString stringWithFormat:@"%@",[response valueForKey:@"AlreadyPresent"]];
                 
                 NSMutableDictionary *registerDatavia = [[NSMutableDictionary alloc]init];

                 
                 
                 NSMutableArray *arryResponse =response;
                 
                 NSString *val = [NSString stringWithFormat:@"%@",[[arryResponse objectAtIndex:0] valueForKey:@"AlreadyPresent"]];
                 
                 if ([val isEqualToString:@"1"]) {
                     
                     //NSMutableArray *arryResponse =response;
                     
                     NSString *BusinessRegID; NSString *IndividualRegID;
                     
                     BusinessRegID = [[arryResponse objectAtIndex:0] valueForKey:@"UserRegisterID"];
                     
                     IndividualRegID = [[arryResponse objectAtIndex:1] valueForKey:@"UserRegisterID"];
                     
                     NSMutableDictionary *registerData = [[NSMutableDictionary alloc]init];
                     [registerData setValue:@"facebook" forKey:@"LoginType"];
                     [registerData setValue:BusinessRegID forKey:USERREGISTERID];
                     [mPref setObject:registerData forKey:@"LoginType"];
                     
                     NSMutableDictionary *registerDatavia = [[NSMutableDictionary alloc]init];
                     [registerDatavia setValue:[[arryResponse objectAtIndex:0] valueForKey:@"LoginType"] forKey:@"LoginType"];
                     [registerDatavia setValue:BusinessRegID forKey:USERREGISTERID];
                     [registerDatavia setValue:[[arryResponse objectAtIndex:0] valueForKey:@"DefaultRadius"] forKey:@"DefaultRadius"];
                     [registerDatavia setValue:BusinessRegID forKey:@"BusinessRegisterID"];
                      [mPref setValue:@"Business" forKey:LOGINTYPE];
                     [registerDatavia setValue:IndividualRegID forKey:@"IndividualRegisterID"];
                     [registerDatavia setValue:[[arryResponse objectAtIndex:0] valueForKey:@"DefaultRadius"] forKey:@"DefaultRadius"];
                     [registerDatavia setValue:[[arryResponse objectAtIndex:0] valueForKey:@"UserRegisterID"] forKey:@"UserRegisterID"];
                     [registerDatavia setValue:[[arryResponse objectAtIndex:0] valueForKey:@"PhotoName"] forKey:@"PhotoName"];
                     [registerDatavia setValue:[[arryResponse objectAtIndex:0] valueForKey:@"DefaultAddress"] forKey:@"DefaultAddress"];
                     [registerDatavia setValue:[[arryResponse objectAtIndex:0] valueForKey:@"RegUserName"] forKey:@"RegUserName"];
                     [registerDatavia setValue:[[arryResponse objectAtIndex:0] valueForKey:@"LoggedUserType"] forKey:@"LoggedUserType"];
                     [registerDatavia setValue:[[arryResponse objectAtIndex:0] valueForKey:@"ContactPerson"] forKey:@"ContactPerson"];
                     [registerDatavia setValue:[[arryResponse objectAtIndex:0] valueForKey:@"BranchName"] forKey:@"BranchName"];
                     [registerDatavia setValue:[[arryResponse objectAtIndex:0] valueForKey:@"StoreDescription"] forKey:@"StoreDescription"];
                     
                     [registerDatavia setValue:[[arryResponse objectAtIndex:0] valueForKey:@"ContactPerson"] forKey:@"ContactPerson"];
                     
                     
                     [mPreferences SaveRegisterDeatils:registerDatavia];
                     
                     //NSString *UserRegisterID  = [response valueForKey:USERREGISTERID];
                     [mPreferences StoreSaveUserRegisterID:BusinessRegID];
                     
                     [self PageChange:[mPref valueForKey:@"PageName"]];
                     
                 }
                 
                 else if ([val isEqualToString:@"0"]){
                     
                     NSDictionary *signinResponse = @{@"FullName":namestr,
                                                      @"GivenNam":lastnamestr,
                                                      @"FamilyName":firstname,
                                                      @"EmailID":emaiId,
                                                      @"LoginType":@"facebook",
                                                      @"systemVersion": [[UIDevice currentDevice] systemVersion],
                                                      @"model":[[UIDevice currentDevice] model],
                                                      @"ImageUrl":imageStringOfLoginUser
                                                      };

                     
                     Registration_Types *mRegTypes = [[Registration_Types alloc]initWithNibName:@"Registration_Types" bundle:nil];
                     
                     mRegTypes.RegisteredObject =signinResponse;
                     [self presentViewController:mRegTypes animated:YES completion:nil];
                     
                     
                 }
                 //  [[NSUserDefaults standardUserDefaults] setObject:emailstr forKey:kfbUserID];
                 [[NSUserDefaults standardUserDefaults]synchronize];
             }
             [self.navigationController popViewControllerAnimated:YES];
         }];
    }
}

-(void)onTick:(NSTimer*)timervalidate
{
    NSLog(@"Tick-----");
    
    
    [self getFacebookDetils];
    
}



@end
