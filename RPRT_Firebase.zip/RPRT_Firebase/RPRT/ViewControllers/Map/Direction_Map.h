//
//  Direction_Map.h
//  RPRT
//
//  Created by sravanthi Gumma on 01/06/16.
//  Copyright © 2016 DevpointSolutions. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreLocation/CoreLocation.h>
#import "MyMapAnnot.h"
#import <MapKit/MapKit.h>
#import "AppDelegate.h"
@interface Direction_Map : UIViewController<MKMapViewDelegate,CLLocationManagerDelegate>
{
    NSDictionary *address;
    CLLocationManager *locationManager;
    CLLocationCoordinate2D coordinate;
    MyMapAnnot *mapAnnotObject;
    int currenDist;
    BOOL firstLaunch;
    NSString *lat;
    
}
@property (strong, nonatomic)  NSDictionary *direction;

-(IBAction)back:(id)sender;

@end
