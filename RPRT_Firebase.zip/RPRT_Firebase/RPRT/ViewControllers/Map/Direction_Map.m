//
//  Direction_Map.m
//  RPRT
//
//  Created by sravanthi Gumma on 01/06/16.
//  Copyright © 2016 DevpointSolutions. All rights reserved.
//

#import "Direction_Map.h"
#import <CoreLocation/CoreLocation.h>
#import "MyMapAnnot.h"
#import "MapView.h"
#import <MapKit/MapKit.h>
#import "RegexKitLite.h"
#import "Web_Services.h"

@interface Direction_Map ()
{
    Web_Services *mWebService;
}

@end

@implementation Direction_Map
//@synthesize mapView;
- (void)viewDidLoad {
    @try {
        
//        Reachability *networkReachability = [Reachability reachabilityForInternetConnection];
//        NetworkStatus networkStatus = [networkReachability currentReachabilityStatus];
//        if (networkStatus == NotReachable) {
//            
//            isOnlineStatus = NO;
//            
//        } else  if (networkStatus == ReachableViaWiFi) {
//            
//            isOnlineStatus = YES;
//        }
//        else if (networkStatus == ReachableViaWWAN) {
//            isOnlineStatus = YES;
//            
//        }
        
        if (isOnlineStatus) {

        
        
        mWebService= [Web_Services GetSharedInstance];
    [super viewDidLoad];
    address = self.direction;
    [self address];
        [self.view layoutIfNeeded];
        }
        
        else if (!isOnlineStatus)
        {
            [self showAlertPop:@"No internet connection" exceptionVal:nil];
        }
    // Do any additional setup after loading the view from its nib.
    }
    @catch (NSException *exception) {
        [self showAlertPop:@"Invalid UserName." exceptionVal:exception];
    }
    @finally {
        
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



- (void)address
{
    
    
    @try {
        
        if (isOnlineStatus) {
            
        
        
        
        //address = notification.userInfo;
        
        MapView* mapView = [[MapView alloc] initWithFrame:
                            CGRectMake(0, 70, self.view.frame.size.width, 600)];// autorelease];
        
        mapView.translatesAutoresizingMaskIntoConstraints = YES;
        
        //NSDictionary *geo = [address objectForKey:@"geometry"];
       // NSDictionary *loc = [geo objectForKey:@"location"];
            
            if (![[address valueForKey:@"LatLong"] isEqualToString:@""]) {
                NSArray *latlong = [[address valueForKey:@"LatLong"] componentsSeparatedByString:@","];// = "17.47367368,78.55762";
                coordinate.latitude=[[latlong objectAtIndex:0] doubleValue];
                coordinate.longitude=[[latlong objectAtIndex:1] doubleValue];
            }
            else
            {
                coordinate.latitude=[[address objectForKey:LATITUDE] doubleValue];
                coordinate.longitude=[[address objectForKey:LONGITUDE] doubleValue];
            }
        
        locationManager = [[CLLocationManager alloc] init];
        locationManager.delegate = self;
        [locationManager setDesiredAccuracy:kCLLocationAccuracyBest];
        if ([[[UIDevice currentDevice] systemVersion] floatValue] >= 8) {
            [locationManager requestAlwaysAuthorization];
        }
        if ([[[UIDevice currentDevice] systemVersion] floatValue] >= 9.2) {
            // locationManager.allowsBackgroundLocationUpdates = YES;
        }
        [locationManager startUpdatingLocation];
        CLLocation *location = [locationManager location];
        
        CLLocationCoordinate2D coordinate1 = [location coordinate];
        [self.view addSubview:mapView];
        
        Place* home = [[Place alloc] init];
        home.name = [address objectForKey:@"VendorName"];
        home.description =[NSString stringWithFormat:@"%@,%@,%@,%@", [address objectForKey:@"Address1"],[address objectForKey:@"Address3"],[address objectForKey:@"AreaName"],[address objectForKey:@"City"]];
        home.latitude = coordinate.latitude;
        home.longitude =  coordinate.longitude;
        
        Place* office = [[Place alloc] init];
        office.name = @"You";
        office.description = @"Current place";
        office.latitude = coordinate1.latitude;
        office.longitude = coordinate1.longitude;
        
        
        [mapView showRouteFrom:home to:office];
        
        }
        else if (!isOnlineStatus)
        {
            [self showAlertPop:@"No internet connection" exceptionVal:nil];
        }
        
    }
    @catch (NSException *exception) {
        [self showAlertPop:@"Invalid UserName." exceptionVal:exception];
    }
    @finally {
        
    }
    
}

- (void)mapView:(MKMapView *)mv didAddAnnotationViews:(NSArray *)views
{
    @try {
        
        MKAnnotationView *annotationView = [views objectAtIndex:0];
        annotationView.image=[UIImage imageNamed:@"ic_food.png"];
        id <MKAnnotation> mp = [annotationView annotation];
        MKCoordinateRegion region = MKCoordinateRegionMakeWithDistance
        ([mp coordinate], 400, 400);
        [mv setRegion:region animated:YES];
        [mv selectAnnotation:mp animated:YES];
        
    }
    @catch (NSException *exception) {
        [self showAlertPop:@"Invalid UserName." exceptionVal:exception];
    }
    @finally {
        
    }
    
}


-(IBAction)back:(id)sender
{
    @try {
        
    [self dismissViewControllerAnimated:YES completion:nil];
    }
    @catch (NSException *exception) {
        [self showAlertPop:@"Invalid UserName." exceptionVal:exception];
    }
    @finally {
        
    }
}
- (void) showAlertPop:(NSString*)alertText exceptionVal:(NSException*)ex {
    //mWeservice
    UIAlertController *myAlertController =[mWebService  alert:alertText];
    [self presentViewController:myAlertController animated:YES completion:nil];
    if(ex != nil)
    {
        NSLog(@"%@", ex.description);
    }
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
