//
//  Map.h
//  RPRT
//
//  Created by sravanthi Gumma on 08/01/16.
//  Copyright © 2016 DevpointSolutions. All rights reserved.
//


#import <MapKit/MapKit.h>
#import "Opportunity_DeatilsController.h"

@interface Map : UIViewController<MKMapViewDelegate,CLLocationManagerDelegate>
{
    CLLocationManager *locationManager;
    CLLocationCoordinate2D currentCentre;
    int currenDist;
    BOOL firstLaunch;
    NSInteger IndexRow;
    NSMutableArray *GetAllOpportunities;
    
  
}
@property (nonatomic,strong)  NSMutableArray *SetOpportunities;
@property (assign, nonatomic)  NSInteger Index;
@property (strong, nonatomic) IBOutlet MKMapView *mapView;



@property(weak,nonatomic) IBOutlet UIView *toolBarView;

@property(weak,nonatomic) IBOutlet UISearchBar *searchbar;

@end
