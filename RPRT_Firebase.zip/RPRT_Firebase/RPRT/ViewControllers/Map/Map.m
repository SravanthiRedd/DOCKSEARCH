//
//  Map.m
//  RPRT
//
//  Created by sravanthi Gumma on 08/01/16.
//  Copyright © 2016 DevpointSolutions. All rights reserved.
//

#import "Map.h"
#import "MapPoint.h"
#import "Home.h"
@interface Map ()<UISearchBarDelegate,UITableViewDelegate,UITableViewDataSource>
{
    Web_Services *mWebService;
    NSUserDefaults *mPref;
     GeoCodeLocation *Addre;
    NSString *Address;
    UIActivityIndicatorView *spinner;
    NSString *imageName;
    UITableView *table;
    BOOL isSearching;
    NSMutableArray *autocompleteUrls;
    CurrentLocation *clocation;
    
    
}
@end

@implementation Map
@synthesize mapView,toolBarView;
- (void)viewDidLoad {
    
    @try {
        [super viewDidLoad];
       
        imageName = @"";
     mPref = [NSUserDefaults standardUserDefaults];
     [self loadToolbar];
        //NSMutableArray *arra = self.SetOpportunities;
        
       //GetAllOpportunities = self.SetOpportunities;
       // NSLog(@"%@ Latlong",GetAllOpportunities);
       // if (GetAllOpportunities.count>0) {
       //       [self plotPositions:GetAllOpportunities];
       // }
        
    
    mapView.delegate = self;
        mWebService = [Web_Services GetSharedInstance];
    // Ensure that we can view our own location in the map view.
    [mapView setShowsUserLocation:YES];
    
          clocation=[CurrentLocation GetSharedInstance];
        
    //Instantiate a location object.
    
    locationManager = [[CLLocationManager alloc] init];
    locationManager.delegate = self;
    [locationManager setDesiredAccuracy:kCLLocationAccuracyBest];
    if ([[[UIDevice currentDevice] systemVersion] floatValue] >= 8) {
        [locationManager requestAlwaysAuthorization];
    }
    if ([[[UIDevice currentDevice] systemVersion] floatValue] >= 9.2) {
        //locationManager.allowsBackgroundLocationUpdates = YES;
    }
    [locationManager startUpdatingLocation];
    
    CLLocation *location = [locationManager location];
   // coordinate = [location coordinate];
    CLLocationCoordinate2D centre = [mapView centerCoordinate];
    MKCoordinateRegion region;
    if (firstLaunch) {
        region = MKCoordinateRegionMakeWithDistance(locationManager.location.coordinate,100,100);
        firstLaunch=YES;
    }else {
        //Set the center point to the visible region of the map and change the radius to match the search radius passed to the Google query string.
        MKMapRect mRect = self.mapView.visibleMapRect;
        MKMapPoint eastMapPoint = MKMapPointMake(MKMapRectGetMinX(mRect), MKMapRectGetMidY(mRect));
        MKMapPoint westMapPoint = MKMapPointMake(MKMapRectGetMaxX(mRect), MKMapRectGetMidY(mRect));
        currenDist = MKMetersBetweenMapPoints(eastMapPoint, westMapPoint);
        //region = MKCoordinateRegionMakeWithDistance(locationManager.location.coordinate,1500,1500);
        region = MKCoordinateRegionMakeWithDistance(centre,15000,15000);
    }
        
        
    //Set the visible region of the map.
   
    [mapView setRegion:region animated:YES];
      self.mapView.centerCoordinate = location.coordinate;
        
        NSString *locationstring = [mPref valueForKey:@"StoredAddress"];
        [self showCurrentLocationAddress:locationstring];
        
        
        UITapGestureRecognizer *longPressGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(MapviewLongPress:)];
        longPressGesture.numberOfTapsRequired= 1;
        [mapView addGestureRecognizer:longPressGesture];
        
       table =[[UITableView alloc]initWithFrame:CGRectMake(10, 115, 320, 250) style:UITableViewStylePlain];
        table.delegate= self;
        table.dataSource= self;
        table.scrollEnabled= YES;
        table.hidden= YES;
        [self.view addSubview:table];
        
        
        
    }
    @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." exceptionVal:exception];
    }
    @finally {
        
    }

}

-(void)showCurrentLocationAddress:(NSString*)locatioString
{
    @try {
        
    
    if (locatioString!=nil) {
    
    CLLocationCoordinate2D center   =  [clocation getLocationFromAddressString:locatioString];
    
    Addre = [clocation geoCodeArea:&center.latitude Longitude:&center.longitude];
    
    [self AddMarkertoMap:center.latitude lon:center.longitude coordinate:center];
    [mPref setValue:[NSString stringWithFormat:@"%@,%@,%@",Addre.Address1,Addre.Address2,Addre.Address3] forKey:@"StoredAddress"];
    [table setHidden:YES];
    [self.searchbar resignFirstResponder];
        
        
        for (id<MKAnnotation> annotation in mapView.annotations){
            MKAnnotationView* anView = [mapView viewForAnnotation: annotation];
            if (anView){
                [mapView removeAnnotation:annotation];
            }
        }
        
        CLLocationCoordinate2D coord = CLLocationCoordinate2DMake(center.latitude, center.longitude);
        
        MKCoordinateSpan span = MKCoordinateSpanMake(0.1, 0.1);
        MKCoordinateRegion region = {coord, span};
        
        MKPointAnnotation *annotation = [[MKPointAnnotation alloc] init];
        [annotation setCoordinate:coord];
        
        [self.mapView setRegion:region];
        [self.mapView addAnnotation:annotation];
        
    }
        
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." exceptionVal:exception];
    } @finally {
        
    }
    
}


-(void)loadToolbar
{
    @try {
        
    
    
        NSData *colorData= [mPref valueForKey:@"COLOR"];
if (colorData == nil) {
            toolBarView.backgroundColor= [UIColor colorWithRed:0/256.0 green:186.0/256.0 blue:210/256.0 alpha:1];
        }
        else
          toolBarView.backgroundColor = [NSKeyedUnarchiver unarchiveObjectWithData:colorData];
        
    }
    @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." exceptionVal:exception];
    }
    @finally {
        
    }

}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(IBAction)Back:(id)sender
{
    @try {
   
        spinner = [[UIActivityIndicatorView alloc]
                   initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
        spinner.frame = CGRectMake(0, 0, 320, 560); // CGPointMake(160, 240);
        spinner.color = [UIColor blueColor];
        spinner.backgroundColor = [UIColor lightTextColor];
        spinner.transform = CGAffineTransformMakeScale(2, 2);
        // spinner.hidesWhenStopped = YES;
        [self.view addSubview:spinner];
        spinner.transform = CGAffineTransformMakeScale(2, 2);
        
        [spinner startAnimating];
        
        // how we stop refresh from freezing the main UI thread
        
        dispatch_async(
                       dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^{
                           
                           // back to the main thread for the UI call
                           dispatch_async(dispatch_get_main_queue(), ^{
                               
                               
                               [spinner startAnimating];
                           });
                           dispatch_async(dispatch_get_main_queue(), ^{
                              
                               if ([[mPref valueForKey:@"Page"] isEqualToString:@"List"]) {
                                   
                                   Opportunity_List_New *mHome = [[Opportunity_List_New alloc]initWithNibName:OPPORTUNITYLISTNEW bundle:nil];
                                   [self presentViewController:mHome animated:YES completion:nil];
                                   
                               }
                               else if([[mPref valueForKey:@"Page"] isEqualToString:@"Home"])
                               {
                                   Home *mHome = [[Home alloc]initWithNibName:HOMEDASHBOARD bundle:nil];
                                   [self presentViewController:mHome animated:YES completion:nil];
                               }
                               
                               [spinner stopAnimating];
                               
                           });
                       });
            
 //[self dismissViewControllerAnimated:YES completion:NULL];
    
    }
    @catch (NSException *exception) {
            [self showAlertPop:@"Error while fetching data." exceptionVal:exception];
    }
    @finally {
            
        }

}
- (void) showAlertPop:(NSString*)alertText exceptionVal:(NSException*)ex {
    //mWeservice
    UIAlertController *myAlertController =[mWebService  alert:alertText];
    [self presentViewController:myAlertController animated:YES completion:nil];
    if(ex != nil)
    {
        NSLog(@"%@", ex.description);
    }
}


#pragma mark - Toolbarbuttons

#pragma mark - MKMapViewDelegate methods.

- (void)plotPositions:(NSMutableArray *)data
{
    @try {
        
        //Remove any existing custom annotations but not the user location blue dot.
        for (id<MKAnnotation> annotation in mapView.annotations)
        {
            if ([annotation isKindOfClass:[MapPoint class]])
            {
                [mapView removeAnnotation:annotation];
            }
        }
        
        
        //Loop through the array of places returned from the Google API.
        for (int i=0; i<[data count]; i++)
        {
            
            //Retrieve the NSDictionary object in each index of the array.
            NSDictionary* place = [data objectAtIndex:i];
            
            
            
            //Get our name and address info for adding to a pin.
            NSString *name=[place objectForKey:@"VendorName"];
            
            
            NSString *vicinity= [NSString stringWithFormat:@"%@,%@,%@,%@,%@",[place objectForKey:@"Address1"] ,[place objectForKey:@"Address2"],[place objectForKey:@"Address3"],[place objectForKey:@"City"],[place objectForKey:@"Country"]];
            
            CLLocationCoordinate2D coordinate;
            
            //Set the lat and long.
            coordinate.latitude=[[place objectForKey:LATITUDE] doubleValue];
            coordinate.longitude=[[place objectForKey:LONGITUDE] doubleValue];
            
            //Create a new annotiation.
            MapPoint *placeObject = [[MapPoint alloc] initWithName:name address:vicinity coordinate:coordinate];
            
            if ([place valueForKey:FOOD]) {
                imageName= @"";
            }
            
            [mapView addAnnotation:placeObject];
            
            
        }
        
    }
    @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." exceptionVal:exception];
    }
    @finally {
        
    }
    
    
}


- (MKOverlayView *)mapView:(MKMapView *)map viewForOverlay:(id <MKOverlay>)overlay
{
    
    @try {

        MKCircleRenderer *circleView = [[MKCircleRenderer alloc] initWithOverlay:overlay];
        circleView.strokeColor = [UIColor blueColor];
        circleView.fillColor = [[UIColor blueColor] colorWithAlphaComponent:0.4];
        circleView.lineWidth = 2;
        
    }
    @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." exceptionVal:exception];
    }
    @finally {
        
    }
    
}


- (void)mapView:(MKMapView *)mv didAddAnnotationViews:(NSArray *)views
{
    @try {
        
        //Zoom back to the user location after adding a new set of annotations.
        
        //Get the center point of the visible map.
        CLLocationCoordinate2D centre = [mv centerCoordinate];
        
        MKCoordinateRegion region;
        
        //If this is the first launch of the app then set the center point of the map to the user's location.
        if (firstLaunch) {
            region = MKCoordinateRegionMakeWithDistance(locationManager.location.coordinate,1000,1000);
            firstLaunch=NO;
        }else {
            //Set the center point to the visible region of the map and change the radius to match the search radius passed to the Google query string.
            region = MKCoordinateRegionMakeWithDistance(centre,currenDist,currenDist);
        }
        
        //Set the visible region of the map.
        [mv setRegion:region animated:YES];
    }
    @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." exceptionVal:exception];
    }
    @finally {
        
    }
    
}

-(void)MapviewLongPress:(UIGestureRecognizer*)sender {
    
    @try {
              CGPoint point = [sender locationInView:self.mapView];
        NSMutableArray * annotationsToRemove = [ self.mapView.annotations mutableCopy ] ;
        [ annotationsToRemove removeObject:self.mapView.userLocation ] ;
        [ self.mapView removeAnnotations:annotationsToRemove ] ;
        CLLocationCoordinate2D coordinate= [self.mapView convertPoint:point toCoordinateFromView:self.mapView];
        double lat = coordinate.latitude;
        double lon = coordinate.longitude;
        Addre = [[CurrentLocation GetSharedInstance]geoCodeArea:&lat Longitude:&lon];
        [self AddMarkertoMap:lat lon:lon coordinate:coordinate];
        
        [mPref setValue:[NSString stringWithFormat:@"%@,%@,%@",Addre.Address1,Addre.Address2,Addre.Address3] forKey:@"StoredAddress"];
        self.searchbar.text= [NSString stringWithFormat:@"%@,%@,%@",Addre.Address1,Addre.Address2,Addre.Address3];
        

        
       
    } @catch (NSException *exception) {
      [self showAlertPop:@"Error while fetching data." exceptionVal:exception];
    } @finally {
        
    }

}

-(void)AddMarkertoMap:(double)Lat lon:(double)lon coordinate:(CLLocationCoordinate2D)coordinate {
    @try {
        //CLGeocoder *ceo = [[CLGeocoder alloc]init];
       // CLLocation *loc = [[CLLocation alloc]initWithLatitude:Lat longitude:lon]; //insert your coordinates
        MKPointAnnotation *point1 = [[MKPointAnnotation alloc] init];
        point1.coordinate = coordinate;
        point1.title = Addre.AreaName;
        point1.subtitle =Addre.AreaName;
        
        
           [self.mapView addAnnotation:point1];
    } @catch (NSException *exception) {
       [self showAlertPop:@"Error while fetching data." exceptionVal:exception];
    } @finally {
        
    }
}




-(void)disclosureTapped
{
    NSLog(@"Hi");
}

- (void)mapView:(MKMapView *)mapView regionDidChangeAnimated:(BOOL)animated {
    
    
    @try {
        
        
        //Get the east and west points on the map so we calculate the distance (zoom level) of the current map view.
        MKMapRect mRect = self.mapView.visibleMapRect;
        MKMapPoint eastMapPoint = MKMapPointMake(MKMapRectGetMinX(mRect), MKMapRectGetMidY(mRect));
        MKMapPoint westMapPoint = MKMapPointMake(MKMapRectGetMaxX(mRect), MKMapRectGetMidY(mRect));
        
        
        //Set our current distance instance variable.
        currenDist = MKMetersBetweenMapPoints(eastMapPoint, westMapPoint);
        
        //Set our current centre point on the map instance variable.
        currentCentre = self.mapView.centerCoordinate;
        
        
    }
    @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." exceptionVal:exception];
    }
    @finally {
        
    }
}

- (void)searchBarTextDidBeginEditing:(UISearchBar *)searchBar {
    isSearching = YES;
}

- (void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)seachtext {
    NSLog(@"Text change - %d",isSearching);
    
    //Remove all objects first.
    // [filteredContentList removeAllObjects];
    
    
    table.hidden = YES;
    
    if ([seachtext isEqualToString:@""]) {
        table.hidden= YES;
    }
    else if ([seachtext length]!=0)
    {
    
    NSString *substring = [NSString stringWithString:seachtext];
//    substring = [substring
//                 stringByReplacingCharactersInRange:range withString:string];
    [self searchAutocompleteEntriesWithSubstring:substring];
         table.hidden = NO;
        
    }
   // return YES;

    
    
    
//    if([seachtext length] != 0) {
//        isSearching = YES;
//        [self seachOffer:seachtext];
//    }
//    else if([seachtext length]==0)
//    {
//        GetOffers = opportunityArray;
//        [table reloadData];
//    }
//    else {
//        isSearching = NO;
//    }
    // [self.tblContentList reloadData];
}

- (void)searchAutocompleteEntriesWithSubstring:(NSString *)substring {
    @try {
        // Put anything that starts with this substring into the autocompleteUrls array
        // The items in this array is what will show up in the table view
        NSString* urlpath;
        if (![substring isEqual:@""])
            //https://maps.googleapis.com/maps/api/place/autocomplete/json?key=AIzaSyBsB3SN513YgmJxs-md1zA2zWPgktPhczU&input=am
        {
            
            
            if (isOnlineStatus) {
                
                
                
                
                // urlpath = [NSString stringWithFormat:@"https://maps.googleapis.com/maps/api/place/autocomplete/json?key=AIzaSyBsB3SN513YgmJxs-md1zA2zWPgktPhczU&input=%@",substring];
                
                urlpath = [NSString stringWithFormat:@"https://maps.googleapis.com/maps/api/place/autocomplete/json?key=AIzaSyAM5zyy3xsgRWpye3fmXLEK1Hm18E_tj98&input=%@",substring];
                
                NSString *escapedUrlString =[urlpath stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet URLFragmentAllowedCharacterSet]];// [urlpath stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
                
                
                NSURL *RPRTUrlpath = [NSURL URLWithString:escapedUrlString];
                
                NSData *myData = [NSData dataWithContentsOfURL:RPRTUrlpath];
                
                NSError* error1;
                
                NSDictionary    * autocompleteUrls1 = [NSJSONSerialization
                                                       JSONObjectWithData:myData
                                                       options:kNilOptions
                                                       error:&error1];
                NSString  *prediction = [autocompleteUrls1 valueForKey:@"predictions"];
                autocompleteUrls = [prediction valueForKey:@"description"];
                
                [table reloadData];
            }
            else if (!isOnlineStatus)
            {
                //[self showAlertPop:@"No internet connection" expObj:nil];
            }
            
        }
        else  if ([substring isEqual:@""])
            
        {
            
        }
        
    }
    @catch (NSException *exception) {
        NSLog(@"Exception %@",exception);
    }
    @finally {
        
    }
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)theTableView
{
    return 1;
}

// number of row in the section, I assume there is only 1 row
- (NSInteger)tableView:(UITableView *)theTableView numberOfRowsInSection:(NSInteger)section
{
    return [autocompleteUrls count];
}

// the cell will be returned to the tableView
- (UITableViewCell *)tableView:(UITableView *)theTableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *cellIdentifier = @"cell";
    
    // Similar to UITableViewCell, but
    UITableViewCell *cell = (UITableViewCell *)[theTableView dequeueReusableCellWithIdentifier:cellIdentifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
    }
    // Just want to test, so I hardcode the data
    cell.textLabel.text =[autocompleteUrls objectAtIndex:indexPath.row];// @"Testing";
    
    return cell;
}



-(void)searchBarSearchButtonClicked:(UISearchBar *)searchBar
{
    [self.searchbar resignFirstResponder];
}





//- (void)seachOffer:(NSString *)substring {
//    @try {
//        // Put anything that starts with this substring into the autocompleteUrls array
//        // The items in this array is what will show up in the table view
//        NSPredicate *predicate = [NSPredicate predicateWithFormat:@"SELF contains [cd] %@", substring];
//        NSArray  *results = [opporArray filteredArrayUsingPredicate:predicate];
//        if ([results count]!=0) {
//            
//            NSMutableArray *array = [[NSMutableArray alloc]init];
//            
//
//            for (int i=0; i<[results count]; i++) {
//                NSString  *str= [results objectAtIndex:i];
//                
//                for (int j=0; j<[GetOffers count]; j++) {
//                    NSString *str2 = [[GetOffers objectAtIndex:j]  valueForKey:@"OpportunityName"];
//                    if ([str isEqualToString:str2]) {
//                        [array addObject:[GetOffers objectAtIndex:j]];
//                    }
//                }
//                
//            }
//            
//            NSOrderedSet *orderedSet = [NSOrderedSet orderedSetWithArray:array];
//            GetOffers = [orderedSet mutableCopy];
//            
//            
//            
//            
//            // GetRetailerOpp = array;
//            
//            [opportunityTable reloadData];
//            
//        }
//        //[autoComplete reloadData];
//    } @catch (NSException *exception) {
//        [self showAlertPop:@"Error while fetching data." expObj:exception];
//    } @finally {
//        
//    }
//}

- (void)tableView:(UITableView *)theTableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
   
    @try {
        
    
    // NSLog(@"selected %d row", indexPath.row);
    
  
    //CLLocationCoordinate2D center;
    self.searchbar.text=[autocompleteUrls objectAtIndex:indexPath.row];
    
    CLLocationCoordinate2D center   =  [clocation getLocationFromAddressString:[autocompleteUrls objectAtIndex:indexPath.row]];
    
    Addre = [clocation geoCodeArea:&center.latitude Longitude:&center.longitude];
    
    [self AddMarkertoMap:center.latitude lon:center.longitude coordinate:center];
    [mPref setValue:[NSString stringWithFormat:@"%@,%@,%@",Addre.Address1,Addre.Address2,Addre.Address3] forKey:@"StoredAddress"];
    [table setHidden:YES];
    [self.searchbar resignFirstResponder];
        
        for (id<MKAnnotation> annotation in mapView.annotations){
            MKAnnotationView* anView = [mapView viewForAnnotation: annotation];
            if (anView){
                [mapView removeAnnotation:annotation];
            }
        }
        
        
        
        CLLocationCoordinate2D coord = CLLocationCoordinate2DMake(center.latitude, center.longitude);
        
        MKCoordinateSpan span = MKCoordinateSpanMake(0.1, 0.1);
        MKCoordinateRegion region = {coord, span};
        
        MKPointAnnotation *annotation = [[MKPointAnnotation alloc] init];
        [annotation setCoordinate:coord];
        
        [self.mapView setRegion:region];
        [self.mapView addAnnotation:annotation];
        
        
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." exceptionVal:exception];
    } @finally {
        
    }
    
   // [mPref setValue:[NSString stringWithFormat:@"%@,%@,%@",Addre
}






@end
