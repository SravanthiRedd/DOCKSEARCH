//
//  ContactForm.h
//  RPRT
//
//  Created by sravanthi Gumma on 03/09/1938 Saka.
//  Copyright © 1938 Saka DevpointSolutions. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ContactForm : UIViewController


@property(strong,nonatomic) NSDictionary *EditedContact;
@property(weak,nonatomic) IBOutlet UIView *mobile;
@property(weak,nonatomic) IBOutlet UIView *name;
@property(weak,nonatomic) IBOutlet UIView *email;
@property(weak,nonatomic) IBOutlet UITextField *txtmobile;
@property(weak,nonatomic) IBOutlet UITextField *txtname;
@property(weak,nonatomic) IBOutlet UITextField *txtemail;
@property(strong,nonatomic) IBOutlet UIButton *BtnSaveCon;
@property(weak,nonatomic) IBOutlet UIImageView *profile;


@property(weak,nonatomic) IBOutlet UIView *contentView;
@property(weak,nonatomic) IBOutlet UIScrollView *scrollView;

@end
