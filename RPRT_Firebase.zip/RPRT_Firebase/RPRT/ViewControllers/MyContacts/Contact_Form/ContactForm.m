//
//  ContactForm.m
//  RPRT
//
//  Created by sravanthi Gumma on 03/09/1938 Saka.
//  Copyright © 1938 Saka DevpointSolutions. All rights reserved.
//

#import "ContactForm.h"
#import "Web_Services.h"
#import "Constances.h"
#import "MyContacts.h"
#import "MainViewController.h"
@interface ContactForm ()<UIImagePickerControllerDelegate,UINavigationControllerDelegate,UITextFieldDelegate>
{
    Web_Services *mWebService;
    NSDictionary *GetEditContact;
    NSString *CustomerID;
    NSUserDefaults *mPref;
    NSString *encodecImage;
}

@end

@implementation ContactForm

- (void)viewDidLoad {
    [super viewDidLoad];
    CustomerID= @"";
    encodecImage = @"";
    
    mWebService = [Web_Services GetSharedInstance];
    mPref = [NSUserDefaults standardUserDefaults];
    GetEditContact = self.EditedContact;
    
    self.email.layer.borderColor = [UIColor colorWithRed:198.0/256.0 green:198.0/256.0 blue:198.0/256.0 alpha:1].CGColor;
    self.email.layer.borderWidth=1;

    self.name.layer.borderColor = [UIColor colorWithRed:198.0/256.0 green:198.0/256.0 blue:198.0/256.0 alpha:1].CGColor;
    self.name.layer.borderWidth=1;

    self.mobile.layer.borderColor = [UIColor colorWithRed:198.0/256.0 green:198.0/256.0 blue:198.0/256.0 alpha:1].CGColor;
    self.mobile.layer.borderWidth=1;
    
    if (GetEditContact!=nil) {
        [self setEditedContailDetails];
    }

    // Do any additional setup after loading the view from its nib.
}

-(void)setEditedContailDetails
{
    self.txtname.text = [GetEditContact valueForKey:@"Name"];
    self.txtmobile.text = [GetEditContact valueForKey:@"PhoneNo"];
    self.txtemail.text = [GetEditContact valueForKey:@"Email"];
    [self.BtnSaveCon setTitle:@"Update Contact" forState:UIControlStateNormal] ;
    
    NSString *ImageURL = [NSString stringWithFormat:@"%@%@",baseImageURL, [GetEditContact valueForKey:@"PhotoName"]];
    
    NSURL *imageURL = [NSURL URLWithString:ImageURL];
    NSString *key = [ImageURL MD5Hash];
    NSData *getData = [FTWCache objectForKey:key];
    self.profile.layer.cornerRadius = self.profile.frame.size.width/2;
    self.profile.layer.borderWidth = 3.0f;
    self.profile.layer.borderColor =[UIColor blueColor].CGColor;
    self.profile.clipsToBounds= YES;
    
    UIImage *image;
    if (getData) {
        image = [UIImage imageWithData:getData];
        self.profile.image  = image;
        encodecImage  =  [getData base64EncodedStringWithOptions:0];
    }
    else {
        self.profile.image  = [UIImage imageNamed:@"img_def"];
        dispatch_queue_t queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_HIGH, 0ul);
        dispatch_async(queue, ^{
            NSData *newData = [NSData dataWithContentsOfURL:imageURL];
            [FTWCache setObject:newData forKey:key];
            UIImage  *image = [UIImage imageWithData:newData];
            dispatch_sync(dispatch_get_main_queue(), ^{
                self.profile.image  = image;
                
            });
            encodecImage  =  [getData base64EncodedStringWithOptions:0];
        });
    }

    
    
}

- (BOOL) textField: (UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString: (NSString *)string {
    if (textField== self.txtmobile) {
        NSNumberFormatter * nf = [[NSNumberFormatter alloc] init];
        [nf setNumberStyle:NSNumberFormatterNoStyle];
        
        NSString * newString = [NSString stringWithFormat:@"%@%@",textField.text,string];
        NSNumber * number = [nf numberFromString:newString];
        
        if (number)
            return YES;
        else
            return NO;
    }
    
    return YES;
}


-(BOOL)textFiledValidation
{
    if ([self.txtname.text isEqualToString:@""]) {
        [self.txtname resignFirstResponder];
         [self showAlertPop:@"Enter Contact name" expObj:nil];
        return NO;
    }
    if ([self.txtmobile.text isEqualToString:@""]) {
        [self.txtmobile resignFirstResponder];
        [self showAlertPop:@"Enter Mobile Number" expObj:nil];
        return NO;
    }
    else if (![self.txtmobile.text isEqualToString:@""])
    {
       // [self validMobileNumber:self.txtmobile.text]
        if ([self validMobileNumber:self.txtmobile.text]) {
            [self.txtmobile resignFirstResponder];
            [self showAlertPop:@"Number Only" expObj:nil];
        }
        
    }
    
    if ([self.txtmobile.text isEqualToString:@""]) {
        [self showAlertPop:@"please enter MobileNumber" expObj:nil];
        return NO;
    }
    
    else  if ([self.txtmobile.text length] != 10 ) {
        [self.txtmobile resignFirstResponder];
        
        [self showAlertPop:@"Invalid Phone OR enter 10 no. only." expObj:nil];
        return NO;
    }
    
    return YES;
}


- (BOOL)validMobileNumber:(NSString *)mobilenumber {
    
    @try {
        
        NSString *phoneRegex = @"^((\\+)|(00))[0-9]{6,14}$";
        NSPredicate *phoneTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", phoneRegex];
        
        return [phoneTest evaluateWithObject:mobilenumber];
        
        
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    }
}

- (BOOL)validEmail:(NSString *)emailString {
    
    @try {
        
        if ([emailString length] == 0) {
            return NO;
        }
        
        NSString *regExPattern =@"[A-Z0-9._%+-]+@(?:[A-Z0-9-])+\\.[A-Za-z]{2,4}";
        // @"[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}";
        
        NSRegularExpression *regEx = [[NSRegularExpression alloc]
                                      initWithPattern:regExPattern
                                      options:NSRegularExpressionCaseInsensitive
                                      error:nil];
        NSUInteger regExMatches =
        [regEx numberOfMatchesInString:emailString
                               options:0
                                 range:NSMakeRange(0, [emailString length])];
        
        NSLog(@"%lu", (unsigned long)regExMatches);
        if (regExMatches == 0) {
            return NO;
        } else {
            return YES;
        }
        
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    }
}


- (IBAction)textFieldDidBeginEditing:(id)textField {
    @try {
        
        [self animateTextField:textField up:YES];
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
}



- (IBAction)textFieldDidEndEditing:(id)textField {
    @try {
        
        [self animateTextField:textField up:NO];
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
}


//-(BOOL)textFieldShouldReturn:(UITextField *)textField
//{
//    [self animateTextField:textField up:NO];
  //  return YES;
//}

- (void)animateTextField:(UITextField *)textField up:(BOOL)up {
    @try {
      
        int animatedDistance;
        //int moveUpValue = textField.frame.origin.y + textField.frame.size.height;
        UIInterfaceOrientation orientation =
        [[UIApplication sharedApplication] statusBarOrientation];
        if (orientation == UIInterfaceOrientationPortrait ||
            orientation == UIInterfaceOrientationPortraitUpsideDown) {
            
            animatedDistance = 280 - (250 - 10 - 5);
        } else {
            
            animatedDistance = 162 - (320 - 50 - 5);
        }

        
        if (animatedDistance > 0) {
            NSString *deviceType = [[UIDevice currentDevice] model];
            
            if ([deviceType isEqualToString:@"iPad"]) {
            }
            
            const int movementDistance = animatedDistance;
            const float movementDuration = 0.3f;
            int movement = (up ? -movementDistance : movementDistance);
            [UIView beginAnimations:nil context:nil];
            [UIView setAnimationBeginsFromCurrentState:YES];
            [UIView setAnimationDuration:movementDuration];
            self.contentView.frame = CGRectOffset(self.contentView.frame, 0, movement);
            [UIView commitAnimations];
        }
        // }
        
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    }
}


-(IBAction)BtnSaveContacts:(id)sender
{
    if ([self textFiledValidation]) {
        
        NSString *cisID = [NSString stringWithFormat:@"%@",[GetEditContact valueForKey:@"CustomerID"]];
        
        if (![cisID  isEqualToString:@""]) {
            CustomerID =[GetEditContact valueForKey:@"CustomerID"];
        }
        else CustomerID = @"";
        
        if (encodecImage ==nil) {
            encodecImage = @"";
        }
        if(CustomerID==nil)
        {
            CustomerID= @"0";
        }
        
        NSMutableArray *customArray = [[NSMutableArray alloc]init];
        
        NSDictionary *CistObj = @{@"CustomerID":CustomerID,
                                  @"UserRegisterID":[mPref valueForKey:USERREGISTERID],
                                  @"Name":self.txtname.text,
                                  @"PhoneNo":self.txtmobile.text,
                                  @"Email":self.txtemail.text,
                                  @"RowStatus":@"A",
                                  @"Invited":@"false",
                                  @"InvitedDate":@"",
                                  @"AlreadyMember":@"",
                                  @"PhotoName":encodecImage
                                  };
        
        [customArray addObject:CistObj];
        
        NSDictionary *myDeletCustomeObj = @{@"Customers":customArray};
        
   NSDictionary *resObj =     [mWebService SaveCustomer:myDeletCustomeObj];
        if (resObj!=nil) {
          
            MyContacts *mContacts = [[MyContacts alloc]initWithNibName:@"MyContacts" bundle:nil];
            
            [self presentViewController:mContacts animated:YES completion:nil];
            
        }
        
    }
}

-(IBAction)back:(id)sender

{
    [self dismissViewControllerAnimated:YES completion:nil];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(IBAction)hideKeyBoardEmail:(id)sender

{
    [self.txtemail resignFirstResponder];
}

-(IBAction)hideKeyBoardNumber:(id)sender

{
    [self.txtmobile resignFirstResponder];
}

-(IBAction)hideKeyBoardContactname:(id)sender

{
    [self.txtname resignFirstResponder];
}


- (IBAction)takePhoto:(id)sender
{
    @try {
        
        UIAlertController * view=   [UIAlertController
                                     alertControllerWithTitle:@"Right Place Right Time"
                                     message:nil
                                     preferredStyle:UIAlertControllerStyleActionSheet];
        
        UIAlertAction* photo = [UIAlertAction
                                actionWithTitle:@"Take Photo"
                                style:UIAlertActionStyleDefault
                                handler:^(UIAlertAction * action)
                                {
                                    //Do some thing here
                                    [view dismissViewControllerAnimated:YES completion:nil];
                                    
                                    UIImagePickerController *picker = [[UIImagePickerController alloc] init];
                                    picker.delegate = self;
                                    picker.allowsEditing = YES;
                                    picker.sourceType = UIImagePickerControllerSourceTypeCamera;
                                    
                                    [self presentViewController:picker animated:YES completion:NULL];
                                    
                                    
                                    
                                }];
        UIAlertAction* gallery = [UIAlertAction
                                  actionWithTitle:@"Chose from Gallery"
                                  style:UIAlertActionStyleDefault
                                  handler:^(UIAlertAction * action)
                                  {
                                      UIImagePickerController *picker = [[UIImagePickerController alloc] init];
                                      picker.delegate = self;
                                      picker.allowsEditing = YES;
                                      picker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
                                      
                                      [self presentViewController:picker animated:YES completion:NULL];
                                      
                                      
                                      
                                      [view dismissViewControllerAnimated:YES completion:nil];
                                      
                                  }];
        
        UIAlertAction* cancel = [UIAlertAction
                                 actionWithTitle:@"Cancel"
                                 style:UIAlertActionStyleDefault
                                 handler:^(UIAlertAction * action)
                                 {
                                     [view dismissViewControllerAnimated:YES completion:nil];
                                     
                                 }];
        
        
        
        [view addAction:photo];
        [view addAction:gallery];
        [view addAction:cancel];
        [self presentViewController:view animated:YES completion:nil];
        
        
        
        
        //    UIImagePickerController *picker = [[UIImagePickerController alloc] init];
        //    picker.delegate = self;
        //    picker.allowsEditing = YES;
        //    picker.sourceType = UIImagePickerControllerSourceTypeCamera;
        //
        //    [self presentViewController:picker animated:YES completion:NULL];
    } @catch (NSException *exception) {
       // [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
}





- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info {
    @try {
        
       // [self.cameraBtn setImage:[UIImage imageNamed:@"Edit_photo.png"] forState:UIControlStateNormal];
        UIImage *chosenImage = info[UIImagePickerControllerEditedImage];
        self.profile.layer.cornerRadius = self.profile.frame.size.width/2;
        self.profile.layer.borderWidth = 3.0f;
        self.profile.layer.borderColor =[UIColor blueColor].CGColor;
        self.profile.clipsToBounds= YES;
        self.profile.image = chosenImage;
        
        
        NSData *data = UIImagePNGRepresentation(chosenImage);
        encodecImage  =  [data base64EncodedStringWithOptions:0];
        
        
      //  [self.Contentview addSubview:regUserImgView];
        [picker dismissViewControllerAnimated:YES completion:NULL];
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
}

- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker {
    @try {
        
        [picker dismissViewControllerAnimated:YES completion:NULL];
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
    
}

- (void) showAlertPop:(NSString*)alertText  expObj:(NSException*) exp{
    if(exp != nil)
    {
        NSLog(@"%@", exp.description);
    }
    NSLog(@"The Exception is %@",exp.description);
    UIAlertController *myAlertController =[mWebService  alert:alertText];
    [self presentViewController:myAlertController animated:YES completion:nil];
}
-(void) viewDidLayoutSubviews {
    
    @try {
        
        
        [super viewDidLayoutSubviews];
        [self.scrollView layoutIfNeeded];
         self.scrollView.contentSize=self.contentView.bounds.size;
        UIGraphicsBeginImageContext(self.view.frame.size);
        UIImage *image = UIGraphicsGetImageFromCurrentImageContext();
        UIGraphicsEndImageContext();
        image= [UIImage imageNamed:@"bgerror.png"];
        self.contentView.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"bgerror.png"]];
        self.view.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"bgerror.png"]];
        
        
    } @catch (NSException *exception) {
        //[self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
}


/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
