//
//  MuCustomer_Cell.h
//  RPRT
//
//  Created by sravanthi Gumma on 02/09/1938 Saka.
//  Copyright © 1938 Saka DevpointSolutions. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MuCustomer_Cell : UITableViewCell
@property(weak,nonatomic) IBOutlet UIImageView *mPhoto;
@property(weak,nonatomic) IBOutlet UIImageView *seletedContact;
@property(weak,nonatomic) IBOutlet UILabel *contactName;
@property(weak,nonatomic) IBOutlet UILabel *PhoneNumber;
@property(weak,nonatomic) IBOutlet UIButton *deleteBtn;
@property(weak,nonatomic) IBOutlet UIButton *EditBtn;
@property(weak,nonatomic) IBOutlet UIButton *RequestBtn;
@property(weak,nonatomic) IBOutlet UIView *custView;

@end
