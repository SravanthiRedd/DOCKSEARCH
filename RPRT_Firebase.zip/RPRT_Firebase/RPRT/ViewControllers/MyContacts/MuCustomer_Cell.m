//
//  MuCustomer_Cell.m
//  RPRT
//
//  Created by sravanthi Gumma on 02/09/1938 Saka.
//  Copyright © 1938 Saka DevpointSolutions. All rights reserved.
//

#import "MuCustomer_Cell.h"

@implementation MuCustomer_Cell

@synthesize mPhoto= mPhoto;
@synthesize contactName= contactName;
@synthesize PhoneNumber = PhoneNumber;
@synthesize deleteBtn= deleteBtn;
@synthesize EditBtn = EditBtn;
@synthesize RequestBtn= RequestBtn;
@synthesize custView = custView;
@synthesize  seletedContact=seletedContact;

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}


-(void)layoutSubviews{
    self.layer.cornerRadius = 45/2;
    
    self.mPhoto.layer.cornerRadius = self.mPhoto.frame.size.width/2;
    self.mPhoto.layer.masksToBounds = YES;
    
    self.custView.layer.shadowColor = [UIColor grayColor].CGColor;
    self.custView.layer.borderColor = [UIColor colorWithRed:175.0/256.0 green:175.0/256.0 blue:175.0/256.0 alpha:1].CGColor;
    self.custView.layer.borderWidth=0.5f;
    self.custView.layer.shadowOffset = CGSizeMake(1.0, 1.0);
    self.custView.layer.shadowOpacity = 0.7;
    self.custView.layer.cornerRadius = 4.0;
    self.contentView.backgroundColor= [UIColor clearColor];
    
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
