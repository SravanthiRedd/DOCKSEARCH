//
//  MyContacts.h
//  RPRT
//
//  Created by sravanthi Gumma on 02/09/1938 Saka.
//  Copyright © 1938 Saka DevpointSolutions. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MyContacts : UIViewController<UITableViewDelegate,UITableViewDataSource,UISearchBarDelegate>
{
    NSMutableArray *SelectedList;
    NSMutableArray *Selectedindex;
 NSMutableString *textViewtext;
}
@property(strong,nonatomic) NSDictionary *CustomerObj;
@property(weak,nonatomic) IBOutlet UITableView *myCustTable;
@property(weak,nonatomic) IBOutlet UISearchBar *searchBar;
@property(weak,nonatomic) IBOutlet UIView *helpSectionView;
@property(weak,nonatomic) IBOutlet UILabel *pageTitle;
@property(strong,nonatomic) NSString *pageTitleString;
@property(weak,nonatomic) IBOutlet UIButton *selectAllBtn;
@property(weak,nonatomic) IBOutlet UIImageView *selectAllImg;
@end
