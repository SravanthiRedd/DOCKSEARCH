//
//  MyContacts.m
//  RPRT
//
//  Created by sravanthi Gumma on 02/09/1938 Saka.
//  Copyright © 1938 Saka DevpointSolutions. All rights reserved.
//

#import "MyContacts.h"
#import <AddressBook/ABAddressBook.h>
#import <AddressBookUI/AddressBookUI.h>
#import <Contacts/Contacts.h>
#import <ContactsUI/ContactsUI.h>
#import "PhoneContacts.h"
#import "Web_Services.h"
#import "Constances.h"
#import "MuCustomer_Cell.h"
#import "ContactForm.h"
#import <Messages/Messages.h>
#import <MessageUI/MessageUI.h>
#import "AppDelegate.h"
#import "MainViewController.h"
#import "CustomIOSAlertView.h"
@interface MyContacts ()<MFMessageComposeViewControllerDelegate,UITextViewDelegate,CustomIOSAlertViewDelegate>
{
    NSMutableArray *contactsArray;
    Web_Services *mWebService;
    NSUserDefaults *mPref;
    NSString *UserRegID;
    NSDictionary *inviteContact;
    BOOL isSearching;
    NSMutableArray *SearchContactArray;
    NSMutableArray *searcStringArray;
    NSString *selectionKey;
    UITextView *requesttext;
    CustomIOSAlertView *InviteAlert;
    NSString *MessageBody;
    NSString *StoreNames;
    
}
@end

@implementation MyContacts

- (void)viewDidLoad {
    [super viewDidLoad];
    selectionKey= @"UnSelect";
    SelectedList = [[NSMutableArray alloc]init];;
    Selectedindex = [[NSMutableArray alloc]init];
    mWebService = [Web_Services GetSharedInstance];
    mPref = [NSUserDefaults standardUserDefaults];
    contactsArray = [[NSMutableArray alloc]init];
    searcStringArray = [[NSMutableArray alloc]init];
    [self GetMyContact];
    SearchContactArray = contactsArray;
    searcStringArray = [SearchContactArray valueForKey:@"Name"];
    [self.myCustTable reloadData];
    
    self.helpSectionView.layer.shadowColor = [UIColor lightGrayColor].CGColor;
    self.helpSectionView.layer.shadowOffset = CGSizeMake(0, 4);
    self.helpSectionView.layer.shadowOpacity = 1;
    self.helpSectionView.layer.shadowRadius = 1.0;
    self.pageTitle.text = self.pageTitleString;
    
    [[NSNotificationCenter defaultCenter]
     addObserver:self
     selector:@selector(MessageNotification:)
     name:@"MessageNotification"
     object:nil];
    
    NSData  *VendorData =    [mPref valueForKey:@"SaveRegisterDetails"];
    NSDictionary *myDictionary =   (NSDictionary*) [NSKeyedUnarchiver unarchiveObjectWithData:VendorData];
    NSLog(@"%@",myDictionary);
    //[ [myDictionary  valueForKey:@"BusinessDeatils"] valueForKey:@"ContactPerson"]
    
    if ([[mPref valueForKey:LOGINTYPE] isEqualToString:@"Business"]) {
        StoreNames=[myDictionary valueForKey:@"RegUserName"];
    }
    else if ([[mPref valueForKey:LOGINTYPE] isEqualToString:@"Individual"])
        StoreNames=[[myDictionary  valueForKey:@"BusinessDeatils"] valueForKey:@"ContactPerson"];
    
    // Do any additional setup after loading the view from its nib.
}

-(void)GetMyContact
{
    UserRegID  =[NSString stringWithFormat:@"%@",[mPref valueForKey:USERREGISTERID]];
    if (UserRegID!=nil && ![UserRegID isEqualToString:@""]) {
        UserRegID= [NSString stringWithFormat:@"%@/Customer",UserRegID];
       contactsArray = [mWebService GetMyCustomers:UserRegID];
    }
    

}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


-(IBAction)back:(id)sender
{
    
    Home *mhome = [[Home alloc]initWithNibName:HOMEDASHBOARD bundle:nil];
    [self presentViewController:mhome animated:YES completion:nil];
    
   // [self dismissViewControllerAnimated:YES completion:nil];
}
-(IBAction)AddPhoneContact:(id)sender
{
    UIAlertController * view=   [UIAlertController
                                 alertControllerWithTitle:@"Right Place Right Time"
                                 message:@"Add Customers"
                                 preferredStyle:UIAlertControllerStyleActionSheet];
    
    UIAlertAction* contacts = [UIAlertAction
                              actionWithTitle:@"Choose From Contacts"
                              style:UIAlertActionStyleDefault
                              handler:^(UIAlertAction * action)
                              {
                                  PhoneContacts *mPhoneContacts = [[PhoneContacts alloc]initWithNibName:@"PhoneContacts" bundle:nil];
                                  
                                  [self presentViewController:mPhoneContacts animated:YES completion:nil];
                                  
                              }];
    
    UIAlertAction* contactForm = [UIAlertAction
                             actionWithTitle:@"Add New"
                             style:UIAlertActionStyleDefault
                             handler:^(UIAlertAction * action)
                             {
                                 ContactForm *mContactForm = [[ContactForm alloc]initWithNibName:@"ContactForm" bundle:nil];
                                 [self presentViewController:mContactForm animated:YES completion:nil];
                             }];

    UIAlertAction* cancel = [UIAlertAction
                             actionWithTitle:@"Cancel"
                             style:UIAlertActionStyleDefault
                             handler:^(UIAlertAction * action)
                             {
                                
                                 [view dismissViewControllerAnimated:YES completion:nil];
                                 
                             }];
    
    [view addAction:contacts];
    [view addAction:contactForm];
    [view addAction:cancel];
    [self presentViewController:view animated:YES completion:nil];
 
}


- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    @try {
        
        if ([contactsArray count]==0) {
            [self.helpSectionView setHidden:NO];
            return 0;
           }
        else
        {
            [self.helpSectionView setHidden:YES];
            return [contactsArray count];
        }
        
        return [contactsArray count];
    } @catch (NSException *exception) {
        // [self showAlertPop:@"Error in Data parsing." expObj:exception];
    } @finally {
        
    }
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 80
    ;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    // static NSString *simpleTableIdentifier = @"MainCellLeft";
    MuCustomer_Cell *cell = (MuCustomer_Cell *)[tableView dequeueReusableCellWithIdentifier:@"MuCustomer_Cell"];
    if (cell == nil)
    {
        NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"MuCustomer_Cell" owner:self options:nil];
        cell = [nib objectAtIndex:0];
    }
    tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    
    NSDictionary *conObj = [contactsArray objectAtIndex:indexPath.row];
    
   
    
    NSString *OppIDv = [NSString stringWithFormat:@"%@",[self.CustomerObj valueForKey:@"OppId"]];
    NSString *CustomerID = [NSString stringWithFormat:@"%@",[conObj valueForKey:@"CustomerID"]];
    if([OppIDv isEqualToString:CustomerID])
    {
         NSLog(@"%@",self.CustomerObj);
        
        
        
        cell.custView.layer.backgroundColor = [UIColor whiteColor].CGColor;
        
        [UIView animateWithDuration:2.0 animations:^{
            cell.custView.layer.backgroundColor = [UIColor colorWithRed:207.0/256.0 green:208.0/256.0 blue:200.0/256.0 alpha:1].CGColor;
        } completion:NULL];
      
       
    }
    
   
    
   

    
    
    
    NSString *IsNew =[NSString stringWithFormat:@"%@",[conObj valueForKey:@"IsNew"]];
     cell.contactName.text = [conObj valueForKey:@"Name"];
    if ([IsNew isEqualToString:@"1"]) {
        [cell.contactName setFont:[UIFont fontWithName:@"Roboto-Medium" size:16]];
    }
    
    NSString *mem =[NSString stringWithFormat:@"%@",[conObj valueForKey:@"AlreadyMember"]];
    
    int *alreadynumber = [mem intValue];
    if (alreadynumber>0) {
      //  cell.alreadyMember.hidden= NO;
        [cell.RequestBtn setImage:[UIImage imageNamed:@"alreadymembe-2r.png"] forState:UIControlStateNormal];
        //alreadymembe-2r.png
        cell.RequestBtn.userInteractionEnabled= false;
    }
    else {
        
       [cell.RequestBtn setImage:[UIImage imageNamed:@"36_invitation.png"] forState:UIControlStateNormal];
        //36_invitation.png
      //  cell.alreadyMember.hidden= YES;
       //  [cell.RequestBtn setHidden:NO];
    }
    cell.PhoneNumber.text = [conObj valueForKey:@"PhoneNo"];
    if (![[conObj valueForKey:@"PhotoName"] isEqualToString:@""]) {
        
        NSString *imageName = [NSString stringWithFormat:@"%@",[conObj valueForKey:@"PhotoName"]];;
        NSArray *imageAry = [imageName componentsSeparatedByString:@","];
        NSString *ImageURL = [NSString stringWithFormat:@"%@%@",baseImageURL, [imageAry objectAtIndex:0]];
        
            NSURL *imageURL = [NSURL URLWithString:ImageURL];
            NSString *key = [ImageURL MD5Hash];
            NSData *getData = [FTWCache objectForKey:key];
            if (getData) {
                UIImage *image = [UIImage imageWithData:getData];
                cell.mPhoto.image  = image;
            }
            else {
                cell.mPhoto.image  = [UIImage imageNamed:@"img_def"];
                dispatch_queue_t queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_HIGH, 0ul);
                dispatch_async(queue, ^{
                    NSData *newData = [NSData dataWithContentsOfURL:imageURL];
                    [FTWCache setObject:newData forKey:key];
                    UIImage *image = [UIImage imageWithData:newData];
                    dispatch_sync(dispatch_get_main_queue(), ^{
                        cell.mPhoto.image  = image;
                        
                    });
                });
            }
        
    }
   
    if ([SelectedList containsObject:[contactsArray objectAtIndex:indexPath.row]]) {
        
        //;
        //  avalbleImage=   [mTimeCalculator image:avalbleImage scaledToSize:siz];
        cell.mPhoto.image =  [UIImage imageNamed:@"Checked.png"];
        
      
    }
//    else{
//        cell.seletedContact.image =  [[UIImage imageNamed:@"uncheck.png"] imageWithTint:[UIColor clearColor]];
//        
//    }
    
    

    [cell.EditBtn addTarget:self action:@selector(EditBtn:) forControlEvents:UIControlEventTouchUpInside];
      [cell.deleteBtn addTarget:self action:@selector(deleteBtn:) forControlEvents:UIControlEventTouchUpInside];
      [cell.RequestBtn addTarget:self action:@selector(RequestBtn:) forControlEvents:UIControlEventTouchUpInside];
   // NSString *Invited = [NSString stringWithFormat:@"%@",[conObj valueForKey:@"Invited"]];
    
    
    
   // if ([Invited isEqualToString:@"1"]) {
     //   [cell.RequestBtn setHidden:YES];
    //}
   // else [cell.RequestBtn setHidden:NO];
    
    return cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    NSIndexPath *someIndexPath = [tableView indexPathForSelectedRow];
    NSString *studentname =  [contactsArray objectAtIndex:indexPath.row];
    if([Selectedindex containsObject:indexPath]){
        [Selectedindex removeObject:indexPath];
        [SelectedList removeObject:studentname];
        
    } else {
        [Selectedindex addObject:someIndexPath];
        [SelectedList addObject:studentname];
    }
    
    [tableView reloadData];
    
}


-(void)deleteBtn:(UIButton*)sender
{
    CGPoint buttonPosition = [sender convertPoint:CGPointZero toView:self.myCustTable];
    
    NSIndexPath *indexPath = [self.myCustTable indexPathForRowAtPoint:buttonPosition];
    
    NSDictionary *selCustomer = [contactsArray objectAtIndex:indexPath.row];
    
    NSMutableArray *customArray= [[NSMutableArray alloc]init];
    
    NSDictionary *CistObj = @{@"CustomerID":[selCustomer valueForKey:@"CustomerID"],
                              @"UserRegisterID":[selCustomer valueForKey:@"UserRegisterID"],
                              @"Name":[selCustomer valueForKey:@"Name"],
                              @"PhoneNo":[selCustomer valueForKey:@"PhoneNo"],
                              @"Email":@"",
                              @"RowStatus":@"D",
                              @"Invited":@"false",
                              @"InvitedDate":@"",
                              @"AlreadyMember":@"",
                              @"PhotoName":@""
                              };
    
    [customArray addObject:CistObj];
    
    NSDictionary *myDeletCustomeObj = @{@"Customers":customArray};
    
     [mWebService SaveCustomer:myDeletCustomeObj];
    contactsArray = [mWebService GetMyCustomers:UserRegID];
    [self.myCustTable reloadData];
}

-(void)EditBtn:(UIButton*)sender
{
    CGPoint buttonPosition = [sender convertPoint:CGPointZero toView:self.myCustTable];
    
    NSIndexPath *indexPath = [self.myCustTable indexPathForRowAtPoint:buttonPosition];
    
    NSDictionary *selCustomer = [contactsArray objectAtIndex:indexPath.row];
    
    ContactForm *mContsctForm = [[ContactForm alloc]initWithNibName:@"ContactForm" bundle:nil];
    
    mContsctForm.EditedContact = selCustomer;
    
    [self presentViewController:mContsctForm animated:YES completion:nil];

}

-(void)RequestBtn:(UIButton*)sender
{
    CGPoint buttonPosition = [sender convertPoint:CGPointZero toView:self.myCustTable];
    
    NSIndexPath *indexPath = [self.myCustTable indexPathForRowAtPoint:buttonPosition];
    
    inviteContact = [contactsArray objectAtIndex:indexPath.row];
    
    NSDateFormatter *dateFormat = [[NSDateFormatter alloc] init];
    [dateFormat setDateFormat: @"yyyy-MM-dd HH:mm:ss"];
    
    //Optionally for time zone conversions
    [dateFormat setTimeZone:[NSTimeZone timeZoneWithAbbreviation:@"UTC"]];
    
    NSString *stringFromDate = [dateFormat stringFromDate:[NSDate date]];
    NSMutableArray *customArray = [[NSMutableArray alloc]init];
   
    NSString *PhoneNumver = [inviteContact valueForKey:@"PhoneNo"];
    NSString * InVited = @"true";
    NSDictionary *CistObj = @{@"CustomerID":[inviteContact valueForKey:@"CustomerID"],
                              @"UserRegisterID":[inviteContact valueForKey:@"UserRegisterID"],
                              @"Name":[inviteContact valueForKey:@"Name"],
                              @"PhoneNo":[inviteContact valueForKey:@"PhoneNo"],
                              @"Email":@"",
                              @"RowStatus":@"A",
                              @"Invited":InVited,
                              @"InvitedDate":stringFromDate,
                              @"AlreadyMember":@"",
                              @"PhotoName":@""
                              };
    
    [customArray addObject:CistObj];
    
    NSDictionary *myDeletCustomeObj = @{@"Customers":customArray};
    
      [mWebService SaveCustomer:myDeletCustomeObj];
      contactsArray = [mWebService GetMyCustomers:UserRegID];
    [self.myCustTable reloadData];

    MFMessageComposeViewController *controller = [[MFMessageComposeViewController alloc] init];
    if([MFMessageComposeViewController canSendText])
    {

        NSData  *VendorData =    [mPref valueForKey:@"SaveRegisterDetails"];
        NSDictionary *myDictionary =   (NSDictionary*) [NSKeyedUnarchiver unarchiveObjectWithData:VendorData];
        NSLog(@"%@",myDictionary);
        
        NSString *StoreName =@"";
        if ([[myDictionary valueForKey:@"ContactPerson"] isEqualToString:@""]) {
            StoreName= [myDictionary valueForKey:@"RegUserName"];
        }
        else StoreName= [myDictionary valueForKey:@"ContactPerson"];
        
        controller.body =[NSString stringWithFormat:@"Hi,\nI am using Right Place Right Time mobile app to post the Opportunities of mystore.\nInstall the app from\nPlay store: http://bit.ly/2fdqw6N\n App store: http://apple.co/2fdvEaV\n\nRegards,\n%@",StoreName];
        controller.recipients = [NSArray arrayWithObjects:PhoneNumver, nil];
        controller.messageComposeDelegate = self;
    
        [self presentViewController:controller animated:YES completion:nil];
    }
    
}


- (void)messageComposeViewController:(MFMessageComposeViewController *)controller didFinishWithResult:(MessageComposeResult)result
{
    
    switch (result)
        {
            case MessageComposeResultSent:
                
                    break;
            case MessageComposeResultFailed:
                
                    break;
                case MessageComposeResultCancelled:
        
                    break;
                
                default:
                
                    break;
        }
    
    [self dismissViewControllerAnimated:YES completion:nil];
}

#pragma mark UISearchbar


- (void)searchBarTextDidBeginEditing:(UISearchBar *)searchBar {
    isSearching = YES;
}

- (void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)seachtext {
    NSLog(@"Text change - %d",isSearching);
    
    //Remove all objects first.
    // [filteredContentList removeAllObjects];
    
    if([seachtext length] != 0) {
        contactsArray = SearchContactArray;
        isSearching = YES;
        [self seachOffer:seachtext];
    }
    else if([seachtext length]==0)
    {
        contactsArray = SearchContactArray;
        [self.myCustTable reloadData];
    }
    else {
        isSearching = NO;
    }
    // [self.tblContentList reloadData];
}

- (void)seachOffer:(NSString *)substring {
    @try {
        // Put anything that starts with this substring into the autocompleteUrls array
        // The items in this array is what will show up in the table view
        NSPredicate *predicate = [NSPredicate predicateWithFormat:@"SELF contains [cd] %@", substring];
        NSArray  *results = [searcStringArray filteredArrayUsingPredicate:predicate];
        if ([results count]!=0) {
            
            NSMutableArray *array = [[NSMutableArray alloc]init];
            
            
            for (int i=0; i<[results count]; i++) {
                NSString  *str= [results objectAtIndex:i];
                
                for (int j=0; j<[contactsArray count]; j++) {
                    NSString *str2 = [[contactsArray objectAtIndex:j]  valueForKey:@"Name"];
                    if ([str isEqualToString:str2]) {
                        [array addObject:[contactsArray objectAtIndex:j]];
                    }
                }
                
            }
            
            NSOrderedSet *orderedSet = [NSOrderedSet orderedSetWithArray:array];
            contactsArray = [orderedSet mutableCopy];
            
            // GetRetailerOpp = array;
            
           [self.myCustTable reloadData];
            
        }
        //[autoComplete reloadData];
    } @catch (NSException *exception) {
       // [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
}
-(void)searchBarTextDidEndEditing:(UISearchBar *)searchBar
{
    NSLog(@"Search Clicked");
    
    [searchBar resignFirstResponder];
}
-(void) searchBarCancelButtonClicked:(UISearchBar *)searchBar
{
    contactsArray = SearchContactArray;
    [self.myCustTable reloadData];
    
     [searchBar resignFirstResponder];
}


- (void)searchBarSearchButtonClicked :(UISearchBar *)searchBar {
    NSLog(@"Search Clicked");
    
    [searchBar resignFirstResponder];
  
}

-(void) viewDidLayoutSubviews {
    
    @try {
        
        [super viewDidLayoutSubviews];
        //[self.scrollview layoutIfNeeded];
        // self.scrollview.contentSize=self.Contentview.bounds.size;
        UIGraphicsBeginImageContext(self.view.frame.size);
        UIImage *image = UIGraphicsGetImageFromCurrentImageContext();
        UIGraphicsEndImageContext();
        image= [UIImage imageNamed:@"bgerror.png"];
        self.view.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"bgerror.png"]];
        
        
    } @catch (NSException *exception) {
        //[self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
}

-(IBAction)selectAll:(id)sender
{
    //[contactsArray objectAtIndex:indexPath.row]
    NSLog(@" %@ ",selectionKey);
    
    if([selectionKey isEqualToString:@"UnSelect"])
    {
        selectionKey= @"Select All";
        for (int i=0; i<[contactsArray count]; i++) {
            NSDictionary *selec =[contactsArray objectAtIndex:i];
            NSInteger row = [contactsArray indexOfObject:selec];
            NSIndexPath *indexPath = [NSIndexPath indexPathForRow:row inSection:0];
            NSString *studentname =  [contactsArray objectAtIndex:indexPath.row];
            [Selectedindex addObject:indexPath];
            [SelectedList addObject:studentname];
           
        }
        [self.myCustTable reloadData];
        [self.selectAllBtn setTitle:@"DeSelect All" forState:UIControlStateNormal];
        self.selectAllImg.image= [[UIImage imageNamed:@"check.png"] imageWithTint:[UIColor darkTextColor]];
    }
    else if ([selectionKey isEqualToString:@"Select All"])
    {
          selectionKey= @"UnSelect";
        [Selectedindex removeAllObjects];
        [SelectedList removeAllObjects];
        [self.selectAllBtn setTitle:@"Select All" forState:UIControlStateNormal];
        self.selectAllImg.image= [[UIImage imageNamed:@"uncheck.png"] imageWithTint:[UIColor clearColor]];
         [self.myCustTable reloadData];
    }
    
}

-(IBAction)sendSMS:(id)sender
{
     [self SMSPopUp];
}
-(IBAction)sendNotification:(id)sender
{
    [self NotificationPopup:nil];
}
-(void)NotificationPopup:(NSDictionary*)inviteObject1
{
    
   //InviteObject =inviteObject1;
  
    
    NSString *InviteMessage= [NSString stringWithFormat:@"%@ would like to add you as a Customer, Customer's can enjoy extra benefits!!",StoreNames];
    
    InviteAlert=[[CustomIOSAlertView alloc] init];
    UIView  *replyView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 350, 300)];
    [InviteAlert setContainerView:replyView];
    [InviteAlert setButtonTitles:[NSMutableArray arrayWithObjects:@"", nil]];
    
    [InviteAlert setDelegate:self];
    
    
    // You may use a Block, rather than a delegate.
    [InviteAlert setOnButtonTouchUpInside:^(CustomIOSAlertView *alertView, int buttonIndex) {
        NSLog(@"Block: Button at position %d is clicked on alertView %d.", buttonIndex, (int)[alertView tag]);
          [alertView close];
    }];
    
    [InviteAlert setUseMotionEffects:true];
    
    
    UILabel *requestTitle = [[UILabel alloc]initWithFrame:CGRectMake(5, 5, 300, 40)];
    requestTitle.text = @" Message Preview";
    [requestTitle setFont:[UIFont fontWithName:@"Roboto-Medium" size:18]];
    requestTitle.textAlignment= NSTextAlignmentCenter;
    //
    //    UIButton *cancel = [[UIButton alloc]initWithFrame:CGRectMake(275, 0, 20, 20)];
    //
    //    [cancel setImage:[UIImage imageNamed:@"ic_close"] forState:UIControlStateNormal];
    //    [cancel addTarget:self action:@selector(cancel:) forControlEvents:UIControlEventTouchUpInside];
    [replyView addSubview:requestTitle];
    
    UILabel *requestName = [[UILabel alloc]initWithFrame:CGRectMake(10, 30, 100, 40)];
    requestName.text = @"Hi,";
    [requestName setFont:[UIFont fontWithName:@"Roboto-Regular" size:17]];
    [replyView addSubview:requestName];
    
    requesttext = [[UITextView alloc]initWithFrame:CGRectMake(10, 70, 330, 100)];
    requesttext.delegate= self;
    requesttext.layer.borderColor = [UIColor lightTextColor].CGColor;
    requesttext.text= InviteMessage;
    [replyView addSubview:requesttext];
    
    UILabel *thanksLbl= [[UILabel alloc]initWithFrame:CGRectMake(10, 170, 150, 25)];
    thanksLbl.text= @"Thanks,";
    thanksLbl.font= [UIFont fontWithName:@"Roboto-Regular" size:15];
    [replyView addSubview:thanksLbl];
    
    UILabel *userName= [[UILabel alloc]initWithFrame:CGRectMake(10, 195, 300, 25)];
    userName.text= StoreNames;
    userName.font= [UIFont fontWithName:@"Roboto-Regular" size:15];
    [replyView addSubview:userName];
    
    UILabel *appNameLbl= [[UILabel alloc]initWithFrame:CGRectMake(10, 225, 300, 25)];
    appNameLbl.text= @"Right Place Right Time";
    appNameLbl.font= [UIFont fontWithName:@"Roboto-Regular" size:15];
    [replyView addSubview:appNameLbl];
    
    
    UIButton *sendBtn = [[UIButton alloc] initWithFrame:CGRectMake(10, 250, 320, 40)];
    [sendBtn setTitle:@"Send" forState:UIControlStateNormal];
    [sendBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [sendBtn addTarget:self action:@selector(NotificationsendBtn:) forControlEvents:UIControlEventTouchUpInside];
    sendBtn.backgroundColor =[UIColor colorWithRed:144.0/256.0 green:147.0/256.0 blue:167.0/256.0 alpha:1];
    [replyView addSubview:sendBtn];
    
    UIButton *Cancel = [[UIButton alloc] initWithFrame:CGRectMake(10, 300, 320, 40)];
    [Cancel setTitle:@"Cancel" forState:UIControlStateNormal];
    [Cancel setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [Cancel addTarget:self action:@selector(NotificationCancel:) forControlEvents:UIControlEventTouchUpInside];
    Cancel.backgroundColor =[UIColor colorWithRed:144.0/256.0 green:147.0/256.0 blue:167.0/256.0 alpha:1];
    [replyView addSubview:Cancel];
    
    
    // [replyView addSubview:cancel];
    
    [InviteAlert show];
    replyView.tag = 2;

    
    
}

-(void)NotificationsendBtn:(UIButton*)sender
{
    [InviteAlert close];
}

-(void)NotificationCancel:(UIButton*)sender
{
     [InviteAlert close];
}


-(void)SMSPopUp
{
   
    
    NSString *InviteMessage= [NSString stringWithFormat:@"%@ would like to add you as a Customer, Customer's can enjoy extra benefits!!",StoreNames];
    
    InviteAlert=[[CustomIOSAlertView alloc] init];
    UIView  *replyView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 350, 350)];
    [InviteAlert setContainerView:replyView];
    [InviteAlert setButtonTitles:[NSMutableArray arrayWithObjects:@"", nil]];
    
    [InviteAlert setDelegate:self];
    
    
    // You may use a Block, rather than a delegate.
    [InviteAlert setOnButtonTouchUpInside:^(CustomIOSAlertView *alertView, int buttonIndex) {
        NSLog(@"Block: Button at position %d is clicked on alertView %d.", buttonIndex, (int)[alertView tag]);
          [alertView close];
    }];
    
    [InviteAlert setUseMotionEffects:true];
    
    
    UILabel *requestTitle = [[UILabel alloc]initWithFrame:CGRectMake(5, 5, 300, 40)];
    requestTitle.text = @" Message Preview";
    [requestTitle setFont:[UIFont fontWithName:@"Roboto-Medium" size:18]];
    requestTitle.textAlignment= NSTextAlignmentCenter;
    //
    //    UIButton *cancel = [[UIButton alloc]initWithFrame:CGRectMake(275, 0, 20, 20)];
    //
    //    [cancel setImage:[UIImage imageNamed:@"ic_close"] forState:UIControlStateNormal];
    //    [cancel addTarget:self action:@selector(cancel:) forControlEvents:UIControlEventTouchUpInside];
    [replyView addSubview:requestTitle];
    
    UILabel *requestName = [[UILabel alloc]initWithFrame:CGRectMake(10, 30, 100, 40)];
    requestName.text = @"Hi,";
    [requestName setFont:[UIFont fontWithName:@"Roboto-Regular" size:17]];
    [replyView addSubview:requestName];
    
    requesttext = [[UITextView alloc]initWithFrame:CGRectMake(10, 70, 330, 100)];
    requesttext.delegate= self;
    requesttext.layer.borderColor = [UIColor lightTextColor].CGColor;
    requesttext.text= InviteMessage;
    [replyView addSubview:requesttext];
    
    UILabel *thanksLbl= [[UILabel alloc]initWithFrame:CGRectMake(10, 170, 150, 25)];
    thanksLbl.text= @"Thanks,";
    thanksLbl.font= [UIFont fontWithName:@"Roboto-Regular" size:15];
    [replyView addSubview:thanksLbl];
    
    UILabel *userName= [[UILabel alloc]initWithFrame:CGRectMake(10, 195, 300, 25)];
    userName.text=StoreNames;
    userName.font= [UIFont fontWithName:@"Roboto-Regular" size:15];
    [replyView addSubview:userName];
    
    UILabel *appNameLbl= [[UILabel alloc]initWithFrame:CGRectMake(10, 225, 300, 25)];
    appNameLbl.text= @"Right Place Right Time";
    appNameLbl.font= [UIFont fontWithName:@"Roboto-Regular" size:15];
    [replyView addSubview:appNameLbl];
    
    UILabel *alertText = [[UILabel alloc]initWithFrame:CGRectMake(10, 250, 340, 60)];
    alertText.text= @"SMS will be sent from your phone, Please ensure you have sufficient balance(Max 160 charactes allowed).";
    alertText.numberOfLines=3;
    alertText.textColor =[UIColor redColor];
    alertText.font= [UIFont fontWithName:@"Roboto-Regular" size:15];
    [replyView addSubview:alertText];
    
    UIButton *sendBtn = [[UIButton alloc] initWithFrame:CGRectMake(10, 310, 320, 40)];
    [sendBtn setTitle:@"Send" forState:UIControlStateNormal];
    [sendBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [sendBtn addTarget:self action:@selector(SMSsendBtn:) forControlEvents:UIControlEventTouchUpInside];
    sendBtn.backgroundColor =[UIColor colorWithRed:144.0/256.0 green:147.0/256.0 blue:167.0/256.0 alpha:1];
    [replyView addSubview:sendBtn];
    
    UIButton *Cancel = [[UIButton alloc] initWithFrame:CGRectMake(10, 360, 320, 40)];
    [Cancel setTitle:@"Cancel" forState:UIControlStateNormal];
    [Cancel setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [Cancel addTarget:self action:@selector(SMSCancel:) forControlEvents:UIControlEventTouchUpInside];
    Cancel.backgroundColor =[UIColor colorWithRed:144.0/256.0 green:147.0/256.0 blue:167.0/256.0 alpha:1];
    [replyView addSubview:Cancel];
    
    
    // [replyView addSubview:cancel];
    
    [InviteAlert show];
    replyView.tag = 2;
    
}

-(void)getSMSMessage
{
   
    
    
    MessageBody =[NSString stringWithFormat:@"Hi,\n%@, \n\n Thanks,\n %@ \n Right Place Right Time",requesttext.text,StoreNames];
    int characterCount = [MessageBody length];
    
    
    NSLog(@"%lu",(unsigned long)characterCount);
    if(characterCount>160)
    {
        NSMutableString *bosyString;//=
        textViewtext =[requesttext.text mutableCopy];
        for (int i=characterCount; i>=160; i--) {
            
            bosyString =  [self TrimString:textViewtext];
            NSUInteger characterCount = [bosyString length];
            NSLog(@"%lu",(unsigned long)characterCount);
        }
        MessageBody = bosyString;
        requesttext.text = textViewtext;
    }

}

-(void)SMSsendBtn:(UIButton*)sender
{
    NSLog(@"%@",SelectedList);
    [self getSMSMessage];
    NSArray *phoneNumberarray = [SelectedList valueForKey:@"PhoneNo"];
    
    MFMessageComposeViewController *controller = [[MFMessageComposeViewController alloc] init];
    if([MFMessageComposeViewController canSendText])
    {
        
        controller.body = MessageBody;
        controller.recipients=phoneNumberarray;
        controller.messageComposeDelegate = self;
        [self presentViewController:controller animated:YES completion:nil];
    }

    [InviteAlert close];
}
-(void)SMSCancel:(UIButton*)sender
{
    [InviteAlert close];
}


- (BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text {
    
    if([text isEqualToString:@"\n"]) {
        [textView resignFirstResponder];
        return NO;
    }
    
    return YES;
}

-(NSMutableString*)TrimString:(NSMutableString*)TrimString
{
    
    NSString *newString =[TrimString substringToIndex:[TrimString length]-1];
    textViewtext = [newString mutableCopy];
    
    NSMutableString   *trimString = [[NSString stringWithFormat:@"Hi,\n%@, \n\n Thanks,\n %@ \n Right Place Right Time",newString,StoreNames] mutableCopy];
    
    
    //      newString= [NSString stringWithFormat:@"Hi \"%@\",\n \"%@\", \n\"%@\"\n \n Thanks,\n%@\nRight Place Right Time.",self.Contactname.text,self.Contactname.text,self.Contactname.text,self.Contactname.text];
    
    return trimString;
}

@end
