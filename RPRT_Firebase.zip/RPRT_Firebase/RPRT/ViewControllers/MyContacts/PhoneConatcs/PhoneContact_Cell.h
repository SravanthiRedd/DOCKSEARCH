//
//  PhoneContact_Cell.h
//  RPRT
//
//  Created by sravanthi Gumma on 02/09/1938 Saka.
//  Copyright © 1938 Saka DevpointSolutions. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PhoneContact_Cell : UITableViewCell
@property(weak,nonatomic) IBOutlet UIImageView *Cimage;
@property(weak,nonatomic) IBOutlet UILabel *PhoneNumber;
@property(weak,nonatomic) IBOutlet UILabel *ContactName;
@property(weak,nonatomic) IBOutlet UIImageView *CheckBtn;
@end
