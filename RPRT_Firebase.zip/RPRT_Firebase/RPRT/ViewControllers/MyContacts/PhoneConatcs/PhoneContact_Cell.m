//
//  PhoneContact_Cell.m
//  RPRT
//
//  Created by sravanthi Gumma on 02/09/1938 Saka.
//  Copyright © 1938 Saka DevpointSolutions. All rights reserved.
//

#import "PhoneContact_Cell.h"

@implementation PhoneContact_Cell

@synthesize Cimage= Cimage;
@synthesize PhoneNumber = PhoneNumber;
@synthesize ContactName = ContactName;
@synthesize  CheckBtn = CheckBtn;
- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}


-(void)layoutSubviews{
    self.layer.cornerRadius = 45/2;
    
    self.Cimage.layer.cornerRadius = self.Cimage.frame.size.width/2;
    self.Cimage.layer.masksToBounds = YES;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
