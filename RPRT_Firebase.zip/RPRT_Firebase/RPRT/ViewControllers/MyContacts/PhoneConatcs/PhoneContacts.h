//
//  PhoneContacts.h
//  RPRT
//
//  Created by sravanthi Gumma on 02/09/1938 Saka.
//  Copyright © 1938 Saka DevpointSolutions. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Contacts/Contacts.h>
#import <ContactsUI/ContactsUI.h>
@interface PhoneContacts : UIViewController<UISearchBarDelegate>
{
     NSMutableArray *contactsArray;
}
@property(weak,nonatomic) IBOutlet UISearchBar *searchBar;
@end
