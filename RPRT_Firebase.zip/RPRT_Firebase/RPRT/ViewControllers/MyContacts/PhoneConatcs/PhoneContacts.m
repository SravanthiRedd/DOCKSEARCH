//
//  PhoneContacts.m
//  RPRT
//
//  Created by sravanthi Gumma on 02/09/1938 Saka.
//  Copyright © 1938 Saka DevpointSolutions. All rights reserved.
//

#import "PhoneContacts.h"
#import "PhoneContact_Cell.h"
#import "Constances.h"
#import "Web_Services.h"
#import "MyContacts.h"
#import <Messages/Messages.h>
#import <MessageUI/MessageUI.h>
@interface PhoneContacts ()<UITableViewDelegate,UITableViewDataSource,MFMessageComposeViewControllerDelegate>
{
   // UITableView *phoneContactTable;
    NSMutableArray *seletedContacts;
    NSMutableArray *seletedIndexs;
    NSUserDefaults *mPref;
    NSString *UserRegiID;
    Web_Services *mWebService;
    NSString *Invitekey;
    BOOL isSearching;
    NSMutableArray *SearchContactArray;
    NSMutableArray *searcStringArray;
    
}
@property(weak,nonatomic) IBOutlet UITableView *phoneContactTable;
@end

@implementation PhoneContacts
@synthesize phoneContactTable;

- (void)viewDidLoad {
    [super viewDidLoad];
    seletedContacts = [[NSMutableArray alloc]init];
    contactsArray = [[NSMutableArray alloc]init];
    seletedIndexs = [[NSMutableArray alloc]init];
    mPref= [NSUserDefaults standardUserDefaults];
    mWebService = [Web_Services GetSharedInstance];
       searcStringArray = [[NSMutableArray alloc]init];
    UserRegiID =@"";
    UserRegiID = [mPref valueForKey:USERREGISTERID];
    Invitekey = @"";
    [self GetMyContact];
    
    [[NSNotificationCenter defaultCenter]
     addObserver:self
     selector:@selector(MessageNotificatiPhone:)
     name:@"MessageNotificatiPhone"
     object:nil];
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)GetMyContact
{
    CNContactStore *store = [[CNContactStore alloc] init];
    [store requestAccessForEntityType:CNEntityTypeContacts completionHandler:^(BOOL granted, NSError * _Nullable error) {
        if (granted == YES) {
            //keys with fetching properties
            NSArray *keys = @[CNContactFamilyNameKey, CNContactGivenNameKey, CNContactPhoneNumbersKey, CNContactImageDataKey];
            NSString *containerId = store.defaultContainerIdentifier;
            NSPredicate *predicate = [CNContact predicateForContactsInContainerWithIdentifier:containerId];
            NSError *error;
            NSArray *cnContacts = [store unifiedContactsMatchingPredicate:predicate keysToFetch:keys error:&error];
            if (error) {
                NSLog(@"error fetching contacts %@", error);
            } else {
                NSString *phone;
                NSString *fullName;
                NSString *firstName;
                NSString *lastName;
                UIImage *profileImage= [[UIImage alloc]init] ;
                NSMutableArray *contactNumbersArray;
                for (CNContact *contact in cnContacts) {
                    // copy data to my custom Contacts class.
                    firstName = contact.givenName;
                    lastName = contact.familyName;
                    if (lastName == nil) {
                        fullName=[NSString stringWithFormat:@"%@",firstName];
                    }else if (firstName == nil){
                        fullName=[NSString stringWithFormat:@"%@",lastName];
                    }
                    else{
                        fullName=[NSString stringWithFormat:@"%@ %@",firstName,lastName];
                    }
                    UIImage *image = [UIImage imageWithData:contact.imageData];
                    if (image != nil) {
                        profileImage = image;
                    }else{
                        profileImage = [UIImage imageNamed:@"person-icon.png"];
                    }
                    for (CNLabeledValue *label in contact.phoneNumbers) {
                        phone = [label.value stringValue];
                        if ([phone length] > 0) {
                            [contactNumbersArray addObject:phone];
                        }
                    }
                    if (phone!=nil) {
                        NSDictionary *addObj;
                        if (profileImage!=nil) {
                            
                            
                            NSString * strippedNumber =
                            [phone stringByReplacingOccurrencesOfString:@"[^0-9]"
                                                                    withString:@""
                                                                       options:NSRegularExpressionSearch
                                                                         range:NSMakeRange(0, [phone length])];
                            
                            
                            
//                          phone =   [phone stringByReplacingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
                            
                            
                            addObj = @{@"fullName":fullName,
                                       @"phone":strippedNumber,
                                       @"Photoo":profileImage
                                       };
                        }
                        else
                        {
                            NSString * strippedNumber =
                            [phone stringByReplacingOccurrencesOfString:@"[^0-9]"
                                                             withString:@""
                                                                options:NSRegularExpressionSearch
                                                                  range:NSMakeRange(0, [phone length])];
                            addObj = @{@"fullName":fullName,
                                       @"phone":strippedNumber
                                      };
                        }
                        
                     
                        
                        
                        //                    NSDictionary* personDict = [[NSDictionary alloc] initWithObjectsAndKeys: fullName,@"fullName",
                        //                       profileImage,@"userImage",
                        //                        phone,@"PhoneNumbers", nil];
                        //                    NSLog(@"%@",personDict);
                        [contactsArray addObject:addObj];
                       
                    }
                }
                dispatch_async(dispatch_get_main_queue(), ^{
                    SearchContactArray = contactsArray;
                    searcStringArray = [SearchContactArray valueForKey:@"fullName"];
                    
                    [phoneContactTable reloadData];
                    
                    // [self.tableViewRef reloadData];
                });
            }
        }
    }];
}



- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    @try {
        
        
        return [contactsArray count];
    } @catch (NSException *exception) {
       // [self showAlertPop:@"Error in Data parsing." expObj:exception];
    } @finally {
        
    }
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 70
    ;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
           // static NSString *simpleTableIdentifier = @"MainCellLeft";
        PhoneContact_Cell *cell = (PhoneContact_Cell *)[tableView dequeueReusableCellWithIdentifier:@"PhoneContact_Cell"];
        if (cell == nil)
        {
            NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"PhoneContact_Cell" owner:self options:nil];
            cell = [nib objectAtIndex:0];
        }
    tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    
    NSDictionary *conObj = [contactsArray objectAtIndex:indexPath.row];
    cell.ContactName.text = [conObj valueForKey:@"fullName"];
    cell.PhoneNumber.text = [conObj valueForKey:@"phone"];
    if ([conObj valueForKey:@"Photoo"]) {
         cell.Cimage.image = [conObj valueForKey:@"Photoo"];
    }
    
    if ([seletedContacts containsObject:[contactsArray[indexPath.row] valueForKey:@"fullName"]]) {
        cell.CheckBtn.image=[UIImage imageNamed:@"aftercheck.png"];
    }
    else{
        cell.CheckBtn.image=[UIImage imageNamed:@"beforecheck.png"];
    }

    return cell;
}


-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSString *phoneNum = [[contactsArray objectAtIndex:indexPath.row] valueForKey:@"fullName"];
    if([seletedIndexs containsObject:indexPath]){
        [seletedContacts removeObject:phoneNum];
        [seletedIndexs removeObject:indexPath];
        
    } else {
        [seletedContacts addObject:phoneNum];
        [seletedIndexs addObject:indexPath];
    }
    [tableView reloadData];

}




//params.put("CustomerID", customerList.get(i).getCustomerID());
//params.put("UserRegisterID", session.getUserRegisterID());
//
//params.put("Name", customerList.get(i).getUserName());
//params.put("PhoneNo", customerList.get(i).getPhoneNumber());
//params.put("Email", DeviceGmailId);
//params.put("RowStatus", "A");
//
//params.put("Invited", customerList.get(i).isInvitedornot());
//params.put("InvitedDate", null);
//params.put("AlreadyMember", null);



-(NSMutableArray*)GetContactDetilas
{
    NSMutableArray *obj = [[NSMutableArray alloc]init];
    
    for (int i=0; i<[seletedIndexs count]; i++) {
        NSIndexPath *path=[seletedIndexs objectAtIndex:i];
        NSDictionary *ConObj = [contactsArray objectAtIndex:path.row];
        NSString    *encodecImage;
        
        NSDateFormatter *dateFormat = [[NSDateFormatter alloc] init];
        [dateFormat setDateFormat: @"yyyy-MM-dd HH:mm:ss"];
        
        //Optionally for time zone conversions
        [dateFormat setTimeZone:[NSTimeZone timeZoneWithAbbreviation:@"UTC"]];
        
        NSString *inviteDate = [dateFormat stringFromDate:[NSDate date]];
        
        if ([Invitekey isEqualToString:@"false"]) {
            inviteDate = @"";
        }
        
        
        if ([ConObj valueForKey:@"Photoo"]) {
            NSData* pictureData = UIImagePNGRepresentation([ConObj valueForKey:@"Photoo"]);
            encodecImage  =  [pictureData base64EncodedStringWithOptions:0];
        }
      else     encodecImage= @"";

        
        NSDictionary *CistObj = @{@"CustomerID":@"",
                                  @"UserRegisterID":UserRegiID,
                                  @"Name":[ConObj valueForKey:@"fullName"],
                                  @"PhoneNo":[ConObj valueForKey:@"phone"],
                                  @"Email":@"",
                                  @"RowStatus":@"A",
                                  @"Invited":Invitekey,
                                  @"InvitedDate":inviteDate,
                                  @"AlreadyMember":@"",
                                  @"PhotoName":encodecImage
                                  };
        
        [obj addObject:CistObj];
        
    }
    return obj;

}

-(IBAction)AddBtn:(id)sender
{
    Invitekey = @"false";
    NSMutableArray *CusObj= [self GetContactDetilas];
    NSString *ConString = [[NSString alloc]init];
    for (int i=0; i<[CusObj count]; i++) {
        if ([ConString isEqualToString:@""]) {
            ConString = [NSString stringWithFormat:@"%@",[CusObj objectAtIndex:i]];
        }
        else
        ConString = [NSString stringWithFormat:@"%@,%@",ConString,[CusObj objectAtIndex:i]];
    }
    
    NSDictionary *FinalInput = @{@"Customers":CusObj};
    
    NSDictionary *response = [mWebService SaveCustomer:FinalInput];
    if (response!=nil) {
        MyContacts *mContacts = [[MyContacts alloc]initWithNibName:@"MyContacts" bundle:nil];
        [self presentViewController:mContacts animated:YES completion:nil];
    }
    
}

-(IBAction)back:(id)sender
{
    [self dismissViewControllerAnimated:YES completion:nil];
}

-(void)sendInvitation:(NSMutableArray*)contactNumber
{
   // NSArray *PhoneNumArray =[NSArray arrayWithObjects:[contactNumber valueForKey:@"PhoneNo"], nil] ;
    
    MFMessageComposeViewController *controller = [[MFMessageComposeViewController alloc] init];
    if([MFMessageComposeViewController canSendText])
    {
        NSData  *VendorData =    [mPref valueForKey:@"SaveRegisterDetails"];
        NSDictionary *myDictionary =   (NSDictionary*) [NSKeyedUnarchiver unarchiveObjectWithData:VendorData];
        NSLog(@"%@",myDictionary);
        
        NSString *StoreName =@"";
        if ([[myDictionary valueForKey:@"ContactPerson"] isEqualToString:@""]) {
            StoreName= [myDictionary valueForKey:@"RegUserName"];
        }
        else StoreName= [myDictionary valueForKey:@"ContactPerson"];
        
        controller.body =[NSString stringWithFormat:@"Hi,\nI am using Right Place Right Time mobile app to post the offers of mystore.\nInstall the app from\nPlay store: http://bit.ly/2fdqw6N\n App store: http://apple.co/2fdvEaV\n\nRegards,\n%@",StoreName];

        controller.recipients =[contactNumber valueForKey:@"PhoneNo"];// [NSArray arrayWithObjects:[contactNumber valueForKey:@"PhoneNo"], nil];
        controller.messageComposeDelegate = self;
        
        [self presentViewController:controller animated:YES completion:nil];
    }

}


- (void)messageComposeViewController:(MFMessageComposeViewController *)controller didFinishWithResult:(MessageComposeResult)result
{
    
    switch (result)
    {
        case MessageComposeResultSent:
            
          
            
            break;
        case MessageComposeResultFailed:
            
         
            
            break;
        case MessageComposeResultCancelled:
            
           
            
            break;
            
        default:
            
            break;
    }
    
    [self dismissViewControllerAnimated:YES completion:nil];
    MyContacts *mContacts = [[MyContacts alloc]initWithNibName:@"MyContacts" bundle:nil];
    [self presentViewController:mContacts animated:YES completion:nil];

}




-(IBAction)BtnAddandInvite:(id)sender
{
    Invitekey = @"true";

 //   NSMutableArray *CusObj= [self GetContactDetilas];
    
    NSMutableArray *customArray  = [self GetContactDetilas];
    
    
    NSDictionary *myDeletCustomeObj = @{@"Customers":customArray};
    
    NSDictionary *respObj = [mWebService SaveCustomer:myDeletCustomeObj];
    
    NSMutableArray *mycustomerArray =respObj;
    NSString *phoneString =@"";
    for (int i=0; i<[mycustomerArray count]; i++) {
        NSString *isAlredyPresent = [NSString stringWithFormat:@"%@",[[mycustomerArray objectAtIndex:i] valueForKey:@"AlreadyMember"]];
        
        
        if ([isAlredyPresent isEqualToString:@"0"] || isAlredyPresent==nil || [isAlredyPresent isEqualToString:@""]) {
            if ([phoneString isEqualToString:@""]) {
                 phoneString = [NSString stringWithFormat:@"%@",[[mycustomerArray objectAtIndex:i] valueForKey:@"PhoneNo"]];
            }
            else
                 phoneString = [NSString stringWithFormat:@"%@,%@",phoneString,[[mycustomerArray objectAtIndex:i] valueForKey:@"PhoneNo"]];
           
        }
        
    }
  
    if (respObj!=nil && ![phoneString isEqualToString:@""]) {
        
        MFMessageComposeViewController *controller = [[MFMessageComposeViewController alloc] init];
        if([MFMessageComposeViewController canSendText])
        {
            NSData  *VendorData =    [mPref valueForKey:@"SaveRegisterDetails"];
            NSDictionary *myDictionary =   (NSDictionary*) [NSKeyedUnarchiver unarchiveObjectWithData:VendorData];
            NSLog(@"%@",myDictionary);
            
            NSArray *phoneNumb= [phoneString componentsSeparatedByString:@","];
            
            NSString *StoreName =@"";
            if ([[myDictionary valueForKey:@"ContactPerson"] isEqualToString:@""]) {
                StoreName= [myDictionary valueForKey:@"RegUserName"];
            }
            else StoreName= [myDictionary valueForKey:@"ContactPerson"];
            
            controller.body =[NSString stringWithFormat:@"Hi,\nI am using Right Place Right Time mobile app to post the offers of mystore.\nInstall the app from\nPlay store: http://bit.ly/2fdqw6N\n App store: http://apple.co/2fdvEaV\n\nRegards,\n%@",StoreName];
            
            controller.recipients =phoneNumb;// [NSArray arrayWithObjects:[contactNumber valueForKey:@"PhoneNo"], nil];
            controller.messageComposeDelegate = self;
            
            [self presentViewController:controller animated:YES completion:nil];
        }
        
        MyContacts *mContacts = [[MyContacts alloc]initWithNibName:@"MyContacts" bundle:nil
                                 ];
        [self presentViewController:mContacts animated:YES completion:nil];
    }
    else
 {
    MyContacts *mContacts = [[MyContacts alloc]initWithNibName:@"MyContacts" bundle:nil
                             ];
    [self presentViewController:mContacts animated:YES completion:nil];
 }
    
    
    
}




#pragma mark UISearchbar


- (void)searchBarTextDidBeginEditing:(UISearchBar *)searchBar {
    isSearching = YES;
}

- (void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)seachtext {
    NSLog(@"Text change - %d",isSearching);
    
    //Remove all objects first.
    // [filteredContentList removeAllObjects];
    
    if([seachtext length] != 0) {
        contactsArray = SearchContactArray;
        isSearching = YES;
        [self seachOffer:seachtext];
    }
    else if([seachtext length]==0)
    {
        contactsArray = SearchContactArray;
        [self.phoneContactTable reloadData];
    }
    else {
        isSearching = NO;
    }
    // [self.tblContentList reloadData];
}

- (void)seachOffer:(NSString *)substring {
    @try {
        // Put anything that starts with this substring into the autocompleteUrls array
        // The items in this array is what will show up in the table view
        NSPredicate *predicate = [NSPredicate predicateWithFormat:@"SELF contains [cd] %@", substring];
        NSArray  *results = [searcStringArray filteredArrayUsingPredicate:predicate];
        if ([results count]!=0) {
            
            NSMutableArray *array = [[NSMutableArray alloc]init];
            
            
            for (int i=0; i<[results count]; i++) {
                NSString  *str= [results objectAtIndex:i];
                
                for (int j=0; j<[contactsArray count]; j++) {
                    NSString *str2 = [[contactsArray objectAtIndex:j]  valueForKey:@"fullName"];
                    if ([str isEqualToString:str2]) {
                        [array addObject:[contactsArray objectAtIndex:j]];
                    }
                }
                
            }
            
            NSOrderedSet *orderedSet = [NSOrderedSet orderedSetWithArray:array];
            contactsArray = [orderedSet mutableCopy];
            
            
            
            
            // GetRetailerOpp = array;
            
            [self.phoneContactTable reloadData];
            
        }
        //[autoComplete reloadData];
    } @catch (NSException *exception) {
        // [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
}
-(void)searchBarTextDidEndEditing:(UISearchBar *)searchBar
{
    NSLog(@"Search Clicked");
    
    [searchBar resignFirstResponder];
}
-(void) searchBarCancelButtonClicked:(UISearchBar *)searchBar
{
    contactsArray = SearchContactArray;
    [self.phoneContactTable reloadData];
    
    [searchBar resignFirstResponder];
}


- (void)searchBarSearchButtonClicked :(UISearchBar *)searchBar {
    NSLog(@"Search Clicked");
    
    [searchBar resignFirstResponder];
    
}

-(void) viewDidLayoutSubviews {
    
    @try {
        
        
        [super viewDidLayoutSubviews];
        //[self.scrollview layoutIfNeeded];
        // self.scrollview.contentSize=self.Contentview.bounds.size;
        UIGraphicsBeginImageContext(self.view.frame.size);
        UIImage *image = UIGraphicsGetImageFromCurrentImageContext();
        UIGraphicsEndImageContext();
        image= [UIImage imageNamed:@"bgerror.png"];
        self.view.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"bgerror.png"]];
        
        
        
        
    } @catch (NSException *exception) {
        //[self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
}





/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
