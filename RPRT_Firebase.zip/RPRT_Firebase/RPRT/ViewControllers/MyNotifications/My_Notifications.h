//
//  My_Notifications.h
//  RPRT
//
//  Created by sravanthi Gumma on 15/10/1938 Saka.
//  Copyright © 1938 Saka DevpointSolutions. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface My_Notifications : UIViewController<UITableViewDelegate,UITableViewDataSource>
@property(weak,nonatomic) IBOutlet UITableView *notificationTable;
@property(weak,nonatomic) IBOutlet UILabel *emptyLbl;
@end
