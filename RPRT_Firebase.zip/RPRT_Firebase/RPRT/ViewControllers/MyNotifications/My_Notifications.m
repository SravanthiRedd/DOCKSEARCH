//
//  My_Notifications.m
//  RPRT
//
//  Created by sravanthi Gumma on 15/10/1938 Saka.
//  Copyright © 1938 Saka DevpointSolutions. All rights reserved.
//

#import "My_Notifications.h"
#import "AppDelegate.h"
#import "Home.h"
#import "Web_Services.h"
#import "My_NotificationCell.h"
#import "CustomIOSAlertView.h"
@interface My_Notifications ()<UITextViewDelegate,CustomIOSAlertViewDelegate>
{
    Web_Services *mWebService;
    NSUserDefaults *mPref;
    NSString *UserRegisterID;
    NSMutableArray *MyNotificationArray;
    CustomIOSAlertView *InviteAlert;
    UITextView *requesttext;
    NSDictionary *InviteObject;
    UIRefreshControl *refreshController;
    UIActivityIndicatorView *spinner;
}
@end

@implementation My_Notifications

- (void)viewDidLoad {
    [super viewDidLoad];
    mWebService= [Web_Services GetSharedInstance];
    mPref = [NSUserDefaults standardUserDefaults];
    UserRegisterID= [mPref valueForKey:USERREGISTERID];
    MyNotificationArray = [mWebService GetMyNotifications:UserRegisterID];
    
    refreshController = [[UIRefreshControl alloc] init];
    refreshController.tintColor = [UIColor grayColor];
    [refreshController addTarget:self action:@selector(refershControlAction) forControlEvents:UIControlEventValueChanged];
    [self.notificationTable addSubview:refreshController];
    self.notificationTable.alwaysBounceVertical = YES;
    self.emptyLbl.hidden=YES;
    
    // Do any additional setup after loading the view from its nib.
}

-(void)refershControlAction
{
    [refreshController endRefreshing];
    MyNotificationArray = [mWebService GetMyNotifications:UserRegisterID];
    [self.notificationTable reloadData];
    //[self viewDidLoad];
    
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    
    if([MyNotificationArray count]==0)
    {
        self.emptyLbl.hidden=NO;
        return 0;
    }
    else
    {
        self.emptyLbl.hidden=YES;
        return [MyNotificationArray count];
    }
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
        return 90;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    static NSString *CellIdentifier = @"My_NotificationCell";
    // Reuse and create cell
    My_NotificationCell *cell =(My_NotificationCell*) [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"My_NotificationCell" owner:self options:nil];
        cell = [nib objectAtIndex:0];
    }
    tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    
    NSDictionary *notifiObj = [MyNotificationArray objectAtIndex:indexPath.row];
    cell.notificationMesz.text = [notifiObj valueForKey:@"NotificationMessage"];
    NSString *NotificationType = [notifiObj valueForKey:@"NotificationType"];
    if ([NotificationType isEqualToString:@"Store Like"]) {
        cell.notificationIcon.image = [UIImage imageNamed:@"like_notify.png"];
    }
    else if ([NotificationType isEqualToString:@"Reserve"])
    {
        cell.notificationIcon.image = [UIImage imageNamed:@"reserved_notify.png"];
    }
    else if ([NotificationType isEqualToString:@"Interested"]) {
        cell.notificationIcon.image = [UIImage imageNamed:@"storereq_notify.png"];
    }
    else if ([NotificationType isEqualToString:@"Added"] ||[NotificationType isEqualToString:@"Customer Added"] || [NotificationType isEqualToString:@"New Customer"])
    {
        cell.notificationIcon.image = [UIImage imageNamed:@"added_notify.png"];
    }
    
    else if ([NotificationType isEqualToString:@"Store Request"])
    {
        cell.notificationIcon.image = [UIImage imageNamed:@"like_notify.png"];
    }
    else if ([NotificationType isEqualToString:@"Connected"])
    {
        cell.notificationIcon.image = [UIImage imageNamed:@"added_notify.png"];
    }
    else if ([NotificationType isEqualToString:@"Connect"])
    {
        cell.notificationIcon.image = [UIImage imageNamed:@"added_notify.png"];
    }
    else if([NotificationType isEqualToString:@"Customer Invite"])
    {
        cell.notificationIcon.image = [UIImage imageNamed:@"added_notify.png"];
    }
    else if ([NotificationType isEqualToString:@"Customer Add"])
    {
        cell.notificationIcon.image = [UIImage imageNamed:@"added_notify.png"];
    }
    else if ([NotificationType isEqualToString:@"Invite"])
    {
          cell.notificationIcon.image = [UIImage imageNamed:@"added_notify.png"];
    }
    //NotificationType = Connected;
    
    
    [cell.AcceptBtn addTarget:self action:@selector(AcceptBtn:) forControlEvents:UIControlEventTouchUpInside];
    [cell.RejectBtnBtn addTarget:self action:@selector(RejectBtnBtn:) forControlEvents:UIControlEventTouchUpInside];
    
    
    cell.AcceptBtn.hidden= YES;
    cell.RejectBtnBtn.hidden= YES;
    
    NSString *ShowInvite = [NSString stringWithFormat:@"%@",[notifiObj valueForKey:@"ShowInvite"]];
    
    NSString *ShowAcceptReject = [NSString stringWithFormat:@"%@",[notifiObj valueForKey:@"ShowAcceptReject"]];
    if ([ShowInvite isEqualToString:@"0"] && [ShowAcceptReject isEqualToString:@"0"]) {
        cell.accepttedDate.frame = CGRectMake(cell.AcceptBtn.frame.origin.x, cell.AcceptBtn.frame.origin.y, cell.accepttedDate.frame.size.width, cell.accepttedDate.frame.size.height);
    }
    
    
    
    
    if ([ShowInvite isEqualToString:@"1"]) {
        cell.AcceptBtn.hidden= NO;
        [cell.AcceptBtn setTitle:@"Invite" forState:UIControlStateNormal];
        cell.RejectBtnBtn.hidden= YES;
        cell.accepttedDate.frame = CGRectMake(cell.RejectBtnBtn.frame.origin.x, cell.RejectBtnBtn.frame.origin.y, cell.accepttedDate.frame.size.width, cell.accepttedDate.frame.size.height);
        
        
    }
    
    
    if ([ShowAcceptReject isEqualToString:@"1"])
    {
        cell.AcceptBtn.hidden= NO;
        [cell.AcceptBtn setTitle:@"Accept" forState:UIControlStateNormal];
        cell.RejectBtnBtn.hidden= NO;
        
    }
    
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"yyyy-MM-dd'T'HH:mm:ss.SSS"];
    NSTimeZone *gmt = [NSTimeZone timeZoneWithAbbreviation:@"UTC"];
    [dateFormatter setTimeZone:gmt];
    NSDate *date5 = [dateFormatter dateFromString:[notifiObj valueForKey:@"CreatedDate"]];
    
    if (date5==nil) {
        NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
        [dateFormatter setDateFormat:@"yyyy-MM-dd'T'HH:mm:ss.SSS"];
        NSTimeZone *gmt = [NSTimeZone timeZoneWithAbbreviation:@"UTC"];
        [dateFormatter setTimeZone:gmt];
        date5 = [dateFormatter dateFromString:[notifiObj valueForKey:@"CreatedDate"]];
        
        if (date5==nil) {
            NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
            [dateFormatter setDateFormat:@"yyyy-MM-dd'T'HH:mm:ss"];
            NSTimeZone *gmt = [NSTimeZone timeZoneWithAbbreviation:@"UTC"];
            [dateFormatter setTimeZone:gmt];
            date5 = [dateFormatter dateFromString:[notifiObj valueForKey:@"CreatedDate"]];
        }
        
    }
    
    NSDateFormatter *dateFormatter1 = [[NSDateFormatter alloc] init];
    [dateFormatter1 setDateFormat:@"yyyy-MM-dd'T'HH:mm:ss"];
    NSTimeZone *gmt1 = [NSTimeZone timeZoneWithAbbreviation:@"GMT"];
    [dateFormatter setTimeZone:gmt1];
    NSString *date = [dateFormatter1 stringFromDate:date5];
    
    date  = [date stringByReplacingOccurrencesOfString:@"T" withString:@" "];
    cell.accepttedDate.text = date;
    
    return cell;
    
}
-(void)AcceptBtn:(UIButton*)sender
{
    CGPoint buttonPosition = [sender convertPoint:CGPointZero toView:self.notificationTable];
    NSIndexPath *indexPath = [self.notificationTable indexPathForRowAtPoint:buttonPosition];
    NSDictionary *selectedFavAddress = [MyNotificationArray objectAtIndex:indexPath.row];
    
    NSString *ShowInvite = [NSString stringWithFormat:@"%@",[selectedFavAddress valueForKey:@"ShowInvite"]];
    NSString *ShowAcceptReject = [NSString stringWithFormat:@"%@",[selectedFavAddress valueForKey:@"ShowAcceptReject"]];
    //ShowAcceptReject
    NSString *NotificationId = [NSString stringWithFormat:@"%@",[selectedFavAddress valueForKey:@"NotificationId"]];
    
    if([ShowInvite isEqualToString:@"1"])
    {
        
        [self showinvitePopup:selectedFavAddress];

    }
    else if ([ShowAcceptReject isEqualToString:@"1"])
    {
        
        spinner = [[UIActivityIndicatorView alloc]
                   initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
        spinner.frame = CGRectMake(0, 0, 320, 560); // CGPointMake(160, 240);
        spinner.color = [UIColor blueColor];
        spinner.backgroundColor = [UIColor lightTextColor];
        spinner.transform = CGAffineTransformMakeScale(2, 2);
        // spinner.hidesWhenStopped = YES;
        [self.view addSubview:spinner];
        spinner.transform = CGAffineTransformMakeScale(2, 2);
        
        [spinner startAnimating];
        
        // how we stop refresh from freezing the main UI thread
        
        dispatch_async(
                       dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^{
                           
                           // back to the main thread for the UI call
                           dispatch_async(dispatch_get_main_queue(), ^{
                               [spinner startAnimating];
                           });
                           dispatch_async(dispatch_get_main_queue(), ^{
        
        
   NSString *acceptResponse =     [mWebService AcceptReject:NotificationId acceptReject:@"true"];
        acceptResponse =[acceptResponse stringByReplacingOccurrencesOfString:@"\"" withString:@""];
        
        if ([acceptResponse isEqualToString:@"1"]) {
            MyNotificationArray = [mWebService GetMyNotifications:UserRegisterID];
            [self.notificationTable reloadData];
             [self showAlertPop:@"Accepted sucessfully" expObj:nil];
            [spinner stopAnimating];
            
        }
                               [spinner stopAnimating];
                               
                           });
                       });
        
    }
    
    
}

- (void) showAlertPop:(NSString*)alertText expObj:(NSException*) exp{
    @try {
        
        if(exp != nil)
        {
            NSLog(@"%@", exp.description);
        }
        UIAlertController *myAlertController =[mWebService  alert:alertText];
        [self presentViewController:myAlertController animated:YES completion:nil];
    }
    @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    }
    @finally {
        
    }
    
}


-(void)RejectBtnBtn:(UIButton*)sender
{
    
    spinner = [[UIActivityIndicatorView alloc]
               initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
    spinner.frame = CGRectMake(0, 0, 320, 560); // CGPointMake(160, 240);
    spinner.color = [UIColor blueColor];
    spinner.backgroundColor = [UIColor lightTextColor];
    spinner.transform = CGAffineTransformMakeScale(2, 2);
    // spinner.hidesWhenStopped = YES;
    [self.view addSubview:spinner];
    spinner.transform = CGAffineTransformMakeScale(2, 2);
    
    [spinner startAnimating];
    
    // how we stop refresh from freezing the main UI thread
    
    dispatch_async(
                   dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^{
                       
                       // back to the main thread for the UI call
                       dispatch_async(dispatch_get_main_queue(), ^{
                           [spinner startAnimating];
                       });
                       dispatch_async(dispatch_get_main_queue(), ^{
    
    CGPoint buttonPosition = [sender convertPoint:CGPointZero toView:self.notificationTable];
    NSIndexPath *indexPath = [self.notificationTable indexPathForRowAtPoint:buttonPosition];
    NSDictionary *selectedFavAddress = [MyNotificationArray objectAtIndex:indexPath.row];
    
    NSString *NotificationId = [NSString stringWithFormat:@"%@",[selectedFavAddress valueForKey:@"NotificationId"]];
    [mWebService AcceptReject:NotificationId acceptReject:@"false"];
                       
                           [spinner stopAnimating];
                       });
                   });
}


/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

-(void)showinvitePopup:(NSDictionary*)inviteObject1
{
    
    InviteObject =inviteObject1;
            NSData  *VendorData =    [mPref valueForKey:@"SaveRegisterDetails"];
            NSDictionary *myDictionary =   (NSDictionary*) [NSKeyedUnarchiver unarchiveObjectWithData:VendorData];
            NSLog(@"%@",myDictionary);
            //[ [myDictionary  valueForKey:@"BusinessDeatils"] valueForKey:@"ContactPerson"]
    NSString *regName;
    if ([[mPref valueForKey:LOGINTYPE] isEqualToString:@"Business"]) {
        regName=[myDictionary valueForKey:@"RegUserName"];
    }
    else if ([[mPref valueForKey:LOGINTYPE] isEqualToString:@"Individual"])
        regName=[[myDictionary  valueForKey:@"BusinessDeatils"] valueForKey:@"ContactPerson"];
      
    NSString *InviteMessage= [NSString stringWithFormat:@"%@ would like to add you as a Customer, Customer's can enjoy extra benefits!!",regName];
    
    
    
    InviteAlert=[[CustomIOSAlertView alloc] init];
    UIView  *replyView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 300, 250)];
    [InviteAlert setContainerView:replyView];
    [InviteAlert setButtonTitles:[NSMutableArray arrayWithObjects:@"", nil]];
    
    [InviteAlert setDelegate:self];
    
    
    // You may use a Block, rather than a delegate.
    [InviteAlert setOnButtonTouchUpInside:^(CustomIOSAlertView *alertView, int buttonIndex) {
        NSLog(@"Block: Button at position %d is clicked on alertView %d.", buttonIndex, (int)[alertView tag]);
        [alertView close];
    }];
    
    [InviteAlert setUseMotionEffects:true];
    
    
    UILabel *requestTitle = [[UILabel alloc]initWithFrame:CGRectMake(5, 5, 200, 20)];
    requestTitle.text = @"Right Place Right Time";
    [requestTitle setFont:[UIFont fontWithName:@"Roboto-Medium" size:14]];
    
//    
//    UIButton *cancel = [[UIButton alloc]initWithFrame:CGRectMake(275, 0, 20, 20)];
//    
//    [cancel setImage:[UIImage imageNamed:@"ic_close"] forState:UIControlStateNormal];
//    [cancel addTarget:self action:@selector(cancel:) forControlEvents:UIControlEventTouchUpInside];
    [replyView addSubview:requestTitle];
    
    UILabel *requestName = [[UILabel alloc]initWithFrame:CGRectMake(5, 30, 100, 20)];
    requestName.text = @"Request :";
    [requestName setFont:[UIFont fontWithName:@"Roboto-Medium" size:15]];
    [replyView addSubview:requestName];
    
    requesttext = [[UITextView alloc]initWithFrame:CGRectMake(5, 50, 290, 140)];
    requesttext.delegate= self;
    requesttext.layer.borderColor = [UIColor lightTextColor].CGColor;
    requesttext.text= InviteMessage;
    [replyView addSubview:requesttext];
    
    UIButton *sendBtn = [[UIButton alloc] initWithFrame:CGRectMake(160, 200, 140, 40)];
    [sendBtn setTitle:@"OK" forState:UIControlStateNormal];
    [sendBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [sendBtn addTarget:self action:@selector(sendBtn:) forControlEvents:UIControlEventTouchUpInside];
    sendBtn.backgroundColor =[UIColor colorWithRed:144.0/256.0 green:147.0/256.0 blue:167.0/256.0 alpha:1];
    [replyView addSubview:sendBtn];
    
    UIButton *Cancel = [[UIButton alloc] initWithFrame:CGRectMake(10, 200, 140, 40)];
    [Cancel setTitle:@"Cancel" forState:UIControlStateNormal];
    [Cancel setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [Cancel addTarget:self action:@selector(Cancel:) forControlEvents:UIControlEventTouchUpInside];
    Cancel.backgroundColor =[UIColor colorWithRed:144.0/256.0 green:147.0/256.0 blue:167.0/256.0 alpha:1];
    [replyView addSubview:Cancel];
    
    
   // [replyView addSubview:cancel];
    
    [InviteAlert show];
    replyView.tag = 2;


}

-(void)sendBtn:(UIButton*)sender
{
    
    spinner = [[UIActivityIndicatorView alloc]
               initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
    spinner.frame = CGRectMake(0, 0, 320, 560); // CGPointMake(160, 240);
    spinner.color = [UIColor blueColor];
    spinner.backgroundColor = [UIColor lightTextColor];
    spinner.transform = CGAffineTransformMakeScale(2, 2);
    // spinner.hidesWhenStopped = YES;
    [self.view addSubview:spinner];
    spinner.transform = CGAffineTransformMakeScale(2, 2);
    
    [spinner startAnimating];
    
    // how we stop refresh from freezing the main UI thread
    
    dispatch_async(
                   dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^{
                       
                       // back to the main thread for the UI call
                       dispatch_async(dispatch_get_main_queue(), ^{
                           [spinner startAnimating];
                       });
                       dispatch_async(dispatch_get_main_queue(), ^{
    
    
    NSString *NotificationId = [NSString stringWithFormat:@"%@",[InviteObject valueForKey:@"NotificationId"]];
    
   NSString *requestReponse = [mWebService SendInvite:NotificationId inviteMessage:requesttext.text];
    
    
requestReponse = [requestReponse stringByReplacingOccurrencesOfString:@"\"" withString:@""];
    if([requestReponse isEqualToString:@"1"])
    {
        
         MyNotificationArray = [mWebService GetMyNotifications:UserRegisterID];
        [self.notificationTable reloadData];
        
      [self showAlertPop:@"Invited sucessfully" expObj:nil];
    }
    
//NSLog(@"%@",requestReponse);
    
     [InviteAlert close];
   // [self viewDidLoad];
                           
                           [spinner stopAnimating];
                           
                           
                       });
                   });

}

-(void)Cancel:(UIButton*)sender
{
    [InviteAlert close];
}

-(IBAction)back:(id)sender
{
    [self dismissViewControllerAnimated:YES completion:nil];
}
@end
