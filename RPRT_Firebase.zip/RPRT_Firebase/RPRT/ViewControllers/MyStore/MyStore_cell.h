//
//  MyStore_cell.h
//  RPRT
//
//  Created by sravanthi Gumma on 17/09/1938 Saka.
//  Copyright © 1938 Saka DevpointSolutions. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MyStore_cell : UITableViewCell

@property(nonatomic,weak) IBOutlet UIImageView *barcodeImage;
@property(nonatomic,weak) IBOutlet UILabel *Activationcode;
@property(nonatomic,weak) IBOutlet UILabel *ActivationDate;
@property(nonatomic,weak) IBOutlet UILabel *salesCode;
@property(nonatomic,weak) IBOutlet UILabel *BusinessName;
@property(nonatomic,weak) IBOutlet UILabel *ContactPerson;
@property(nonatomic,weak) IBOutlet UILabel *PhoneNo;
@property(nonatomic,weak) IBOutlet UILabel *StoreAddress;
@property(nonatomic,weak) IBOutlet UIImageView *profileImage;
@property(nonatomic,weak) IBOutlet UIView *customView;;


//{
//    ActivationCodeId = 5;
//    ActivationDate = "2016-12-07T15:37:32.057";
//    Activationcode = RPRT537;
//    BusinessName = "Karthik real estate ";
//    ContactPerson = "Karthik chevella";
//    DateGenerated = "0001-01-01T00:00:00";
//    IsUsed = 0;
//    LatLong = "17.4296936,78.445753";
//    PhoneNo = 0985632147;
//    PhotoName = "113-20161207120554952PM.jpg,113-20161207120554921PM.jpg,";
//    RowStatus = "<null>";
//    SalesPersonId = 0;
//    StoreAddress = "8-3-1116/2, Hyderabad, India";
//    UserRegisterID = 113;
//},


@end
