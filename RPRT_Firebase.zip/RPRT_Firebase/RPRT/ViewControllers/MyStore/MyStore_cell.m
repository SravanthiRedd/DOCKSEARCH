//
//  MyStore_cell.m
//  RPRT
//
//  Created by sravanthi Gumma on 17/09/1938 Saka.
//  Copyright © 1938 Saka DevpointSolutions. All rights reserved.
//

#import "MyStore_cell.h"

@implementation MyStore_cell

@synthesize barcodeImage= barcodeImage;
@synthesize Activationcode= Activationcode;
@synthesize ActivationDate = ActivationDate;
@synthesize salesCode = salesCode;
@synthesize BusinessName= BusinessName;
@synthesize ContactPerson = ContactPerson;
@synthesize PhoneNo = PhoneNo;
@synthesize StoreAddress = StoreAddress;
@synthesize profileImage= profileImage;

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

-(void)layoutSubviews{
    
    self.customView.layer.shadowColor = [UIColor grayColor].CGColor;
    self.customView.layer.borderColor = [UIColor colorWithRed:175.0/256.0 green:175.0/256.0 blue:175.0/256.0 alpha:1].CGColor;
    self.customView.layer.borderWidth=0.5f;
    self.customView.layer.shadowOffset = CGSizeMake(1.0, 1.0);
    self.customView.layer.shadowOpacity = 0.7;
    self.customView.layer.cornerRadius = 4.0;
  
    self.profileImage.layer.cornerRadius = self.profileImage.frame.size.width/2;
    self.profileImage.layer.masksToBounds = YES;

    
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
