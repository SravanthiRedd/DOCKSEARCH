//
//  My_Store.h
//  RPRT
//
//  Created by sravanthi Gumma on 16/09/1938 Saka.
//  Copyright © 1938 Saka DevpointSolutions. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface My_Store : UIViewController
@property(weak,nonatomic) IBOutlet UITableView *mysalesCodeTable;
@property (weak,nonatomic) IBOutlet UILabel *mysalesCode;
@property (weak,nonatomic) IBOutlet UIImageView *QRimage;
@property(weak,nonatomic) IBOutlet UIView *GetMyCodeBtnView;
@property(weak,nonatomic) IBOutlet UIView *GetMyCodeView;
@property(weak,nonatomic) IBOutlet UIView *GetMyCodesView;
@end
