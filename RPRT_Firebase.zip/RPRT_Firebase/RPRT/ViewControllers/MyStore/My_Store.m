//
//  My_Store.m
//  RPRT
//
//  Created by sravanthi Gumma on 16/09/1938 Saka.
//  Copyright © 1938 Saka DevpointSolutions. All rights reserved.
//

#import "My_Store.h"
#import "MainViewController.h"
#import "MyStore_cell.h"
#import "UIImage+MDQRCode.h"
@interface My_Store ()<UITableViewDelegate,UITableViewDataSource>
{
    Web_Services *mWebSerice;
    NSUserDefaults *mPref;
    NSMutableArray *mysalesCodeArray;
}
@end

@implementation My_Store

- (void)viewDidLoad {
    [super viewDidLoad];
    mWebSerice = [Web_Services GetSharedInstance];
    mPref = [NSUserDefaults standardUserDefaults];
   
    [self getMysalesCode];
    [self.mysalesCodeTable reloadData];
    
    self.GetMyCodeView.layer.shadowColor = [UIColor grayColor].CGColor;
    self.GetMyCodeView.layer.borderColor = [UIColor colorWithRed:175.0/256.0 green:175.0/256.0 blue:175.0/256.0 alpha:1].CGColor;
    self.GetMyCodeView.layer.borderWidth=0.5f;
    self.GetMyCodeView.layer.shadowOffset = CGSizeMake(1.0, 1.0);
    self.GetMyCodeView.layer.shadowOpacity = 0.7;
    self.GetMyCodeView.layer.cornerRadius = 4.0;
    
    self.GetMyCodesView.layer.shadowColor = [UIColor grayColor].CGColor;
    self.GetMyCodesView.layer.borderColor = [UIColor colorWithRed:175.0/256.0 green:175.0/256.0 blue:175.0/256.0 alpha:1].CGColor;
    self.GetMyCodesView.layer.borderWidth=0.5f;
    self.GetMyCodesView.layer.shadowOffset = CGSizeMake(1.0, 1.0);
    self.GetMyCodesView.layer.shadowOpacity = 0.7;
    self.GetMyCodesView.layer.cornerRadius = 4.0;
    
    
    self.GetMyCodeBtnView.layer.shadowColor = [UIColor grayColor].CGColor;
    self.GetMyCodeBtnView.layer.borderColor = [UIColor colorWithRed:175.0/256.0 green:175.0/256.0 blue:175.0/256.0 alpha:1].CGColor;
    self.GetMyCodeBtnView.layer.borderWidth=0.5f;
    self.GetMyCodeBtnView.layer.shadowOffset = CGSizeMake(1.0, 1.0);
    self.GetMyCodeBtnView.layer.shadowOpacity = 0.7;
    self.GetMyCodeBtnView.layer.cornerRadius = 4.0;

    
    // Do any additional setup after loading the view from its nib.
}

-(void)getMysalesCode
{
   mysalesCodeArray= [mWebSerice MySalesCodes:[mPref valueForKey:USERREGISTERID]];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void) viewDidLayoutSubviews {
    
    @try {
        
        
        [super viewDidLayoutSubviews];
        //[self.scrollview layoutIfNeeded];
        // self.scrollview.contentSize=self.Contentview.bounds.size;
        UIGraphicsBeginImageContext(self.view.frame.size);
        UIImage *image = UIGraphicsGetImageFromCurrentImageContext();
        UIGraphicsEndImageContext();
        image= [UIImage imageNamed:@"bgerror.png"];
        self.view.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"bgerror.png"]];
        
        
        
        
    } @catch (NSException *exception) {
        //[self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
}

-(IBAction)GenerateSalesCode:(id)sender
{
    NSString *codestring =[NSString stringWithFormat:@"%@",[mPref valueForKey:USERREGISTERID]];
    codestring = [NSString stringWithFormat:@"%@/%@",codestring,@"Sale"];
    NSString *reponseCode = [mWebSerice GenerateSalesCode:codestring];
    self.mysalesCode.text = [NSString stringWithFormat:@"%@",reponseCode];
    
    CGFloat imageSize = ceilf(self.view.bounds.size.width * 0.6f);
    UIImageView *imageView = [[UIImageView alloc] initWithFrame:CGRectMake(floorf(self.view.bounds.size.width * 0.5f - imageSize * 0.5f), floorf(self.view.bounds.size.height * 0.5f - imageSize * 0.5f), imageSize, imageSize)];
    self.QRimage.image  =[UIImage mdQRCodeForString:reponseCode size:imageView.bounds.size.width fillColor:[UIColor darkGrayColor]];

    [self getMysalesCode];
    [self.mysalesCodeTable reloadData];
    
}


-(IBAction)GenerateDemoCode:(id)sender
{
    NSString *codestring =[NSString stringWithFormat:@"%@",[mPref valueForKey:USERREGISTERID]];
    codestring = [NSString stringWithFormat:@"%@/%@",codestring,@"Demo"];
    NSString *reponseCode = [mWebSerice GenerateSalesCode:codestring];
    self.mysalesCode.text = [NSString stringWithFormat:@"%@",reponseCode];
    CGFloat imageSize = ceilf(self.view.bounds.size.width * 0.6f);
    UIImageView *imageView = [[UIImageView alloc] initWithFrame:CGRectMake(floorf(self.view.bounds.size.width * 0.5f - imageSize * 0.5f), floorf(self.view.bounds.size.height * 0.5f - imageSize * 0.5f), imageSize, imageSize)];
    self.QRimage.image  =[UIImage mdQRCodeForString:reponseCode size:imageView.bounds.size.width fillColor:[UIColor darkGrayColor]];
    [self getMysalesCode];
    [self.mysalesCodeTable reloadData];
    
}


- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    
    return mysalesCodeArray.count;
    // return 10;
    
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 155;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    
    
    MyStore_cell *cell = (MyStore_cell *)[tableView dequeueReusableCellWithIdentifier:@"MyStore_cell"];
    
    if (cell == nil)
    {
        NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"MyStore_cell" owner:self options:nil];
        cell = [nib objectAtIndex:0];
    }
    
    tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
 NSDictionary     *type = [mysalesCodeArray objectAtIndex:indexPath.row];
    cell.salesCode.text = [type valueForKey:@"Activationcode"];
    
    NSString *qrString = [NSString stringWithFormat:@"%@",[type valueForKey:@"Activationcode"]];
    
    CGFloat imageSize = ceilf(self.view.bounds.size.width * 0.6f);
    UIImageView *imageView = [[UIImageView alloc] initWithFrame:CGRectMake(floorf(self.view.bounds.size.width * 0.5f - imageSize * 0.5f), floorf(self.view.bounds.size.height * 0.5f - imageSize * 0.5f), imageSize, imageSize)];
    cell.barcodeImage.image  =[UIImage mdQRCodeForString:qrString size:imageView.bounds.size.width fillColor:[UIColor darkGrayColor]];
    cell.PhoneNo.text =[type valueForKey:@"PhoneNo"];
     cell.ContactPerson.text =[type valueForKey:@"ContactPerson"];
     cell.BusinessName.text =[type valueForKey:@"BusinessName"];
     cell.Activationcode.text =[type valueForKey:@"Activationcode"];
    cell.ActivationDate.text =[type valueForKey:@"ActivationDate"];
    cell.StoreAddress.text = [type valueForKey:@"StoreAddress"];
    
    
    NSString *imageName = [NSString stringWithFormat:@"%@",[type valueForKey:@"PhotoName"]];;
    NSArray *imageAry = [imageName componentsSeparatedByString:@","];
    NSString *ImageURL = [NSString stringWithFormat:@"%@%@",baseImageURL, [imageAry objectAtIndex:0]];
    
    NSURL *imageURL = [NSURL URLWithString:ImageURL];
    NSString *key = [ImageURL MD5Hash];
    NSData *getData = [FTWCache objectForKey:key];
    if (getData) {
        UIImage *image = [UIImage imageWithData:getData];
        cell.profileImage.image  = image;
    }
    else {
        cell.profileImage.image  = [UIImage imageNamed:@"img_def"];
        dispatch_queue_t queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_HIGH, 0ul);
        dispatch_async(queue, ^{
            NSData *newData = [NSData dataWithContentsOfURL:imageURL];
            [FTWCache setObject:newData forKey:key];
            UIImage *image = [UIImage imageWithData:newData];
            dispatch_sync(dispatch_get_main_queue(), ^{
                cell.profileImage.image  = image;
                
            });
        });
        
        
    }

    
    
    return cell;

}


-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    @try {
        
        NSString *VenDorRedID = [[mysalesCodeArray objectAtIndex:indexPath.row] valueForKey:@"UserRegisterID"];
        
        NSString *userRegID = [mPref valueForKey:USERREGISTERID];
        if(VenDorRedID!=nil && ![VenDorRedID isEqualToString:@""])
        {
            
            NSString *FinalId = [NSString stringWithFormat:@"%@/%@",VenDorRedID,userRegID];
            
            NSDictionary *getStoreResp =[ mWebSerice GetStoreDetails:FinalId];
            
            Store_Details *mStoreDetails = [[Store_Details alloc]initWithNibName:@"Store_Details" bundle:nil];
            mStoreDetails.GetStoreDeatils =getStoreResp;
            [self presentViewController:mStoreDetails animated:YES completion:nil];
        }
        
    }
    @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }

}


- (void) showAlertPop:(NSString*)alertText expObj:(NSException*) exp{
    if(exp != nil)
    {
        NSLog(@"%@", exp.description);
    }
    UIAlertController *myAlertController =[mWebSerice  alert:alertText];
    [self presentViewController:myAlertController animated:YES completion:nil];
}


//ActivationCodeId = 5;
//ActivationDate = "2016-12-07T15:37:32.057";
//Activationcode = RPRT537;
//BusinessName = "Karthik real estate ";
//ContactPerson = "Karthik chevella";
//DateGenerated = "0001-01-01T00:00:00";
//IsUsed = 0;
//LatLong = "17.4296936,78.445753";
//PhoneNo = 0985632147;
//PhotoName = "113-20161207120554952PM.jpg,113-20161207120554921PM.jpg,";
//RowStatus = "<null>";
//SalesPersonId = 0;
//StoreAddress = "8-3-1116/2, Hyderabad, India";
//UserRegisterID = 113;
//},



/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

-(IBAction)back:(id)sender
{
    [self dismissViewControllerAnimated:YES completion:nil];
}
@end
