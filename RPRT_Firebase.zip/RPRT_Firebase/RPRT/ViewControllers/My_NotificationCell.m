//
//  My_NotificationCell.m
//  RPRT
//
//  Created by sravanthi Gumma on 15/10/1938 Saka.
//  Copyright © 1938 Saka DevpointSolutions. All rights reserved.
//

#import "My_NotificationCell.h"

@implementation My_NotificationCell
@synthesize notificationMesz= notificationMesz;
@synthesize notificationView= notificationView;
@synthesize notificationIcon = notificationIcon;
@synthesize accepttedDate = accepttedDate;

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}
-(void)layoutSubviews{
    
    self.notificationView.layer.shadowColor = [UIColor grayColor].CGColor;
    self.notificationView.layer.borderColor = [UIColor colorWithRed:175.0/256.0 green:175.0/256.0 blue:175.0/256.0 alpha:1].CGColor;
    self.notificationView.layer.borderWidth=0.5f;
    self.notificationView.layer.shadowOffset = CGSizeMake(1.0, 1.0);
    // self.notificationView.layer.shadowOpacity = 0.7;
    // self.notificationView.layer.cornerRadius = 4.0;
    
    self.AcceptBtn.layer.cornerRadius=4.0;
    self.RejectBtnBtn.layer.cornerRadius=4.0;
    
    
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
    
    // Configure the view for the selected state
}


@end
