//
//  NearBy_Users.h
//  RPRT
//
//  Created by sravanthi Gumma on 19/08/16.
//  Copyright © 2016 DevpointSolutions. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MapKit/MapKit.h>
#import <CoreLocation/CoreLocation.h>
@interface NearBy_Users : UIViewController<CLLocationManagerDelegate,MKMapViewDelegate>

@property(nonatomic,strong) IBOutlet MKMapView *mapView;
@property(nonatomic,strong) IBOutlet UILabel *nearbyUsersCount;

@end
