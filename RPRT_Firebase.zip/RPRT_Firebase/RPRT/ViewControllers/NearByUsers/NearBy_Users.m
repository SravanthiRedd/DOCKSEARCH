//
//  NearBy_Users.m
//  RPRT
//
//  Created by sravanthi Gumma on 19/08/16.
//  Copyright © 2016 DevpointSolutions. All rights reserved.
//

#import "NearBy_Users.h"
#import "GeoCodeLocation.h"
#import "CurrentLocation.h"
#import "Constances.h"
#import "MainViewController.h"
#import "MapPoint.h"

@interface NearBy_Users ()
{
    CLLocationManager *locationManager;
    CLLocationCoordinate2D currentCentre;
    int currenDist;
    BOOL firstLaunch;
    GeoCodeLocation *geoCode;
    Web_Services *mWebService;
}
@end


@implementation NearBy_Users
@synthesize nearbyUsersCount;

- (void)viewDidLoad {
    [super viewDidLoad];
    
    @try {
        
    mWebService = [Web_Services GetSharedInstance];
    geoCode = [GeoCodeLocation GetSharedInstance];
    [self loadUserCurrentLocation];
    [self getNearBuUsers];
    
    //UILabel *nearByUserCountLbl= [UILabel alloc]initWithFrame:<#(CGRect)#>
    
    
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." exceptionVal:exception];
    } @finally {
        
    }
    
    // Do any additional setup after loading the view from its nib.
}

-(void)loadUserCurrentLocation
{
    @try {
        
   
    
    self.mapView.delegate = self;
    // Ensure that we can view our own location in the map view.
    [self.mapView setShowsUserLocation:YES];
    //Instantiate a location object.
    locationManager = [[CLLocationManager alloc] init];
    locationManager.delegate = self;
    [locationManager setDesiredAccuracy:kCLLocationAccuracyBest];
    if ([[[UIDevice currentDevice] systemVersion] floatValue] >= 8) {
        [locationManager requestAlwaysAuthorization];
    }
    if ([[[UIDevice currentDevice] systemVersion] floatValue] >= 9.2) {
        // locationManager.allowsBackgroundLocationUpdates = YES;
    }
    [locationManager startUpdatingLocation];
    CLLocation *location = [locationManager location];
    // coordinate = [location coordinate];
    CLLocationCoordinate2D centre = [self.mapView centerCoordinate];
    MKCoordinateRegion region;
    if (firstLaunch) {
        region = MKCoordinateRegionMakeWithDistance(locationManager.location.coordinate,10000,10000);
        firstLaunch=NO;
    }else {
        MKMapRect mRect = self.mapView.visibleMapRect;
        MKMapPoint eastMapPoint = MKMapPointMake(MKMapRectGetMinX(mRect), MKMapRectGetMidY(mRect));
        MKMapPoint westMapPoint = MKMapPointMake(MKMapRectGetMaxX(mRect), MKMapRectGetMidY(mRect));
        currenDist = MKMetersBetweenMapPoints(eastMapPoint, westMapPoint);
        region = MKCoordinateRegionMakeWithDistance(centre,currenDist,currenDist);
    }
    MKCoordinateSpan span;
    span.latitudeDelta  = 0; // Change these values to change the zoom
    span.longitudeDelta = 0;
    region.span = span;
    
    [self.mapView setRegion:region animated:YES];
    self.mapView.centerCoordinate = location.coordinate;
  //  CurrentLocation *locations; CLLocationCoordinate2D *crentLoc;
    CurrentLocation *locations = [CurrentLocation alloc];
    
    double lat = location.coordinate.latitude;
    double lon= location.coordinate.longitude;
    geoCode = [locations geoCodeArea:&lat Longitude:&lon];
    
    MKCircle *circle = [MKCircle circleWithCenterCoordinate:location.coordinate radius:500];
    [self.mapView addOverlay:circle];
        
    } @catch (NSException *exception) {
         [self showAlertPop:@"Error while fetching data." exceptionVal:exception];
    } @finally {
        
    }
    
    
}


- (MKOverlayView *)mapView:(MKMapView *)mapView viewForOverlay:(id<MKOverlay>)overlay
{
    MKCircleView *circleView = [[MKCircleView alloc] initWithOverlay:overlay];
    
    [circleView setFillColor:[UIColor clearColor]];
    [circleView setStrokeColor:[UIColor blackColor]];
    [circleView setAlpha:0.5f];
    return circleView;
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)getNearBuUsers
{
    @try {
        
        NSMutableDictionary *locatioLatLon = [[NSMutableDictionary alloc]init];
        [locatioLatLon setValue:geoCode.Latitude forKey:LATITUDE];
        [locatioLatLon setValue:geoCode.Longitude forKey:LONGITUDE];
        [locatioLatLon setValue:geoCode.State forKey:@"State"];
        [locatioLatLon setValue:geoCode.Country forKey:@"Country"];
        
     NSUserDefaults   *mPref = [NSUserDefaults standardUserDefaults];
        NSString *radious;
        if ([mPref valueForKey:@"Radious"]==nil) {
            radious = @"500";
            
        }
        else
            radious =[mPref valueForKey:@"Radious"];
        
       
        [locatioLatLon setValue:[mPref valueForKey:MODULEID] forKey:@"ModuleId"];
        [locatioLatLon setValue:radious forKey:@"Radious"];
       
    NSMutableArray  *getOpportutnity =[mWebService GetUsersInfo:locatioLatLon];
        
        
        if (getOpportutnity.count>0) {
            
            nearbyUsersCount.text = [NSString stringWithFormat:@"%lu users are near by you",(unsigned long)getOpportutnity.count];
            
            [self plotPositions:getOpportutnity];
        }

      //  return getOpportutnity;

        
    }
    @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." exceptionVal:exception];
    }
    @finally {
        
    }
}

- (void)plotPositions:(NSMutableArray *)data
{
    @try {
        
        //Remove any existing custom annotations but not the user location blue dot.
        for (id<MKAnnotation> annotation in self.mapView.annotations)
        {
            if ([annotation isKindOfClass:[MapPoint class]])
            {
                [self.mapView removeAnnotation:annotation];
            }
        }
        
        
        //Loop through the array of places returned from the Google API.
        for (int i=0; i<[data count]; i++)
        {
            
            //Retrieve the NSDictionary object in each index of the array.
            NSDictionary* place = [data objectAtIndex:i];
            
            
            
            //Get our name and address info for adding to a pin.
            NSString *name=[place objectForKey:@"VendorName"];
            
            
            NSString *vicinity= [NSString stringWithFormat:@"%@,%@,%@,%@,%@",[place objectForKey:@"UserNme"] ,[place objectForKey:@"Address2"],[place objectForKey:@"Address3"],[place objectForKey:@"City"],[place objectForKey:@"Country"]];
            
            CLLocationCoordinate2D coordinate;
            
            //Set the lat and long.
            coordinate.latitude=[[place objectForKey:LATITUDE] doubleValue];
            coordinate.longitude=[[place objectForKey:LONGITUDE] doubleValue];
            
            //Create a new annotiation.
            MapPoint *placeObject = [[MapPoint alloc] initWithName:name address:vicinity coordinate:coordinate];
            
            if ([place valueForKey:FOOD]) {
               // imageName= @"";
            }
            
            [self.mapView addAnnotation:placeObject];
            
            
        }
        
    }
    @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." exceptionVal:exception];
    }
    @finally {
        
    }
    
    
}


- (void) showAlertPop:(NSString*)alertText exceptionVal:(NSException*)ex {
    //mWeservice
    UIAlertController *myAlertController =[mWebService  alert:alertText];
    [self presentViewController:myAlertController animated:YES completion:nil];
    if(ex != nil)
    {
        NSLog(@"%@", ex.description);
    }
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

-(IBAction)back:(id)sender
{
    
    [self dismissViewControllerAnimated:YES completion:nil];
}

@end
