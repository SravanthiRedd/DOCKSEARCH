//
//  Details_FoodAndSales.h
//  RPRT
//
//  Created by sravanthi Gumma on 12/09/16.
//  Copyright © 2016 DevpointSolutions. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MainViewController.h"
#import "Web_Services.h"
#import <MessageUI/MessageUI.h>

@interface Details_FoodAndSales : UIViewController<UIScrollViewDelegate,MFMailComposeViewControllerDelegate,MFMessageComposeViewControllerDelegate>
{
    NSDictionary *getSelctedOpp;
}


@property(nonatomic,strong) NSString *Pagekey;

@property (nonatomic,strong) IBOutlet UIButton *bLockBtn;
@property (strong,nonatomic)  IBOutlet UILabel *offerName;
@property (strong,nonatomic)  IBOutlet UILabel *subCategory;
@property (strong,nonatomic)  IBOutlet UILabel *vendorname;
@property (strong,nonatomic)  IBOutlet UILabel *offerDescription;
@property (strong,nonatomic)  IBOutlet UILabel *actualPrice;
@property (strong,nonatomic)  IBOutlet UILabel *offerprice;
@property (strong,nonatomic)  IBOutlet UILabel *deliveryStatus;
@property (strong,nonatomic)  IBOutlet UILabel *address;
@property (strong,nonatomic)  IBOutlet UILabel *phoneNumber;
@property (strong,nonatomic)  IBOutlet UILabel *offerDate;
@property (strong,nonatomic)  IBOutlet UILabel *offerStatus;
@property (strong,nonatomic)  IBOutlet UILabel *available;
@property (strong,nonatomic) IBOutlet UIImageView *scrollImage;

@property(strong,nonatomic) IBOutlet UIView *contentView;
@property(strong,nonatomic) IBOutlet UIScrollView *photoScroll;
@property(strong,nonatomic) IBOutlet UIScrollView *scrollView;

@property (nonatomic,retain)  NSDictionary *SetSelectedOpportunity;
@property (nonatomic,weak) IBOutlet UIView *quantityView;
@property (strong,nonatomic)  IBOutlet UILabel *quantityLbl;

@property(strong,nonatomic) IBOutlet UIImageView *qrImage;
@property(strong,nonatomic) IBOutlet UIButton *btn;
@property(strong,nonatomic) IBOutlet UILabel *lbl;
@property(weak,nonatomic) IBOutlet UIImageView *deliveryIcon;
@property(strong,nonatomic) IBOutlet UIButton *userBlocks;



-(IBAction)increment:(id)sender;
-(IBAction)decrement:(id)sender;

-(IBAction)back:(id)sender;
-(IBAction)myBlocks:(id)sender;
-(IBAction)shareBtn:(id)sender;

@end
