//
//  Details_GameandJobs.h
//  RPRT
//
//  Created by sravanthi Gumma on 14/09/16.
//  Copyright © 2016 DevpointSolutions. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "CustomIOSAlertView.h"
#import <MessageUI/MessageUI.h>


@interface Details_GameandJobs : UIViewController<CustomIOSAlertViewDelegate,MFMessageComposeViewControllerDelegate,MFMailComposeViewControllerDelegate,UIScrollViewDelegate>
{
    NSDictionary *getSelctedOpp;
    NSString *categoryName;
    CustomIOSAlertView *ImageAlert;
}
@property(nonatomic,strong) NSString *Pagekey;
@property (nonatomic,strong) IBOutlet UIButton *bLockBtn;
@property (strong,nonatomic)  IBOutlet UILabel *offerName;
@property (strong,nonatomic)  IBOutlet UILabel *subCategory;
@property (strong,nonatomic)  IBOutlet UILabel *vendorname;
@property (strong,nonatomic)  IBOutlet UILabel *offerDescription;
@property (strong,nonatomic)  IBOutlet UILabel *skillset;

@property (strong,nonatomic)  IBOutlet UILabel *address;
@property (strong,nonatomic)  IBOutlet UILabel *phoneNumber;
@property (strong,nonatomic)  IBOutlet UILabel *offerDate;
@property (strong,nonatomic)  IBOutlet UILabel *offerStatus;
@property (strong,nonatomic)  IBOutlet UILabel *available;
@property (strong,nonatomic)  IBOutlet UILabel *gameType;

@property (strong,nonatomic)  IBOutlet UILabel *aboutOfferlabel;

@property (strong,nonatomic) IBOutlet UIImageView *scrollImage;

@property (strong,nonatomic)  IBOutlet UILabel *skilSetlabel;


@property(strong,nonatomic) IBOutlet UIView *contentView;
@property(strong,nonatomic) IBOutlet UIScrollView *scrollView;

@property (nonatomic,retain)  NSDictionary *SetSelectedOpportunity;
@property (nonatomic,retain)  NSString *setSelectedCategory;
@property (nonatomic,weak) IBOutlet UIView *quantityView;
@property (strong,nonatomic)  IBOutlet UILabel *quantityLbl;

@property(strong,nonatomic) IBOutlet UIImageView *qrImage;
@property(strong,nonatomic) IBOutlet UIButton *btn;
@property(strong,nonatomic) IBOutlet UILabel *lbl;
@property(strong,nonatomic) IBOutlet UIButton *userBlocks;


-(IBAction)back:(id)sender;
-(IBAction)myBlocks:(id)sender;

@end
