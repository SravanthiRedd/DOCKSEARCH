//
//  Details_GameandJobs.m
//  RPRT
//
//  Created by sravanthi Gumma on 14/09/16.
//  Copyright © 2016 DevpointSolutions. All rights reserved.
//

#import "Details_GameandJobs.h"
#import "UIImage+MDQRCode.h"
#import "Direction_Map.h"
#import "TimeCalculator.h"
#import "NSMutableAttributedString+StringColor.h"
#import "AppDelegate.h"
#import "PopUpViewController.h"

@interface Details_GameandJobs ()
{
    Preferences *mPreferences;
    Web_Services *mWebService;
    NSUserDefaults *mPrefs;
    NSDictionary *timeDetails;
    MZTimerLabel *timeCoutDown;
    TimeCalculator *mConverter;
    UIPageControl *pagecontroller;
    NSMutableArray *imagesCount;
    UIActivityIndicatorView *spinnerView;
    NSString *blockIcon;
    NSString *notifyIcon;
    NSString *stopicon;
    NSString *claimIcon;
    NSString *notifiedIcon;
    UIActivityIndicatorView *spinner;
}
@property (strong, nonatomic) PopUpViewController *popViewController;

@end

@implementation Details_GameandJobs

- (void)viewDidLoad {
    [super viewDidLoad];
    
    mPreferences = [Preferences GetSharedInstance];
    mWebService= [Web_Services GetSharedInstance];
    mPrefs = [NSUserDefaults standardUserDefaults];
    mConverter = [TimeCalculator GetSharedInstance];
    
   
    blockIcon = [mPrefs valueForKey:@"Block"];
    notifyIcon = [mPrefs valueForKey:@"Notify"];
    stopicon = [mPrefs valueForKey:@"Stop"];
    claimIcon = [mPrefs valueForKey:@"Claim"];
    notifiedIcon = [mPrefs valueForKey:@"Notified"];
    
    getSelctedOpp = self.SetSelectedOpportunity;
    categoryName = [getSelctedOpp valueForKey:@"Category"];// self.setSelectedCategory;
    if (getSelctedOpp!=nil) {
        [self loadDesign];
    }
    UITapGestureRecognizer *singleTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(qrImageTap)];
    singleTap.numberOfTapsRequired = 1;
    [self.qrImage setUserInteractionEnabled:YES];
    [self.qrImage addGestureRecognizer:singleTap];
    
    
    // Do any additional setup after loading the view from its nib.
}
-(void)loadDesign
{
    
    
    
    
    self.offerName.text = [NSString stringWithFormat:@"%@",[getSelctedOpp valueForKey:@"OpportunityName"]];
    self.subCategory.text = [NSString stringWithFormat:@"%@",[getSelctedOpp valueForKey:@"SubCategory"]];
    
    NSString *byenaem ;
    if ([[getSelctedOpp valueForKey:@"VendorName"] isEqualToString:@""]) {
        byenaem = [getSelctedOpp valueForKey:@"UserName"];
    }
    else byenaem =[getSelctedOpp valueForKey:@"VendorName"];
    
    self.vendorname.text = [NSString stringWithFormat:@"By %@",byenaem];

    
    NSMutableAttributedString *text = [self.vendorname.attributedText mutableCopy];
    [text addAttribute:NSUnderlineStyleAttributeName value:@(NSUnderlineStyleSingle) range:NSMakeRange(0, text.length)];
    self.vendorname.attributedText = text;
    
  //  NSArray *addressarray = [[getSelctedOpp valueForKey:@"OpportunityKeywords"] componentsSeparatedByString:@","];
     self.skillset.text = [NSString stringWithFormat:@"%@",[getSelctedOpp valueForKey:@"SubCategory"]];
    
     self.aboutOfferlabel.text= @"Job Description";
    
    
    
    
     if ([categoryName  isEqualToString:SPORTS])
     {
          self.aboutOfferlabel.text= @"Sport Description";
         
         self.gameType.text= @"Game :";
         self.skilSetlabel.text = @"Sports Type:";
        self.skillset.text = [NSString stringWithFormat:@"%@",[getSelctedOpp valueForKey:@"SubCategory"]];
          //self.offerDescription.text = [NSString stringWithFormat:@"%@",[getSelctedOpp valueForKey:@"OpportunityDescription"]];
         
     }
    else
      if ([categoryName  isEqualToString:MEETINGS])
        {
            self.gameType.text= @"Event :";
            self.skilSetlabel.text= @"Event Type :";
            
             self.skillset.text = [NSString stringWithFormat:@"%@",[getSelctedOpp valueForKey:@"SubCategory"]];
            self.aboutOfferlabel.text= @"Event Description";
            // self.offerDescription.text = [NSString stringWithFormat:@"%@",[getSelctedOpp valueForKey:@"OpportunityDescription"]];
            
        }
      else   if ([categoryName  isEqualToString:JOBS])
      {
           self.skillset.text = [NSString stringWithFormat:@"%@",[getSelctedOpp valueForKey:@"OpportunityKeywords"]];
          
      }
    
      self.offerDescription.text = [NSString stringWithFormat:@"%@",[getSelctedOpp valueForKey:@"OpportunityDescription"]];
   
    //OpportunityName
   
    
    self.available.backgroundColor= [UIColor colorWithRed:226.0/256.0 green:54.0/256.0 blue:78.0/256.0 alpha:1];
    self.available.textColor = [UIColor whiteColor];
    
    NSString *availacnt =[getSelctedOpp valueForKey:@"Available"];
    int count = [availacnt intValue];
    if(count<0)
    {
        count = 0;
    }
    else count = count;
    self.available.text =[NSString stringWithFormat:@"Qty :%d",count];
    
    
    
   // self.available.text = [NSString stringWithFormat:@"Qty :%@",[getSelctedOpp valueForKey:@"Available"]];
    [[ self.available layer] setCornerRadius:5.0f];
    [[ self.available layer] setMasksToBounds:YES];
    
    
    
    
    //Actual price with rough line
    
    
    self.address.text = [NSString stringWithFormat:@"%@,%@",[getSelctedOpp valueForKey:@"Address3"],[getSelctedOpp valueForKey:@"AreaName"]];
    
    self.phoneNumber.text = [NSString stringWithFormat:@"%@",[getSelctedOpp valueForKey:@"VendorMobile"]];
    
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"yyyy-MM-dd'T'HH:mm:ss"];
    NSTimeZone *gmt = [NSTimeZone timeZoneWithAbbreviation:@"UTC"];
    [dateFormatter setTimeZone:gmt];
    NSDate *date5 = [dateFormatter dateFromString:[getSelctedOpp valueForKey:@"StartDate"]];
    
    NSDateFormatter *dateFormatter1 = [[NSDateFormatter alloc] init];
    [dateFormatter1 setDateFormat:@"yyyy-MM-dd'T'HH:mm:ss"];
    NSTimeZone *gmt1 = [NSTimeZone timeZoneWithAbbreviation:@"GMT"];
    [dateFormatter setTimeZone:gmt1];
    NSString *date = [dateFormatter1 stringFromDate:date5];
    
    date  = [date stringByReplacingOccurrencesOfString:@"T" withString:@" "];
    self.offerDate.text = date;
    
    NSString *start = [dateFormatter stringFromDate:date5];
    
    if (start==nil) {
        [dateFormatter setDateFormat:@"yyyy-MM-dd'T'HH:mm:ss.SSS"];
        gmt = [NSTimeZone timeZoneWithAbbreviation:@"UTC"];
        [dateFormatter setTimeZone:gmt];
        date5 = [dateFormatter dateFromString:[getSelctedOpp valueForKey:@"StartDate"]];
        start = [dateFormatter stringFromDate:date5];
        
        
    }
    
    UITapGestureRecognizer *singleTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(StoreDeatils:)];
    singleTap.numberOfTapsRequired = 1;
    [self.vendorname setUserInteractionEnabled:YES];
    [self.vendorname addGestureRecognizer:singleTap];

    
    
//    NSString *str=  [dateFormatter stringFromDate:date5];
//    self.offerDate.text =[NSString stringWithFormat:@"%@",[str stringByReplacingOccurrencesOfString:@"T" withString:@" "]];
    
    /*set offer Status */
    [self addimagestoScrollView];
    [self setofferStatus];
    [self setBlokorNotify];
    
    // self.bLockBtn.layer.cornerRadius = 50;
    
}

-(void)StoreDeatils:(UIPinchGestureRecognizer *)recognizer{
    
    @try {
        
       // if ([mPrefs valueForKey:USERREGISTERID]) {
            
            
        NSString *userRegID = [mPrefs valueForKey:USERREGISTERID];
        if(userRegID==nil)
        {
            userRegID= @"0";
        }
        
        NSString *VenDorRedID= [getSelctedOpp valueForKey:@"UserRegisterId"];
        NSString *FinalId = [NSString stringWithFormat:@"%@/%@",VenDorRedID,userRegID];
        
        NSDictionary *getStoreResp =[ mWebService GetStoreDetails:FinalId];

        
            Store_Details *mStoreDetails = [[Store_Details alloc]initWithNibName:@"Store_Details" bundle:nil];
            mStoreDetails.GetStoreDeatils =getStoreResp;
            [self presentViewController:mStoreDetails animated:YES completion:nil];
            
        //}
      //  else
        //{
          //  Login *mlogin = [[Login alloc]initWithNibName:LOGIN bundle:nil];
          //  [self presentViewController:mlogin animated:YES completion:nil];
        //}
        //GetStoreDetails
        
        
    } @catch (NSException *exception) {
        
    } @finally {
        
    }
    
    //ImageAlert = [CustomIOSAlertView ]
}



-(void)addimagestoScrollView
{
    @try {
        
        
        NSString *imageName = [NSString stringWithFormat:@"%@",[getSelctedOpp valueForKey:@"PhotoName"]];;
        NSArray *imageAry = [imageName componentsSeparatedByString:@","];
        NSString *ImageURL = [NSString stringWithFormat:@"%@%@",baseImageURL, [imageAry objectAtIndex:0]];
        
        if ([[imageAry objectAtIndex:0] isEqualToString:@""]) {
            
            imageName = [NSString stringWithFormat:@"%@",[getSelctedOpp valueForKey:@"CategoryImage"]];;
            ImageURL = [NSString stringWithFormat:@"%@%@",baseImageURL, imageName];
            
            NSURL *imageURL = [NSURL URLWithString:ImageURL];
            NSString *key = [ImageURL MD5Hash];
            NSData *getData = [FTWCache objectForKey:key];
            if (getData) {
                UIImage *image = [UIImage imageWithData:getData];
                self.scrollImage.image  = image;
            }
            else {
                self.scrollImage.image  = [UIImage imageNamed:@"img_def"];
                dispatch_queue_t queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_HIGH, 0ul);
                dispatch_async(queue, ^{
                    NSData *newData = [NSData dataWithContentsOfURL:imageURL];
                    [FTWCache setObject:newData forKey:key];
                    UIImage *image = [UIImage imageWithData:newData];
                    dispatch_sync(dispatch_get_main_queue(), ^{
                        self.scrollImage.image  = image;
                        
                    });
                });
            }
            
        }
        
        else {
            
            NSURL *imageURL = [NSURL URLWithString:ImageURL];
            NSString *key = [ImageURL MD5Hash];
            NSData *getData = [FTWCache objectForKey:key];
            if (getData) {
                UIImage *image = [UIImage imageWithData:getData];
                self.scrollImage.image  = image;
            }
            else {
                self.scrollImage.image  = [UIImage imageNamed:@"img_def"];
                dispatch_queue_t queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_HIGH, 0ul);
                dispatch_async(queue, ^{
                    NSData *newData = [NSData dataWithContentsOfURL:imageURL];
                    [FTWCache setObject:newData forKey:key];
                    UIImage *image = [UIImage imageWithData:newData];
                    dispatch_sync(dispatch_get_main_queue(), ^{
                        self.scrollImage.image  = image;
                        
                    });
                });
            }
            
        }
        
        UITapGestureRecognizer *photoScrollTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(photoScrollTap)];
        photoScrollTap.numberOfTapsRequired = 1;
        [self.scrollImage setUserInteractionEnabled:YES];
        [self.scrollImage addGestureRecognizer:photoScrollTap];
        

        
        
        
        //        NSString *imag = [getSelctedOpp objectForKey:@"PhotoName"];
        //        NSArray *stringArray = [imag componentsSeparatedByString:@","];
        //        CGRect workingFrame =CGRectMake(0, 5, 350, 350);// self.photoScroll.frame;
        //        self.photoScroll.backgroundColor = [UIColor clearColor];
        //        workingFrame.origin.x = 0;
        //
        //
        //     imagesCount = [NSMutableArray arrayWithCapacity:[stringArray count]];
        //
        //
        //
        //        if (stringArray!=0 && ![stringArray[0] isEqualToString:@""]) {
        //            for (NSDictionary *dict in stringArray)
        //            {
        //                if (![dict isEqual:@""])
        //                {
        //                    UIImage *image;
        //
        //
        //                    NSMutableString* aString = [NSMutableString stringWithFormat:@"%@%@",baseImageURL,dict];
        //
        //
        //                    NSURL *imageURL = [NSURL URLWithString:aString];
        //                    NSString *key = [aString MD5Hash];
        //                    NSData *getData = [FTWCache objectForKey:key];
        //                    if (getData) {
        //                        image = [UIImage imageWithData:getData];
        //
        //                        [imagesCount addObject:image];
        //                        // cell.OpportunityImage.image  = image;
        //                    }
        //                    else {
        //                        //cell.OpportunityImage.image  = [UIImage imageNamed:@"img_def"];
        //                        dispatch_queue_t queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_HIGH, 0ul);
        //                        dispatch_async(queue, ^{
        //                            NSData *newData = [NSData dataWithContentsOfURL:imageURL];
        //                            [FTWCache setObject:newData forKey:key];
        //                            UIImage *image = [UIImage imageWithData:newData];
        //                            dispatch_sync(dispatch_get_main_queue(), ^{
        //                                [imagesCount addObject:image];
        //                                // cell.OpportunityImage.image  = image;
        //
        //                            });
        //                        });
        //                    }
        //
        //
        //
        //                   CGSize size = CGSizeMake(320, 250);
        //
        //
        //
        //                 self.scrollImage = [[UIImageView alloc] initWithImage:[mConverter image:image scaledToSize:size]];
        //
        //                   // self.scrollImage.image =[mConverter image:image scaledToSize:size];
        //
        //                    [self.scrollImage setContentMode:UIViewContentModeScaleAspectFit];
        //
        //                    self.scrollImage.frame = workingFrame;
        //
        //                    // NSLog(@"%@",workingFrame);
        //                   [self.photoScroll addSubview:self.scrollImage];
        //
        //                    workingFrame.origin.x = workingFrame.origin.x + workingFrame.size.width;
        //
        //                }
        //
        //
        //            }
        //        }
        //
        //
        //
        //
        //        else
        //        {
        //            NSString *dict =[getSelctedOpp objectForKey:@"CategoryImage"];
        //            NSMutableString* aString = [NSMutableString stringWithFormat:@"%@%@",baseImageURL,dict];
        //
        //            UIImage *image;
        //            NSURL *imageURL = [NSURL URLWithString:aString];
        //            NSString *key = [aString MD5Hash];
        //            NSData *getData = [FTWCache objectForKey:key];
        //            if (getData) {
        //                image = [UIImage imageWithData:getData];
        //
        //
        //
        //
        //                [imagesCount addObject:image];
        //                // cell.OpportunityImage.image  = image;
        //            }
        //            else {
        //                //cell.OpportunityImage.image  = [UIImage imageNamed:@"img_def"];
        //                dispatch_queue_t queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_HIGH, 0ul);
        //                dispatch_async(queue, ^{
        //                    NSData *newData = [NSData dataWithContentsOfURL:imageURL];
        //                    [FTWCache setObject:newData forKey:key];
        //                    UIImage *image = [UIImage imageWithData:newData];
        //                    dispatch_sync(dispatch_get_main_queue(), ^{
        //                        [imagesCount addObject:image];
        //                        // cell.OpportunityImage.image  = image;
        //
        //                    });
        //                });
        //            }
        //
        //
        //
        //            CGSize size = CGSizeMake(560, 450);
        //
        //            self.scrollImage = [[UIImageView alloc] initWithImage:[mConverter image:image scaledToSize:size]];
        //
        //            //self.scrollImage.image =[mConverter image:image scaledToSize:size];
        //
        //            [self.scrollImage setContentMode:UIViewContentModeScaleAspectFit];
        //
        //            self.scrollImage.frame = workingFrame;
        //              [self.photoScroll addSubview:self.scrollImage];
        //            workingFrame.origin.x = workingFrame.origin.x + workingFrame.size.width;
        //
        //        }
        //
        //
        //        //NSString *qrString = [NSString stringWithFormat:@"RPRT,%@,Ongoing,%@",[Opportunity valueForKey:@"KeyValue"],[Opportunity valueForKey:@"BlockedUserId"]];
        //
        //
        //
        //        UITapGestureRecognizer *singleTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(ImageTap)];
        //        singleTap.numberOfTapsRequired = 1;
        //        [self.scrollImage setUserInteractionEnabled:YES];
        //        [self.scrollImage addGestureRecognizer:singleTap];
        //
        //
        //        pagecontroller = [[UIPageControl alloc]initWithFrame:CGRectMake(150, 250, 50, 20)];
        //
        //        pagecontroller.numberOfPages = [imagesCount count];
        //        pagecontroller.currentPage = 0;
        //        pagecontroller.pageIndicatorTintColor = [UIColor blueColor];
        //        [pagecontroller addTarget:self action:@selector(changePage:) forControlEvents:UIControlEventTouchUpInside];
        //
        //
        //
        //        //[self.Contentview addSubview:pagecontroller];
        //
        //
        //
        //
        //        [self.photoScroll setPagingEnabled:YES];
        //
        //        [self.photoScroll setContentSize:CGSizeMake(workingFrame.origin.x, workingFrame.size.height)];
    }
    @catch (NSException *exception) {
        //[self showAlertPop:@"Error while fetching data." expObj:exception];
    }
    @finally {
        
    }
    
}

-(void)setofferStatus
{
    NSString *satrtDate = [NSString stringWithFormat:@"%@",[getSelctedOpp valueForKey:@"EndDate"]];
    
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"yyyy-MM-dd'T'HH:mm:ss"];
    NSTimeZone *gmt = [NSTimeZone timeZoneWithAbbreviation:@"UTC"];
    [dateFormatter setTimeZone:gmt];
    NSDate *date5 = [dateFormatter dateFromString:satrtDate];
    
    if ([[getSelctedOpp valueForKey:@"OppStatus"] isEqualToString:@"Live"] || [[getSelctedOpp valueForKey:@"OppStatus"] isEqualToString:@""])
    {
        
        if (date5!=nil) {
            timeDetails= [[Preferences GetSharedInstance]remaningTime:[NSDate date] endDate:date5];
        }
        else{
            
            NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
            [dateFormatter setDateFormat:@"yyyy-MM-dd'T'HH:mm:ss.SSS"];
            
            NSTimeZone *gmt = [NSTimeZone timeZoneWithAbbreviation:@"UTC"];
            [dateFormatter setTimeZone:gmt];
            NSDate *date5 = [dateFormatter dateFromString:satrtDate];
            timeDetails= [[Preferences GetSharedInstance]remaningTime:[NSDate date] endDate:date5];
            
        }
        
        NSUInteger  Remaingtyime = [[timeDetails valueForKey:@"Time"] intValue];
        //NSString   *OfferTag =[NSString stringWithFormat:@"%d",Remaingtyime];
        int hour = [[timeDetails valueForKey:@"Hour"] intValue];
        // Timer.textColor = categoryColor;
        int seconds = [[timeDetails valueForKey:@"Seconds"] intValue];
        if (seconds!=0)
            Remaingtyime = Remaingtyime+(seconds/60);
        
        if(Remaingtyime!=0)
        {
            Remaingtyime = Remaingtyime+(hour*60);
            
            timeCoutDown = [[MZTimerLabel alloc] initWithLabel:self.offerStatus andTimerType:MZTimerLabelTypeTimer];
            [timeCoutDown setCountDownTime:Remaingtyime*60];
            [timeCoutDown start];
        }
        else
        {
            self.offerStatus.text= @"Expired!!";
        }
        
    }
    else
    {
        self.offerStatus.text= @"Expired!!";
        
    }
    
}


-(void)setBlokorNotify
{
   
    NSString *userBlock =[NSString stringWithFormat:@"%@",[getSelctedOpp valueForKey:@"BlockId"]];
    if (![userBlock isEqualToString:@"0"] && [[getSelctedOpp valueForKey:@"OppStatus"] isEqualToString:@"Live"]) {
        
        
        
        if ([[getSelctedOpp valueForKey:@"BlockText"] isEqualToString:@"UnBlock"]) {
            [self.bLockBtn setImage:[UIImage imageNamed:blockIcon] forState:UIControlStateNormal];
            
            self.quantityView.hidden = YES;
            self.qrImage.hidden= YES;
            self.lbl.hidden= NO;
            self.btn.hidden= NO;
            self.offerDate.hidden= NO;
            
        }
        else if([[getSelctedOpp valueForKey:@"BlockText"] isEqualToString:@"Claimed"])
        {
            [self.bLockBtn setImage:[UIImage imageNamed:claimIcon] forState:UIControlStateNormal];
            self.available.hidden = YES;
            self.quantityLbl.text = [NSString stringWithFormat:@"%@",[getSelctedOpp valueForKey:@"BlockedQuantity"]];
            self.lbl.hidden= YES;
             self.bLockBtn.userInteractionEnabled = NO;
            self.btn.hidden= YES;
            self.offerDate.hidden= YES;
            self.qrImage.hidden= NO;
            self.quantityView.hidden= YES;
            
        }
        
        else if([[getSelctedOpp valueForKey:@"BlockText"] isEqualToString:@"Blocked"])
        {
            [self.bLockBtn setImage:[UIImage imageNamed:stopicon] forState:UIControlStateNormal];
            self.available.hidden = YES;
            self.quantityLbl.text = [NSString stringWithFormat:@"%@",[getSelctedOpp valueForKey:@"BlockedQuantity"]];
            
            self.lbl.hidden= YES;
            self.btn.hidden= YES;
            self.offerDate.hidden= YES;
            self.qrImage.hidden= NO;
            self.quantityView.hidden = NO;
            
            
        }
        
        //   [self.bLockBtn setBackgroundColor:[UIColor yellowColor]];
        
        
    }
    else if([userBlock isEqualToString:@"0"] && [[getSelctedOpp valueForKey:@"OppStatus"] isEqualToString:@"Live"])
    {
        //  [self.bLockBtn setBackgroundColor:[UIColor greenColor]];
        [self.bLockBtn setImage:[UIImage imageNamed:blockIcon] forState:UIControlStateNormal];
        
        self.quantityView.hidden = YES;
        self.qrImage.hidden= YES;
    }
    else if ([[getSelctedOpp valueForKey:@"OppStatus"] isEqualToString:@"Expired"])
    {
        [self.bLockBtn setImage:[UIImage imageNamed:notifyIcon] forState:UIControlStateNormal];
        self.quantityView.hidden = YES;
        self.qrImage.hidden= YES;
        
         if ([[getSelctedOpp valueForKey:@"BlockText"] isEqualToString:@"Notify"])
        {
            [self.bLockBtn setImage:[UIImage imageNamed:notifiedIcon] forState:UIControlStateNormal];
            //self.bLockBtn.enabled = NO;
        }
        
    }
    
    NSString *RegisterID =   [mPrefs objectForKey:USERREGISTERID];
    if (RegisterID == [getSelctedOpp valueForKey:@"UserRegisterId"])
    {
        self.bLockBtn.hidden= YES;
        self.userBlocks.hidden = NO;
        [self.userBlocks setImage:[UIImage imageNamed:@"registerIcon.png"] forState:UIControlStateNormal];
       
        
    }
     [self.userBlocks addTarget:self action:@selector(UserReserVations:) forControlEvents:UIControlEventTouchUpInside];
    
    [self.bLockBtn addTarget:self action:@selector(Reserve:) forControlEvents:UIControlEventTouchUpInside];
    
    
    
//    NSString *userBlock =[NSString stringWithFormat:@"%@",[getSelctedOpp valueForKey:@"BlockId"]];
//    if (![userBlock isEqualToString:@"0"] && [[getSelctedOpp valueForKey:@"OppStatus"] isEqualToString:@"Live"]) {
//        //   [self.bLockBtn setBackgroundColor:[UIColor yellowColor]];
//        [self.bLockBtn setImage:[UIImage imageNamed:stopicon] forState:UIControlStateNormal];
//        self.quantityLbl.text = [NSString stringWithFormat:@"%@",[getSelctedOpp valueForKey:@"BlockedQuantity"]];
//          self.available.hidden = YES;
//        
//        
//    }
//    else if([userBlock isEqualToString:@"0"] && [[getSelctedOpp valueForKey:@"OppStatus"] isEqualToString:@"Live"])
//    {
//        //  [self.bLockBtn setBackgroundColor:[UIColor greenColor]];
//        [self.bLockBtn setImage:[UIImage imageNamed:blockIcon] forState:UIControlStateNormal];
//        self.quantityView.hidden = YES;
//    }
//    else if ([[getSelctedOpp valueForKey:@"OppStatus"] isEqualToString:@"Expired"])
//    {
//        [self.bLockBtn setImage:[UIImage imageNamed:notifyIcon] forState:UIControlStateNormal];
//        self.quantityView.hidden = YES;
//    }
//    
//    NSString *RegisterID =   [mPrefs objectForKey:USERREGISTERID];
//    if (RegisterID == [getSelctedOpp valueForKey:@"UserRegisterId"])
//    {
//        self.bLockBtn.hidden= YES;
//        
//    }
//    
//    [self.bLockBtn addTarget:self action:@selector(Reserve:) forControlEvents:UIControlEventTouchUpInside];
    
    
    
//    NSString *userBlock =[NSString stringWithFormat:@"%@",[getSelctedOpp valueForKey:@"Blocked"]];
//    if ([userBlock isEqualToString:@"1"] && [[getSelctedOpp valueForKey:@"OppStatus"] isEqualToString:@"Live"]) {
//      //  [self.bLockBtn setBackgroundColor:[UIColor yellowColor]];
//        [self.bLockBtn setImage:[UIImage imageNamed:stopicon] forState:UIControlStateNormal];
//        
//    }
//    else if([userBlock isEqualToString:@"0"] && [[getSelctedOpp valueForKey:@"OppStatus"] isEqualToString:@"Live"])
//    {
//       // [self.bLockBtn setBackgroundColor:[UIColor greenColor]];
//        [self.bLockBtn setImage:[UIImage imageNamed:blockIcon] forState:UIControlStateNormal];
//    }
//    else if ([[getSelctedOpp valueForKey:@"OppStatus"] isEqualToString:@"Expired"])
//    {
//        [self.bLockBtn setImage:[UIImage imageNamed:notifyIcon] forState:UIControlStateNormal];
//    }
//    
//    [self.bLockBtn addTarget:self action:@selector(Reserve:) forControlEvents:UIControlEventTouchUpInside];
    
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


-(void) viewDidLayoutSubviews
{
    
    
    
    [ super viewDidLayoutSubviews];
    [self.scrollView layoutIfNeeded];
    
    self.scrollView.contentSize = self.contentView.bounds.size;
    
    UIGraphicsBeginImageContext(self.view.frame.size);
    UIImage *image = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    self.contentView.backgroundColor = [UIColor colorWithPatternImage:image];
    
    
}


-(IBAction)increment:(id)sender
{
    // if ([self.quantityLbl.text isEqualToString:@"1"]) {
    NSMutableDictionary *reserved =[self getservedOffer];
    NSInteger quan = [[getSelctedOpp valueForKey:@"BlockedQuantity"] intValue];
    
    quan=quan+1;
    [reserved setValue:[NSString stringWithFormat:@"%ld",(long)quan] forKey:@"QunatityCnt"];
    [reserved setValue:@"Increment" forKey:@"Direction"];
    [self BlockOrNotify:reserved];
    //}
    
}
-(IBAction)decrement:(id)sender
{
    
    NSInteger quan = [[getSelctedOpp valueForKey:@"BlockedQuantity"] intValue];
    
    
    if (quan>1) {
        
        NSMutableDictionary *reserved =[self getservedOffer];
        NSInteger quan = [[getSelctedOpp valueForKey:@"BlockedQuantity"] intValue];
        quan=quan-1;
        [reserved setValue:[NSString stringWithFormat:@"%ld",(long)quan] forKey:@"QunatityCnt"];
        [reserved setValue:@"Decrement" forKey:@"Direction"];
        [self BlockOrNotify:reserved];
        
        //        NSMutableDictionary *reserved =[self getservedOffer];
        //        [reserved setValue:@"Decrement" forKey:@"Decrement"];
        //        [self BlockOrNotify:reserved];
    }
    
}


-(IBAction)Navigation:(id)sender
{
    
    Direction_Map *mMap= [Direction_Map alloc];
    mMap.direction =getSelctedOpp;
    Direction_Map *mMapview =
    [mMap initWithNibName:DIRECTIONMAP bundle:nil];
    [self presentViewController:mMapview animated:YES completion:nil];
    
}

-(IBAction)call:(id)sender
{
    NSString *contNumber=[getSelctedOpp valueForKey:@"VendorMobile"];
    @try {
        UIDevice *device = [UIDevice currentDevice];
        if ([[device model] isEqualToString:@"iPhone"]) {
            
            NSURL *phoneUrl = [NSURL
                               URLWithString:[NSString stringWithFormat:@"telprompt:%@", contNumber]];
            
            if ([[UIApplication sharedApplication] canOpenURL:phoneUrl]) {
                UIApplication *application = [UIApplication sharedApplication];
                [application openURL:phoneUrl options:@{} completionHandler:nil];

                
                //[[UIApplication sharedApplication] openURL:phoneUrl];
            }
            
        } else {
            
            UIAlertController *myAlertController =
            [mWebService alert:@"Your device doesn't support this feature."];
            [self presentViewController:myAlertController
                               animated:YES
                             completion:nil];
        }
    } @catch (NSException *exception) {
        //NSLog(EXCEPTIONCON, exception.reason);
        UIAlertController *myAlertController =
        [mWebService alert:@"Error while fetching data"];
        [self presentViewController:myAlertController animated:YES completion:nil];
    }
    
}

- (void)Reserve:(id)sender {
    
    @try {
        
        
        
        
        
        NSString *RegisterID =   [mPrefs objectForKey:USERREGISTERID];
        if (RegisterID!= [getSelctedOpp valueForKey:@"UserRegisterId"] && RegisterID!=nil) {
            
            NSDictionary *BlockedItem = getSelctedOpp;
            
            NSMutableDictionary *reserved =[self getservedOffer];
            
            
            
            
            if([[BlockedItem valueForKey:@"OppStatus"] isEqualToString:@"Expired"])
                
            {
                if ([[BlockedItem valueForKey:@"BlockText"] isEqualToString:@"Blocked"] && [[BlockedItem valueForKey:@"OppStatus"] isEqualToString:@"Expired"])
                {
                    [self showAlertPop:@"Sorry!! this Opportunities aleady placed" expObj:nil];
                }
                
                else
                {

                
                
                
                UIAlertController *alertt = [UIAlertController alertControllerWithTitle:@"Right Place Right Time"
                                                                                message:@"Sorry! It's expired. Please click on notify to get notified in future."
                                                                         preferredStyle:UIAlertControllerStyleAlert];
                
                UIAlertAction* ok = [UIAlertAction actionWithTitle:@"Notify" style:UIAlertActionStyleDefault
                                                           handler:^(UIAlertAction * action) {
                                                               
                                                               
                                                               [self BlockOrNotify:reserved];
                                                               
                                                               
                                                           }];
                UIAlertAction* cancel = [UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleDefault
                                                               handler:^(UIAlertAction * action) {
                                                                   [alertt dismissViewControllerAnimated:YES completion:nil];
                                                                   
                                                                   
                                                               }];
                
                [alertt addAction:ok];
                [alertt addAction:cancel];
                [self presentViewController:alertt animated:YES completion:nil];
                }
            }
            
            else  if([[BlockedItem valueForKey:@"OppStatus"] isEqualToString:@"Live"])
            {
                    [self BlockOrNotify:reserved];
                
                
            }
        }
        else if (RegisterID == [getSelctedOpp valueForKey:@"UserRegisterId"])
        {
            UIAlertController * login=   [UIAlertController
                                          alertControllerWithTitle:@"RPRT"
                                          message:@"Unable to Block the Opportunities"
                                          preferredStyle:UIAlertControllerStyleAlert];
            
            UIAlertAction* yesButton = [UIAlertAction
                                        actionWithTitle:@"OK"
                                        style:UIAlertActionStyleDefault
                                        handler:^(UIAlertAction * action)
                                        {
                                            [login dismissViewControllerAnimated:YES completion:nil];
                                            
                                            //[self dismissViewControllerAnimated:alert completion:nil];
                                        }];
            
            [login addAction:yesButton];
            
            
            //[self dismissViewControllerAnimated:YES completion:nil];
            [self presentViewController:login animated:YES completion:nil];
        }
        
        else if(RegisterID==nil) {
            UIAlertController * login=   [UIAlertController
                                          alertControllerWithTitle:@"RPRT"
                                          message:@"Please Register/Login"
                                          preferredStyle:UIAlertControllerStyleAlert];
            
            UIAlertAction* yesButton = [UIAlertAction
                                        actionWithTitle:@"OK"
                                        style:UIAlertActionStyleDefault
                                        handler:^(UIAlertAction * action)
                                        {
                                            [mPrefs setValue:@"Opportunity_Details" forKey:@"Back"];
                                            
                                            self.popViewController = [[PopUpViewController alloc] initWithNibName:@"PopUpViewController" bundle:nil];
                                            [self.popViewController setTitle:@"This is a popup view"];
                                            
                                            [self.popViewController showInView:self.view withImage:[UIImage imageNamed:@"rprt_usinfo.png"] withMessage:@"You just triggered a great popup window" animated:YES];
                                            
                                            
//                                            Login * mLogin = [[ Login alloc] initWithNibName:LOGIN bundle:nil];
//                                            [self presentViewController:mLogin animated:YES completion:nil];
                                            
                                            //[self dismissViewControllerAnimated:alert completion:nil];
                                        }];
            
            UIAlertAction* cancelBtn = [UIAlertAction
                                        actionWithTitle:@"Cancel"
                                        style:UIAlertActionStyleDefault
                                        handler:^(UIAlertAction * action)
                                        {
                                            //Handel your yes please button action here
                                            [login dismissViewControllerAnimated:YES completion:nil];
                                        }];
            
            
            
            [login addAction:yesButton];
            [login addAction:cancelBtn];
            
            //[self dismissViewControllerAnimated:YES completion:nil];
            [self presentViewController:login animated:YES completion:nil];
        }
        
    } @catch (NSException *exception) {
        
    } @finally {
        
    }
    
}

-(NSMutableDictionary*)getservedOffer
{
    @try {
        
        NSString *RegisterID =   [mPrefs objectForKey:USERREGISTERID];
        NSMutableArray *resrve = [mWebService GetReservedOpportunitiesBYUserRegId:RegisterID];
        NSString *opportunityId = [getSelctedOpp valueForKey:@"OpportunityID"];
        
        NSMutableDictionary *reservedDic = [getSelctedOpp mutableCopy];
        
        for (int i=0 ; i<[resrve count]; i++) {
            
            NSString *oppId =[resrve[i] valueForKey:@"OpportunityId"];
            
            if ([opportunityId isEqual:oppId]) {
                
                
                [reservedDic setValue:[resrve[i] valueForKey:@"BlockId"] forKey:@"BlockId"];
                [reservedDic setValue:[resrve[i] valueForKey:@"BlockText"] forKey:@"BlockText"];
                if ([[resrve[i] valueForKey:@"BlockText"] isEqualToString:@"Blocked"]) {
                    
                    [reservedDic setValue:@"1" forKey:@"Blocked"];
                }
                else if ([[resrve[i] valueForKey:@"BlockText"] isEqualToString:@"UnBlock"]) {
                    [reservedDic setValue:@"0" forKey:@"Blocked"];
                }
                
            }
            
        }
        
        return reservedDic;
        
    } @catch (NSException *exception) {
        
    } @finally {
        
    }
}

-(void)BlockOrNotify:(NSDictionary*)BlockOffer
{
    @try {
        
        spinner = [[UIActivityIndicatorView alloc]
                   initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
        spinner.frame = CGRectMake(0, 0, 320, 560); // CGPointMake(160, 240);
        spinner.color = [UIColor blueColor];
        spinner.backgroundColor = [UIColor lightTextColor];
        spinner.transform = CGAffineTransformMakeScale(2, 2);
        // spinner.hidesWhenStopped = YES;
        [self.view addSubview:spinner];
        spinner.transform = CGAffineTransformMakeScale(2, 2);
        
        [spinner startAnimating];
        
        // how we stop refresh from freezing the main UI thread
        
        dispatch_async(
                       dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^{
                           
                           // back to the main thread for the UI call
                           dispatch_async(dispatch_get_main_queue(), ^{
                               [spinner startAnimating];
                           });
                           dispatch_async(dispatch_get_main_queue(), ^{
                               
                               NSDictionary *BlockedItem = BlockOffer;
                               NSString *RegisterID =   [mPrefs objectForKey:USERREGISTERID];
                               NSMutableDictionary *dic = [[NSMutableDictionary alloc]init];
                               NSString *uniqueIdentifier = [[[UIDevice currentDevice] identifierForVendor] UUIDString];
                               [dic setValue:[BlockedItem valueForKey:@"OpportunityID"] forKey:@"OpportunityId"];
                               //[dic setValue:[BlockedItem valueForKey:@"KeyValue"] forKey:@"KeyValue"];
                               
                               
                               if ([[BlockedItem valueForKey:@"OppStatus"] isEqualToString:@"Live"] && [[BlockedItem valueForKey:@"Direction"] isEqualToString:@"Increment"]) {
                                   
                                   [dic setValue:@"Blocked" forKey:@"BlockText"];
                                   [dic setValue:[BlockedItem valueForKey:@"BlockId"] forKey:@"BlockId"];
                                   [dic setValue:[BlockedItem valueForKey:@"QunatityCnt"] forKey:@"Quantity"];
                                   
                               }
                               
                               else if ([[BlockedItem valueForKey:@"OppStatus"] isEqualToString:@"Live"] && [[BlockedItem valueForKey:@"Direction"] isEqualToString:@"Decrement"]) {
                                   
                                   [dic setValue:@"Blocked" forKey:@"BlockText"];
                                   [dic setValue:[BlockedItem valueForKey:@"BlockId"] forKey:@"BlockId"];
                                   [dic setValue:[BlockedItem valueForKey:@"QunatityCnt"] forKey:@"Quantity"];
                                   
                               }
                               
                               else if ([[BlockedItem valueForKey:@"OppStatus"] isEqualToString:@"Expired"])
                               {
                                   [dic setValue:@"Notify" forKey:@"BlockText"];
                                   [dic setValue:@"0" forKey:@"BlockId"];
                                   [dic setValue:@"0" forKey:@"Quantity"];
                               }
                               
                               else if ([[BlockedItem valueForKey:@"BlockId"] intValue] ==0) {
                                   [dic setValue:@"Blocked" forKey:@"BlockText"];
                                   [dic setValue:@"0" forKey:@"BlockId"];
                                   [dic setValue:@"1" forKey:@"Quantity"];
                               }
                               
                               else if ([[BlockedItem valueForKey:@"BlockId"] intValue] !=0)
                               {
                                   if ([[BlockedItem valueForKey:@"BlockText"] isEqualToString:@"UnBlock"]) {
                                       
                                       [dic setValue:@"Blocked" forKey:@"BlockText"];
                                       [dic setValue:[BlockedItem valueForKey:@"BlockId"] forKey:@"BlockId"];
                                       [dic setValue:@"1" forKey:@"Quantity"];
                                   }
                                   else if ([[BlockedItem valueForKey:@"BlockText"] isEqualToString:@"Blocked"])
                                   {
                                       [dic setValue:@"UnBlock" forKey:@"BlockText"];
                                       [dic setValue:[BlockedItem valueForKey:@"BlockId"] forKey:@"BlockId"];
                                       [dic setValue:@"0" forKey:@"Quantity"];
                                       
                                   }
                                   
                               }
                               
                               
                               [dic setValue:uniqueIdentifier forKey:@"DeviceId"];
                               [dic setValue:RegisterID forKey:@"BlockedUserId"];
                               [dic setValue:@""  forKey:@"ClaimedTime"];
                               [dic setValue:@"" forKey:@"TransactionComplete"];
                               
                               NSString *keyValue = [NSString stringWithFormat:@"RPRT-%@-%@-%@",[BlockedItem valueForKey:@"OpportunityID"],RegisterID,[BlockedItem valueForKey:@"UserRegisterId"]];
                               [dic setValue:keyValue forKey:@"KeyValue"];
                               
                               // NSString *OfferName =[NSString stringWithFormat:@"The selected %@ was blocked", [BlockedItem valueForKey:@"VendorName"]];
                               NSDictionary *blockeditemResponse =[mWebService SaveBlockeditem:dic];
                               
                               if ((blockeditemResponse!=nil)) {
                                   
                                   NSString * erroeMessage =[blockeditemResponse valueForKey:@"ErrorMessage"];
                                   
                                   if ( ( ![erroeMessage isEqual:[NSNull null]] ) && ( [erroeMessage length] != 0 ) ) {
                                       [self showAlertPop:erroeMessage expObj:nil];
                                   }
                                   
                                   else  if (([erroeMessage isEqual:[NSNull null]])) {
                                       
                                       //getSelctedOpp= [self getservedOffer];

                                       
                                       NSMutableDictionary *dic = [blockeditemResponse mutableCopy];
                                       [dic setValue:[BlockedItem valueForKey:@"OpportunityID"] forKey:@"OpportunityID"];
                                       [self updatedetailedofOffer:dic];
                                       
                                       
                                       if ([[dic valueForKey:@"BlockText"] isEqualToString:@"Blocked"]) {
                                           [self showAlertPop:@"Your request is placed, please be on time!!" expObj:nil];
                                           
                                       }
                                       else if ([[dic valueForKey:@"BlockText"] isEqualToString:@"UnBlock"]) {
                                           [self showAlertPop:@"Your Opportunities request is cancelled!" expObj:nil];
                                           
                                       }
                                       
                                       else if ([[dic valueForKey:@"BlockText"] isEqualToString:@"Notify"])
                                       {
                                           [self showAlertPop:@"Your Opportunities is Notifyn to you" expObj:nil];
                                       }
                                       
                                       
                                   }
                                   
                                   
                               }
                               else
                               {
                                   [self showAlertPop:@"Sorry! We are unable to process your request! Please try after some time." expObj:nil];
                                   //
                               }
                               
                               [spinner stopAnimating];
                               
                           });
                       });
        
    } @catch (NSException *exceptio) {
        [self showAlertPop:@"Error while fetching data." expObj:nil];
    } @finally {
        
    }
}

-(void)updatedetailedofOffer:(NSMutableDictionary*)opportunityID

{
    @try {
        
       // NSString *offerId = [opportunityID valueForKey:@"OpportunityID"];
        
        
        //NSDictionary *updatedOpportunity=[[Web_Services GetSharedInstance]GetOpportunityByID:offerId MethodName:@"GetOpportunityById"];
        
        NSMutableDictionary *dci = [getSelctedOpp mutableCopy];
        [dci setValue:[opportunityID valueForKey:@"BlockId"] forKey:@"BlockId"];
        [dci setValue:[opportunityID valueForKey:@"BlockText"] forKey:@"BlockText"];
        [dci setValue:[opportunityID valueForKey:@"Quantity"] forKey:@"BlockedQuantity"];
        [dci setValue:[opportunityID valueForKey:@"KeyValue"] forKey:@"BlockedKeyValue"];
        [timeCoutDown stop];
        
        getSelctedOpp = dci;
        [self loadDesign];
        
    }
    @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
    
}


- (void) showAlertPop:(NSString*)alertText  expObj:(NSException*) exp{
    if(exp != nil)
    {
        NSLog(@"%@", exp.description);
    }
    NSLog(@"The Exception is %@",exp.description);
    UIAlertController *myAlertController =[mWebService  alert:alertText];
    [self presentViewController:myAlertController animated:YES completion:nil];
}


/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */

-(IBAction)back:(id)sender
{
    
    spinner = [[UIActivityIndicatorView alloc]
               initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
    spinner.frame = CGRectMake(0, 0, 320, 560); // CGPointMake(160, 240);
    spinner.color = [UIColor blueColor];
    spinner.backgroundColor = [UIColor lightTextColor];
    spinner.transform = CGAffineTransformMakeScale(2, 2);
    // spinner.hidesWhenStopped = YES;
    [self.view addSubview:spinner];
    spinner.transform = CGAffineTransformMakeScale(2, 2);
    
    [spinner startAnimating];
    
    // how we stop refresh from freezing the main UI thread
    
    dispatch_async(
                   dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^{
                       
                       // back to the main thread for the UI call
                       dispatch_async(dispatch_get_main_queue(), ^{
                           [spinner startAnimating];
                       });
                       dispatch_async(dispatch_get_main_queue(), ^{
                           
                           if ([self.Pagekey isEqualToString:@"ListCategory"]) {
                               Opportunity_List_New * mOpportunity_list = [[ Opportunity_List_New alloc] initWithNibName:OPPORTUNITYLISTNEW bundle:nil];
                               [self presentViewController:mOpportunity_list animated:YES completion:nil];
                           }
                           else if ([self.Pagekey isEqualToString:@"Exclusive"])
                           {
                               Excluseive_Offer *mExclusiveOffer = [[Excluseive_Offer alloc]initWithNibName:@"Excluseive_Offer" bundle:nil];
                               [self presentViewController:mExclusiveOffer animated:YES completion:nil];
                           }
                           else   //if ([self.Pagekey isEqualToString:@"StoreOffer"])
                               
                           {
                               [self dismissViewControllerAnimated:YES completion:nil];
                           }
                           [spinner stopAnimating];
                       });
                   });
    
   // [self dismissViewControllerAnimated:YES completion:nil];
}



- (void)UserReserVations:(id)sender {
    NSLog(@"UserBlocks");
    spinnerView = [[UIActivityIndicatorView alloc]
                   initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
    spinnerView.frame = CGRectMake(0, 0, 320, 560); // CGPointMake(160, 240);
    spinnerView.color = [UIColor blueColor];
    spinnerView.backgroundColor = [UIColor lightTextColor];
    spinnerView.transform = CGAffineTransformMakeScale(2, 2);
    // spinner.hidesWhenStopped = YES;
    [self.contentView addSubview:spinnerView];
    spinnerView.transform = CGAffineTransformMakeScale(2, 2);
    
    [spinnerView startAnimating];
    
    // how we stop refresh from freezing the main UI thread
    
    dispatch_async(
                   dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^{
                       
                       // back to the main thread for the UI call
                       dispatch_async(dispatch_get_main_queue(), ^{
                           [spinnerView startAnimating];
                       });
                       dispatch_async(dispatch_get_main_queue(), ^{
                           NSString *opportunityID = [getSelctedOpp valueForKey:@"OpportunityID"];
                           
                           UserBlocks *userBlocks = [UserBlocks alloc];
                           
                           
                           userBlocks.opportunityID = opportunityID;
                           
                           
                           UserBlocks *muserBlocks = [userBlocks initWithNibName:@"UserBlocks" bundle:nil];
                           [self presentViewController:muserBlocks animated:YES completion:nil];

                           [spinner stopAnimating];
                       });
                   });
    
    
    //   NSString *opportunityID = [getSelctedOpp valueForKey:@"OpportunityID"];
    //NSDictionary *reserveList= [mWebService GetVendorBlocks:opportunityID MethodName:@"GetReservedOpportunitiesBYID"];
    
}


-(IBAction)myBlocks:(id)sender
{
    @try {
        
        spinnerView = [[UIActivityIndicatorView alloc]
                       initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
        spinnerView.frame = CGRectMake(0, 0, 320, 560); // CGPointMake(160, 240);
        spinnerView.color = [UIColor blueColor];
        spinnerView.backgroundColor = [UIColor lightTextColor];
        spinnerView.transform = CGAffineTransformMakeScale(2, 2);
        // spinner.hidesWhenStopped = YES;
        [self.contentView addSubview:spinnerView];
        spinnerView.transform = CGAffineTransformMakeScale(2, 2);
        
        [spinnerView startAnimating];
        
        // how we stop refresh from freezing the main UI thread
        
        dispatch_async(
                       dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^{
                           
                           // back to the main thread for the UI call
                           dispatch_async(dispatch_get_main_queue(), ^{
                               [spinnerView startAnimating];
                           });
                           dispatch_async(dispatch_get_main_queue(), ^{
                               
                               if ([mPrefs valueForKey:USERREGISTERID] !=nil) {
                                   MyBlocks * mMyBlocks = [[ MyBlocks alloc] initWithNibName:MYBLOCKS bundle:nil];
                                   [self presentViewController:mMyBlocks animated:YES completion:nil];
                               }
                               else
                               {
                                   self.popViewController = [[PopUpViewController alloc] initWithNibName:@"PopUpViewController" bundle:nil];
                                   [self.popViewController setTitle:@"This is a popup view"];
                                   
                                   [self.popViewController showInView:self.view withImage:[UIImage imageNamed:@"rprt_usinfo.png"] withMessage:@"You just triggered a great popup window" animated:YES];
                                   
                                   
//                                   Login * mLogin = [[ Login alloc] initWithNibName:LOGIN bundle:nil];
//                                   [self presentViewController:mLogin animated:YES completion:nil];
                               }
                               
                               [spinnerView stopAnimating];
                               
                               
                           });
                       });
        
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
}



-(void)qrImageTap
{
    
    @try {
        
        
        //   UIImageView *tableGridImage;// = (UIImageView*)recognizer.view;
        
        CGFloat imageSize = ceilf(self.view.bounds.size.width * 0.6f);
        UIImageView *imageView = [[UIImageView alloc] initWithFrame:CGRectMake(floorf(self.view.bounds.size.width * 0.5f - imageSize * 0.5f), floorf(self.view.bounds.size.height * 0.5f - imageSize * 0.5f), imageSize, imageSize)];
        
        
        // tableGridImage.image  =[UIImage mdQRCodeForString:qrString size:imageView.bounds.size.width fillColor:[UIColor darkGrayColor]];
        
        
        [self customimageAlert:imageView];
        
        
        
    } @catch (NSException *exception) {
        
    } @finally {
        
    }
    
    //ImageAlert = [CustomIOSAlertView ]
}


-(void)customimageAlert:(UIImageView*)tableGridImage
{
    @try {
        
        ImageAlert=[[CustomIOSAlertView alloc] init];
        UIView  *imageView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 300, 200)];
        [ImageAlert setContainerView:imageView];
        [ImageAlert setButtonTitles:[NSMutableArray arrayWithObjects:@"", nil]];
        
        [ImageAlert setDelegate:self];
        
        
        // You may use a Block, rather than a delegate.
        [ImageAlert setOnButtonTouchUpInside:^(CustomIOSAlertView *alertView, int buttonIndex) {
            NSLog(@"Block: Button at position %d is clicked on alertView %d.", buttonIndex, (int)[alertView tag]);
            [alertView close];
        }];
        
        [ImageAlert setUseMotionEffects:true];
        
        UIButton *cancel = [[UIButton alloc]initWithFrame:CGRectMake(275, 0, 20, 20)];
        
        [cancel setImage:[UIImage imageNamed:@"ic_close"] forState:UIControlStateNormal];
        [cancel addTarget:self action:@selector(cancel:) forControlEvents:UIControlEventTouchUpInside];
        
        UILabel *lbel = [[UILabel alloc]initWithFrame:CGRectMake(10, 210,300, 40)];
        lbel.text = @"Please show this QR image to redeem";
        lbel.textColor = [UIColor redColor];
        
        UILabel *qrtext = [[UILabel alloc]initWithFrame:CGRectMake(10, 170,300, 40)];
        qrtext.text =[NSString stringWithFormat:@"%@",[getSelctedOpp valueForKey:@"BlockedKeyValue"]];        qrtext.textColor = [UIColor blackColor];
      
        
        NSString *qrString = [NSString stringWithFormat:@"%@",[getSelctedOpp valueForKey:@"BlockedKeyValue"]];
        
        
        UIImageView *VendorProfile = [[UIImageView alloc]initWithImage:[UIImage mdQRCodeForString:qrString size:imageView.bounds.size.width fillColor:[UIColor darkGrayColor]]];
        VendorProfile.frame = CGRectMake(50, 20, 150, 150);

        [imageView addSubview:cancel];
          [imageView addSubview:qrtext];
        [imageView addSubview:lbel];
        [imageView addSubview:VendorProfile];
        
        [ImageAlert show];
        ImageAlert.tag = 2;
    }
    @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
}


-(void)cancel:(UIButton*)sender
{
    [ImageAlert close];
}

-(void)photoScrollTap{
    
    @try {
        
        
        ImageAlert=[[CustomIOSAlertView alloc] init];
        UIView  *imageView =[[UIView alloc] initWithFrame:CGRectMake(0, 0, 300, 310)];
        [ImageAlert setContainerView:imageView];
        [ImageAlert setButtonTitles:[NSMutableArray arrayWithObjects:@"", nil]];
        
        [ImageAlert setDelegate:self];
        
        
        // You may use a Block, rather than a delegate.
        [ImageAlert setOnButtonTouchUpInside:^(CustomIOSAlertView *alertView, int buttonIndex) {
            NSLog(@"Block: Button at position %d is clicked on alertView %d.", buttonIndex, (int)[alertView tag]);
            [alertView close];
        }];
        
        [ImageAlert setUseMotionEffects:true];
        
        
        UILabel *labl = [[UILabel alloc]initWithFrame:CGRectMake(10, 15, 200, 24)];
        labl.text= @"Right Place Right Time";
        
        UIButton *cancel = [[UIButton alloc]initWithFrame:CGRectMake(275, 10, 24, 24)];
        
        [cancel setImage:[UIImage imageNamed:@"ic_close"] forState:UIControlStateNormal];
        [cancel addTarget:self action:@selector(cancel:) forControlEvents:UIControlEventTouchUpInside];
        
        UIScrollView *pScoll= [[UIScrollView alloc]initWithFrame:CGRectMake(0, 20, 300, 300)];
        pScoll.delegate= self;
        
        NSString *imag = [getSelctedOpp objectForKey:@"PhotoName"];
        NSArray *stringArray = [imag componentsSeparatedByString:@","];
        
        NSMutableArray   *Images = [NSMutableArray arrayWithCapacity:[stringArray count]];
        
        if (stringArray!=0 && ![stringArray[0] isEqualToString:@""]) {
            for (NSDictionary *dict in stringArray)
            {
                if (![dict isEqual:@""])
                {
                    UIImage *image;
                    
                    
                    NSMutableString* aString = [NSMutableString stringWithFormat:@"%@%@",baseImageURL,dict];
                    
                    
                    NSURL *imageURL = [NSURL URLWithString:aString];
                    NSString *key = [aString MD5Hash];
                    NSData *getData = [FTWCache objectForKey:key];
                    if (getData) {
                        image = [UIImage imageWithData:getData];
                        
                        [Images addObject:image];
                        
                    }
                    else {
                        //cell.OpportunityImage.image  = [UIImage imageNamed:@"img_def"];
                        dispatch_queue_t queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_HIGH, 0ul);
                        dispatch_async(queue, ^{
                            NSData *newData = [NSData dataWithContentsOfURL:imageURL];
                            [FTWCache setObject:newData forKey:key];
                            UIImage *image = [UIImage imageWithData:newData];
                            dispatch_sync(dispatch_get_main_queue(), ^{
                                [Images addObject:image];
                            });
                        });
                    }
                    
                }
            }
        }
        CGRect workingFrames =CGRectMake(pScoll.frame.origin.x, pScoll.frame.origin.y, pScoll.frame.size.width+10, pScoll.frame.size.height);
        
        
        UIImageView *ImageView;
        
        for (int i=0 ; i<[Images count] ;i++)
        {
            
            UIImage *im= [Images objectAtIndex:i];
            
            CGSize size = CGSizeMake(250, 250);//[self image:img scaledToSize:size]
            
            
            ImageView = [[UIImageView alloc] initWithImage:[mConverter image:im scaledToSize:size]];
            
            [ImageView setContentMode:UIViewContentModeScaleAspectFit];
            
            ImageView.frame = workingFrames;
            // ImageView.frame = CGRectMake(workingFrames.origin.x, 0, workingFrames.size.width+150, workingFrames.size.height+150);
            
            // NSLog(@"%@",workingFrame);
            [pScoll addSubview:ImageView];
            
            workingFrames.origin.x = workingFrames.origin.x + workingFrames.size.width;
            
        }
        
        [pScoll setPagingEnabled:YES];
        
        [pScoll setContentSize:CGSizeMake(workingFrames.origin.x, workingFrames.size.height)];
        
        pagecontroller = [[UIPageControl alloc]initWithFrame:CGRectMake(150, 315, 50, 20)];
        
        pagecontroller.numberOfPages = [Images count];
        pagecontroller.currentPage = 0;
        pagecontroller.pageIndicatorTintColor = [UIColor blueColor];
        [pagecontroller addTarget:self action:@selector(changePage:) forControlEvents:UIControlEventTouchUpInside];
        [imageView addSubview:pagecontroller];
        
        
        // UIImageView *VendorProfile = [[UIImageView alloc]initWithImage:self.scrollImage.image];
        // VendorProfile.frame = CGRectMake(0, 20, 300, 230);
        [imageView addSubview:labl];
        [imageView addSubview:cancel];
        
        [imageView addSubview:pScoll];
        
        [ImageAlert show];
        ImageAlert.tag = 2;
        
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
    
    //ImageAlert = [CustomIOSAlertView ]
}


-(void)changePage:(UIPageControl*)controller
{
    NSLog(@"Changed Controller");
}



-(IBAction)shareBtn:(id)sender
{
    
   // NSString *Addres=[getSelctedOpp valueForKey:@"OpportunityName"];
    //NSString *areName=[getSelctedOpp valueForKey:@"AreaName"];
    
    
    UIAlertController * view=   [UIAlertController
                                 alertControllerWithTitle:@"Rigth Place Right Time"
                                 message:@"Select Sharing option"
                                 preferredStyle:UIAlertControllerStyleActionSheet];
    
    UIAlertAction* watsapp = [UIAlertAction
                              actionWithTitle:@"Share via Whatsapp"
                              style:UIAlertActionStyleDefault
                              handler:^(UIAlertAction * action)
                              {
                                  
                                  
                                  
                                  NSString *ursl =  [mConverter whatspandSMSText:getSelctedOpp];//[NSString stringWithFormat:@"A new opportunity is posted at %@ \n%@ \nIf you do not have the app, please download it from Apple:https://itunes.apple.com/in/app/right-place-right-time/id1145309259?mt=8",areName,Addres];
                                  
                                  ursl =    (NSString*)CFBridgingRelease(CFURLCreateStringByAddingPercentEscapes(NULL,(CFStringRef) ursl, NULL,CFSTR("!*();:@&=+$,/?%#[]"),kCFStringEncodingUTF8));
                                  
                                  NSString * urlWhats = [NSString stringWithFormat:@"whatsapp://send?text=%@",ursl];
                                  NSURL * whatsappURL = [NSURL URLWithString:urlWhats];
                                  if ([[UIApplication sharedApplication] canOpenURL: whatsappURL]) {
                                      [[UIApplication sharedApplication] openURL: whatsappURL];
                                  } else {
                                      [self showAlertPop:@"Unable to share opportunity." expObj:nil];
                                      // can not share with whats app
                                  }
                                  
                              }];
    UIAlertAction* email = [UIAlertAction
                            actionWithTitle:@"Share via E-mail"
                            style:UIAlertActionStyleDefault
                            handler:^(UIAlertAction * action)
                            {
                                NSString *ursl = [mConverter emailText:getSelctedOpp];
                                
                                // NSString *ursl = [NSString stringWithFormat:@"%@",emailstring];
                                
                                NSString *cat =[getSelctedOpp valueForKey:@"Category"];
                                if ([cat isEqualToString:@"Professional Services"]) {
                                    cat= @"Expert Help";
                                }
                                else if ([cat isEqualToString:MEETINGS])
                                    cat= @"Events & Entertainments";
                                
                                NSString *subjectt = [NSString stringWithFormat:@"Right Place Right Time : %@",cat];
                                
                                if ([MFMailComposeViewController canSendMail]) {
                                    MFMailComposeViewController *mailController = [[MFMailComposeViewController alloc] init];
                                    [mailController setMailComposeDelegate:self];
                                    [mailController setSubject:subjectt];
                                    [mailController setToRecipients:@[@"email1", @"email2"]];
                                    [mailController setMessageBody:ursl isHTML:NO];
                                    [self presentViewController:mailController animated:YES completion:nil];
                                }
                                
                                [view dismissViewControllerAnimated:YES completion:nil];
                                
                            }];
    
    
    UIAlertAction* sms = [UIAlertAction
                          actionWithTitle:@"Share via iMessage"
                          style:UIAlertActionStyleDefault
                          handler:^(UIAlertAction * action)
                          {
                              
                              NSString *ursl =[mConverter whatspandSMSText:getSelctedOpp];// [NSString stringWithFormat:@"A new opportunity is posted at %@ \n%@ \nIf you do not have the app, please download it from Apple:https://itunes.apple.com/in/app/right-place-right-time/id1145309259?mt=8",areName,Addres];
                              
                              if ([MFMessageComposeViewController canSendText]) {
                                  MFMessageComposeViewController *messageController = [[MFMessageComposeViewController alloc] init];
                                  [messageController setMessageComposeDelegate:self];
                                  [messageController setRecipients:nil];
                                  [messageController setBody:ursl];
                                  [self presentViewController:messageController animated:NO completion:nil];
                              }
                              
                              [view dismissViewControllerAnimated:YES completion:nil];
                              
                          }];
    
    UIAlertAction* cancel = [UIAlertAction
                             actionWithTitle:@"Cancel"
                             style:UIAlertActionStyleDefault
                             handler:^(UIAlertAction * action)
                             {
                                 [view dismissViewControllerAnimated:YES completion:nil];
                                 
                             }];
    [watsapp setValue:[[UIImage imageNamed:@"whatsapp.png"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal] forKey:@"image"];
    [email setValue:[[UIImage imageNamed:@"email.png"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal] forKey:@"image"];
    [sms setValue:[[UIImage imageNamed:@"sms.png"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal] forKey:@"image"];
    
    
    [view addAction:watsapp];
    [view addAction:email];
    [view addAction:sms];
    [view addAction:cancel];
    [self presentViewController:view animated:YES completion:nil];
    
    
}
- (void)mailComposeController:(MFMailComposeViewController*)controller didFinishWithResult:(MFMailComposeResult)result error:(NSError*)error {
    [self dismissViewControllerAnimated:YES completion:nil];
}

// Then implement the delegate method
- (void)messageComposeViewController:(MFMessageComposeViewController *)controller didFinishWithResult:(MessageComposeResult)result {
    [self dismissViewControllerAnimated:YES completion:nil];
}




@end
