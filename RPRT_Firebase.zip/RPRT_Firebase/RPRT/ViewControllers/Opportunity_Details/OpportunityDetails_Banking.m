//
//  OpportunityDetails_Banking.m
//  RPRT
//
//  Created by sravanthi Gumma on 08/09/16.
//  Copyright © 2016 DevpointSolutions. All rights reserved.
//

#import "OpportunityDetails_Banking.h"
#import "Direction_Map.h"
#import "TimeCalculator.h"
#import "NSMutableAttributedString+StringColor.h"
#import "PopUpViewController.h"

@interface OpportunityDetails_Banking ()<DLStarRatingDelegate,CustomIOSAlertViewDelegate,floatMenuDelegate>
{
    CurrentLocation *mLocation;
    UIImageView *ImageView;
    UIView *footerView;
    Web_Services *mWebService;
    
    UIAlertController * alert;
    UITextField *Title;
    UITextField *EmailID;
    UITextField *UserComments;
    NSString *reviewRate;
    CustomIOSAlertView *ReviewAlert;
    UIView *ReviewDesign;
    MZTimerLabel *TimeCoutDown;
    UIPageControl *pagecontroller;
    CustomIOSAlertView *ImageAlert;
    NSUserDefaults *mPref ;
    UIActivityIndicatorView *spinner;
    Opportunity_DeatilsController *mOppDetilControl;
    UIColor *categoryColor;
    VCFloatingActionButton *FloatBtn;
    NSInteger timerCount;
    NSInteger indexs;
    int Remaingtyime;
    NSDictionary *startOffer;
    UIButton *block;
    TimeCalculator *mConverter;
    UIBlurEffect *blurEffect;
    UIVisualEffectView *blurEffectView;
    UIButton *reservations;
    UIButton *back;
    NSString *category;
    CGSize size ;
    NSMutableArray *reserveList;
    NSString *sucessaletString;
    NSString *failureString;
    NSString *cancelString;
    NSString *fullstring;
    NSString *expiresString;
    // UITableView *reserveTable;
    
}

@property (strong, nonatomic) PopUpViewController *popViewController;
@property(strong ,nonatomic) IBOutlet UITableView *reserveTable;
@property (strong, nonatomic) UITabBar *tabBarController;
@property (nonatomic, copy)  NSDictionary *setCache;
@property (weak, nonatomic) IBOutlet UIView *Contentview;
@property (weak, nonatomic) IBOutlet UIScrollView *scrollview;
@property (weak, nonatomic) IBOutlet UIScrollView *PhotoScroll;
//@property (nonatomic, strong) IBOutlet UIPageControl *pageControl;
@property (nonatomic, strong) NSMutableArray *Images;
@property (nonatomic, copy) NSArray *chosenImages;


@end



@implementation OpportunityDetails_Banking



@synthesize Description,Address,OpportunityName,Vendorname,Timer,PostedDate,MobileNumber,blockTimer,viewRatings;
@synthesize tabBarController,reserveTable,call;


- (void)viewDidLoad {
    [super viewDidLoad];
    
   
    mPref = [NSUserDefaults standardUserDefaults];
    [self loadColorBG];
    mOppDetilControl = [Opportunity_DeatilsController getsharedinstace];
    mConverter= [TimeCalculator GetSharedInstance];
    self.setCache = [[NSMutableDictionary alloc] init];
    mWebService = [Web_Services GetSharedInstance];
    
    indexs = self.index;
    GetSelectedOpportunity = [self.SetAllOpportunities objectAtIndex:indexs];
    
    NSLog(@"%@",GetSelectedOpportunity);
    
    OfferTag = self.SetofferTag;
    mLocation = [CurrentLocation GetSharedInstance];
    [self UpdateView:GetSelectedOpportunity];
    
    blockTimer.hidden = YES;
    category =[mPref valueForKey:CATEGORY];
    
    CGSize sizes = CGSizeMake(24, 24);
    
    reservations = [[UIButton alloc]initWithFrame:CGRectMake(340, 10, 40, 40)];
    reservations.backgroundColor =  [UIColor clearColor];
    UIImage *images =[mConverter image:[UIImage imageNamed:@"listic.png"] scaledToSize:sizes];
    [reservations setImage:images forState:UIControlStateNormal];
    [reservations addTarget:self action:@selector(reservations:) forControlEvents:UIControlEventTouchUpInside];
    [self.Contentview addSubview:reservations];
    
    
    
    back = [[UIButton alloc]initWithFrame:CGRectMake(0, 10, 40, 40)];
    back.backgroundColor =  [UIColor clearColor];
    //UIImage *bac =[mConverter image:[UIImage imageNamed:@"back.png"] scaledToSize:size];
    [back setImage:[mConverter image:[UIImage imageNamed:@"back.png"] scaledToSize:sizes] forState:UIControlStateNormal];
    [back addTarget:self action:@selector(back:) forControlEvents:UIControlEventTouchUpInside];
    [self.Contentview addSubview:back];

    
    
    


    
    
    // Do any additional setup after loading the view from its nib.
}
-(void)loadColorBG
{
    @try {
        
        
        // NSString *category =[mPref valueForKey:CATEGORY];
        NSData *colorData= [mPref valueForKey:@"COLOR"];
        categoryColor = [NSKeyedUnarchiver unarchiveObjectWithData:colorData];
        
    }
    @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
}

-(void)UpdateView:(NSDictionary*)Opportunity
{
    @try {
        [reserveTable setHidden:YES];
        
        NSString *opportunityID = [Opportunity valueForKey:@"OpportunityID"];
        
        NSString *RegisterID =   [mPref objectForKey:USERREGISTERID];
        if (RegisterID == [GetSelectedOpportunity valueForKey:@"UserRegisterId"] && RegisterID!=nil) {
            
            
            reserveList= [mWebService GetVendorBlocks:opportunityID MethodName:@"GetReservedOpportunitiesBYID"];
            
            
            
            if ([reserveList count]>0) {
                
                
                _PhotoScroll.frame = CGRectMake(_PhotoScroll.frame.origin.x, _PhotoScroll.frame.origin.y, _PhotoScroll.frame.size.width, _PhotoScroll.frame.size.height-30);
                
                
                tabBarController =[[UITabBar alloc]init];
                tabBarController.delegate = self;
                
                CGSize sizes =  CGSizeMake(20, 20);
                
                //  [mConverter image:[UIImage imageNamed:@"reserved.png"]  scaledToSize:size];
                
                tabBarController.frame = CGRectMake(_PhotoScroll.frame.origin.x, _PhotoScroll.frame.size.height-28, _PhotoScroll.frame.size.width, 30);
                UITabBarItem * newItem1 = [[UITabBarItem alloc] initWithTitle:@"Deatils" image:   [mConverter image:[UIImage imageNamed:@"deatils.png"]  scaledToSize:sizes] tag:1];
                UITabBarItem * newItem2 = [[UITabBarItem alloc] initWithTitle:@"Reservations" image: [mConverter image:[UIImage imageNamed:@"reserved.png"]  scaledToSize:sizes] tag:2];
                
                
                
                for (UITabBarItem* item in tabBarController.items)
                {
                    [item setTitlePositionAdjustment:UIOffsetMake(0, -20)];
                }
                
                
                
                //[tabBarController setSelectedItem:newItem1];
                
                
                [tabBarController setItems:[NSArray arrayWithObjects:newItem1,newItem2,nil]];
                tabBarController.delegate = self;
                
                
                [[UITabBar appearance] setBackgroundColor:[UIColor colorWithRed:211.0/256.0 green:192.0/256.0 blue:187.0/256.0 alpha:1]];
                tabBarController.clipsToBounds = YES;
                [self.Contentview addSubview:tabBarController];
                tabBarController.selectedItem = newItem1;
                
                self.view.backgroundColor=[UIColor colorWithRed:236.0/256.0 green:236.0/256.0 blue:236.0/256.0 alpha:1];
                [reserveTable setHidden:YES];
                
            }
            
        }
        
        
        Description.text = [NSString stringWithFormat:@"%@",[Opportunity valueForKey:@"OpportunityDescription"]];
        
          //NSString *RegisterID =   [mPref objectForKey:USERREGISTERID];
         //if (RegisterID == [Record valueForKey:@"UserRegisterId"])
         //{
        block.hidden= NO;
        
        
            sucessaletString = @"Your request is placed, please contact the owner!!";
            failureString= @"Sorry! We are unable to process your request! Please try after some time.";
            cancelString = @"Your property request is cancelled!";
            fullstring= @"Sorry! The limit has been reached.";
            expiresString= @"Sorry! It's expired. Please click on notify to get notified in future.";
        
        
        Address.text = [NSString stringWithFormat:@"%@,%@,%@",[Opportunity valueForKey:@"Address1"],[Opportunity valueForKey:@"Address2"],[Opportunity valueForKey:@"AreaName"]];
        
        OpportunityName.text = [NSString stringWithFormat:@"%@",[Opportunity valueForKey:@"OpportunityName"]];
        
        //NSString *Date =[[Opportunity valueForKey:@"StartDate"] stringByReplacingOccurrencesOfString:@"T" withString:@" "];
        
        NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
        [dateFormatter setDateFormat:@"yyyy-MM-dd'T'HH:mm:ss"];
        NSTimeZone *gmt = [NSTimeZone timeZoneWithAbbreviation:@"UTC"];
        [dateFormatter setTimeZone:gmt];
        NSDate *date5 = [dateFormatter dateFromString:[Opportunity valueForKey:@"StartDate"]];
        NSString *start = [dateFormatter stringFromDate:date5];
        
        if (start==nil) {
            [dateFormatter setDateFormat:@"yyyy-MM-dd'T'HH:mm:ss.SSS"];
            gmt = [NSTimeZone timeZoneWithAbbreviation:@"UTC"];
            [dateFormatter setTimeZone:gmt];
            date5 = [dateFormatter dateFromString:[Opportunity valueForKey:@"StartDate"]];
            start = [dateFormatter stringFromDate:date5];
            
            
        }
        
        
        NSString *str=  [dateFormatter stringFromDate:date5];
        PostedDate.text =[NSString stringWithFormat:@"%@",[str stringByReplacingOccurrencesOfString:@"T" withString:@" "]];
        
        Vendorname.text = [NSString stringWithFormat:@"%@,%@",[Opportunity valueForKey:@"VendorName"],[Opportunity valueForKey:@"AreaName"]];
        
        MobileNumber.text = [NSString stringWithFormat:@"%@",[Opportunity valueForKey:@"VendorMobile"]];
        
        Description.text = [NSString stringWithFormat:@"%@",[Opportunity valueForKey:@"OpportunityDescription"]];
        
        [self ViewRatings:[Opportunity valueForKey:@"RatingValue"]];
        //[self updateImageToScrollView:Opportunity];
       // [self updateTimerforBlockedOpportunity:Opportunity];
        
        
    }
    @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
}

-(void)ViewRatings:(NSString*)rating
{
    @try {
        
        
        DLStarRatingControl *customNumberOfStars = [[DLStarRatingControl alloc] initWithFrame:CGRectMake(60,350,120,20)];
        customNumberOfStars.delegate = self;
        //RatingValue = "4.00";
        
        customNumberOfStars.rating = [rating intValue];
        // NSString *rate =[Record valueForKey:@"RatingValue"];
        double  your_float = [rating floatValue];
        self.Rate.text = [NSString stringWithFormat:@"%.1f",your_float];
        //
        
        // Rate.text =[[rating intValue];
        
        [self.Contentview addSubview:customNumberOfStars];
        
        
        viewRatings.userInteractionEnabled = YES;
        UITapGestureRecognizer *tapGesture =
        [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapViewRatings)];
        [viewRatings addGestureRecognizer:tapGesture];
        
        
    }
    @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    }
    @finally {
        
    }
}


-(void)updateImageToScrollView:(NSDictionary*)Opportunity
{
    @try {
        
        NSString *imag = [Opportunity objectForKey:@"PhotoName"];
        NSArray *stringArray = [imag componentsSeparatedByString:@","];
        CGRect workingFrame = _PhotoScroll.frame;
        _PhotoScroll.backgroundColor = [UIColor clearColor];
        workingFrame.origin.x = 0;
        
        
        _Images = [NSMutableArray arrayWithCapacity:[stringArray count]];
        
        
        
        if (stringArray!=0 && ![stringArray[0] isEqualToString:@""]) {
            for (NSDictionary *dict in stringArray)
            {
                if (![dict isEqual:@""])
                {
                    UIImage *image;
                    
                    
                    NSMutableString* aString = [NSMutableString stringWithFormat:@"%@%@",baseImageURL,dict];
                    
                    
                    NSURL *imageURL = [NSURL URLWithString:aString];
                    NSString *key = [aString MD5Hash];
                    NSData *getData = [FTWCache objectForKey:key];
                    if (getData) {
                        image = [UIImage imageWithData:getData];
                        
                        [_Images addObject:image];
                        // cell.OpportunityImage.image  = image;
                    }
                    else {
                        //cell.OpportunityImage.image  = [UIImage imageNamed:@"img_def"];
                        dispatch_queue_t queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_HIGH, 0ul);
                        dispatch_async(queue, ^{
                            NSData *newData = [NSData dataWithContentsOfURL:imageURL];
                            [FTWCache setObject:newData forKey:key];
                            UIImage *image = [UIImage imageWithData:newData];
                            dispatch_sync(dispatch_get_main_queue(), ^{
                                [_Images addObject:image];
                                // cell.OpportunityImage.image  = image;
                                
                            });
                        });
                    }
                    
                    if ([reserveList count]>0) {
                        size = CGSizeMake(560, 418);
                        
                    }
                    
                    else if ([reserveList count]==0)
                    {
                        size = CGSizeMake(560, 450);
                    }
                    
                    
                    ImageView = [[UIImageView alloc] initWithImage:[mConverter image:image scaledToSize:size]];
                    
                    [ImageView setContentMode:UIViewContentModeScaleAspectFit];
                    
                    ImageView.frame = workingFrame;
                    
                    // NSLog(@"%@",workingFrame);
                    [_PhotoScroll addSubview:ImageView];
                    
                    workingFrame.origin.x = workingFrame.origin.x + workingFrame.size.width;
                    
                }
                
                
            }
        }
        
        
        
        
        else
        {
            NSString *dict =[Opportunity objectForKey:@"CategoryImage"];
            NSMutableString* aString = [NSMutableString stringWithFormat:@"%@%@",baseImageURL,dict];
            
            UIImage *image;
            NSURL *imageURL = [NSURL URLWithString:aString];
            NSString *key = [aString MD5Hash];
            NSData *getData = [FTWCache objectForKey:key];
            if (getData) {
                image = [UIImage imageWithData:getData];
                
                
                
                
                [_Images addObject:image];
                // cell.OpportunityImage.image  = image;
            }
            else {
                //cell.OpportunityImage.image  = [UIImage imageNamed:@"img_def"];
                dispatch_queue_t queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_HIGH, 0ul);
                dispatch_async(queue, ^{
                    NSData *newData = [NSData dataWithContentsOfURL:imageURL];
                    [FTWCache setObject:newData forKey:key];
                    UIImage *image = [UIImage imageWithData:newData];
                    dispatch_sync(dispatch_get_main_queue(), ^{
                        [_Images addObject:image];
                        // cell.OpportunityImage.image  = image;
                        
                    });
                });
            }
            
            
            if ([reserveList count]>0) {
                size =  CGSizeMake(560, 417);
            }
            else
            {
                size = CGSizeMake(560, 450);
            }
            
            
            ImageView = [[UIImageView alloc] initWithImage:[mConverter image:image scaledToSize:size]];
            
            [ImageView setContentMode:UIViewContentModeScaleAspectFit];
            
            ImageView.frame = workingFrame;
            
            // NSLog(@"%@",workingFrame);
            [_PhotoScroll addSubview:ImageView];
            
            workingFrame.origin.x = workingFrame.origin.x + workingFrame.size.width;
            
        }
        
        
        //NSString *qrString = [NSString stringWithFormat:@"RPRT,%@,Ongoing,%@",[Opportunity valueForKey:@"KeyValue"],[Opportunity valueForKey:@"BlockedUserId"]];
        
        
        
        UITapGestureRecognizer *singleTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(ImageTap)];
        singleTap.numberOfTapsRequired = 1;
        [ImageView setUserInteractionEnabled:YES];
        [ImageView addGestureRecognizer:singleTap];
        
        
        pagecontroller = [[UIPageControl alloc]initWithFrame:CGRectMake(150, 250, 50, 20)];
        
        pagecontroller.numberOfPages = [_Images count];
        pagecontroller.currentPage = 0;
        pagecontroller.pageIndicatorTintColor = [UIColor blueColor];
        [pagecontroller addTarget:self action:@selector(changePage:) forControlEvents:UIControlEventTouchUpInside];
        
        
        
        [self.Contentview addSubview:pagecontroller];
        
        
        
        
        [_PhotoScroll setPagingEnabled:YES];
        
        [_PhotoScroll setContentSize:CGSizeMake(workingFrame.origin.x, workingFrame.size.height)];
    }
    @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    }
    @finally {
        
    }
    
}

-(IBAction)changePage:(UIPageControl*)sender
{
    @try {
        
        
        NSInteger page = pagecontroller.currentPage;
        if (page < 0)
            return;
        if (page >= 2)
            return;
        CGRect frame = _PhotoScroll.frame;
        frame.origin.x = frame.size.width * page;
        frame.origin.y = 0;
        _PhotoScroll.frame = frame;
        // [scrollView scrollRectToVisible:frame animated:YES];
    }
    @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
}

-(void)updateTimerforBlockedOpportunity:(NSDictionary*)Opportunity
{
    
    @try {
        
        
        NSString *satrtDate = [NSString stringWithFormat:@"%@",[Opportunity valueForKey:@"EndDate"]];
        
        NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
        [dateFormatter setDateFormat:@"yyyy-MM-dd'T'HH:mm:ss"];
        NSTimeZone *gmt = [NSTimeZone timeZoneWithAbbreviation:@"UTC"];
        [dateFormatter setTimeZone:gmt];
        NSDate *date5 = [dateFormatter dateFromString:satrtDate];
        
        block = [[UIButton alloc]initWithFrame:CGRectMake(325,265,50,50)];
        block.layer.masksToBounds = YES;
        
        block.layer.cornerRadius = 0.5 * block.bounds.size.width;
        
        
        
        NSString *RegisterID =   [mPref objectForKey:USERREGISTERID];
        if (RegisterID == [GetSelectedOpportunity valueForKey:@"UserRegisterId"])
        {
            call.hidden= YES;
            block.hidden= YES;
            
        }
        else call.hidden= NO;
        block.hidden=NO;
        
        
        if ([[Opportunity valueForKey:@"OppStatus"] isEqualToString:@"Live"] || [[Opportunity valueForKey:@"OppStatus"] isEqualToString:@""])
        {
            
            
            
            
            if (date5!=nil) {
                startOffer= [[Preferences GetSharedInstance]remaningTime:[NSDate date] endDate:date5];
            }
            else{
                
                NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
                [dateFormatter setDateFormat:@"yyyy-MM-dd'T'HH:mm:ss.SSS"];
                
                NSTimeZone *gmt = [NSTimeZone timeZoneWithAbbreviation:@"UTC"];
                [dateFormatter setTimeZone:gmt];
                NSDate *date5 = [dateFormatter dateFromString:satrtDate];
                startOffer= [[Preferences GetSharedInstance]remaningTime:[NSDate date] endDate:date5];
                
            }
            
            Remaingtyime = [[startOffer valueForKey:@"Time"] intValue];
            OfferTag =[NSString stringWithFormat:@"%d",Remaingtyime];
            int hour = [[startOffer valueForKey:@"Hour"] intValue];
            Timer.textColor = categoryColor;
            int seconds = [[startOffer valueForKey:@"Seconds"] intValue];
            if (seconds!=0)
                Remaingtyime = Remaingtyime+(seconds/60);
            
            
            
            if(Remaingtyime!=0)
            {
                Remaingtyime = Remaingtyime+(hour*60);
                
                [Timer setFont:[UIFont fontWithName:@"Oswald-Bold" size:24]];
                
                
                NSString *userBlock =[NSString stringWithFormat:@"%@",[Opportunity valueForKey:@"Blocked"]];
                if ([userBlock isEqualToString:@"1"]) {
                    block.tag= 1;
                    Timer.hidden = YES;
                    blockTimer.hidden= NO;
                    
                    [block setBackgroundColor:[UIColor colorWithRed:255.0/256.0 green:156.0/256.0 blue:0./256.0 alpha:1]];
                    [block setImage:[UIImage imageNamed:@"stop.png"] forState:UIControlStateNormal];
                    //[self addtimetoimage:@"5"];
                    
                    UILabel *lbel = [[UILabel alloc]initWithFrame:CGRectMake(20, 100, 300, 200)];
                    [lbel setTextColor:[UIColor redColor]];
                    [lbel setFont:[UIFont fontWithName:@"Roboto-Medium" size:66]];
                    //[self.Contentview addSubview:lbel];
                    
                    blurEffect = [UIBlurEffect effectWithStyle:UIBlurEffectStyleDark];
                    blurEffectView = [[UIVisualEffectView alloc] initWithEffect:blurEffect];
                    blurEffectView.frame =CGRectMake(_PhotoScroll.frame.origin.x, _PhotoScroll.frame.origin.y, _PhotoScroll.frame.size.width, _PhotoScroll.frame.size.height-10);// _PhotoScroll.frame;
                    // blurEffectView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
                    blockTimer.frame = CGRectMake(blockTimer.frame.origin.x, blockTimer.frame.origin.y-50,blockTimer.frame.size.width+50, blockTimer.frame.size.height);
                    
                    [blurEffectView addSubview:lbel];
                    [self.Contentview addSubview:blurEffectView];
                    
                    TimeCoutDown = [[MZTimerLabel alloc] initWithLabel:lbel
                                                          andTimerType:MZTimerLabelTypeTimer];
                    [TimeCoutDown setCountDownTime:Remaingtyime*60];
                    [TimeCoutDown start];
                    [self.Contentview bringSubviewToFront:back];
                    [self.Contentview bringSubviewToFront:reservations];
                    
                    
                }
                else if([userBlock isEqualToString:@"0"])
                {
                    Timer.hidden = NO;
                    blockTimer.hidden= YES;
                    block.tag=2;
                    [block setImage:[UIImage imageNamed:@"play.png"] forState:UIControlStateNormal];
                    TimeCoutDown = [[MZTimerLabel alloc] initWithLabel:Timer andTimerType:MZTimerLabelTypeTimer];
                    [TimeCoutDown setCountDownTime:Remaingtyime*60];
                    [TimeCoutDown start];
                    
                    block.backgroundColor = categoryColor;
                }
                
            }
            else
            {
                
                Timer.hidden = NO;
                block.tag= 3;
                Timer.text = @"Offer Expired!!";
                [block setImage:[UIImage imageNamed:@"play.png"] forState:UIControlStateNormal];
                block.backgroundColor = categoryColor;
                
            }
            
            //[block setImage:[UIImage imageNamed:@"play.png"] forState:UIControlStateNormal];
        }
        else if ([[Opportunity valueForKey:@"OppStatus"] isEqualToString:@"Expired"])
        {
            block.tag=3;
            CGSize siz =CGSizeMake(20, 20);
            UIImage  *image=   [mConverter image:[UIImage imageNamed:@"list_notify.png"] scaledToSize:siz];
            
            Timer.hidden = NO;
            block.tag= 3;
            Timer.text = @"Offer Expired!!";
            [block setImage:image forState:UIControlStateNormal];
            block.backgroundColor = categoryColor;
        }
        
        [self.Contentview addSubview:block];
        
        [block addTarget:self action:@selector(Reserve:) forControlEvents:UIControlEventTouchUpInside];
        
        
    }
    @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    }
    @finally {
        
    }
    
}

- (void)Reserve:(id)sender {
    
    @try {
        
        spinner = [[UIActivityIndicatorView alloc]
                   initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
        spinner.frame = CGRectMake(0, 0, 320, 560); // CGPointMake(160, 240);
        spinner.color = [UIColor blueColor];
        spinner.backgroundColor = [UIColor lightTextColor];
        spinner.transform = CGAffineTransformMakeScale(2, 2);
        // spinner.hidesWhenStopped = YES;
        [self.view addSubview:spinner];
        spinner.transform = CGAffineTransformMakeScale(2, 2);
        
        [spinner startAnimating];
        
        // how we stop refresh from freezing the main UI thread
        
        dispatch_async(
                       dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^{
                           
                           // back to the main thread for the UI call
                           dispatch_async(dispatch_get_main_queue(), ^{
                               [spinner startAnimating];
                           });
                           dispatch_async(dispatch_get_main_queue(), ^{
                               
                               NSString *RegisterID =   [mPref objectForKey:USERREGISTERID];
                               if (RegisterID!= [GetSelectedOpportunity valueForKey:@"UserRegisterId"] && RegisterID!=nil) {
                                   
                                   NSDictionary *BlockedItem = GetSelectedOpportunity;
                                   
                                   NSMutableDictionary *reserved =[self getservedOffer];
                                   
                                   
                                   
                                   
                                   if([[BlockedItem valueForKey:@"OppStatus"] isEqualToString:@"Expired"])
                                       
                                   {
                                       UIAlertController *alertt = [UIAlertController alertControllerWithTitle:@"Right Place Right Time"
                                                                                                       message:expiresString
                                                                                                preferredStyle:UIAlertControllerStyleAlert];
                                       
                                       UIAlertAction* ok = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault
                                                                                  handler:^(UIAlertAction * action) {
                                                                                      
                                                                                      
                                                                                      //   NSDictionary *BlockedItem = GetSelectedOpportunity;
                                                                                      [self BlockOrNotify:reserved];
                                                                                      
                                                                                      
                                                                                  }];
                                       UIAlertAction* cancel = [UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleDefault
                                                                                      handler:^(UIAlertAction * action) {
                                                                                          [alertt dismissViewControllerAnimated:YES completion:nil];
                                                                                          
                                                                                          
                                                                                      }];
                                       
                                       [alertt addAction:ok];
                                       [alertt addAction:cancel];
                                       [self presentViewController:alertt animated:YES completion:nil];
                                   }
                                   
                                   else  if([[BlockedItem valueForKey:@"OppStatus"] isEqualToString:@"Live"])
                                   {
                                       
                                           [self BlockOrNotify:reserved];
                                       
                                   }
                               }
                               else if (RegisterID == [GetSelectedOpportunity valueForKey:@"UserRegisterId"])
                               {
                                   UIAlertController * login=   [UIAlertController
                                                                 alertControllerWithTitle:@"RPRT"
                                                                 message:@"Unable to Block the Offer"
                                                                 preferredStyle:UIAlertControllerStyleAlert];
                                   
                                   UIAlertAction* yesButton = [UIAlertAction
                                                               actionWithTitle:@"OK"
                                                               style:UIAlertActionStyleDefault
                                                               handler:^(UIAlertAction * action)
                                                               {
                                                                   [login dismissViewControllerAnimated:YES completion:nil];
                                                                   
                                                                   //[self dismissViewControllerAnimated:alert completion:nil];
                                                               }];
                                   
                                   [login addAction:yesButton];
                                   
                                   
                                   //[self dismissViewControllerAnimated:YES completion:nil];
                                   [self presentViewController:login animated:YES completion:nil];
                               }
                               
                               else if(RegisterID==nil) {
                                   UIAlertController * login=   [UIAlertController
                                                                 alertControllerWithTitle:@"RPRT"
                                                                 message:@"Please Register/Login"
                                                                 preferredStyle:UIAlertControllerStyleAlert];
                                   
                                   UIAlertAction* yesButton = [UIAlertAction
                                                               actionWithTitle:@"OK"
                                                               style:UIAlertActionStyleDefault
                                                               handler:^(UIAlertAction * action)
                                                               {
                                                                   [mPref setValue:@"Opportunity_Details" forKey:@"Back"];
                                                                   
                                                                   self.popViewController = [[PopUpViewController alloc] initWithNibName:@"PopUpViewController" bundle:nil];
                                                                   [self.popViewController setTitle:@"This is a popup view"];
                                                                   
                                                                   [self.popViewController showInView:self.view withImage:[UIImage imageNamed:@"rprt_usinfo.png"] withMessage:@"You just triggered a great popup window" animated:YES];
                                                                   
                                                                   
//                                                                   Login * mLogin = [[ Login alloc] initWithNibName:LOGIN bundle:nil];
//                                                                   [self presentViewController:mLogin animated:YES completion:nil];
                                                                   
                                                                   //[self dismissViewControllerAnimated:alert completion:nil];
                                                               }];
                                   
                                   UIAlertAction* cancelBtn = [UIAlertAction
                                                               actionWithTitle:@"Cancel"
                                                               style:UIAlertActionStyleDefault
                                                               handler:^(UIAlertAction * action)
                                                               {
                                                                   //Handel your yes please button action here
                                                                   [login dismissViewControllerAnimated:YES completion:nil];
                                                               }];
                                   
                                   
                                   
                                   [login addAction:yesButton];
                                   [login addAction:cancelBtn];
                                   
                                   //[self dismissViewControllerAnimated:YES completion:nil];
                                   [self presentViewController:login animated:YES completion:nil];
                                   
                               }
                               
                               [spinner stopAnimating];
                               
                           });
                       });
        
        
        
        
    }
    @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
    
}

-(NSMutableDictionary*)getservedOffer
{
    @try {
        
        NSString *RegisterID =   [mPref objectForKey:USERREGISTERID];
        NSMutableArray *resrve = [mWebService GetReservedOpportunitiesBYUserRegId:RegisterID];
        NSString *opportunityId = [GetSelectedOpportunity valueForKey:@"OpportunityID"];
        
        NSMutableDictionary *reservedDic = [GetSelectedOpportunity mutableCopy];
        
        for (int i=0 ; i<[resrve count]; i++) {
            
            NSString *oppId =[resrve[i] valueForKey:@"OpportunityId"];
            
            if ([opportunityId isEqual:oppId]) {
                
                
                [reservedDic setValue:[resrve[i] valueForKey:@"BlockId"] forKey:@"BlockId"];
                [reservedDic setValue:[resrve[i] valueForKey:@"BlockText"] forKey:@"BlockText"];
                
                
                
                //BlockText = Blocked;
                if ([[resrve[i] valueForKey:@"BlockText"] isEqualToString:@"Blocked"]) {
                    
                    [reservedDic setValue:@"1" forKey:@"Blocked"];
                }
                else if ([[resrve[i] valueForKey:@"BlockText"] isEqualToString:@"UnBlock"]) {
                    [reservedDic setValue:@"0" forKey:@"Blocked"];
                }
                
            }
            
            
        }
        
        return reservedDic;
        
    } @catch (NSException *exception) {
        
    } @finally {
        
    }
}


- (void)scrollViewDidScroll:(UIScrollView *)sender {
    @try {
        
        CGFloat pageWidth = _PhotoScroll.frame.size.width;
        float fractionalPage = _PhotoScroll.contentOffset.x / pageWidth;
        NSInteger page = lround(fractionalPage);
        pagecontroller.currentPage = page;
    }
    @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
}



-(void)BlockOrNotify:(NSDictionary*)BlockOffer
{
    @try {
        
        NSDictionary *BlockedItem = BlockOffer;
        NSString *RegisterID =   [mPref objectForKey:USERREGISTERID];
        NSMutableDictionary *dic = [[NSMutableDictionary alloc]init];
        NSString *uniqueIdentifier = [[[UIDevice currentDevice] identifierForVendor] UUIDString];
        [dic setValue:[BlockedItem valueForKey:@"OpportunityID"] forKey:@"OpportunityId"];
        //[dic setValue:[BlockedItem valueForKey:@"KeyValue"] forKey:@"KeyValue"];
        
        if ([[BlockedItem valueForKey:@"BlockId"] intValue] ==0) {
            [dic setValue:@"Blocked" forKey:@"BlockText"];
            [dic setValue:@"0" forKey:@"BlockId"];
        }
        else if([[BlockedItem valueForKey:@"Blocked"]intValue]== 1)
        {
            [dic setValue:@"Block" forKey:@"BlockText"];
            [dic setValue:[BlockedItem valueForKey:@"BlockId"] forKey:@"BlockId"];
        }
        else if ([[BlockedItem valueForKey:@"BlockId"] intValue] !=0)
        {
            [dic setValue:@"Blocked" forKey:@"BlockText"];
            [dic setValue:[BlockedItem valueForKey:@"BlockId"] forKey:@"BlockId"];
        }
        
        
        [dic setValue:uniqueIdentifier forKey:@"DeviceId"];
        [dic setValue:RegisterID forKey:@"BlockedUserId"];
        [dic setValue:@"1" forKey:@"Quantity"];
        [dic setValue:@""  forKey:@"ClaimedTime"];
        [dic setValue:@"" forKey:@"TransactionComplete"];
        NSString *keyValue = [NSString stringWithFormat:@"RPRT%@%@",[BlockedItem valueForKey:@"UserRegisterId"],[BlockedItem valueForKey:@"OpportunityID"]];
        [dic setValue:keyValue forKey:@"KeyValue"];
        
        // NSString *OfferName =[NSString stringWithFormat:@"The selected %@ was blocked", [BlockedItem valueForKey:@"VendorName"]];
        NSDictionary *blockeditemResponse =[mWebService SaveBlockeditem:dic];
        
        
        if ((blockeditemResponse!=nil)) {
            
            if ([[dic valueForKey:@"BlockText"] isEqualToString:@"Blocked"]) {
                
                [tabBarController setHidden:YES];
                Timer.hidden=YES;
                
                //                [self.Contentview addSubview:blurEffectView];
                //                [self.Contentview bringSubviewToFront:back];
                //                [self.Contentview bringSubviewToFront:reservations];
                //                Timer.hidden= NO;
                
                
                [self showAlertPop:sucessaletString expObj:nil];
                
            }
            else if ([[dic valueForKey:@"BlockText"] isEqualToString:@"UnBlock"]) {
                
                [blurEffectView removeFromSuperview];
                [tabBarController setHidden:YES];
                [self showAlertPop:cancelString expObj:nil];
                
            }
            
            //            if(![blurEffectView isDescendantOfView:self.Contentview]) {
            //                [self.Contentview addSubview:blurEffectView];
            //                [self.Contentview bringSubviewToFront:back];
            //                [self.Contentview bringSubviewToFront:reservations];
            //                Timer.hidden= YES;
            //                //[blurEffectView removeFromSuperview];
            //            }
            //            else {
            //                [blurEffectView removeFromSuperview];
            //                Timer.hidden= NO;
            //            }
            
            
            NSMutableDictionary *dic = [blockeditemResponse mutableCopy];
            [dic setValue:[BlockedItem valueForKey:@"OpportunityID"] forKey:@"OpportunityID"];
            [self updatedetailedofOffer:dic];
            
        }
        else
        {
            [self showAlertPop:failureString expObj:nil];
            //
        }
        
    } @catch (NSException *exceptio) {
        
    } @finally {
        
    }
}


-(void)updatedetailedofOffer:(NSMutableDictionary*)opportunityID

{
    @try {
        
        NSString *offerId = [opportunityID valueForKey:@"OpportunityID"];
        
        
        NSDictionary *updatedOpportunity=[[Web_Services GetSharedInstance]GetOpportunityByID:offerId MethodName:@"GetOpportunityById"];
        
        NSMutableDictionary *dci = [updatedOpportunity mutableCopy];
        [dci setValue:[opportunityID valueForKey:@"BlockId"] forKey:@"BlockId"];
        
        //BlockText = Blocked;
        if ([[opportunityID valueForKey:@"BlockText"] isEqualToString:@"Blocked"]) {
            [dci setValue:@"1" forKey:@"Blocked"];
        }
        else if ([[opportunityID valueForKey:@"BlockText"] isEqualToString:@"Block"]) {
            [dci setValue:@"0" forKey:@"Blocked"];
        }
        
        [self UpdateView:dci];
        
    }
    @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
    
}


-(void)SetBorderToTextFieldL:(CALayer*)border Texfield:(UITextField*)TextfiedNam {
    @try {
        border.borderColor = [UIColor lightGrayColor].CGColor;
        border.frame = CGRectMake(0, TextfiedNam.frame.size.height - 1, TextfiedNam.frame.size.width, TextfiedNam.frame.size.height);
        border.borderWidth = 1;//
        [TextfiedNam.layer addSublayer:border];
        TextfiedNam.layer.masksToBounds = YES;
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
}


- (void)tapViewRatings {
    @try {
        
//        Rating *mRatings = [Rating alloc];
//        mRatings.SetOpportunities = GetSelectedOpportunity;
//        Rating *mPlaceOrderA01 =
//        [mRatings initWithNibName:RATINGS bundle:nil];
//        [self presentViewController:mPlaceOrderA01 animated:YES completion:nil];
    }
    @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    }
    @finally {
        
    }
    
}



-(void)ImageTap{
    
    @try {
        
        
        ImageAlert=[[CustomIOSAlertView alloc] init];
        UIView  *imageView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 300, 200)];
        [ImageAlert setContainerView:imageView];
        [ImageAlert setButtonTitles:[NSMutableArray arrayWithObjects:@"", nil]];
        
        [ImageAlert setDelegate:self];
        
        
        // You may use a Block, rather than a delegate.
        [ImageAlert setOnButtonTouchUpInside:^(CustomIOSAlertView *alertView, int buttonIndex) {
            NSLog(@"Block: Button at position %d is clicked on alertView %d.", buttonIndex, (int)[alertView tag]);
            [alertView close];
        }];
        
        [ImageAlert setUseMotionEffects:true];
        
        UIButton *cancel = [[UIButton alloc]initWithFrame:CGRectMake(275, 0, 20, 20)];
        
        [cancel setImage:[UIImage imageNamed:@"ic_close"] forState:UIControlStateNormal];
        [cancel addTarget:self action:@selector(cancel:) forControlEvents:UIControlEventTouchUpInside];
        
        
        UIImageView *VendorProfile = [[UIImageView alloc]initWithImage:ImageView.image];
        VendorProfile.frame = CGRectMake(0, 20, 300, 230);
        [imageView addSubview:cancel];
        [imageView addSubview:VendorProfile];
        
        [ImageAlert show];
        ImageAlert.tag = 2;
        
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
    
    //ImageAlert = [CustomIOSAlertView ]
}


-(void)cancel:(UIButton*)sender
{
    @try {
        
        
        [ImageAlert close];
    }
    @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
}




-(void)back:(id)sender
{
    
    @try
    {
        
        Opportunity_List_New * mOpportunity_list = [[ Opportunity_List_New alloc] initWithNibName:OPPORTUNITYLISTNEW bundle:nil];
        [self presentViewController:mOpportunity_list animated:YES completion:nil];
        
        
        //        [self dismissViewControllerAnimated:YES completion:NULL];
    }
    @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    }
    @finally {
        
    }
    
}

-(IBAction)call:(id)sender
{
    NSString *contNumber=[GetSelectedOpportunity valueForKey:@"VendorMobile"];
    @try {
        UIDevice *device = [UIDevice currentDevice];
        if ([[device model] isEqualToString:@"iPhone"]) {
            
            NSURL *phoneUrl = [NSURL
                               URLWithString:[NSString stringWithFormat:@"telprompt:%@", contNumber]];
            
            if ([[UIApplication sharedApplication] canOpenURL:phoneUrl]) {
                UIApplication *application = [UIApplication sharedApplication];
                [application openURL:phoneUrl options:@{} completionHandler:nil];

               // [[UIApplication sharedApplication] openURL:phoneUrl];
            }
            
        } else {
            
            UIAlertController *myAlertController =
            [mWebService alert:@"Your device doesn't support this feature."];
            [self presentViewController:myAlertController
                               animated:YES
                             completion:nil];
        }
    } @catch (NSException *exception) {
        //NSLog(EXCEPTIONCON, exception.reason);
        UIAlertController *myAlertController =
        [mWebService alert:@"Error while fetching data"];
        [self presentViewController:myAlertController animated:YES completion:nil];
    }
    
}


-(IBAction)Navigation:(id)sender
{
    @try {
        
        Direction_Map *mMap= [Direction_Map alloc];
        mMap.direction =[self.SetAllOpportunities objectAtIndex:indexs];
        Direction_Map *mMapview =
        [mMap initWithNibName:DIRECTIONMAP bundle:nil];
        [self presentViewController:mMapview animated:YES completion:nil];
        
    }
    @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    }
    @finally {
        
    }
    
}


-(void)reservations:(id)sender
{
    @try {
        
        spinner = [[UIActivityIndicatorView alloc]
                   initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
        spinner.frame = CGRectMake(0, 0, 320, 560); // CGPointMake(160, 240);
        spinner.color = [UIColor blueColor];
        spinner.backgroundColor = [UIColor lightTextColor];
        spinner.transform = CGAffineTransformMakeScale(2, 2);
        // spinner.hidesWhenStopped = YES;
        [self.view addSubview:spinner];
        spinner.transform = CGAffineTransformMakeScale(2, 2);
        
        [spinner startAnimating];
        
        // how we stop refresh from freezing the main UI thread
        
        dispatch_async(
                       dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^{
                           
                           // back to the main thread for the UI call
                           dispatch_async(dispatch_get_main_queue(), ^{
                               [spinner startAnimating];
                           });
                           dispatch_async(dispatch_get_main_queue(), ^{
                               
                               if ([mPref valueForKey:USERREGISTERID] !=nil) {
                                   MyBlocks * mMyBlocks = [[ MyBlocks alloc] initWithNibName:MYBLOCKS bundle:nil];
                                   [self presentViewController:mMyBlocks animated:YES completion:nil];
                               }
                               else
                               {
                                   self.popViewController = [[PopUpViewController alloc] initWithNibName:@"PopUpViewController" bundle:nil];
                                   [self.popViewController setTitle:@"This is a popup view"];
                                   
                                   [self.popViewController showInView:self.view withImage:[UIImage imageNamed:@"rprt_usinfo.png"] withMessage:@"You just triggered a great popup window" animated:YES];

                                   
                                   
//                                   Login * mLogin = [[ Login alloc] initWithNibName:LOGIN bundle:nil];
//                                   [self presentViewController:mLogin animated:YES completion:nil];
                               }
                               
                               [spinner stopAnimating];
                               
                               
                           });
                       });
        
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
    
}


- (void) showAlertPop:(NSString*)alertText  expObj:(NSException*) exp{
    if(exp != nil)
    {
        NSLog(@"%@", exp.description);
    }
    NSLog(@"The Exception is %@",exp.description);
    UIAlertController *myAlertController =[mWebService  alert:alertText];
    [self presentViewController:myAlertController animated:YES completion:nil];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


#pragma mark - OpportunityReservationsList

- (NSInteger)numberOfSectionsInTableView:(UITableView *)theTableView
{
    return 1;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 110;
}


- (NSInteger)tableView:(UITableView *)theTableView numberOfRowsInSection:(NSInteger)section
{
    return [reserveList count];
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    @try {
        // static NSString *simpleTableIdentifier = @"UserBlockCell";
        
        UserBlockCell *cell = (UserBlockCell *)[tableView dequeueReusableCellWithIdentifier:USERBLOCKCELL];
        if (cell == nil)
        {
            NSArray *nib = [[NSBundle mainBundle] loadNibNamed:USERBLOCKCELL owner:self options:nil];
            cell = [nib objectAtIndex:0];
        }
        
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        cell.backgroundColor = [UIColor clearColor];
        //cell.view1.layer.borderColor = [[UIColor lightGrayColor] CGColor];
        cell.layer.cornerRadius = 45/2;
        
        
        
        NSDictionary *dic = [reserveList objectAtIndex:indexPath.row];
        cell.VendorName.text =[NSString stringWithFormat:@"%@",[dic valueForKey:@"RegUserName"]];
        cell.emaiId.text =[NSString stringWithFormat:@"%@", [dic valueForKey:@"RegEmail"]];
        //cell.blockTime.text =[NSString stringWithFormat:@"%@", [dic valueForKey:@"BlockText"]];
        cell.key.text =[NSString stringWithFormat:@"%@", [dic valueForKey:@"KeyValue"]];
        //         CGFloat imageSize = ceilf(self.view.bounds.size.width * 0.6f);
        //        UIImageView *imageView = [[UIImageView alloc] initWithFrame:CGRectMake(floorf(self.view.bounds.size.width * 0.5f - imageSize * 0.5f), floorf(self.view.bounds.size.height * 0.5f - imageSize * 0.5f), imageSize, imageSize)];
        //      cell.UserImage.image=[UIImage mdQRCodeForString:[dic valueForKey:@"KeyValue"] size:imageView.bounds.size.width fillColor:[UIColor darkGrayColor]];
        
        NSArray *imagearr= [[dic valueForKey:@"PhotoName"] componentsSeparatedByString:@","];
        
        
        // NSString *imageName = [NSString stringWithFormat:@"%@",[dic valueForKey:@"PhotoName"]];;
        
        NSString *ImageURL = [NSString stringWithFormat:@"%@%@",baseImageURL, [imagearr objectAtIndex:0]];
        
        
        //        NSString *imageName = [NSString stringWithFormat:@"%@",[dic valueForKey:@"PhotoName"]];;
        //
        //        NSString *ImageURL = [NSString stringWithFormat:@"%@%@",baseImageURL, imageName];
        
        NSURL *imageURL = [NSURL URLWithString:ImageURL];
        NSString *key = [ImageURL MD5Hash];
        NSData *getData = [FTWCache objectForKey:key];
        if (getData) {
            UIImage *image = [UIImage imageWithData:getData];
            cell.UserImage.image  = image;
        }
        else {
            cell.UserImage.image  = [UIImage imageNamed:@"img_def"];
            dispatch_queue_t queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_HIGH, 0ul);
            dispatch_async(queue, ^{
                NSData *newData = [NSData dataWithContentsOfURL:imageURL];
                [FTWCache setObject:newData forKey:key];
                UIImage *image = [UIImage imageWithData:newData];
                dispatch_sync(dispatch_get_main_queue(), ^{
                    cell.UserImage.image  = image;
                    
                });
            });
        }
        
        NSString *satrtDate = [NSString stringWithFormat:@"%@",[dic valueForKey:@"EndDate"]];
        NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
        [dateFormatter setDateFormat:@"yyyy-MM-dd'T'HH:mm:ss"];
        NSTimeZone *gmt = [NSTimeZone timeZoneWithAbbreviation:@"UTC"];
        [dateFormatter setTimeZone:gmt];
        NSDate *date5 = [dateFormatter dateFromString:satrtDate];
        
        NSDictionary *offertime= [[Preferences GetSharedInstance]remaningTime:[NSDate date] endDate:date5];
        int remain = [[offertime valueForKey:@"Time"] intValue];
        int hour = [[offertime valueForKey:@"Hour"] intValue];
        Timer.textColor = categoryColor;
        int seconds = [[offertime valueForKey:@"Seconds"] intValue];
        if (seconds!=0)
            remain = remain+(seconds/60);
        
        
        if(remain!=0 || seconds!=0)
        {
            remain = remain+(hour*60);
            TimeCoutDown = [[MZTimerLabel alloc] initWithLabel:cell.offerTimer andTimerType:MZTimerLabelTypeTimer];
            [TimeCoutDown setCountDownTime:remain*60];
            [TimeCoutDown start];
            
        }
        else
        {
            cell.offerTimer.text = @"Expired!!";
        }
        
        UIButton      *upcomingBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        upcomingBtn.frame = CGRectMake(200, 70, 150, 30);
        
        UIImage *upimg = [[UIImage alloc]init];
        upimg = [UIImage imageNamed:@"call_blk.png"];
        
        CGSize iconsize =CGSizeMake(18, 18);
        UIImage   *image=   [mConverter image:upimg scaledToSize:iconsize];
        [upcomingBtn setImage: image forState:UIControlStateNormal];
        
        [upcomingBtn setTitleEdgeInsets:UIEdgeInsetsMake(30, 0, 30, -15)];
        [upcomingBtn setTitle:[NSString stringWithFormat:@"%@", [dic valueForKey:@"PhoneNo"]] forState:UIControlStateNormal];
        [upcomingBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        [upcomingBtn addTarget:self action:@selector(tablecall:) forControlEvents:UIControlEventTouchUpInside];
        [cell addSubview:upcomingBtn];
        
        
        return cell;
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
    
    
    
}


-(void)tablecall:(id)sender
{
    CGPoint buttonPosition = [sender convertPoint:CGPointZero toView:reserveTable];
    NSIndexPath *indexPath = [reserveTable indexPathForRowAtPoint:buttonPosition];
    NSDictionary *selectedItem = [reserveList objectAtIndex:indexPath.row];
    NSString *contNumber = [selectedItem valueForKey:@"PhoneNo"];
    
    @try {
        UIDevice *device = [UIDevice currentDevice];
        if ([[device model] isEqualToString:@"iPhone"]) {
            
            NSURL *phoneUrl = [NSURL
                               URLWithString:[NSString stringWithFormat:@"telprompt:%@", contNumber]];
            
            if ([[UIApplication sharedApplication] canOpenURL:phoneUrl]) {
                
                UIApplication *application = [UIApplication sharedApplication];
                [application openURL:phoneUrl options:@{} completionHandler:nil];
                
                
               // [[UIApplication sharedApplication] openURL:phoneUrl];
            }
            
        } else {
            
            UIAlertController *myAlertController =
            [[Web_Services alloc] alert:@"Your device doesn't support this feature."];
            [self presentViewController:myAlertController
                               animated:YES
                             completion:nil];
        }
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
    
}

-(void) viewDidLayoutSubviews
{
    @try {
        
        
        [ super viewDidLayoutSubviews];
        [self.scrollview layoutIfNeeded];
        
        self.scrollview.contentSize=self.Contentview.bounds.size;
        
        UIGraphicsBeginImageContext(self.view.frame.size);
        UIImage *image = UIGraphicsGetImageFromCurrentImageContext();
        UIGraphicsEndImageContext();
        
        self.Contentview.backgroundColor = [UIColor colorWithPatternImage:image];
    }
    @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
