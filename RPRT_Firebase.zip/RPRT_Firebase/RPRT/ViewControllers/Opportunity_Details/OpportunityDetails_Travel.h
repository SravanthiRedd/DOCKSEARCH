//
//  OpportunityDetails_Travel.h
//  RPRT
//
//  Created by sravanthi Gumma on 12/07/16.
//  Copyright © 2016 DevpointSolutions. All rights reserved.
//


//#import "Rating.h"
//#import "RatingBar.h"
#import <UIKit/UIKit.h>
@interface OpportunityDetails_Travel : UIViewController<UITabBarDelegate,UITableViewDataSource>
{
    NSDictionary *GetSelectedOpportunity;
    NSString *OfferTag;
    NSMutableArray *GetAllOpportunities;
}

@property (weak, nonatomic) IBOutlet UILabel *Timer;
@property (weak, nonatomic) IBOutlet UILabel *Description;
@property (weak, nonatomic) IBOutlet UILabel *Address;

@property (weak, nonatomic) IBOutlet UILabel *Vendorname;
@property (weak, nonatomic) IBOutlet UILabel *OpportunityName;
@property (weak, nonatomic) IBOutlet UILabel *PostedDate;
@property (weak, nonatomic) IBOutlet UILabel *Rate;
@property (weak, nonatomic) IBOutlet UILabel *MobileNumber;
@property (weak, nonatomic) IBOutlet UILabel *note;

@property (assign, nonatomic) NSInteger index;
@property (assign ,nonatomic) NSMutableArray *SetAllOpportunities;
@property (nonatomic,strong)  NSDictionary *SetOpportunity;
@property (nonatomic,strong)  NSString *SetofferTag;

@property (weak, nonatomic) IBOutlet UILabel *fromAddress;
@property (weak, nonatomic) IBOutlet UILabel *toaddress;
@property (weak, nonatomic) IBOutlet UILabel *price;
@property (weak, nonatomic) IBOutlet UILabel *available;
@property (nonatomic,weak) IBOutlet UILabel *blockTimer;
@property (nonatomic,weak) IBOutlet UILabel *viewRatings;

@property (nonatomic,weak) IBOutlet UIButton *call;
@end
