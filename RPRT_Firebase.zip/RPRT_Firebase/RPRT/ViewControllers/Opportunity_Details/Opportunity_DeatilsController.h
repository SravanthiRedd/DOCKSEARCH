//
//  Opportunity_DeatilsController.h
//  RPRT
//
//  Created by sravanthi Gumma on 16/02/16.
//  Copyright © 2016 DevpointSolutions. All rights reserved.
//


#import "Opportunity_DeatilsController.h"
#import "Opportunity_Details.h"
#import "OpportunityDetails_Travel.h"
#import "OpportunityDetails_Banking.h"


@interface Opportunity_DeatilsController : UIViewController<UIPageViewControllerDataSource>
{
    NSMutableArray *GetAllOpportunites;
    NSString *GetSelectedOpportunity;
    NSString *GetOffertag;
    
}

+(Opportunity_DeatilsController*)getsharedinstace;

@property (strong, nonatomic) UIPageViewController *pageController;

@property (nonatomic,retain)  NSString *SetSelectedOpportunity;
@property (nonatomic,strong)  NSMutableArray *SetAllOpportunity;
@property (nonatomic,strong)  NSString *SetOfferTag;

-(IBAction)back:(id)sender;

@property (weak, nonatomic) IBOutlet UIButton *Radious;
@property (weak,nonatomic)IBOutlet UIButton *Settings;
@property (weak, nonatomic) IBOutlet UIButton *back;
-(void)hidestatusbar;
@property(strong,nonatomic) IBOutlet UIView *toolBarView;
@end
