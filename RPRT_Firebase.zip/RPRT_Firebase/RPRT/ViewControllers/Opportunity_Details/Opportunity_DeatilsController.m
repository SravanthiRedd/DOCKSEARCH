//
//  Opportunity_DeatilsController.m
//  RPRT
//
//  Created by sravanthi Gumma on 16/02/16.
//  Copyright © 2016 DevpointSolutions. All rights reserved.
//

#import "Opportunity_DeatilsController.h"
#import "Web_Services.h"
#import "Home.h"

@interface Opportunity_DeatilsController ()
{
    //NSMutableArray *AllOpportunities;
    NSString *SelectedOpportunity;
    NSString *RetailerLoginData;
    int selectedIndex;
   
    UIView *contentView;
  
    Web_Services *mWebservice;
    UIView *RadiousView;
    UIButton *radiousMenu;
    NSUserDefaults *mPref ;
    UIActivityIndicatorView *spinner;
    NSString *category ;

}
@end
static Opportunity_DeatilsController *OppShareInstance = nil;


@implementation Opportunity_DeatilsController
@synthesize pageController,Settings,Radious,toolBarView;


+(Opportunity_DeatilsController*)getsharedinstace
{
    if(OppShareInstance == nil)
    {
        OppShareInstance = [[Opportunity_DeatilsController alloc] init];
    }
    return OppShareInstance;

}

- (void)viewDidLoad {
    @try {
      
    [super viewDidLoad];
     mWebservice = [Web_Services GetSharedInstance];
      mPref = [NSUserDefaults standardUserDefaults];
    GetAllOpportunites = self.SetAllOpportunity;
    GetSelectedOpportunity = self.SetSelectedOpportunity;
        GetOffertag = self.SetOfferTag;
    selectedIndex = [GetSelectedOpportunity intValue];

       [self setNeedsStatusBarAppearanceUpdate];
        
    
    //add Viewpager
    
    self.pageController = [[UIPageViewController alloc] initWithTransitionStyle:UIPageViewControllerTransitionStyleScroll navigationOrientation:UIPageViewControllerNavigationOrientationHorizontal options:nil];
    
    
    self.pageController.dataSource = self;
    // [[self.pageController view] setFrame:[[self view] bounds]];f
    
    [[self.pageController view] setFrame:CGRectMake(0, 15, 380, 900)];
        
        category =[mPref valueForKey:CATEGORY];
        //Opportunity_Details *childViewController;
        NSArray *viewControllers ;
        category =[mPref valueForKey:CATEGORY];
        
        if ([category isEqualToString:TRAVELS]) {
            OpportunityDetails_Travel *initialViewController = [self viewControllerAtIndex1:selectedIndex];
            
            
            viewControllers = [NSArray arrayWithObject:initialViewController];
        
        }
        
        else  if ([category isEqualToString:BANKING]) {
            NSLog(@"sdfgsdfg");
            OpportunityDetails_Banking *initialViewController = [self viewControllerAtIndex2:selectedIndex];
            
            
            viewControllers = [NSArray arrayWithObject:initialViewController];
            
        }
        
        else
        {
            Opportunity_Details *initialViewController = [self viewControllerAtIndex:selectedIndex];
            
            
            viewControllers = [NSArray arrayWithObject:initialViewController];
        }
       
    
    [self.pageController setViewControllers:viewControllers direction:UIPageViewControllerNavigationDirectionForward animated:NO completion:nil];
    
    [self addChildViewController:self.pageController];
    [[self view] addSubview:[self.pageController view]];
    [self.pageController didMoveToParentViewController:self];
    
    //load Setting Button
        
    [self LoadToolBar];
    
        
    
   
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
    
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)LoadToolBar

{
    
    @try {
        
    
  //  NSString *category =[mPref valueForKey:CATEGORY];
        NSData *colorData= [mPref valueForKey:@"COLOR"];
if (colorData == nil) {
            toolBarView.backgroundColor= [UIColor colorWithRed:0/256.0 green:186.0/256.0 blue:210/256.0 alpha:1];
        }
        else
          toolBarView.backgroundColor = [NSKeyedUnarchiver unarchiveObjectWithData:colorData];
    
   
    //toolBarView.hidden= YES;
    }
    @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    }
    @finally {
        
    }
}

-(void)hidestatusbar
{
    
    @try {
        
    toolBarView.hidden = YES;
    
     [[self.pageController view] setFrame:CGRectMake(0, 0, 380, 900)];
    }
    @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    }
    @finally {
        
    }
}


- (IBAction) Myblock:(id) sender {
    
    @try {
        
    
    
            spinner = [[UIActivityIndicatorView alloc]
                       initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
            spinner.frame = CGRectMake(0, 0, 320, 560); // CGPointMake(160, 240);
            spinner.color = [UIColor blueColor];
            spinner.backgroundColor = [UIColor lightTextColor];
            spinner.transform = CGAffineTransformMakeScale(2, 2);
            // spinner.hidesWhenStopped = YES;
            [self.view addSubview:spinner];
            spinner.transform = CGAffineTransformMakeScale(2, 2);
    
            [spinner startAnimating];
    
            // how we stop refresh from freezing the main UI thread
    
            dispatch_async(
                           dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^{
    
                               // back to the main thread for the UI call
                               dispatch_async(dispatch_get_main_queue(), ^{
                                   [spinner startAnimating];
                               });
                               dispatch_async(dispatch_get_main_queue(), ^{
    
    MyBlocks * mMyBlocks = [[ MyBlocks alloc] initWithNibName:MYBLOCKS bundle:nil];
    [self presentViewController:mMyBlocks animated:YES completion:nil];
                                     [spinner stopAnimating];
                                
                               
                                                          });
                                                      });
        
    }
    @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    }
    @finally {
        
    }

}



-(IBAction)back:(id)sender {
    
    @try
    {
        [self dismissViewControllerAnimated:YES completion:NULL];
    }

@catch (NSException *exception) {
    [self showAlertPop:@"Error while fetching data." expObj:exception];
}
@finally {
    
}

}

#pragma mark - UIPageViewControllerDataSource

- (Opportunity_Details *)viewControllerAtIndex:(NSUInteger)index {
    @try {
        
            Opportunity_Details *childViewController = [[Opportunity_Details alloc] initWithNibName:OPPORTUNITYDETAILS bundle:nil];
            childViewController.index = index;
            childViewController.SetAllOpportunities = GetAllOpportunites;
            childViewController.SetofferTag = GetOffertag;
            
            return childViewController;
          } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
    
}


- (OpportunityDetails_Travel *)viewControllerAtIndex1:(NSUInteger)index {
    @try {
        
       
            OpportunityDetails_Travel     *childView = [[OpportunityDetails_Travel alloc] initWithNibName:OPPORTUNITYDETAILSTRAVEL bundle:nil];
            childView.index = index;
            childView.SetAllOpportunities = GetAllOpportunites;
            childView.SetofferTag = GetOffertag;
            
            return childView;
            
        
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
    
}


- (OpportunityDetails_Banking *)viewControllerAtIndex2:(NSUInteger)index {
    @try {
        
        
        OpportunityDetails_Banking     *childView = [[OpportunityDetails_Banking alloc] initWithNibName:@"OpportunityDetails_Banking" bundle:nil];
        childView.index = index;
        childView.SetAllOpportunities = GetAllOpportunites;
        childView.SetofferTag = GetOffertag;
        
        return childView;
        
        
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
    
}




- (UIViewController *)pageViewController:(UIPageViewController *)pageViewController viewControllerBeforeViewController:(UIViewController *)viewController {
    @try {
        
           if ([category isEqualToString:TRAVELS]) {
               
               NSUInteger index = [(OpportunityDetails_Travel *)viewController index];
               
               if (index == 0) {
                   return nil;
               }
               
               // Decrease the index by 1 to return
               index--;
               
               return [self viewControllerAtIndex1:index];

            }
        
           else if ([category isEqualToString:BANKING]) {
               
               NSUInteger index = [(OpportunityDetails_Banking *)viewController index];
               
               if (index == 0) {
                   return nil;
               }
               
               // Decrease the index by 1 to return
               index--;
               
               return [self viewControllerAtIndex2:index];
           }
        
        else
        {
            NSUInteger index = [(Opportunity_Details *)viewController index];
            
            if (index == 0) {
                return nil;
            }
            
            // Decrease the index by 1 to return
            index--;
            
            return [self viewControllerAtIndex:index];
        }
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
    
}

- (UIViewController *)pageViewController:(UIPageViewController *)pageViewController viewControllerAfterViewController:(UIViewController *)viewController {
    @try {
        
        if ([category isEqualToString:TRAVELS]) {
            
            NSUInteger index = [(OpportunityDetails_Travel *)viewController index];
            
            index++;
            
            if (index == [GetAllOpportunites count]) {
                return nil;
            }
            
            return [self viewControllerAtIndex1:index];
            
            
        }
        
        else   if ([category isEqualToString:BANKING]) {
        
            NSUInteger index = [(OpportunityDetails_Banking *)viewController index];
            
            index++;
            
            if (index == [GetAllOpportunites count]) {
                return nil;
            }
            
            return [self viewControllerAtIndex2:index];

        }
        
        else
        {
            NSUInteger index = [(Opportunity_Details *)viewController index];
            
            index++;
            
            if (index == [GetAllOpportunites count]) {
                return nil;
            }
            
            return [self viewControllerAtIndex:index];

        }
       
    
  
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
    
}

- (NSInteger)presentationCountForPageViewController:(UIPageViewController *)pageViewController {
    // The number of items reflected in the page indicator.
    return [GetAllOpportunites count];
}

- (NSInteger)presentationIndexForPageViewController:(UIPageViewController *)pageViewController {
    // The selected item reflected in the page indicator.
    return selectedIndex;
}


-(void)StoreRadios:(NSString*)rad
{
    @try {
        [[Preferences GetSharedInstance]StoreRadious:rad];
        Opportunity_List_New * mOpportunity_list = [[ Opportunity_List_New alloc] initWithNibName:OPPORTUNITYLISTNEW bundle:nil];
        [self presentViewController:mOpportunity_list animated:YES completion:nil];
    }
    @catch (NSException *exception) {
        [self showAlertPop:@"Invalid UserName." expObj:exception];
    }
    @finally {
        
    }
}

- (void) showAlertPop:(NSString*)alertText expObj:(NSException*) exp{
    if(exp != nil)
    {
        NSLog(@"%@", exp.description);
    }
    UIAlertController *myAlertController =[mWebservice  alert:alertText];
    [self presentViewController:myAlertController animated:YES completion:nil];
}










@end
