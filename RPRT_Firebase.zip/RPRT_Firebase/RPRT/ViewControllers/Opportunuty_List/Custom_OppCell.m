//
//  Custom_OppCell.m
//  RPRT
//
//  Created by sravanthi Gumma on 04/09/1938 Saka.
//  Copyright © 1938 Saka DevpointSolutions. All rights reserved.
//

#import "Custom_OppCell.h"
//static CGFloat radius = 2;
@implementation Custom_OppCell
@synthesize opportunity = opprtunity;
@synthesize Opdescription = Opdescription;
@synthesize view1 = view1;
@synthesize view2 = view2;

@synthesize blockBtn= blockBtn;
@synthesize offerPostBy =offerPostBy;
@synthesize categoryType = categoryType;

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}
-(void)layoutSubviews{
//    self.layer.cornerRadius = 45/2;
//    UIBezierPath *shadowPath = [UIBezierPath
//                                bezierPathWithRoundedRect: self.bounds
//                                cornerRadius: radius];
//    self.layer.masksToBounds = false;
//    self.layer.shadowColor = [UIColor blackColor].CGColor;
//    self.layer.shadowOffset = CGSizeMake(0, 4);
//    self.layer.shadowOpacity = 0.2;
//    self.layer.shadowPath = shadowPath.CGPath;
    
   // self.view1.layer.cornerRadius=5;
    
    self.view1.layer.shadowColor = [UIColor grayColor].CGColor;
    self.view1.layer.borderColor = [UIColor colorWithRed:175.0/256.0 green:175.0/256.0 blue:175.0/256.0 alpha:1].CGColor;
    self.view1.layer.borderWidth=0.5f;
    self.view1.layer.shadowOffset = CGSizeMake(1.0, 1.0);
    self.view1.layer.shadowOpacity = 0.7;
    self.view1.layer.cornerRadius = 4.0;

    
    
    
    
    // self.layer.shadowColor = [UIColor lightGrayColor].CGColor;
    //self.layer.shadowOffset = CGSizeMake(0, 4);
    // self.layer.shadowOpacity = 1;
    //  self.layer.shadowRadius = 1.0;
    
    
    
    self.OpportunityImage.layer.cornerRadius = self.OpportunityImage.frame.size.width/2;
    self.OpportunityImage.layer.masksToBounds = YES;
}
-(id)initWithCoder:(NSCoder *)aDecoder{
    return [super initWithCoder:aDecoder];
}



@end
