//
//  Food_Sale_Cell.h
//  RPRT
//
//  Created by sravanthi Gumma on 14/09/16.
//  Copyright © 2016 DevpointSolutions. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Food_Sale_Cell : UITableViewCell
@property (nonatomic,weak)IBOutlet UILabel *opportunity;
@property (nonatomic,weak) IBOutlet UILabel *description;
@property (nonatomic,weak) IBOutlet UIView *view1;
@property (nonatomic,weak) IBOutlet UIView *view2;
@property (weak, nonatomic) IBOutlet UILabel *Location;
@property (weak, nonatomic) IBOutlet UILabel *Timer;
@property (weak, nonatomic) IBOutlet UILabel *Avialable;
@property (weak, nonatomic) IBOutlet UILabel *delivery;
@property (weak, nonatomic) IBOutlet UILabel *categoryType;
@property (weak, nonatomic) IBOutlet UILabel *actualprice;
@property (weak, nonatomic) IBOutlet UILabel *price;
@property (weak, nonatomic) IBOutlet UILabel *offerpostBy;

@property (weak, nonatomic) IBOutlet UILabel *priceLbl;
@property (weak, nonatomic) IBOutlet UILabel *deliveryLbl;

@property (weak, nonatomic) IBOutlet UIImageView *OpportunityImage;
@property(weak,nonatomic) IBOutlet UIButton *shareBtn;
@property(weak,nonatomic) IBOutlet UIButton *spamBtn;
@property(weak,nonatomic) IBOutlet UIButton *blockBtn;
@end
