//
//  Travel_cell.h
//  RPRT
//
//  Created by sravanthi Gumma on 26/09/16.
//  Copyright © 2016 DevpointSolutions. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Travel_cell : UITableViewCell
@property (nonatomic,weak)IBOutlet UILabel *opportunity;
//@property (nonatomic,weak) IBOutlet UILabel *description;
@property (nonatomic,weak) IBOutlet UIView *view1;
@property (nonatomic,weak) IBOutlet UIView *view2;

@property (weak, nonatomic) IBOutlet UILabel *fromAddress;
@property (weak, nonatomic) IBOutlet UILabel *toAddress;
@property (weak, nonatomic) IBOutlet UILabel *available;
@property (weak, nonatomic) IBOutlet UILabel *offerStatsu;
@property (weak, nonatomic) IBOutlet UILabel *subcategory;

@property (weak, nonatomic) IBOutlet UILabel *offerpostBy;



@property (weak, nonatomic) IBOutlet UIImageView *OpportunityImage;


@property(weak,nonatomic) IBOutlet UIButton *blockBtn;@end
