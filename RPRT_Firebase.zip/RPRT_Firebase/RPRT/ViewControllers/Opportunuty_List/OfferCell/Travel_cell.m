//
//  Travel_cell.m
//  RPRT
//
//  Created by sravanthi Gumma on 26/09/16.
//  Copyright © 2016 DevpointSolutions. All rights reserved.
//

#import "Travel_cell.h"
//static CGFloat radius = 2;
@implementation Travel_cell
@synthesize opportunity = opprtunity;

@synthesize view1 = view1;
@synthesize view2 = view2;
@synthesize available = available;

@synthesize subcategory = subcategory;
@synthesize blockBtn = blockBtn;

@synthesize offerpostBy = offerpostBy;
- (void)awakeFromNib {
    // Initialization code
    [super awakeFromNib];
    //    view1.layer.borderColor = [[UIColor lightGrayColor]CGColor];
    //    view1.layer.borderWidth =1;
    //    view2.layer.borderColor = [[UIColor lightGrayColor]CGColor];
    //    view2.layer.borderWidth =1;
    
}


-(void)layoutSubviews{
//    self.layer.cornerRadius = 45/2;
//  //  UIBezierPath *shadowPath = [UIBezierPath
//                             //   bezierPathWithRoundedRect: self.bounds
//                             //   cornerRadius: radius];
//    self.layer.masksToBounds = false;
//    //    self.layer.shadowColor = [UIColor blackColor].CGColor;
//    //    self.layer.shadowOffset = CGSizeMake(0, 1);
//    //    self.layer.shadowOpacity = 0.2;
//    // self.layer.shadowPath = shadowPath.CGPath;
//    
//    
//    self.layer.shadowColor = [UIColor lightGrayColor].CGColor;
//    self.layer.shadowOffset = CGSizeMake(0, 4);
//    self.layer.shadowOpacity = 1;
//    self.layer.shadowRadius = 1.0;
//    
//    
//    self.view1.layer.cornerRadius=5;

    self.view1.layer.shadowColor = [UIColor grayColor].CGColor;
    self.view1.layer.borderColor = [UIColor colorWithRed:175.0/256.0 green:175.0/256.0 blue:175.0/256.0 alpha:1].CGColor;
    self.view1.layer.borderWidth=0.5f;
    self.view1.layer.shadowOffset = CGSizeMake(1.0, 1.0);
    self.view1.layer.shadowOpacity = 0.7;
    self.view1.layer.cornerRadius = 4.0;
    
    
    self.OpportunityImage.layer.cornerRadius = self.OpportunityImage.frame.size.width/2;
    self.OpportunityImage.layer.masksToBounds = YES;
}
-(id)initWithCoder:(NSCoder *)aDecoder{
    return [super initWithCoder:aDecoder];
}


- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
    
    // Configure the view for the selected state
}

-(void)viewDidLoad
{
    NSLog(@"sdfgsdf");
}

@end
