//
//  Offertabs.h
//  RPRT
//
//  Created by sravanthi Gumma on 12/01/16.
//  Copyright © 2016 DevpointSolutions. All rights reserved.
//



#import "VCFloatingActionButton.h"
#import "OpportunityCell.h"
#import "DLStarRatingControl.h"
#import "Opportunity_DeatilsController.h"
#import "Map.h"
#import "CustomIOSAlertView.h"
#import "MZTimerLabel.h"
#import "MyBlocks.h"


@interface Offertabs :UIViewController<UITableViewDataSource,UITableViewDelegate,CLLocationManagerDelegate,floatMenuDelegate>
{
    CLLocationManager *locationManager;
    CLLocationCoordinate2D coordinate;
    NSDictionary *GetOpportunuties;
}
@property (weak) IBOutlet UILabel *label;
@property NSString *textLabel;

@property (weak, nonatomic) IBOutlet UIButton *Radious;
@property (nonatomic,strong) IBOutlet UITableView *opportunityTable;
@property (nonatomic,strong)  UIButton *liveBtn;
@property (nonatomic,strong)  UIButton *upComingBtn;
@property (nonatomic,strong)  UIButton *expiredBtn;
@property (nonatomic,strong)  NSDictionary *SetOpportunities;



@end
