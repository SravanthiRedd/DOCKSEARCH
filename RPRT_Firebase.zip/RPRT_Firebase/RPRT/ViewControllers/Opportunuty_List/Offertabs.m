	//
//  Offertabs.m
//  RPRT
//
//  Created by sravanthi Gumma on 12/01/16.
//  Copyright © 2016 DevpointSolutions. All rights reserved.
//

#import "Offertabs.h"

@interface Offertabs ()<CLLocationManagerDelegate,DLStarRatingDelegate,CustomIOSAlertViewDelegate,MZTimerLabelDelegate>
{
    int count;
    CustomIOSAlertView *SortAlert;
    Web_Services *webService;
    NSMutableArray *GetOffers;
    CurrentLocation *mLocation;
    NSString *moduleID;
    UIView *SortDemoView;
    UIButton *Date;
    UIButton*Time;
    UIButton *Distance;
    NSString *AlertString;
     MZTimerLabel *TimeCoutDown;
    NSUserDefaults *mPref;
    UIActivityIndicatorView *spinner;

}
@property (strong, nonatomic) VCFloatingActionButton *FloatBtn;
@property (nonatomic, copy)  NSDictionary *setCache;
@end

@implementation Offertabs
@synthesize opportunityTable,liveBtn,upComingBtn,expiredBtn,FloatBtn,Radious;
- (void)viewDidLoad {
 
    
    @try {
        
        //GetOpportunuties = [NSDictionary alloc];
        [super viewDidLoad];
        self.setCache = [[NSMutableDictionary alloc] init];
        
        NSDictionary  *GetOpportunuty = self.SetOpportunities;
        mPref = [[NSUserDefaults alloc] init];
        AlertString = @"Date";
        GetOffers = [[NSMutableArray alloc]init];
        moduleID = self.textLabel;
        if([moduleID isEqualToString:@"2"])
        {
            
            
            GetOffers = [GetOpportunuty valueForKey:@"ListExpire"];
            
            if (GetOffers.count>1) {
                [opportunityTable reloadData];

                opportunityTable.hidden = NO;
                
            }
            
            
         else if (GetOffers.count==0) {
             opportunityTable.hidden = YES;
             [opportunityTable reloadData];

                UILabel *lbl = [[UILabel alloc]initWithFrame:CGRectMake(100, 200, 150, 25)];
                lbl.text =@"No Record Found!!";
                [self.view addSubview:lbl];
              opportunityTable.hidden = YES;
            }
           
        }
        else if([moduleID isEqualToString:@"1"])
        {
            GetOffers = [GetOpportunuty valueForKey:@"ListUpcoming"];
              if (GetOffers.count>1) {
                  

                    [opportunityTable reloadData];
              }
           else if (GetOffers.count==0) {
               opportunityTable.hidden = YES;
               [opportunityTable reloadData];
                UILabel *lbl = [[UILabel alloc]initWithFrame:CGRectMake(100, 200, 150, 25)];
                lbl.text =@"No Record Found!!";
                [self.view addSubview:lbl];
               
            }
           
        }
        else if ([moduleID isEqualToString:@"0"])
        {
            GetOffers = [GetOpportunuty valueForKey:@"Listongoing"];
               if (GetOffers.count>1) {
       
                    [opportunityTable reloadData];
               }
          else  if (GetOffers.count==0) {
              opportunityTable.hidden = YES;
              [opportunityTable reloadData];

                UILabel *lbl = [[UILabel alloc]initWithFrame:CGRectMake(100, 200, 150, 25)];
                lbl.text =@"No Record Found!!";
                [self.view addSubview:lbl];
              
              opportunityTable.hidden = YES;
            }
        }
      
        webService = [Web_Services GetSharedInstance];
        
        //Creation live, Upcoming and Expired buttons
        self.opportunityTable.backgroundColor = [UIColor clearColor];
        self.opportunityTable.opaque = NO;
        
        UIImageView *tempImageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"pagebg.jpg"]];
        [tempImageView setFrame:self.opportunityTable.frame];
        
        self.opportunityTable.backgroundView = tempImageView;
        
        mLocation = [CurrentLocation GetSharedInstance];
        
        [self LoadFloatview];

    }
    @catch (NSException *exception) {
        NSLog(@"The error is %@",exception.description);
    }
    @finally {
        
    }
    
    
    // Do any additional setup after loading the view from its nib.
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [GetOffers count];
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 150;
}


// This will tell your UITableView what data to put in which cells in your table.
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSString *simpleTableIdentifier = @"OpportunityCell";
    
    OpportunityCell *cell = (OpportunityCell *)[tableView dequeueReusableCellWithIdentifier:simpleTableIdentifier];
    if (cell == nil)
    {
        NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"OpportunityCell" owner:self options:nil];
        cell = [nib objectAtIndex:0];
    }
    cell.backgroundColor = [UIColor clearColor];
    cell.view1.layer.borderColor = [[UIColor lightGrayColor] CGColor];
    cell.view1.layer.borderWidth = 1;
    cell.view2.layer.borderColor = [[UIColor lightGrayColor] CGColor];
    cell.view2.layer.borderWidth = 1;
    
    //update tableview cell
    
     NSDictionary *Record = [GetOffers objectAtIndex:indexPath.row];
    cell.opportunity.text =[NSString stringWithFormat:@"%@",[Record valueForKey:@"VendorName"]];
    cell.description.text = [NSString stringWithFormat:@"%@",[Record valueForKey:@"OpportunityDescription"]];
    cell.Location.text = [NSString stringWithFormat:@"%@",[Record valueForKey:@"AreaName"]];
    
    if([self.textLabel  isEqualToString:@"2"])
    {
        
        cell.Timer.text = @"Expired!!";
        cell.Avialable.text = @"";
    }
    else if ([self.textLabel  isEqualToString:@"1"])
    {
        NSString *satrtDate = [NSString stringWithFormat:@"%@",[Record valueForKey:@"StartDate"]];
        NSArray *Datestr = [satrtDate componentsSeparatedByString:@"T"];
        
        
        
        NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
        [dateFormatter setDateFormat:@"yyyy-MM-dd"];
        NSTimeZone *gmt = [NSTimeZone timeZoneWithAbbreviation:@"UTC"];
        [dateFormatter setTimeZone:gmt];
        
        NSDate *currentDateInLocal = [NSDate date];
        NSString *currentLocalDateAsStr = [dateFormatter stringFromDate:currentDateInLocal];
        NSString *Datetime =[Datestr objectAtIndex:0];
        if ([currentLocalDateAsStr isEqualToString:Datetime]) {
            
            NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
            dateFormatter.dateFormat = @"HH:mm:ss";
            NSString *time =[Datestr objectAtIndex:1];
            NSDate *date = [dateFormatter dateFromString:time];
            dateFormatter.dateFormat = @"hh:mm a";
            NSString *pmamDateString = [dateFormatter stringFromDate:date];
            
            cell.Timer.text =[NSString stringWithFormat:@"Start on %@",pmamDateString];
        }
        else
        {
            cell.Timer.text =[NSString stringWithFormat:@"Start on %@",Datetime];
        }
         cell.Avialable.text = [NSString stringWithFormat:@"Available : %@",[Record valueForKey:@"Available"]];
    }
    else if ([self.textLabel  isEqualToString:@"0"])
    {
        
        NSString *satrtDate = [NSString stringWithFormat:@"%@",[Record valueForKey:@"EndDate"]];
        NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
        [dateFormatter setDateFormat:@"yyyy-MM-dd'T'HH:mm:ss"];
        NSTimeZone *gmt = [NSTimeZone timeZoneWithAbbreviation:@"UTC"];
        [dateFormatter setTimeZone:gmt];
        NSDate *date5 = [dateFormatter dateFromString:satrtDate];
        
        NSDictionary *startOffer= [[Preferences GetSharedInstance]remaningTime:[NSDate date] endDate:date5];
        int Remaingtyime = [[startOffer valueForKey:@"Time"] intValue];
        
        TimeCoutDown = [[MZTimerLabel alloc] initWithLabel:cell.Timer andTimerType:MZTimerLabelTypeTimer];
        [TimeCoutDown setCountDownTime:Remaingtyime*60];
        [TimeCoutDown start];
        
         cell.Avialable.text =[NSString stringWithFormat:@"Available:%@",[Record valueForKey:@"Available"]];
    }
   
    
    NSString *imageName = [NSString stringWithFormat:@"%@",[Record valueForKey:@"PhotoName"]];;
      NSArray *imageAry = [imageName componentsSeparatedByString:@","];
    NSString *ImageURL = [NSString stringWithFormat:@"%@%@",baseImageURL, [imageAry objectAtIndex:0]];
    
    if ([[imageAry objectAtIndex:0] isEqualToString:@""]) {
        NSString *category =[Record objectForKey:@"Category"]; //[ //
        if([category isEqualToString:@"Food"])
        {
          
            cell.OpportunityImage.image = [UIImage imageNamed:@"food_new.png"];
        }
        else if ([category isEqualToString:@"Jobs"])
        {
           
            cell.OpportunityImage.image = [UIImage imageNamed:@"jobs_new.png"];

            
        }
        else if([category isEqualToString:@"Meetings"])
        {
          cell.OpportunityImage.image =[UIImage imageNamed:@"meetings_new.png"];
            
        }
        else if([category isEqualToString:@"Professional Services"])
        {
          
            cell.OpportunityImage.image = [UIImage imageNamed:@"professionalhelp_new.png"];
            
        }
        else if([category isEqualToString:@"Sale"])
        {
           
            cell.OpportunityImage.image = [UIImage imageNamed:@"sales_new.png"];
            
        }
        else if([category isEqualToString:@"Sports"])
        {          
            cell.OpportunityImage.image = [UIImage imageNamed:@"sports_new.png"];
            
        }
    }
    
    else {
    
    NSURL *imageURL = [NSURL URLWithString:ImageURL];
    NSString *key = [ImageURL MD5Hash];
    NSData *getData = [FTWCache objectForKey:key];
    if (getData) {
        UIImage *image = [UIImage imageWithData:getData];
        cell.OpportunityImage.image  = image;
    }
    else {
        cell.OpportunityImage.image  = [UIImage imageNamed:@"img_def"];
        dispatch_queue_t queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_HIGH, 0ul);
        dispatch_async(queue, ^{
            NSData *newData = [NSData dataWithContentsOfURL:imageURL];
            [FTWCache setObject:newData forKey:key];
            UIImage *image = [UIImage imageWithData:newData];
            dispatch_sync(dispatch_get_main_queue(), ^{
                cell.OpportunityImage.image  = image;
                
            });
        });
    }
    
    }
    
    
    
    


    if ([Record valueForKey:@"distance"] ==[NSNull null]) {
        
    }
    
   // NSMutableDictionary *locatioLatLon = [[NSMutableDictionary alloc]init];
   // [locatioLatLon setValue:[Record valueForKey:@"Latitude"] forKey:@"Latitude"];
  //  [locatioLatLon setValue:[Record valueForKey:@"Longitude"] forKey:@"Longitude"];
    
    //cell.Distance.text = [NSString stringWithFormat:@"%@",[Record valueForKey:@"distance"]];
    
    DLStarRatingControl *customNumberOfStars = [[DLStarRatingControl alloc] initWithFrame:CGRectMake(15,112,230,25)];
    customNumberOfStars.delegate = self;
    //RatingValue = "4.00";
    
    customNumberOfStars.rating = [[Record valueForKey:@"RatingValue"] intValue];
    
    
    [cell.contentView addSubview:customNumberOfStars];
    
    //block button
    UIButton *blockBtn = [[UIButton alloc]initWithFrame:CGRectMake(300,112,60,25)];
    blockBtn.layer.masksToBounds = YES;
    blockBtn.layer.cornerRadius = 2;
    [blockBtn setBackgroundColor:[UIColor orangeColor]];
    if ([moduleID isEqualToString:@"2"]) {
        [blockBtn setTitle:@"Notify" forState:UIControlStateNormal];
        [blockBtn addTarget:self action:@selector(Block:) forControlEvents:UIControlEventTouchUpInside];
        [cell addSubview:blockBtn];
    }
    else if ([moduleID isEqualToString:@"1"])
    {
        
    }
    else if ([moduleID isEqualToString:@"0"])
    {
         [blockBtn setTitle:@"Block" forState:UIControlStateNormal];
        [blockBtn addTarget:self action:@selector(Block:) forControlEvents:UIControlEventTouchUpInside];
        [cell addSubview:blockBtn];
    }
    
  
    //[blockBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    //[blockBtn setImage:[UIImage imageNamed:@"block.png"] forState:UIControlStateNormal];
    
    
    //NSUInteger row = [indexPath row];
    
    
    return cell;
}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
    
    @try {
        
        
        spinner = [[UIActivityIndicatorView alloc]
                   initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
        spinner.frame = CGRectMake(0, 0, 320, 560); // CGPointMake(160, 240);
        spinner.color = [UIColor blueColor];
        spinner.backgroundColor = [UIColor lightTextColor];
        spinner.transform = CGAffineTransformMakeScale(2, 2);
        // spinner.hidesWhenStopped = YES;
        [self.view addSubview:spinner];
        spinner.transform = CGAffineTransformMakeScale(2, 2);
        
        [spinner startAnimating];
        
        // how we stop refresh from freezing the main UI thread
        
        dispatch_async(
                       dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^{
                           
                           // back to the main thread for the UI call
                           dispatch_async(dispatch_get_main_queue(), ^{
                               [spinner startAnimating];
                           });
                           dispatch_async(dispatch_get_main_queue(), ^{
                               NSDictionary *SelectedItem = [GetOffers objectAtIndex:indexPath.row];
                               [self saveViewOpprtunity:SelectedItem];
                               Opportunity_DeatilsController *mplaceOrder = [Opportunity_DeatilsController alloc];
                               mplaceOrder.SetAllOpportunity =GetOffers;
                               mplaceOrder.SetSelectedOpportunity =[NSString stringWithFormat:@"%ld",(long)indexPath.row];
                               mplaceOrder.SetOfferTag = self.textLabel;
                               Opportunity_DeatilsController *mPlaceOrderA01 =
                               [mplaceOrder initWithNibName:@"Opportunity_DeatilsController" bundle:nil];
                               [self presentViewController:mPlaceOrderA01 animated:YES completion:nil];

                               [spinner stopAnimating];
                               
                           });
                       });
    }
    @catch (NSException *exception) {
        
    }
    @finally {
        
    }
}

-(void)saveViewOpprtunity:(NSDictionary*)Offer
{
    NSUserDefaults *prefss = [NSUserDefaults standardUserDefaults];
    NSString *userID =   [prefss objectForKey:@"SaveUserID"];

    NSMutableDictionary *dic = [[NSMutableDictionary alloc]init];
    [dic setObject:[Offer valueForKey:@"OpportunityID"] forKey:@"OpportunityID"];
    [dic setObject:userID forKey:@"UserID"];
    [webService SaveUserViewedOpportunities:dic];
}



-(void)Block:(UIButton*)sender
{
    
    
    @try {
        
        
        spinner = [[UIActivityIndicatorView alloc]
                   initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
        spinner.frame = CGRectMake(0, 0, 320, 560); // CGPointMake(160, 240);
        spinner.color = [UIColor blueColor];
        spinner.backgroundColor = [UIColor lightTextColor];
        spinner.transform = CGAffineTransformMakeScale(2, 2);
        // spinner.hidesWhenStopped = YES;
        [self.view addSubview:spinner];
        spinner.transform = CGAffineTransformMakeScale(2, 2);
        
        [spinner startAnimating];
        
        // how we stop refresh from freezing the main UI thread
        
        dispatch_async(
                       dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^{
                           
                           // back to the main thread for the UI call
                           dispatch_async(dispatch_get_main_queue(), ^{
                               [spinner startAnimating];
                           });
                           dispatch_async(dispatch_get_main_queue(), ^{
                               NSUserDefaults *prefss = [NSUserDefaults standardUserDefaults];
                               
                               NSString *RegisterID =   [prefss objectForKey:@"UserRegisterID"];
                               if (RegisterID!=nil) {
                                   CGPoint buttonPosition = [sender convertPoint:CGPointZero toView:opportunityTable];
                                   NSIndexPath *indexPath = [opportunityTable indexPathForRowAtPoint:buttonPosition];
                                   NSDictionary *BlockedItem = [GetOffers objectAtIndex:indexPath.row];
                                   NSMutableDictionary *dic = [[NSMutableDictionary alloc]init];
                                   NSString *uniqueIdentifier = [[[UIDevice currentDevice] identifierForVendor] UUIDString];
                                   [dic setValue:[BlockedItem valueForKey:@"OpportunityID"] forKey:@"OpportunityId"];
                                   [dic setValue:[BlockedItem valueForKey:@"KeyValue"] forKey:@"KeyValue"];
                                   
                                   if([moduleID isEqualToString:@"2"])
                                   {
                                       
                                       [dic setValue:@"Notified" forKey:@"BlockText"];
                                   }
                                   else if([moduleID isEqualToString:@"0"])
                                   {
                                       [dic setValue:@"Blocked" forKey:@"BlockText"];
                                   }
                                   [dic setValue:uniqueIdentifier forKey:@"DeviceId"];
                                   [dic setValue:RegisterID forKey:@"BlockedUserId"];
                                   NSString *OfferName =[NSString stringWithFormat:@"The selected %@ was blocked", [BlockedItem valueForKey:@"VendorName"]];
                                   NSDictionary *blockeditemResponse =[webService SaveBlockeditem:dic];
                                   if ((blockeditemResponse!=nil)) {
                                       
                                       
                                       MyBlocks *mMyBlocks = [[MyBlocks alloc]initWithNibName:@"MyBlocks" bundle:nil];
                                       [self presentViewController:mMyBlocks animated:YES completion:nil];
                                       
                                       
//                                       UIAlertController * alert=   [UIAlertController
//                                                                     alertControllerWithTitle:@"Blocked"
//                                                                     message:OfferName
//                                                                     preferredStyle:UIAlertControllerStyleAlert];
//                                       
//                                       UIAlertAction* yesButton = [UIAlertAction
//                                                                   actionWithTitle:@"OK"
//                                                                   style:UIAlertActionStyleDefault
//                                                                   handler:^(UIAlertAction * action)
//                                                                   {
//                                                                       //Handel your yes please button action here
//                                                                       [self dismissViewControllerAnimated:alert completion:nil];
//                                                                   }];
//                                       
//                                       [alert addAction:yesButton];
//                                       
//                                       
//                                       [self presentViewController:alert animated:YES completion:nil];
                                   }
                               }
                               else{
                                   UIAlertController * alert=   [UIAlertController
                                                                 alertControllerWithTitle:@"RPRT"
                                                                 message:@"Please Register/Login"
                                                                 preferredStyle:UIAlertControllerStyleAlert];
                                   
                                   UIAlertAction* yesButton = [UIAlertAction
                                                               actionWithTitle:@"OK"
                                                               style:UIAlertActionStyleDefault
                                                               handler:^(UIAlertAction * action)
                                                               {
                                                                   Login * mLogin = [[ Login alloc] initWithNibName:@"Login" bundle:nil];
                                                                   [self presentViewController:mLogin animated:YES completion:nil];
                                                                   
                                                                   //[self dismissViewControllerAnimated:alert completion:nil];
                                                               }];
                                   
                                   UIAlertAction* cancelBtn = [UIAlertAction
                                                               actionWithTitle:@"Cancel"
                                                               style:UIAlertActionStyleDefault
                                                               handler:^(UIAlertAction * action)
                                                               {
                                                                   //Handel your yes please button action here
                                                                   [self dismissViewControllerAnimated:alert completion:nil];
                                                               }];
                                   
                                   
                                   
                                   [alert addAction:yesButton];
                                   [alert addAction:cancelBtn];
                                   
                                   
                                   [self presentViewController:alert animated:YES completion:nil];
                                   
                               }

                               [spinner stopAnimating];
                               
                           });
                       });
    }
    @catch (NSException *exception) {
        
    }
    @finally {
        
    }
    
   
}


-(void)LoadFloatview
{
    @try {
        CGRect floatFrame = CGRectMake(320,500,42,42);
        NSMutableArray *block = [self getMyblocks];
        NSString *blocks = [NSString stringWithFormat:@"My Blocks:%lu",(unsigned long)[block count]];
        FloatBtn = [[VCFloatingActionButton alloc]initWithFrame:floatFrame normalImage:[UIImage imageNamed:@"ic_add"] andPressedImage:[UIImage imageNamed:@"closeic"] withScrollview:opportunityTable];
        
        FloatBtn.layer.cornerRadius = 45/2;
        FloatBtn.imageArray = @[@"myblocks_drw.png",@"ic_add.png",@"sortfloat",@"mapfloat"];
        FloatBtn.labelArray = @[blocks,@"Add",@"Sort",@"Map"];
        FloatBtn.hideWhileScrolling = YES;
        FloatBtn.delegate = self;        
        [self.view addSubview:FloatBtn];
    }
    @catch (NSException *exception) {
        NSLog(@"%@" , exception.description);
    }
    @finally {
        
    }
    
}


-(NSMutableArray*)getMyblocks
{
    if ([mPref valueForKey:@"UserRegisterID"] !=nil) {
        NSMutableArray   *GetBlocks = [[Web_Services GetSharedInstance]GetOpportinityReview:[mPref valueForKey:@"UserRegisterID"] MethodName:@"GetReservedOpportunitiesBYUserRegId"];
        
        return GetBlocks;

    }
    else
    {
        return 0;
    }
   }

#pragma mark - floatMenuDelegate
-(void) didSelectMenuOptionAtIndex:(NSInteger)row
{
    NSLog(@"%ld",(long)row);
    
    NSString *FloadBtsnString =[FloatBtn.labelArray objectAtIndex:row];
    if ([FloadBtsnString isEqualToString:@"Map"]) {
        Map *mMap = [[Map alloc]initWithNibName:@"Map" bundle:nil];
        
        [self presentViewController:mMap animated:YES completion:nil];
    }
    
    else if ([FloadBtsnString isEqualToString:@"Sort"])
    {
        SortAlert=[[CustomIOSAlertView alloc] init];
        
        [SortAlert setContainerView:[self SortDemoView]];
        [SortAlert setButtonTitles:[NSMutableArray arrayWithObjects:@"", nil]];
        
        [SortAlert setDelegate:self];
        
        
        // You may use a Block, rather than a delegate.
        [SortAlert setOnButtonTouchUpInside:^(CustomIOSAlertView *alertView, int buttonIndex) {
            NSLog(@"Block: Button at position %d is clicked on alertView %d.", buttonIndex, (int)[alertView tag]);
            [alertView close];
        }];
        UIView *HeaderView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, 300, 40)];
        
        HeaderView.backgroundColor = [UIColor colorWithRed:0.00 green:0.57 blue:0.92 alpha:1.0];
        
        UILabel *fromLabel = [[UILabel alloc]initWithFrame:CGRectMake(10, 0, 150, 40)];
        fromLabel.text = @" Sort Options";
        fromLabel.font = [UIFont systemFontOfSize:15];
        fromLabel.numberOfLines = 1;
        fromLabel.baselineAdjustment = UIBaselineAdjustmentAlignBaselines;
        fromLabel.adjustsFontSizeToFitWidth = YES;
        
        fromLabel.minimumScaleFactor = 10.0f/12.0f;
        fromLabel.clipsToBounds = YES;
        fromLabel.backgroundColor = [UIColor clearColor];
        fromLabel.textColor = [UIColor whiteColor];
        fromLabel.textAlignment = NSTextAlignmentLeft;
        [HeaderView addSubview:fromLabel];
        
        UIButton *Okbtn = [[UIButton alloc]init];
        [Okbtn setImage:[UIImage imageNamed:@"ic_tick.png"] forState:UIControlStateNormal];
        [Okbtn addTarget:self action:@selector(SortOk:) forControlEvents:UIControlEventTouchUpInside];
        Okbtn.frame = CGRectMake(200, 10, 20, 20);
        [HeaderView addSubview:Okbtn];
        
        
        UIButton *Cancelbtn = [[UIButton alloc]init];
        [Cancelbtn setImage:[UIImage imageNamed:@"ic_close.png"] forState:UIControlStateNormal];
        [Cancelbtn addTarget:self action:@selector(SortCancel:) forControlEvents:UIControlEventTouchUpInside];
        Cancelbtn.frame = CGRectMake(250, 10, 20, 20);
        [HeaderView addSubview:Cancelbtn];
        [SortDemoView addSubview:HeaderView];
        [SortDemoView addSubview:Date];
        [SortDemoView addSubview:Time];
        [SortDemoView addSubview:Distance];
        
        
        [SortAlert setUseMotionEffects:true];
        
        
        [SortAlert show];
        SortAlert.tag = 2;
        
    }
    
    else if ([FloadBtsnString isEqualToString:@"Add"])
    {
               
       
           
              spinner = [[UIActivityIndicatorView alloc]
                         initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
              spinner.frame = CGRectMake(0, 0, 320, 560); // CGPointMake(160, 240);
              spinner.color = [UIColor blueColor];
              spinner.backgroundColor = [UIColor lightTextColor];
              spinner.transform = CGAffineTransformMakeScale(2, 2);
              // spinner.hidesWhenStopped = YES;
              [self.view addSubview:spinner];
              spinner.transform = CGAffineTransformMakeScale(2, 2);
              
              [spinner startAnimating];
              
              // how we stop refresh from freezing the main UI thread
              
              dispatch_async(
                             dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^{
                                 
                                 // back to the main thread for the UI call
                                 dispatch_async(dispatch_get_main_queue(), ^{
                                     [spinner startAnimating];
                                 });
                                 dispatch_async(dispatch_get_main_queue(), ^{
                                     [self GotoPost];

                                     [spinner stopAnimating];
                                     
                                 });
                             });
    }
    
    else if ([FloadBtsnString isEqualToString:@"My Blockes"])
    {
       
        if ([mPref valueForKey:@"UserRegisterID"] !=nil) {
            
            MyBlocks *mMyBlocks = [[MyBlocks alloc]initWithNibName:@"MyBlocks" bundle:nil];
            [self presentViewController:mMyBlocks animated:YES completion:nil];
        }
        else
        {
            Login *mLogin = [[Login alloc]initWithNibName:@"Login" bundle:nil];
            [self presentViewController:mLogin animated:YES completion:nil];
        }
        }
}

-(void)GotoPost
{
    @try {
        NSString *ModuleId =[mPref valueForKey:@"ModuleID"];
        
        if ([ModuleId isEqualToString:@"33"]) {
            Post_Food * mPosting = [[ Post_Food alloc] initWithNibName:@"Post_Food" bundle:nil];
            [self presentViewController:mPosting animated:YES completion:nil];
            
        }
        else if ([ModuleId isEqualToString:@"34"])
        {
            Post_Sales * mPosting = [[ Post_Sales alloc] initWithNibName:@"Post_Sales" bundle:nil];
            [self presentViewController:mPosting animated:YES completion:nil];
        }
        else if ([ModuleId isEqualToString:@"37"])
        {
            Post_Professional * mPosting = [[ Post_Professional alloc] initWithNibName:@"Post_Professional" bundle:nil];
            [self presentViewController:mPosting animated:YES completion:nil];
        }
        else if ([ModuleId isEqualToString:@"38"])
        {
            Post_Sports * mPosting = [[ Post_Sports alloc] initWithNibName:@"Post_Sports" bundle:nil];
            [self presentViewController:mPosting animated:YES completion:nil];
        }
        else if ([ModuleId isEqualToString:@"36"])
        {
            Post_Jobs * mPosting = [[ Post_Jobs alloc] initWithNibName:@"Post_Jobs" bundle:nil];
            [self presentViewController:mPosting animated:YES completion:nil];
        }
        else if ([ModuleId isEqualToString:@"39"])
        {
            Post_Meetings * mPosting = [[ Post_Meetings alloc] initWithNibName:@"Post_Meetings" bundle:nil];
            [self presentViewController:mPosting animated:YES completion:nil];
        }
        else
        {
            Login * mLogin= [[ Login alloc] initWithNibName:@"Login" bundle:nil];
            [self presentViewController:mLogin animated:YES completion:nil];
        }
    }
    @catch (NSException *exception) {
        
    }
    @finally {
        
    }
}

- (UIView *)SortDemoView
{
    SortDemoView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 300, 200)];
    
    Date = [UIButton buttonWithType:UIButtonTypeCustom];
    Time = [UIButton buttonWithType:UIButtonTypeCustom];
    Distance = [UIButton buttonWithType:UIButtonTypeCustom];
    Date.frame = CGRectMake(200, 75, 17, 17);
    Time.frame = CGRectMake(200, 115, 17, 17);
    Distance.frame = CGRectMake(200, 150, 17, 17);
    //Distance
    
    UILabel *SortByDistance = [[UILabel alloc]initWithFrame:CGRectMake(30, 150, 150, 17)];
    SortByDistance.text = @"Distance";
    SortByDistance.backgroundColor = [UIColor clearColor];
    SortByDistance.textColor = [UIColor orangeColor];
    [SortDemoView addSubview:SortByDistance];
    
    UILabel *SortBytime = [[UILabel alloc]initWithFrame:CGRectMake(30, 115, 100, 17)];
    SortBytime.text = @"Time";
    SortBytime.backgroundColor = [UIColor clearColor];
    SortBytime.textColor = [UIColor orangeColor];
    [SortDemoView addSubview:SortBytime];
    
    UILabel *SortbyDate = [[UILabel alloc]initWithFrame:CGRectMake(30, 75, 100, 17)];
    SortbyDate.text = @"Date";
    SortbyDate.backgroundColor = [UIColor clearColor];
    SortbyDate.textColor = [UIColor orangeColor];
    [SortDemoView addSubview:SortbyDate];
   
    if([AlertString isEqualToString:@"Date"])
    {
        
        [Date setImage:[UIImage imageNamed:@"RadioButton-Selected.png"] forState:UIControlStateNormal];
        [Time setImage:[UIImage imageNamed:@"RadioButton-Unselected.png"] forState:UIControlStateNormal];
        [Distance setImage:[UIImage imageNamed:@"RadioButton-Unselected.png"] forState:UIControlStateNormal];
        
    }
    else if([AlertString isEqualToString:@"Time"])
    {
        
        
        [Time setImage:[UIImage imageNamed:@"RadioButton-Selected.png"] forState:UIControlStateNormal];
        [Date setImage:[UIImage imageNamed:@"RadioButton-Unselected.png"] forState:UIControlStateNormal];
        [Distance setImage:[UIImage imageNamed:@"RadioButton-Unselected.png"] forState:UIControlStateNormal];
        
        
    }
    
    else if([AlertString isEqualToString:@"Distance"])
    {
        
        
        [Distance setImage:[UIImage imageNamed:@"RadioButton-Selected.png"] forState:UIControlStateNormal];
        [Date setImage:[UIImage imageNamed:@"RadioButton-Unselected.png"] forState:UIControlStateNormal];
        [Time setImage:[UIImage imageNamed:@"RadioButton-Unselected.png"] forState:UIControlStateNormal];
    }
    
    
    
    [Date addTarget:self action:@selector(Date:) forControlEvents:UIControlEventTouchUpInside];
    [Distance addTarget:self action:@selector(Distance:) forControlEvents:UIControlEventTouchUpInside];
    [Time addTarget:self action:@selector(Time:) forControlEvents:UIControlEventTouchUpInside];
    [SortDemoView addSubview:Date];
    [SortDemoView addSubview:Time];
    [SortDemoView addSubview:Distance];
    return SortDemoView;
}

-(void)SortOk:(UIButton*)sender
{
   // NSMutableArray  *GetallOffer = [[DataBase GetSharedInstance]SelectAllOpportunityByDate];
    
    [SortAlert close];
}
-(void)SortCancel:(UIButton*)sender
{
     [SortAlert close];
}

-(void)Date:(UIButton*)sender
{
    [Date setImage:[UIImage imageNamed:@"RadioButton-Selected.png"] forState:UIControlStateNormal];
   [Time setImage:[UIImage imageNamed:@"RadioButton-Unselected.png"] forState:UIControlStateNormal];
    [Distance setImage:[UIImage imageNamed:@"RadioButton-Unselected.png"] forState:UIControlStateNormal];
    AlertString = @"Date";
    [opportunityTable reloadData];
}
-(void)Time:(UIButton*)sender
{
    [Time setImage:[UIImage imageNamed:@"RadioButton-Selected.png"] forState:UIControlStateNormal];
    [Date setImage:[UIImage imageNamed:@"RadioButton-Unselected.png"] forState:UIControlStateNormal];
    [Distance setImage:[UIImage imageNamed:@"RadioButton-Unselected.png"] forState:UIControlStateNormal];
    AlertString = @"Time";
    [opportunityTable reloadData];
}
-(void)Distance:(UIButton*)sender
{
    [Distance setImage:[UIImage imageNamed:@"RadioButton-Selected.png"] forState:UIControlStateNormal];
    [Time setImage:[UIImage imageNamed:@"RadioButton-Unselected.png"] forState:UIControlStateNormal];
    [Date setImage:[UIImage imageNamed:@"RadioButton-Unselected.png"] forState:UIControlStateNormal];
    AlertString = @"Distance";
    [opportunityTable reloadData];
}



#pragma mark - � CLLocationManagerDelegate Method


- (void)loadView {
    [super loadView];
    
    UITapGestureRecognizer *radious = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(testone:)];
   [Radious addGestureRecognizer:radious];
    
    
    
}




- (void) K500:(id) sender {
    [self StoreRadios:@"500"];
}
- (void) K1000:(id) sender {
    [self StoreRadios:@"1000"];
}

- (void) K2000:(id) sender {
    [self StoreRadios:@"2000"];
}

- (void) K3000:(id) sender {
    [self StoreRadios:@"3000"];
}
- (void) K5000:(id) sender {
    [self StoreRadios:@"5000"];
}


- (BOOL) canPerformAction:(SEL)selector withSender:(id) sender
{
 
    
    if (selector == @selector(copy:))
    {
        return NO;
    }
    return NO;
}
- (BOOL) canBecomeFirstResponder {
    return YES;
}


-(void)StoreRadios:(NSString*)radious {
    @try {
        
        [Radious setTitle:radious forState:UIControlStateNormal];
        [[Preferences GetSharedInstance]StoreRadious:radious];
        
    }
    @catch (NSException *exception) {
       NSLog(@"%@" , exception.description);
    }
    @finally {
        
    }
}


@end
