//
//  OpportunityCell.h
//  RPRT
//
//  Created by sravanthi Gumma on 09/02/16.
//  Copyright © 2016 DevpointSolutions. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface OpportunityCell : UITableViewCell
@property (nonatomic,weak)IBOutlet UILabel *opportunity;
@property (nonatomic,weak) IBOutlet UILabel *description;
@property (nonatomic,weak) IBOutlet UIView *view1;
@property (nonatomic,weak) IBOutlet UIView *view2;
@property (weak, nonatomic) IBOutlet UILabel *Location;
@property (weak, nonatomic) IBOutlet UILabel *Timer;
@property (weak, nonatomic) IBOutlet UILabel *Avialable;
@property (weak, nonatomic) IBOutlet UILabel *categoryType;
@property (weak, nonatomic) IBOutlet UILabel *offerPostBy;
@property (weak, nonatomic) IBOutlet UILabel *Price;



@property (weak, nonatomic) IBOutlet UILabel *deliverylabel;
@property (weak, nonatomic) IBOutlet UILabel *priceLabel;


@property (weak,nonatomic) IBOutlet UIButton *blockBtn;

@property (weak, nonatomic) IBOutlet UIImageView *OpportunityImage
;
@property(weak,nonatomic) IBOutlet UIButton *shareBtn;
@property(weak,nonatomic) IBOutlet UIButton *spamBtn;
@end
