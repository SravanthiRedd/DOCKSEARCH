//
//  Opportunity_Cardcell.h
//  RPRT
//
//  Created by sravanthi Gumma on 14/04/16.
//  Copyright © 2016 DevpointSolutions. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Opportunity_Cardcell : UITableViewCell
@property (nonatomic,weak)IBOutlet UILabel *opportunity;
@property (nonatomic,weak) IBOutlet UILabel *description;
@property (nonatomic,weak) IBOutlet UIView *cardview;
@property (nonatomic,weak) IBOutlet UIView *view2;
@property (weak, nonatomic) IBOutlet UILabel *Location;
@property (weak, nonatomic) IBOutlet UILabel *Distance;
@property (weak, nonatomic) IBOutlet UILabel *Timer;
@property (weak, nonatomic) IBOutlet UILabel *Avialable;
@property (weak, nonatomic) IBOutlet UIImageView *OpportunityImage;
@end
