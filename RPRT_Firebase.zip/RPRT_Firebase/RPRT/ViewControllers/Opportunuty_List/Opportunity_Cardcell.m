//
//  Opportunity_Cardcell.m
//  RPRT
//
//  Created by sravanthi Gumma on 14/04/16.
//  Copyright © 2016 DevpointSolutions. All rights reserved.
//

#import "Opportunity_Cardcell.h"

@implementation Opportunity_Cardcell
@synthesize opportunity = opprtunity;
@synthesize description = description;
@synthesize cardview = cardview;
@synthesize view2 = view2;
@synthesize Avialable = Avialable;
- (void)awakeFromNib {
    [super awakeFromNib];
    
    
    // Initialization code
}

-(void)layoutSubviews
{
    [self cardSetup];
   // [self imageSetup];
}
-(void)cardSetup
{
    [cardview setAlpha:1];
    cardview.layer.masksToBounds = NO;
    cardview.layer.cornerRadius = 1; // if you like rounded corners
    cardview.layer.shadowOffset = CGSizeMake(-.2f, .2f); //%%% this shadow will hang slightly down and to the right
    cardview.layer.shadowRadius = 1; //%%% I prefer thinner, subtler shadows, but you can play with this
    cardview.layer.shadowOpacity = 0.2; //%%% same thing with this, subtle is better for me
    
    //%%% This is a little hard to explain, but basically, it lowers the performance required to build shadows.  If you don't use this, it will lag
    UIBezierPath *path = [UIBezierPath bezierPathWithRect:cardview.bounds];
   cardview.layer.shadowPath = path.CGPath;
    
    self.backgroundColor = [UIColor colorWithRed:.9 green:.9 blue:.9 alpha:1]; //%%% I prefer choosing colors programmatically than on the storyboard
}


- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
