//
//  Opportunity_List_New.h
//  RPRT
//
//  Created by sravanthi Gumma on 04/04/16.
//  Copyright © 2016 DevpointSolutions. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MainViewController.h"
#import "VCFloatingActionButton.h"
#import "DLStarRatingControl.h"
#import "CustomIOSAlertView.h"
#import "OpportunityCell.h"
#import "Food_Sale_Cell.h"
#import "Travel_cell.h"

#import "Opportunity_DeatilsController.h"
#import "Details_FoodAndSales.h"
#import "Details_Events_Help_Banking.h"
#import "Details_Travels.h"
#import "Details_RealEstate.h"
#import "Details_GameandJobs.h"

#import "Map.h"
#import "MyBlocks.h"
#import "NearBy_Users.h"

@interface Opportunity_List_New : UIViewController<floatMenuDelegate,UITableViewDelegate,UITableViewDataSource,DLStarRatingDelegate,UITextFieldDelegate,CustomIOSAlertViewDelegate,UISearchBarDelegate>
{
    UIButton  *liveBtn;
    UIButton  *upcomingBtn;
    UIButton  *expiredBtn;
    UIButton *liveTapped;
    UIButton *upcomingTapped;
    UIButton *expiredTapped;
}

//+(Opportunity_List_New *)GetSharedInstance;
@property(nonatomic,retain) NSTimer *timer1;
@property (nonatomic,strong) IBOutlet UITableView *opportunityTable;
@property (weak, nonatomic) IBOutlet UIButton *Radious;
@property (weak,nonatomic) IBOutlet UIView *checkview;
@property (weak,nonatomic) IBOutlet UIView *seachView;
@property (weak, nonatomic) IBOutlet UIImageView *CatImage;
@property (nonatomic, strong) IBOutlet UIButton *leftButton;
@property (nonatomic, weak) IBOutlet UIButton *myActivity;
@property (nonatomic, strong) IBOutlet UIButton *floatBtnFrame;
@property (weak,nonatomic)IBOutlet UIButton *Settings;
@property(weak,nonatomic)IBOutlet UITextField *searchText;
-(void)LoadCheckBoxs;
@property(weak,nonatomic) IBOutlet UIView *toolBarView;
@property(weak,nonatomic) IBOutlet UILabel *toolbarLbl;
@property(weak,nonatomic) IBOutlet UILabel *availbleStatus;
@property(weak,nonatomic) IBOutlet UILabel *availbleStatus1;
@property(weak,nonatomic) IBOutlet UILabel *availbleStatus2;
@property(weak,nonatomic) IBOutlet UILabel *soryString;
@property(weak,nonatomic) IBOutlet UILabel *ulString;
@property(weak,nonatomic) IBOutlet UILabel *grtDayString;
@property(weak,nonatomic) IBOutlet UILabel *howitsWorkLbl;
@property(weak,nonatomic) IBOutlet UILabel *postLabel;

@property(weak,nonatomic) IBOutlet UIImageView *catImage1;
@property(weak,nonatomic) IBOutlet UIImageView *catImage2;
@property(weak,nonatomic) IBOutlet UIImageView *catImage3;

@property(weak,nonatomic) IBOutlet UIView *customView;
//@property(weak)

-(IBAction)map:(id)sender;
-(IBAction)floatButton:(id)sender;
-(IBAction)myActivity:(id)sender;

@property (strong,nonatomic) IBOutlet UIView *availableStatusView;
//
//-(void) slideShowHideMenu;
@end
