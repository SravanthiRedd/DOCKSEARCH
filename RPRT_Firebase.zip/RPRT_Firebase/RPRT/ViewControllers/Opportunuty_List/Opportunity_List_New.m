//
//  Opportunity_List_New.m
//  RPRT
//
//  Created by sravanthi Gumma on 04/04/16.
//  Copyright © 2016 DevpointSolutions. All rights reserved.
//

#import "Opportunity_List_New.h"
#import "UIImage+Color.h"
#import "TimeCalculator.h"
#import "UIImage+MDQRCode.h"
#import "Details_Health.h"
#import <MessageUI/MessageUI.h>
#import "PopUpViewController.h"


//#define CURRENCY_SYMBOL [[NSLocale currentLocale] objectForKey:NSLocaleCurrencySymbol]



@interface Opportunity_List_New ()<UIAlertViewDelegate,MFMailComposeViewControllerDelegate,MFMessageComposeViewControllerDelegate>
{
    NSString *SlideMenuTag;
    NSString *taglabel;
    CustomIOSAlertView *SortAlert;
    Web_Services *webService;
    NSMutableArray *GetOffers;
    CurrentLocation *mLocation;
    NSString *moduleID;
    UIView *SortDemoView;
    UIButton *Date;
    UIButton*Time;
    UIButton *Distance;
    NSString *AlertString;
    MZTimerLabel *TimeCoutDown;
    NSUserDefaults *mPref;
    UIActivityIndicatorView *spinner;
    Web_Services *mWebService;
    NSDictionary *getOpportutnity;
    NSMutableArray *livearry;
    NSMutableArray *upcomingarry;
    NSMutableArray *expiredarray;
    NSDictionary *GetAllOpp;
    GeoCodeLocation *geoCode;
    UITableView *autoComplete;
    NSMutableArray *autocompleteUrls;
    CLLocationCoordinate2D center;
    NSString *seachlatlong;
    UILabel *lbl;
    CustomIOSAlertView *ImageAlert;
    TimeCalculator *mTimecalculator ;
  
    UIColor *catColour;
    NSString *category;
    UITableView *table;
    NSArray * radiousArray;
    UIButton *searchBtn;
    NSMutableArray *opporArray;
    BOOL isSearching;
    NSMutableArray *opportunityArray;
    UISearchBar *search;
    NSString *Key;
    //NetworkStatus networkStatus;
    
    
    NSString *notifyIcon;
    NSString *blockIcon;
    NSString *stopIcon;
    NSString *claimIcon;
    NSString *notifedIcon;
    Preferences *mTimePreference;NSString *NotifiedOpportunityId;
    NSString *CURRENCY_SYMBOL;
    
    
}
@property (strong, nonatomic) PopUpViewController *popViewController;
@property (strong, nonatomic)  VCFloatingActionButton *FloatBtn;
@property (weak, nonatomic) IBOutlet UIView *Contentview;
@property (weak, nonatomic) IBOutlet UIScrollView *scrollview;

@end

@implementation Opportunity_List_New
static Opportunity_List_New *OppShareInstance = nil;


@synthesize opportunityTable,Settings,Radious,searchText,checkview,seachView,CatImage,toolBarView,toolbarLbl,availbleStatus,timer1,availableStatusView,ulString,grtDayString,soryString;

@synthesize scrollview,Contentview,myActivity;

double timerInterval1 = 30;

//double timerInterval1 = 30;

- (NSTimer *) timer {
    if (!timer1) {
        timer1 = [NSTimer timerWithTimeInterval:timerInterval1 target:self selector:@selector(onTick1:) userInfo:nil repeats:YES];
    }
    return timer1;
}
-(void)onTick1:(NSTimer*)timer
{
    //NSLog(@"Tick Tick......");
    @try {
        [self updateopportunityTableview];
        [self LoadCheckBoxs];
    } @catch (NSException *exception) {
        
    } @finally {
        
    }
}



- (void)viewDidLoad {
    
    @try {
        
        
        [super viewDidLoad];
        
        
//        NSLocale *theLocale = [NSLocale currentLocale];
//        NSString *currencySymbol = [theLocale objectForKey:NSLocaleCurrencySymbol];
//        NSLog(@"Currency Symbol : %@",currencySymbol);
//        NSString *currencyCode = [theLocale objectForKey:NSLocaleCurrencyCode];
//        NSLog(@"Currency Code : %@",currencyCode);
        
       
       // NSString *currencyCode = [locale objectForKey: NSLocaleCurrencyCode];
        
        
//        NSString *currencyLocaleLanguage= [NSLocale canonicalLanguageIdentifierFromString: [codeForCountryDictionary objectForKey:@"India"]];
//        NSString *countryLanguage= [NSString stringWithFormat: @"%@_%@", [codeForCountryDictionary objectForKey:@"India"], currencyLocaleLanguage];
//        NSLocale *currencyLocale = [[NSLocale alloc] initWithLocaleIdentifier: countryLanguage];
//
//        
//
//        NSString *localeId = @"JPY"; //[[NSLocale commonISOCurrencyCodes] objectAtIndex:1];
//        NSLocale *locale = [NSLocale currentLocale];
//        NSString *currency = [locale displayNameForKey:NSLocaleCurrencySymbol
//                                                 value:[codeForCountryDictionary objectForKey:@"India"]];
//        NSLog(@"locale %@ currency %@", localeId, currency);
        
        
        
       // NSLog(@"%@ %.2f",CURRENCY_SYMBOL,25.50);
        
        
        // [[NSRunLoop mainRunLoop] addTimer:self.timer1 forMode:NSRunLoopCommonModes];
        //    Reachability *networkReachability = [Reachability reachabilityForInternetConnection];
        //  networkStatus = [networkReachability currentReachabilityStatus];
        
        CURRENCY_SYMBOL = @"";
        
        NotifiedOpportunityId = @"";
        mWebService = [Web_Services GetSharedInstance];
        mPref = [NSUserDefaults standardUserDefaults];
        CurrentLocation *location; CLLocationCoordinate2D *crentLoc;
        location = [CurrentLocation alloc];
        mTimecalculator =[TimeCalculator GetSharedInstance];
        geoCode = [GeoCodeLocation GetSharedInstance];
        mTimePreference= [Preferences GetSharedInstance];
        [self LoadCheckBoxs];
        
        if ([mPref valueForKey:@"StoredAddress"]) {
            //[mPref setValue:selectedAdress forKey:@"StoredAddress"];
            center   =  [[CurrentLocation GetSharedInstance]getLocationFromAddressString:[mPref valueForKey:@"StoredAddress"]];
            
            geoCode = [location geoCodeArea:&center.latitude Longitude:&center.longitude];
            
            
            //geoCodeArea:(double*)Lat Longitude :(double*)Log
            
            searchText.text =[mPref valueForKey:@"StoredAddress"];
        }
        else
        {
            
            crentLoc = [location getCurrentLatLog];
           
            CurrentLocation *LatLog;
            if(![mPref objectForKey:@"SaveUserID"])
            {
                LatLog = [CurrentLocation alloc];
                geoCode = [LatLog getCurrentLocation:crentLoc];
               
            }
            else{
                geoCode = [location getCurrentLocation:crentLoc];
               
            }
            
            if (geoCode!=nil) {
                searchText.text = [NSString stringWithFormat:@"%@,%@,%@,%@",geoCode.Address1,geoCode.Address2,geoCode.Address3,geoCode.AreaName];
                
            }
            
        }
        
        GetOffers = [[NSMutableArray alloc]init];
        opportunityTable.backgroundColor = [UIColor clearColor];
        opportunityTable.opaque = NO;
        
        
        [self updateopportunityTableview];
        [self loadTableview];
        [self loadHelpsection];
        // [self LoadCheckBoxs];
        
        [self LoadFloatview];
        
        
        
        
        
        
        
        
        //    CALayer *borderTypeCat = [CALayer layer];
        //
        //    borderTypeCat.borderColor = [UIColor lightGrayColor].CGColor;
        //
        //    borderTypeCat.frame = CGRectMake(0, Radious.frame.size.height - 1, Radious.frame.size.width, Radious.frame.size.height);
        //    borderTypeCat.borderWidth = 1;
        //    [Radious.layer addSublayer:borderTypeCat];
        //    Radious.layer.masksToBounds = YES;
        
        
        
        searchText.layer.borderColor = [UIColor colorWithRed:237.0/256.0 green:237.0/256.0 blue:237.0/256.0 alpha:1].CGColor;//.CGColor;
        searchText.layer.borderWidth = 1;
        seachlatlong =[NSString stringWithFormat:@"%@,%@",geoCode.Latitude,geoCode.Longitude];
        
        
        [self RadiousBtnTitle];
        
        
        UITapGestureRecognizer *tapGestureRecognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(labelTapped)];
        tapGestureRecognizer.numberOfTapsRequired = 1;
        [toolbarLbl addGestureRecognizer:tapGestureRecognizer];
        toolbarLbl.userInteractionEnabled = YES;
        
        NSString *path = [[NSBundle mainBundle] pathForResource:CATEGORY ofType:@"plist"];
        NSMutableDictionary *dict = [NSMutableDictionary dictionaryWithContentsOfFile:path];
        radiousArray = [[NSArray alloc] init];
        
        radiousArray= [dict valueForKey:@"Radious"];
        
        // availbleStatus.hidden=YES;
        
        
    }
    @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
    
    
    // Do any additional setup after loading the view from its nib.
}

-(void)loadHelpsection
{
    UIGraphicsBeginImageContext(self.view.frame.size);
    [[UIImage imageNamed:@"bgerror.png"] drawInRect:self.view.bounds];
    //UIImage *image = UIGraphicsGetImageFromCurrentImageContext();
    
    
    UIImage *backgroundImage = [[UIImage imageNamed:@"bgerror.png"]
                                stretchableImageWithLeftCapWidth:1 topCapHeight:0];
    
    
    CGRect rect = CGRectMake(0, 0, backgroundImage.size.width, backgroundImage.size.height);
    UIGraphicsBeginImageContext(rect.size);
    CGContextRef context = UIGraphicsGetCurrentContext();
    CGContextClipToMask(context, rect, backgroundImage.CGImage);
    CGContextSetFillColorWithColor(context, [[UIColor whiteColor] CGColor]);
    CGContextFillRect(context, rect);
    UIImage *img = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    UIImage *flippedImage = [UIImage imageWithCGImage:img.CGImage
                                                scale:1.0 orientation: UIImageOrientationDownMirrored];
    
    
    
    UIGraphicsEndImageContext();
    // [theImageView setTintColor:[UIColor redColor]];
    self.view.backgroundColor = [UIColor colorWithPatternImage:flippedImage];
    
}
-(void)LoadCheckBoxs
{
    @try {
        
        
        // [[NSUserDefaults standardUserDefaults] setObject:colorData forKey:@"myColor"];
        
        category =[mPref valueForKey:CATEGORY];
        
        
        self.customView.layer.shadowColor = [UIColor lightGrayColor].CGColor;
        self.customView.layer.shadowOffset = CGSizeMake(0, 4);
        self.customView.layer.shadowOpacity = 1;
        self.customView.layer.shadowRadius = 1.0;
        
        if([mPref valueForKey:USERREGISTERID])
        {
            [myActivity setHidden:NO];
        }
        else [myActivity setHidden:YES];
        
        NSMutableAttributedString *text = [self.howitsWorkLbl.attributedText mutableCopy];
        [text addAttribute:NSUnderlineStyleAttributeName value:@(NSUnderlineStyleSingle) range:NSMakeRange(0, text.length)];
        self.howitsWorkLbl.attributedText = text;
        
        
        
        
        
        
        
//http://gladiatorapps.com/?p=91
        
        
        notifyIcon = @"intrested.png";
        blockIcon = @"list_reserve.png";
        stopIcon= @"list_cancelbtn.png";
        claimIcon= @"list_claim.png";
        notifedIcon= @"list_notified.png";
        
        
        if([category isEqualToString:FOOD])
        {
            //list_cancelbtn.png
            //        list_notify.png
            //        list_reserve.png
            
            
            [self.floatBtnFrame setImage:[UIImage imageNamed:@"food_float.png"] forState:UIControlStateNormal];
          
            
                    if ([[mPref valueForKey:LOGINTYPE] isEqualToString:@"Business"]) {
                        self.floatBtnFrame.hidden=NO;
                    }
                    else if ([[mPref valueForKey:LOGINTYPE] isEqualToString:@"Individual"]) {
                        self.floatBtnFrame.hidden=YES;
                    }

            
            
            
            
            
            catColour = [UIColor colorWithRed:204.0/256.0 green:40.0/256.0 blue:63.0/256.0 alpha:1];
            NSData *colorData = [NSKeyedArchiver archivedDataWithRootObject:catColour];
            [mPref setObject:colorData forKey:@"COLOR"];
            
            CatImage.image = [UIImage imageNamed:@"food_lbk.png"];
            toolbarLbl.text =@"Food";
            
            soryString.text = @"Sorry!! No Opportunities are going on now.";
            ulString.text = @"No more wastage of food";
            self.availbleStatus.text = @"Restaurants can post a 15 mins Opportunities before closing the store.";
            self.availbleStatus1.text = @"You will be notified about it if you are near by";
            self.availbleStatus2.text = @"Block the Opportunities and redeem at the store.";
            
            grtDayString.text = @"Bon apetit!!";
            self.catImage1.image = [UIImage imageNamed:@"food_lst.png"];
            self.catImage2.image = [UIImage imageNamed:@"food_lst.png"];
            self.catImage3.image = [UIImage imageNamed:@"food_lst.png"];
            
        }
        else if ([category isEqualToString:JOBS])
        {
            [self.floatBtnFrame setImage:[UIImage imageNamed:@"job_float.png"] forState:UIControlStateNormal];
           
            if ([[mPref valueForKey:LOGINTYPE] isEqualToString:@"Business"]) {
                self.floatBtnFrame.hidden=NO;
            }
            else if ([[mPref valueForKey:LOGINTYPE] isEqualToString:@"Individual"]) {
                self.floatBtnFrame.hidden=YES;
            }
            

            
            catColour = [UIColor colorWithRed:63.0/256.0 green:107.0/256.0 blue:178.0/256.0 alpha:1];
            NSData *colorData = [NSKeyedArchiver archivedDataWithRootObject:catColour];
            [mPref setObject:colorData forKey:@"Color"];
            CatImage.image = [UIImage imageNamed:@"jobs_blk.png"];
            toolbarLbl.text =@"Jobs";
            
            
            soryString.text = @"Sorry!! No job requests now.";
            ulString.text = @"Lists the jobs near by";
            self.availbleStatus.text = @"Employers can post an job vacancy to get near by talent";
            self.availbleStatus1.text = @"You will be notified about it if you are near by and Block the job and attend the interview";
            self.availbleStatus2.text = @"Employers can get their position filled instantly must have for part time job seekers";
            
            grtDayString.text = @"Hope you find a great job :)";
            
            grtDayString.textColor =catColour;
            self.catImage1.image = [UIImage imageNamed:@"jobs_lst.png"];
            self.catImage2.image = [UIImage imageNamed:@"jobs_lst.png"];
            self.catImage3.image = [UIImage imageNamed:@"jobs_lst.png"];
            
            
            
        }
        else if([category isEqualToString:MEETINGS])
        {
            [self.floatBtnFrame setImage:[UIImage imageNamed:@"events_events.png"] forState:UIControlStateNormal];
          
           
            
            catColour = [UIColor colorWithRed:212.0/256.0 green:37.0/256.0 blue:122.0/256.0 alpha:1];
            NSData *colorData = [NSKeyedArchiver archivedDataWithRootObject:catColour];
            [mPref setObject:colorData forKey:@"Color"];
            CatImage.image =[UIImage imageNamed:@"events_blk.png"];
            toolbarLbl.text =@"Events & Entertainment";
            
            soryString.text = @"Sorry!! No events near by now.";
            ulString.text = @"Join an event";
            self.availbleStatus.text = @"Events like Parties, Seminars, Debates, Discussions etc... can be posted.";
            self.availbleStatus1.text = @"You will be notified about it if you are near by";
            self.availbleStatus2.text = @"Block the event and talk to organizer";
            
            grtDayString.text = @"Have a good time :)";
            
            grtDayString.textColor = catColour;
            
            self.catImage1.image = [UIImage imageNamed:@"events_hlp.png"];
            self.catImage2.image = [UIImage imageNamed:@"events_hlp.png"];
            self.catImage3.image = [UIImage imageNamed:@"events_hlp.png"];
            
        }
        else if([category isEqualToString:PROFESSIONALHELP])
        {
             [self.floatBtnFrame setImage:[UIImage imageNamed:@"ExpertHelp_float.png"] forState:UIControlStateNormal];
            
            
            
            catColour = [UIColor colorWithRed:61.0/256.0 green:72.0/256.0 blue:202.0/256.0 alpha:1];
            NSData *colorData = [NSKeyedArchiver archivedDataWithRootObject:catColour];
            [mPref setObject:colorData forKey:@"Color"];
            CatImage.image = [UIImage imageNamed:@"professionalhelp_blk.png"];
            toolbarLbl.text =@"Expert Help";
            
            soryString.text = @"Sorry!! No activities now.";
            ulString.text = @"Get helped";
            self.availbleStatus.text = @"If you are looking for professionals like Plumber, Electrician, professionals at your door step";
            self.availbleStatus1.text = @"Then post a 30mins deal near by professionals will be notified about it";
            self.availbleStatus2.text = @"Professionals will block and get connected to you";
            
            grtDayString.text = @"Hope your problem is fixed :)";
            
            grtDayString.textColor = catColour;
            self.catImage1.image = [UIImage imageNamed:@"professionalhelp_hlp.png"];
            self.catImage2.image = [UIImage imageNamed:@"professionalhelp_hlp.png"];
            self.catImage3.image = [UIImage imageNamed:@"professionalhelp_hlp.png"];
            
            
        }
        else if([category isEqualToString:SALES])
        {
              [self.floatBtnFrame setImage:[UIImage imageNamed:@"sales_float.png"] forState:UIControlStateNormal];
            
            if ([[mPref valueForKey:LOGINTYPE] isEqualToString:@"Business"]) {
                self.floatBtnFrame.hidden=NO;
            }
            else if ([[mPref valueForKey:LOGINTYPE] isEqualToString:@"Individual"]) {
                self.floatBtnFrame.hidden=YES;
            }
            

            
            
            catColour =[UIColor colorWithRed:194.0/256.0 green:166.0/256.0 blue:33.0/256.0 alpha:1];
            NSData *colorData = [NSKeyedArchiver archivedDataWithRootObject:catColour];
            [mPref setObject:colorData forKey:@"Color"];
            
            CatImage.image = [UIImage imageNamed:@"sales_blk.png"];
            toolbarLbl.text =@"Sales";
            
            
            soryString.text = @"Sorry!! No Opportunities are going on now.";
            ulString.text = @"Get instant Opportunities near you";
            self.availbleStatus.text = @"Stores can post an 15Mins/30Mins Opportunities to clear the stock";
            self.availbleStatus1.text = @"You will be notified about it if you are near by and Block the Opportunities and redeem at the store";
            self.availbleStatus2.text = @"Stores can clear the stock at lightning speed";
            
            grtDayString.text = @"Happy Shopping!!";
            
            grtDayString.textColor = catColour;
            self.catImage1.image = [UIImage imageNamed:@"sales_lst.png"];
            self.catImage2.image = [UIImage imageNamed:@"sales_lst.png"];
            self.catImage3.image = [UIImage imageNamed:@"sales_lst.png"];
            
        }
        else if([category isEqualToString:SPORTS])
        {
             [self.floatBtnFrame setImage:[UIImage imageNamed:@"sports_float.png"] forState:UIControlStateNormal];
            
            
            
            catColour =[UIColor colorWithRed:0.0/256.0 green:164.0/256.0 blue:186.0/256.0 alpha:1];
            
            NSData *colorData = [NSKeyedArchiver archivedDataWithRootObject:catColour];
            [mPref setObject:colorData forKey:@"Color"];
            
            CatImage.image = [UIImage imageNamed:@"sports_blk.png"];
            toolbarLbl.text =@"Sports";
            
            
            soryString.text = @"Sorry!! No activities now.";
            ulString.text = @"Always Play";
            self.availbleStatus.text = @"If a team is lacking players they can post";
            self.availbleStatus1.text = @"If you want an opponent/companion for your game.Then you can post";
            self.availbleStatus2.text = @"You will be notified about it if you are near by.Block the activity and talk to organizer";
            
            grtDayString.text = @"Stay fit, Enjoy your game :)";
            
            grtDayString.textColor = catColour;
            self.catImage1.image = [UIImage imageNamed:@"sports_hlp.png"];
            self.catImage2.image = [UIImage imageNamed:@"sports_hlp.png"];
            self.catImage3.image = [UIImage imageNamed:@"sports_hlp.png"];
            
            
        }
        
        else if([category isEqualToString:TRAVELS])
        {
             [self.floatBtnFrame setImage:[UIImage imageNamed:@"travel_float.png"] forState:UIControlStateNormal];
            
          
            
            
            catColour =[UIColor colorWithRed:148.0/256.0 green:51.0/256.0 blue:143.0/256.0 alpha:1];
            NSData *colorData = [NSKeyedArchiver archivedDataWithRootObject:catColour];
            [mPref setObject:colorData forKey:@"Color"];
            
            CatImage.image = [UIImage imageNamed:@"travel_blk.png"];
            toolbarLbl.text =@"Travel";
            
            
            
            soryString.text = @"Sorry!! No rides found now.";
            ulString.text = @"Go distances by sharing";
            self.availbleStatus.text = @"Vehicle owners can posts a jouney";
            self.availbleStatus1.text = @"You will be notified about it if you are near by";
            self.availbleStatus2.text = @"Block the ride and talk to owner";
            
            grtDayString.text = @"Have a safe journey :)";
            
            grtDayString.textColor = catColour;
            self.catImage1.image = [UIImage imageNamed:@"travel_hlp.png"];
            self.catImage2.image = [UIImage imageNamed:@"travel_hlp.png"];
            self.catImage3.image = [UIImage imageNamed:@"travel_hlp.png"];
            
        }
        else if([category isEqualToString:REALESTATE])
        {
             [self.floatBtnFrame setImage:[UIImage imageNamed:@"realestate_float.png"] forState:UIControlStateNormal];
         
            
            
            catColour =[UIColor colorWithRed:103.0/256.0 green:58.0/256.0 blue:183.0/256.0 alpha:1];
            
            NSData *colorData = [NSKeyedArchiver archivedDataWithRootObject:catColour];
            [mPref setObject:colorData forKey:@"Color"];
            
            CatImage.image = [UIImage imageNamed:@"realestate_blk.png"];
            toolbarLbl.text =@"Real Estate";
            
            soryString.text = @"Sorry!! No properties found";
            ulString.text = @"Lists the Sale, Rent or Sharing";
            self.availbleStatus.text = @"Prop Owners can Sell/Rent/Share the property";
            self.availbleStatus1.text = @"You will be notified about it if you are near by";
            self.availbleStatus2.text = @"Block the property and talk to owner";
            
            grtDayString.text = @"Hope you buy a good property :)";
            
            grtDayString.textColor = catColour;
            self.catImage1.image = [UIImage imageNamed:@"realestate_lst.png"];
            self.catImage2.image = [UIImage imageNamed:@"realestate_lst.png"];
            self.catImage3.image = [UIImage imageNamed:@"realestate_lst.png"];
            
        }
        
        else if([category isEqualToString:BANKING])
        {
             [self.floatBtnFrame setImage:[UIImage imageNamed:@"banking_float.png"] forState:UIControlStateNormal];
            
           
            
            
            catColour =[UIColor colorWithRed:10.0/256.0 green:131.0/256.0 blue:106.0/256.0 alpha:1];
            
            NSData *colorData = [NSKeyedArchiver archivedDataWithRootObject:catColour];
            [mPref setObject:colorData forKey:@"Color"];
            
            CatImage.image = [UIImage imageNamed:@"banking_lbk.png"];
            toolbarLbl.text =@"Banking & Finance";
            
            soryString.text = @"Sorry!! No activities now.";
            ulString.text = @"$Financial$";
            self.availbleStatus.text = @"If you are looking for an Personal Loan, Forex, Insurance or Investments at your place";
            self.availbleStatus1.text = @"Then post a 30mins deal Near by Professionals will be notified about it";
            self.availbleStatus2.text = @"Professionals will block and get connected to you.";
            
            grtDayString.text = @"Money Honey ;)";
            
            grtDayString.textColor = catColour;
            self.catImage1.image = [UIImage imageNamed:@"banking_hlp.png"];
            self.catImage2.image = [UIImage imageNamed:@"banking_hlp.png"];
            self.catImage3.image = [UIImage imageNamed:@"banking_hlp.png"];
            
        }
        
        else if([category isEqualToString:HEALTH])
        {
            
               [self.floatBtnFrame setImage:[UIImage imageNamed:@"Health_float.png"] forState:UIControlStateNormal];
            
          
           
            
            catColour =[UIColor colorWithRed:104.0/256.0 green:162.0/256.0 blue:44.0/256.0 alpha:1];
            
            NSData *colorData = [NSKeyedArchiver archivedDataWithRootObject:catColour];
            [mPref setObject:colorData forKey:@"Color"];
            
            CatImage.image = [UIImage imageNamed:@"health_lbk.png"];
            toolbarLbl.text =@"Health";
            
            soryString.text = @"Sorry!! No activities now.";
            ulString.text = @"Health is wealth";
            self.availbleStatus.text = @"Health realted Opportunities like check ups, tests or camps can be posted by hospitals";
            self.availbleStatus1.text = @"Hospitals can also post an urgent blood requirement. Users can request for an ambulance.";
            self.availbleStatus2.text = @"Doctors can post their available time slots.The near by users will be notified about it.";
            
            grtDayString.text = @"Take care :)";
            
            grtDayString.textColor = catColour;
            self.catImage1.image = [UIImage imageNamed:@"health_hlp.png"];
            self.catImage2.image = [UIImage imageNamed:@"health_hlp.png"];
            self.catImage3.image = [UIImage imageNamed:@"health_hlp.png"];
            
        }

        [mPref setValue:@"intrested_list.png" forKey:@"Notify"];
        [mPref setValue:@"de_reserve.png" forKey:@"Block"];
        [mPref setValue:@"de_cancel.png" forKey:@"Stop"];
        [mPref setValue:@"de_claim.png" forKey:@"Claim"];
        [mPref setValue:@"de_notified.png" forKey:@"Notified"];
        
        Key = @"Live";
        toolBarView.backgroundColor =catColour;
       liveBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        liveBtn.frame = CGRectMake(50, 10, 100, 25);
        [liveBtn addTarget:self action:@selector(liveBtnClick:) forControlEvents:UIControlEventTouchUpInside];
        UIImage *image = [[UIImage alloc]init];
        image = [UIImage imageNamed:@"check.png"];
        
        
        CGSize siz =CGSizeMake(18, 18);
        image=   [mTimecalculator image:image scaledToSize:siz];
        
        
        image =  [image imageWithTint:toolBarView.backgroundColor];
        
        //    image = [self colorImage:image withColor:toolBarView.backgroundColor];
        //
        
        [liveBtn setImage: image forState:UIControlStateNormal];
        // [liveBtn ]
        [liveBtn setTitleEdgeInsets:UIEdgeInsetsMake(30, 0, 30, -15)];
        [liveBtn setTitle:@"Live" forState:UIControlStateNormal];
        [liveBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        liveBtn.tag = 1;
        
        [checkview addSubview:liveBtn];
        
        
        
        expiredBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        expiredBtn.frame = CGRectMake(135, 10, 150, 25);
        [expiredBtn addTarget:self action:@selector(expiredBtnClick:) forControlEvents:UIControlEventTouchUpInside];
        UIImage *eximg = [[UIImage alloc]init];
        eximg = [UIImage imageNamed:@"uncheck.png"];
        
        CGSize sizex =CGSizeMake(18, 18);
        eximg=   [mTimecalculator image:eximg scaledToSize:sizex];
        [expiredBtn setImage: eximg forState:UIControlStateNormal];
        [expiredBtn setTitleEdgeInsets:UIEdgeInsetsMake(30, 0, 30, -15)];
        [expiredBtn setTitle:@"Expired" forState:UIControlStateNormal];
        [expiredBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        expiredBtn.tag = 0;
        
//        UILabel *lbl_card_count = [[UILabel alloc]initWithFrame:CGRectMake(120           ,0, 18, 18)];
//        lbl_card_count.textColor = [UIColor whiteColor];
//        lbl_card_count.textAlignment = NSTextAlignmentCenter;
//        lbl_card_count.text = [NSString stringWithFormat:@"1"];
//        lbl_card_count.layer.borderWidth = 1;
//        lbl_card_count.layer.cornerRadius = 8;
//        lbl_card_count.layer.masksToBounds = YES;
//        lbl_card_count.layer.borderColor =[[UIColor clearColor] CGColor];
//        lbl_card_count.layer.shadowColor = [[UIColor clearColor] CGColor];
//        lbl_card_count.layer.shadowOffset = CGSizeMake(0.0, 0.0);
//        lbl_card_count.layer.shadowOpacity = 0.0;
//        lbl_card_count.backgroundColor = [UIColor colorWithRed:247.0/255.0 green:45.0/255.0 blue:143.0/255.0 alpha:1.0];
//        lbl_card_count.font = [UIFont fontWithName:@"ArialMT" size:11];
//        [expiredBtn addSubview:lbl_card_count];
        
        
        checkview.layer.cornerRadius = 45/2;
        
        
        checkview.layer.masksToBounds = false;
        checkview.layer.shadowColor = [UIColor blackColor].CGColor;
        checkview.layer.shadowOffset = CGSizeMake(0, 1);
        checkview.layer.shadowOpacity = 0.2;
        checkview.layer.cornerRadius = 5;
        [checkview addSubview:expiredBtn];
        
        
//        searchBtn =[[UIButton alloc]initWithFrame:CGRectMake(expiredBtn.frame.origin.x+expiredBtn.frame.size.width-10, expiredBtn.frame.origin.y, 24, 24)];
//        [searchBtn addTarget:self action:@selector(searchEvent:) forControlEvents:UIControlEventTouchUpInside];
//        [searchBtn setImage:[UIImage imageNamed:@"search_blk.png"] forState:UIControlStateNormal];
//        [checkview addSubview:searchBtn];
        
        seachView.layer.cornerRadius = 45/2;
        
        
        seachView.layer.masksToBounds = false;
        seachView.layer.shadowColor = [UIColor blackColor].CGColor;
        seachView.layer.shadowOffset = CGSizeMake(0, 1);
        seachView.layer.shadowOpacity = 0.2;
        seachView.layer.cornerRadius = 5;
        
        opporArray = [[NSMutableArray alloc]init];
        opportunityArray = [[NSMutableArray alloc]init];
        
        
//        UIButton *nearByBtn =[[UIButton alloc]initWithFrame:CGRectMake(searchBtn.frame.origin.x+searchBtn.frame.size.width+15, searchBtn.frame.origin.y, 24, 24)];
//        [nearByBtn addTarget:self action:@selector(nearByusers:) forControlEvents:UIControlEventTouchUpInside];
//        [nearByBtn setImage:[UIImage imageNamed:@"useric.png"] forState:UIControlStateNormal];
//        [checkview addSubview:nearByBtn];
        
        
        
        
        
        
    }
    @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
    
 }


-(void)loadTableview
{
    self.postLabel.backgroundColor =catColour;
    self.postLabel.textColor = [UIColor whiteColor];
    NSArray *expiredarrayCnt =[GetAllOpp valueForKey:@"ListExpire"];
    
    UILabel *expiredTag = [[UILabel alloc]initWithFrame:CGRectMake(125,0, 18, 18)];
    expiredTag.textColor = [UIColor whiteColor];
    expiredTag.textAlignment = NSTextAlignmentCenter;
    expiredTag.text = [NSString stringWithFormat:@"%ld",(unsigned long)[expiredarrayCnt count]];
    expiredTag.layer.borderWidth = 1;
    expiredTag.layer.cornerRadius = 8;
    expiredTag.layer.masksToBounds = YES;
    expiredTag.layer.borderColor =[[UIColor clearColor] CGColor];
    expiredTag.layer.shadowColor = [[UIColor clearColor] CGColor];
    expiredTag.layer.shadowOffset = CGSizeMake(0.0, 0.0);
    expiredTag.layer.shadowOpacity = 0.0;
    expiredTag.backgroundColor =catColour;// [UIColor colorWithRed:247.0/255.0 green:45.0/255.0 blue:143.0/255.0 alpha:1.0];
    
    expiredTag.font = [UIFont fontWithName:@"ArialMT" size:11];
    if ([expiredarrayCnt count]>0) {
         [expiredBtn addSubview:expiredTag];
    }
    
   
   NSArray *liverrayCnt =[GetAllOpp valueForKey:@"Listongoing"];
    
    UILabel *liveTag = [[UILabel alloc]initWithFrame:CGRectMake(85,0, 18, 18)];
    liveTag.textColor = [UIColor whiteColor];
    liveTag.textAlignment = NSTextAlignmentCenter;
    liveTag.text = [NSString stringWithFormat:@"%ld",(unsigned long)[liverrayCnt count]];
    liveTag.layer.borderWidth = 1;
    liveTag.layer.cornerRadius = 8;
    liveTag.layer.masksToBounds = YES;
    liveTag.layer.borderColor =[[UIColor clearColor] CGColor];
    liveTag.layer.shadowColor = [[UIColor clearColor] CGColor];
    liveTag.layer.shadowOffset = CGSizeMake(0.0, 0.0);
    liveTag.layer.shadowOpacity = 0.0;
    liveTag.backgroundColor =catColour;// [UIColor colorWithRed:247.0/255.0 green:45.0/255.0 blue:143.0/255.0 alpha:1.0];
    liveTag.font = [UIFont fontWithName:@"ArialMT" size:11];
    
    if ([liverrayCnt count]>0) {
       [liveBtn addSubview:liveTag];
    }
    
    if ([mPref valueForKey:@"Notification"]) {
        NotifiedOpportunityId =[NSString stringWithFormat:@"%@",[mPref valueForKey:@"NotificationID"]];
        [mPref setValue:nil forKeyPath:@"Notification"];
        [mPref setValue:nil forKeyPath:@"NotificationID"];
    }
    
    
    Key= [mPref valueForKey:@"Key"];
    if ([Key isEqualToString:@"Live"]) {
        
        livearry = [GetAllOpp valueForKey:@"Listongoing"];
        if ([GetOffers count]>0) {
            for (int i=0; i<[livearry count]; i++) {
                [GetOffers addObject:livearry[i]];
                NSString *offerName = [GetOffers[i] valueForKey:@"OpportunityName"];
                NSString *offerDescription = [GetOffers[i] valueForKey:@"OpportunityDescription"];
                [opporArray addObject:offerName];
                [opporArray addObject:offerDescription];
            }
            opportunityArray = GetOffers;
            
            if (![NotifiedOpportunityId isEqualToString:@""]) {
                [self checkNotifiedObject:NotifiedOpportunityId];
            }
            
            //   availbleStatus.hidden=YES;
            [opportunityTable reloadData];
        }
        else
        {
            for (int i=0; i<[livearry count]; i++) {
                [GetOffers addObject:livearry[i]];
                NSString *offerName = [GetOffers[i] valueForKey:@"OpportunityName"];
                NSString *offerDescription = [GetOffers[i] valueForKey:@"OpportunityDescription"];
                [opporArray addObject:offerName];
                [opporArray addObject:offerDescription];
            }
            opportunityArray = GetOffers;
            if (![NotifiedOpportunityId isEqualToString:@""]) {
                [self checkNotifiedObject:NotifiedOpportunityId];
            }
            //  availbleStatus.hidden=YES;
            [opportunityTable reloadData];
        }
        
        if ([GetOffers count]==0) {
            //availbleStatus.hidden=NO;
            opportunityTable.hidden = YES;
            [opportunityTable reloadData];
            
        }
        else
        {
            
            
        }
    }
    
    else if ([Key isEqualToString:@"Expired"])
    {
        expiredBtn.tag = 1;
        
        [self setButtonimage:expiredBtn];
        
        expiredarray =[GetAllOpp valueForKey:@"ListExpire"];
        if ([GetOffers count]>0) {
            for (int i=0; i<[expiredarray count]; i++) {
                [GetOffers addObject:expiredarray[i]];
                NSString *offerName = [GetOffers[i] valueForKey:@"OpportunityName"];
                 NSString *offerDescription = [GetOffers[i] valueForKey:@"OpportunityDescription"];
                [opporArray addObject:offerName];
                [opporArray addObject:offerDescription];
            }
            opportunityArray = GetOffers;
        }
        else{
            for (int i=0; i<[expiredarray count]; i++) {
                [GetOffers addObject:expiredarray[i]];
                NSString *offerName = [GetOffers[i] valueForKey:@"OpportunityName"];
                NSString *offerDescription = [GetOffers[i] valueForKey:@"OpportunityDescription"];
                [opporArray addObject:offerName];
                [opporArray addObject:offerDescription];
            }
            opportunityArray = GetOffers;
//            if (![NotifiedOpportunityId isEqualToString:@""]) {
//                [self checkNotifiedObject:NotifiedOpportunityId];
//            }
        }
        // availbleStatus.hidden=YES;
        [opportunityTable reloadData];
    }
    
    else if ([Key isEqualToString:@"Live+Expired"])
    {
        liveBtn.tag =0;
        expiredBtn.tag = 0;
        
        
        livearry = [GetAllOpp valueForKey:@"Listongoing"];
        if ([GetOffers count]>0) {
            for (int i=0; i<[livearry count]; i++) {
                [GetOffers addObject:livearry[i]];
                NSString *offerName = [GetOffers[i] valueForKey:@"OpportunityName"];
                NSString *offerDescription = [GetOffers[i] valueForKey:@"OpportunityDescription"];
                [opporArray addObject:offerName];
                [opporArray addObject:offerDescription];
            }
            opportunityArray = GetOffers;
        }
        else
        {
            for (int i=0; i<[livearry count]; i++) {
                [GetOffers addObject:livearry[i]];
                NSString *offerName = [GetOffers[i] valueForKey:@"OpportunityName"];
                NSString *offerDescription = [GetOffers[i] valueForKey:@"OpportunityDescription"];
                [opporArray addObject:offerName];
                [opporArray addObject:offerDescription];
            }
            opportunityArray = GetOffers;
//            if (![NotifiedOpportunityId isEqualToString:@""]) {
//                [self checkNotifiedObject:NotifiedOpportunityId];
//            }
            
        }
        
        expiredarray =[GetAllOpp valueForKey:@"ListExpire"];
        if ([GetOffers count]>0) {
            for (int i=0; i<[expiredarray count]; i++) {
                [GetOffers addObject:expiredarray[i]];
                NSString *offerName = [GetOffers[i] valueForKey:@"OpportunityName"];
                NSString *offerDescription = [GetOffers[i] valueForKey:@"OpportunityDescription"];
                [opporArray addObject:offerName];
                [opporArray addObject:offerDescription];
            }
            opportunityArray = GetOffers;
//            if (![NotifiedOpportunityId isEqualToString:@""]) {
//                [self checkNotifiedObject:NotifiedOpportunityId];
//            }
        }
        else{
            for (int i=0; i<[expiredarray count]; i++) {
                [GetOffers addObject:expiredarray[i]];
                NSString *offerName = [GetOffers[i] valueForKey:@"OpportunityName"];
                NSString *offerDescription = [GetOffers[i] valueForKey:@"OpportunityDescription"];
                [opporArray addObject:offerName];
                [opporArray addObject:offerDescription];
            }
            opportunityArray = GetOffers;
//            if (![NotifiedOpportunityId isEqualToString:@""]) {
//                [self checkNotifiedObject:NotifiedOpportunityId];
//            }
        }
        [self setButtonimage:liveBtn];
        [self setButtonimage:expiredBtn];
        // availbleStatus.hidden=YES;
        
        [opportunityTable reloadData];
        
    }
    else
    {
        livearry = [GetAllOpp valueForKey:@"Listongoing"];
        if ([GetOffers count]>0) {
            for (int i=0; i<[livearry count]; i++) {
                [GetOffers addObject:livearry[i]];
                NSString *offerName = [GetOffers[i] valueForKey:@"OpportunityName"];
                NSString *offerDescription = [GetOffers[i] valueForKey:@"OpportunityDescription"];
                [opporArray addObject:offerName];
                [opporArray addObject:offerDescription];
            }
            opportunityArray = GetOffers;
//            if (![NotifiedOpportunityId isEqualToString:@""]) {
//                [self checkNotifiedObject:NotifiedOpportunityId];
//            }
            // availbleStatus.hidden=YES;
            [opportunityTable reloadData];
        }
        else
        {
            for (int i=0; i<[livearry count]; i++) {
                [GetOffers addObject:livearry[i]];
                NSString *offerName = [GetOffers[i] valueForKey:@"OpportunityName"];
                NSString *offerDescription = [GetOffers[i] valueForKey:@"OpportunityDescription"];
                [opporArray addObject:offerName];
                [opporArray addObject:offerDescription];
            }
            opportunityArray = GetOffers;
//            if (![NotifiedOpportunityId isEqualToString:@""]) {
//                [self checkNotifiedObject:NotifiedOpportunityId];
//            }
        }
        
        if ([GetOffers count]==0) {
            // availbleStatus.hidden=NO;
            opportunityTable.hidden = YES;
            [opportunityTable reloadData];
            
            
        }
        else
        {
            //
        }
        [opportunityTable reloadData];
        
    }
}

-(void)checkNotifiedObject:(NSString*)notifiedID
{
    NSString *key=@"";
    for (int i = 0 ; i < [opportunityArray count ] ; i++) {
        
        NSString *oppId =[NSString stringWithFormat:@"%@",[[opportunityArray objectAtIndex:i] valueForKey:@"OpportunityID"]];
        
        if (![oppId isEqualToString:notifiedID]) {
            key=@"Available";
                    }
          }
    if ([key isEqualToString:@""]) {
       // NSDictionary *obje=[mWebService GetOpportunityByID:notifiedID MethodName:@"GetOpportunityByID"];
        //[GetOffers addObject:obje];
    }
    [opportunityTable reloadData];
    
}


-(void)LoadFloatview
{
    @try {
        
        
        autoComplete = [[UITableView alloc] initWithFrame:
                        CGRectMake(5, searchText.frame.origin.y+180, 325, 200) style:UITableViewStylePlain];
        autoComplete.delegate = self;
        autoComplete.dataSource = self;
        autoComplete.scrollEnabled = YES;
        autoComplete.hidden = YES;
        [self.view addSubview:autoComplete];
        
        
    }
    @catch (NSException *exception) {
        NSLog(@"%@" , exception.description);
    }
    @finally {
        
    }
    
}

- (UIImage *)colorImage:(UIImage *)origImage withColor:(UIColor *)color
{
    @try {
        
        
        UIGraphicsBeginImageContextWithOptions(origImage.size, YES, 0);
        CGContextRef context = UIGraphicsGetCurrentContext();
        
        CGContextSetFillColorWithColor(context, [color CGColor]);
        CGContextFillRect(context, (CGRect){ {0,0}, origImage.size} );
        
        // CGAffineTransform flipVertical = CGAffineTransformMake(1, 0, 0, -1, 0, origImage.size.height);
        //  CGContextConcatCTM(context, flipVertical);
        // CGContextDrawImage(context, (CGRect){ pt, origImage.size }, [origImage CGImage]);
        
        UIImage *image = UIGraphicsGetImageFromCurrentImageContext();
        UIGraphicsEndImageContext();
        
        return image;
    }
    @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
    
}

- (BOOL)textField:(UITextField *)textField
shouldChangeCharactersInRange:(NSRange)range
replacementString:(NSString *)string {
    @try {
        
        autoComplete.hidden = NO;
        
        if ([searchText.text isEqualToString:@""]) {
            autoComplete.hidden= YES;
        }
        
        NSString *substring = [NSString stringWithString:searchText.text];
        substring = [substring
                     stringByReplacingCharactersInRange:range withString:string];
        [self searchAutocompleteEntriesWithSubstring:substring];
        return YES;
    }
    @catch (NSException *exception) {
        NSLog(@"Exception %@",exception);
    }
    @finally {
        
    }
}

- (void)searchAutocompleteEntriesWithSubstring:(NSString *)substring {
    @try {
        // Put anything that starts with this substring into the autocompleteUrls array
        // The items in this array is what will show up in the table view
        NSString* urlpath;
        if (![substring isEqual:@""])
            //https://maps.googleapis.com/maps/api/place/autocomplete/json?key=AIzaSyBsB3SN513YgmJxs-md1zA2zWPgktPhczU&input=am
        {
            
            
            if (isOnlineStatus) {
                
                
                
                
               // urlpath = [NSString stringWithFormat:@"https://maps.googleapis.com/maps/api/place/autocomplete/json?key=AIzaSyBsB3SN513YgmJxs-md1zA2zWPgktPhczU&input=%@",substring];
                
                urlpath = [NSString stringWithFormat:@"https://maps.googleapis.com/maps/api/place/autocomplete/json?key=AIzaSyAM5zyy3xsgRWpye3fmXLEK1Hm18E_tj98&input=%@",substring];
                
                NSString *escapedUrlString =[urlpath stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet URLFragmentAllowedCharacterSet]];// [urlpath stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
                
                
                NSURL *RPRTUrlpath = [NSURL URLWithString:escapedUrlString];
                
                NSData *myData = [NSData dataWithContentsOfURL:RPRTUrlpath];
                
                NSError* error1;
                
                NSDictionary    * autocompleteUrls1 = [NSJSONSerialization
                                                       JSONObjectWithData:myData
                                                       options:kNilOptions
                                                       error:&error1];
                NSString  *prediction = [autocompleteUrls1 valueForKey:@"predictions"];
                autocompleteUrls = [prediction valueForKey:@"description"];
                
                [autoComplete reloadData];
            }
            else if (!isOnlineStatus)
            {
                [self showAlertPop:@"No internet connection" expObj:nil];
            }
            
        }
        else  if ([substring isEqual:@""])
            
        {
            
        }
        
    }
    @catch (NSException *exception) {
        NSLog(@"Exception %@",exception);
    }
    @finally {
        
    }
}


-(void)liveBtnClick:(UIButton*)sender
{
    @try {
        table.hidden = YES;
        
        [searchText resignFirstResponder];
        
        taglabel =0;
        liveTapped = (UIButton*)sender;
        
        
        spinner = [[UIActivityIndicatorView alloc]
                   initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
        spinner.frame = CGRectMake(0, 0, 320, 560); // CGPointMake(160, 240);
        spinner.color = [UIColor blueColor];
        spinner.backgroundColor = [UIColor lightTextColor];
        spinner.transform = CGAffineTransformMakeScale(2, 2);
        // spinner.hidesWhenStopped = YES;
        [self.view addSubview:spinner];
        spinner.transform = CGAffineTransformMakeScale(2, 2);
        
        [spinner startAnimating];
        
        // how we stop refresh from freezing the main UI thread
        
        dispatch_async(
                       dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^{
                           
                           
                           if (liveTapped.tag == 0) {
                               if ([Key isEqualToString:@"Live"]) {
                                   Key = @"Live";
                               }
                               else if ([Key isEqualToString:@"Expired"])
                               {
                                   Key = @"Live+Expired";
                               }
                               
                               livearry = [GetAllOpp valueForKey:@"Listongoing"];
                               if ([GetOffers count]>0) {
                                   for (int i=0; i<[livearry count]; i++) {
                                       [GetOffers addObject:livearry[i]];
                                       NSString *offerName = [GetOffers[i] valueForKey:@"OpportunityName"];
                                       NSString *offerDescription = [GetOffers[i] valueForKey:@"OpportunityDescription"];
                                       [opporArray addObject:offerDescription];
                                       [opporArray addObject:offerName];
                                   }
                                   //  availbleStatus.hidden=YES;
                                   opportunityArray = GetOffers;
                               }
                               else
                               {
                                   for (int i=0; i<[livearry count]; i++) {
                                       [GetOffers addObject:livearry[i]];
                                       NSString *offerName = [GetOffers[i] valueForKey:@"OpportunityName"];
                                       [opporArray addObject:offerName];
                                       NSString *offerDescription = [GetOffers[i] valueForKey:@"OpportunityDescription"];
                                       [opporArray addObject:offerDescription];
                                   }
                                   opportunityArray = GetOffers;
                                   
                               }
                               
                               
                           }
                           else if (liveTapped.tag == 1)
                           {
                               
                               if ([Key isEqualToString:@"Live+Expired"])
                               {
                                   Key = @"Expired";
                               }
                               else if ([Key isEqualToString:@"Live"])
                               {
                                   Key = @"";
                               }
                               else if ([Key isEqualToString:@"Expired"])
                               {
                                   Key = @"Expired";
                               }
                               
                               upcomingarry =[GetAllOpp valueForKey:@"Listongoing"];
                               if ([GetOffers count]>0) {
                                   for (int i=0; i<[upcomingarry count]; i++) {
                                       [GetOffers removeObject:upcomingarry[i]];
                                       
                                       NSString *offerName = [upcomingarry[i] valueForKey:@"OpportunityName"];
                                       [opporArray removeObject:offerName];
                                       NSString *offerDescription =  [upcomingarry[i] valueForKey:@"OpportunityDescription"];
                                       [opporArray removeObject:offerDescription];
                                   }
                                   //   availbleStatus.hidden=YES;
                                   opportunityArray = GetOffers;
                               }
                           }
                             [self setButtonimage:sender];
                           
                           
                           // back to the main thread for the UI call
                           dispatch_async(dispatch_get_main_queue(), ^{
                               
                               
                               [spinner startAnimating];
                           });
                           dispatch_async(dispatch_get_main_queue(), ^{
                             
                               [opportunityTable reloadData];
                               [spinner stopAnimating];
                               
                           });
                       });
        
        
        
        
        //[opportunityTable reloadData];
        
    }
    @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
}


-(void)expiredBtnClick:(UIButton*)sender
{
    
    @try {
        table.hidden = YES;
        
        [searchText resignFirstResponder];
        liveTapped = (UIButton*)sender;
        
        spinner = [[UIActivityIndicatorView alloc]
                   initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
        spinner.frame = CGRectMake(0, 0, 320, 560); // CGPointMake(160, 240);
        spinner.color = [UIColor blueColor];
        spinner.backgroundColor = [UIColor lightTextColor];
        spinner.transform = CGAffineTransformMakeScale(2, 2);
        // spinner.hidesWhenStopped = YES;
        [self.view addSubview:spinner];
        spinner.transform = CGAffineTransformMakeScale(2, 2);
        
        [spinner startAnimating];
        
        // how we stop refresh from freezing the main UI thread
        
        dispatch_async(
                       dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^{
                           
                           
                           // back to the main thread for the UI call
                           dispatch_async(dispatch_get_main_queue(), ^{
                               
                               [spinner startAnimating];
                           });
                           dispatch_async(dispatch_get_main_queue(), ^{
                               
                               if (liveTapped.tag == 0) {
                                   
                                   if ([Key isEqualToString:@"Expired"]) {
                                       Key = @"Expired";
                                   }
                                   else if ([Key isEqualToString:@"Live"])
                                   {
                                       Key = @"Live+Expired";
                                   }
                                   
                                   
                                   
                                   expiredarray =[GetAllOpp valueForKey:@"ListExpire"];
                                   if ([GetOffers count]>0) {
                                       for (int i=0; i<[expiredarray count]; i++) {
                                           [GetOffers addObject:expiredarray[i]];
                                           NSString *offerName = [GetOffers[i] valueForKey:@"OpportunityName"];
                                           [opporArray addObject:offerName];
                                           NSString *offerDescription = [GetOffers[i] valueForKey:@"OpportunityDescription"];
                                           [opporArray addObject:offerDescription];
                                       }
                                       // availbleStatus.hidden=YES;
                                       opportunityArray = GetOffers;
                                   }
                                   else{
                                       for (int i=0; i<[expiredarray count]; i++) {
                                           [GetOffers addObject:expiredarray[i]];
                                           NSString *offerName = [GetOffers[i] valueForKey:@"OpportunityName"];
                                           [opporArray addObject:offerName];
                                           NSString *offerDescription = [GetOffers[i] valueForKey:@"OpportunityDescription"];
                                           [opporArray addObject:offerDescription];
                                       }
                                       
                                       opportunityArray = GetOffers;
                                   }
                                   
                               }
                               else  if (liveTapped.tag == 1)
                               {
                                   
                                   if ([Key isEqualToString:@"Live+Expired"])
                                   {
                                       Key = @"Live";
                                   }
                                   else if ([Key isEqualToString:@"Expired"])
                                   {
                                       Key = @"";
                                   }
                                   else if ([Key isEqualToString:@"Live"])
                                   {
                                       Key = @"Live";
                                   }
                                   
                                   expiredarray =[GetAllOpp valueForKey:@"ListExpire"];
                                   if ([GetOffers count]>0) {
                                       for (int i=0; i<[expiredarray count]; i++) {
                                           [GetOffers removeObject:[expiredarray objectAtIndex:i]];
                                           NSString *offerName = [[expiredarray objectAtIndex:i] valueForKey:@"OpportunityName"];
                                           [opporArray removeObject:offerName];
                                           
                                           NSString *offerDescription = [[expiredarray objectAtIndex:i] valueForKey:@"OpportunityDescription"];
                                           [opporArray removeObject:offerDescription];
                                           
                                           
                                       }
                                       
                                       opportunityArray = GetOffers;
                                   }
                               }
                               
                               [self setButtonimage:sender];
                               dispatch_async(dispatch_get_main_queue(), ^{
                                    [opportunityTable reloadData];
                               });
                               
                             
                               [spinner stopAnimating];
                               
                           });
                       });
    }
    @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
    
    // [self setButtonimage:sender];
}

-(IBAction)searchEvent:(id)sender
{
    @try {
        
        search = [[UISearchBar alloc]initWithFrame:CGRectMake(checkview.frame.origin.x, checkview.frame.origin.y, checkview.frame.size.width, checkview.frame.size.height)];
        search.delegate = self;
        search.placeholder = @"Enter Search String";
        search.showsScopeBar = YES;
        search.showsCancelButton = YES;
        [self.view addSubview:search];
        
        
        UIPanGestureRecognizer *panRecognizer = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(hidekeyboard)];
        [panRecognizer setMinimumNumberOfTouches:1];
        [self.view addGestureRecognizer:panRecognizer];
        
        [UIView animateWithDuration:1 animations:^{
            
            [search layoutIfNeeded];
        } completion:^(BOOL finished) {
            
            [UIView animateWithDuration:1 animations:^{
                
                [search layoutIfNeeded];
            }];
            
        }];
        [checkview setHidden:YES];
        
    } @catch (NSException *exception) {
        
    } @finally {
        
    }
}

- (void)searchBarCancelButtonClicked:(UISearchBar *)searchBar{
    [searchBar resignFirstResponder];
    [searchBar setShowsCancelButton:NO animated:YES];
    [search setHidden:YES];
    [checkview setHidden:NO];
}

-(void)hidekeyboard
{
    [search resignFirstResponder];
    //    [search setHidden:YES];
    //  [checkview setHidden:NO];
}
- (void)searchBarTextDidBeginEditing:(UISearchBar *)searchBar {
    isSearching = YES;
}

- (void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)seachtext {
    NSLog(@"Text change - %d",isSearching);
    
    //Remove all objects first.
    // [filteredContentList removeAllObjects];
    
    if([seachtext length] != 0) {
        isSearching = YES;
        [self seachOffer:seachtext];
    }
    else if([seachtext length]==0)
    {
        GetOffers = opportunityArray;
        [opportunityTable reloadData];
    }
    else {
        isSearching = NO;
    }
    // [self.tblContentList reloadData];
}

- (void)seachOffer:(NSString *)substring {
    @try {
        // Put anything that starts with this substring into the autocompleteUrls array
        // The items in this array is what will show up in the table view
        NSPredicate *predicate = [NSPredicate predicateWithFormat:@"SELF contains [cd] %@", substring];
        NSArray  *results = [opporArray filteredArrayUsingPredicate:predicate];
        if ([results count]!=0) {
            
            NSMutableArray *array = [[NSMutableArray alloc]init];
            
            
            for (int i=0; i<[results count]; i++) {
                NSString  *str= [results objectAtIndex:i];
                
                for (int j=0; j<[GetOffers count]; j++) {
                    NSString *str2 = [[GetOffers objectAtIndex:j]  valueForKey:@"OpportunityName"];
                    NSString *str3 = [[GetOffers objectAtIndex:j]  valueForKey:@"OpportunityDescription"];
                    if ([str isEqualToString:str2] || [str isEqualToString:str3]) {
                        [array addObject:[GetOffers objectAtIndex:j]];
                    }
                }
                
            }
            
            NSOrderedSet *orderedSet = [NSOrderedSet orderedSetWithArray:array];
            GetOffers = [orderedSet mutableCopy];
            
            
            
            
            // GetRetailerOpp = array;
            
            [opportunityTable reloadData];
            
        }
        //[autoComplete reloadData];
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
}

- (void)searchBarSearchButtonClicked :(UISearchBar *)searchBar {
    NSLog(@"Search Clicked");
    
    [searchBar resignFirstResponder];
    //[searchBar setHidden:YES];
    //[checkview setHidden:NO];
    //[self searchTableList];
}

- (BOOL)textFieldShouldClear:(UITextField *)textField {
    //if we only try and resignFirstResponder on textField or searchBar,
    //the keyboard will not dissapear (at least not on iPad)!
    [self performSelector:@selector(searchBarCancelButtonClicked) withObject:search afterDelay: 0.1];
    return YES;
}

-(void)searchBarCancelButtonClicked
{
    [search resignFirstResponder];
    [search setHidden:YES];
    [checkview setHidden:NO];
    GetOffers = opportunityArray;
    [opportunityTable reloadData];
}

-(IBAction)nearByusers:(id)sender
{
    @try {
        
        spinner = [[UIActivityIndicatorView alloc]
                   initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
        spinner.frame = CGRectMake(0, 0, 320, 560); // CGPointMake(160, 240);
        spinner.color = [UIColor blueColor];
        spinner.backgroundColor = [UIColor lightTextColor];
        spinner.transform = CGAffineTransformMakeScale(2, 2);
        // spinner.hidesWhenStopped = YES;
        [self.view addSubview:spinner];
        spinner.transform = CGAffineTransformMakeScale(2, 2);
        
        [spinner startAnimating];
        
        // how we stop refresh from freezing the main UI thread
        
        dispatch_async(
                       dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^{ dispatch_async(dispatch_get_main_queue(), ^{
            
            [spinner startAnimating];
        });
                           dispatch_async(dispatch_get_main_queue(), ^{
                               
                               
                               
                               NearBy_Users *mNearByUsers = [[NearBy_Users alloc]initWithNibName:@"NearBy_Users" bundle:nil];
                               [self presentViewController:mNearByUsers animated:YES completion:nil];
                               
                               [spinner stopAnimating];
                               
                           });
                       });
        
        
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
        
    } @finally {
        
    }
    
}

-(void)setButtonimage:(UIButton*)sender
{
    @try
    {
        
        
        liveTapped = (UIButton*)sender;
        CGSize sizex =CGSizeMake(18, 18);
        if (liveTapped.tag == 1) {
            liveTapped.tag = 0;
            
            UIImage *eximg = [UIImage imageNamed:@"uncheck.png"];
            
            
            eximg=   [mTimecalculator image:eximg scaledToSize:sizex];
            
            
            [sender  setImage:eximg forState:UIControlStateNormal];
        }
        else if (liveTapped.tag == 0)
            
        {
            liveTapped.tag = 1;
            
            UIImage *eximg = [UIImage imageNamed:@"check.png"];
            CGSize siz =CGSizeMake(18, 18);
            eximg=   [mTimecalculator image:eximg scaledToSize:siz];
            
            
            eximg =  [eximg imageWithTint:toolBarView.backgroundColor];
            
            eximg=   [mTimecalculator image:eximg scaledToSize:sizex];
            
            
            [sender  setImage:eximg forState:UIControlStateNormal];
            
            // [sender  setImage:[UIImage imageNamed: @"check.png"] forState:UIControlStateNormal];
            
            
            if ([GetOffers count]>0) {
                
                //availbleStatus.hidden=YES;
                opportunityTable.hidden= NO;
            }
            else
            {
                
                //   availbleStatus.hidden=NO;
                opportunityTable.hidden= YES;
            }
            
        }
    }
    @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
}

-(void)updateopportunityTableview
{
    @try {
        
        
        
        NSMutableDictionary *locatioLatLon = [[NSMutableDictionary alloc]init];
        [locatioLatLon setValue:geoCode.Latitude forKey:LATITUDE];
        [locatioLatLon setValue:geoCode.Longitude forKey:LONGITUDE];
        [locatioLatLon setValue:geoCode.State forKey:@"State"];
        [locatioLatLon setValue:geoCode.Country forKey:@"Country"];
        
        GetAllOpp =   [self updateOpportunityTable:locatioLatLon ];
        
        
    }
    @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
}

-(NSDictionary*)updateOpportunityTable:(NSDictionary*)currentlocation  {
    @try {
        
        
        mPref = [NSUserDefaults standardUserDefaults];
        NSString *radious;
        if ([mPref valueForKey:@"Radious"]==nil) {
            radious = @"500";
            
        }
        else
            radious =[mPref valueForKey:@"Radious"];
        
        NSMutableDictionary *location = [[NSMutableDictionary alloc]init];
        [location setValue:[currentlocation valueForKey:LATITUDE] forKey:LATITUDE];
        [location setValue:[currentlocation valueForKey:LONGITUDE] forKey:LONGITUDE];
        [location setValue:[currentlocation valueForKey:@"State"] forKey:@"State"];
        [location setValue:[currentlocation valueForKey:@"Country"] forKey:@"Country"];
        [location setValue:[mPref valueForKey:MODULEID] forKey:@"ModuleId"];
        [location setValue:radious forKey:@"Radious"];
        mWebService = [Web_Services GetSharedInstance];
        getOpportutnity =[mWebService GetOpportunities:location];
        return getOpportutnity;
        
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    
    if (tableView == opportunityTable)
    {
        
        if ([GetOffers count]>0) {
            
            [availableStatusView setHidden:YES];
         //   return 1;
            return [GetOffers count];
            
        }
        
        else  if ([GetOffers count] == 0)
        {
            
            [availableStatusView setHidden:NO];
            return 0;
        }
        
    }
    
    if (tableView == autoComplete)
    {
        return 1;
    }
    else if (tableView == table)
    {
        return 1;
    }
    
    return 1;
    
    
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    
    
    if (tableView == autoComplete) {
        return  [autocompleteUrls count];
        
    }
    else if(tableView == opportunityTable)
    {
        if ([GetOffers count]>0) {
            
            [availableStatusView setHidden:YES];
            return 1;
        }
        
        else  if ([GetOffers count] == 0)
        {
            
            [availableStatusView setHidden:NO];
            return 0;
        }
        
        return 0;
        
    }
    else if (tableView == table)
    {
        return 5;
    }
    return [GetOffers count];
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (tableView == opportunityTable) {
        
                return 189;
      
    }
    else
    {
        return 50;
    }
    
}




- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    //this is the space
    
     if ([category isEqualToString:HEALTH] || [category isEqualToString:BANKING] || [category isEqualToString:PROFESSIONALHELP])
     {
         return 0;
     }
     else return  8;
    
}

// This will tell your UITableView what data to put in which cells in your table.
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    @try {
        
        if (isOnlineStatus) {
            
            NSDictionary *components = [NSDictionary dictionaryWithObject:geoCode.countryCode forKey:NSLocaleCountryCode];
            NSString *localeIdent = [NSLocale localeIdentifierFromComponents:components];
            NSLocale *locale = [[NSLocale alloc] initWithLocaleIdentifier:localeIdent];
            CURRENCY_SYMBOL = [locale objectForKey:NSLocaleCurrencySymbol];
            
            UITableViewCell *cell= nil;
            if (tableView ==opportunityTable) {
                table.hidden = YES;
                
                
                
                if ([category isEqualToString:FOOD] || [category isEqualToString:SALES]) {
                    Food_Sale_Cell *cell = (Food_Sale_Cell *)[tableView dequeueReusableCellWithIdentifier:@"Food_Sale_Cell"];
                    
                    //OpportunityCell *cell =(OpportunityCell *) [tableView dequeueReusableCellWithIdentifier:simpleTableIdentifier forIndexPath:indexPath];
                    
                    if (cell == nil)
                    {
                        NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"Food_Sale_Cell" owner:self options:nil];
                        cell = [nib objectAtIndex:0];
                    }
                    cell.selectionStyle = UITableViewCellSelectionStyleNone;
                    cell.backgroundColor = [UIColor lightGrayColor];
                   
                    cell.layer.cornerRadius = 45/2;
                    
                    
                    cell.selectionStyle = UITableViewCellSelectionStyleNone;
                    cell.backgroundColor = [UIColor clearColor];
                    //cell.view1.layer.borderColor = [[UIColor lightGrayColor] CGColor];
                    cell.layer.cornerRadius = 45/2;
                
                    NSDictionary *Record = [GetOffers objectAtIndex:indexPath.section];
                    
                    //
                    NSIndexPath *indexPath = [NSIndexPath indexPathForRow:1 inSection: 1];
                    
                    [tableView selectRowAtIndexPath:indexPath animated:NO scrollPosition:UITableViewScrollPositionNone];
                    
                    
                    [cell.shareBtn addTarget:self action:@selector(shareData:) forControlEvents:UIControlEventTouchUpInside];
                    cell.shareBtn.imageView.alpha=0.5;
                    
                    
                    
                    [cell.spamBtn addTarget:self action:@selector(spamData:) forControlEvents:UIControlEventTouchUpInside];
                    cell.spamBtn.imageView.alpha=0.5;
                    
                    
                    
                    
                    
                    NSMutableAttributedString *actual=[[NSMutableAttributedString alloc]initWithString:[NSString stringWithFormat:@"%@ %@",CURRENCY_SYMBOL,[Record valueForKey:@"ActualPrice"]]];
                    [actual addAttribute:NSStrikethroughStyleAttributeName value:[NSNumber numberWithInt:2] range:NSMakeRange(0,[actual length])];
                    
                    
                  
                        cell.actualprice.attributedText = actual;
                        
                        cell.price.text =[NSString stringWithFormat:@"%@ %@",CURRENCY_SYMBOL,[Record valueForKey:@"Price"]];
                    
                    cell.deliveryLbl.textColor= catColour;
                    cell.priceLbl.textColor= catColour;
                    cell.categoryType.textColor = catColour;
                    
                    
                    NSString *byenaem ;
                    if ([[Record valueForKey:@"VendorName"] isEqualToString:@""]) {
                        byenaem = [Record valueForKey:@"UserName"];
                    }
                    else byenaem =[Record valueForKey:@"VendorName"];
                    
                     cell.offerpostBy.text = [NSString stringWithFormat:@"By %@",byenaem];

                    //cell.offerpostBy.text = [NSString stringWithFormat:@"By %@",[Record valueForKey:@"VendorName"]];
                    
                    
                    UIColor *color;// = [UIColor greenColor];
                    
                    
                        cell.opportunity.text =[NSString stringWithFormat:@"%@",[Record valueForKey:@"OpportunityName"]];
                        cell.description.text = [NSString stringWithFormat:@"%@",[Record valueForKey:@"OpportunityDescription"]];
                        cell.Location.text = [NSString stringWithFormat:@"%@",[Record valueForKey:@"AreaName"]];
                    
                        color =  catColour;
                    NSString *availacnt =[Record valueForKey:@"Available"];
                    int count = [availacnt intValue];
                        if(count<0)
                        {
                            count = 0;
                        }
                        else count = count;
                        cell.Avialable.text =[NSString stringWithFormat:@"Available:%d",count];
                        
                    
                    
                    [cell.Timer setTextColor:color];
                    
                    if ([[Record valueForKey:@"OppStatus"] isEqualToString:@"Live"]) {
                        NSString *satrtDate = [NSString stringWithFormat:@"%@",[Record valueForKey:@"EndDate"]];
                        
                        NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
                        [dateFormatter setDateFormat:@"yyyy-MM-dd'T'HH:mm:ss"];
                        NSTimeZone *gmt = [NSTimeZone timeZoneWithAbbreviation:@"UTC"];
                        [dateFormatter setTimeZone:gmt];
                        NSDate *date5 = [dateFormatter dateFromString:satrtDate];
                        
                        NSDictionary *startOffer;
                        if (date5!=nil) {
                            startOffer= [mTimePreference remaningTime:[NSDate date] endDate:date5];
                        }
                        else{
                            
                            NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
                            [dateFormatter setDateFormat:@"yyyy-MM-dd'T'HH:mm:ss.SSS"];
                            
                            NSTimeZone *gmt = [NSTimeZone timeZoneWithAbbreviation:@"UTC"];
                            [dateFormatter setTimeZone:gmt];
                            NSDate *date5 = [dateFormatter dateFromString:satrtDate];
                            startOffer= [mTimePreference remaningTime:[NSDate date] endDate:date5];
                            
                        }
                        
                        
                        int Remaingtyime = [[startOffer valueForKey:@"Time"] intValue];
                        int hour = [[startOffer valueForKey:@"Hour"] intValue];
                        int seconds = [[startOffer valueForKey:@"Seconds"] intValue];
                        if (seconds!=0) {
                            Remaingtyime = Remaingtyime+(seconds/60);
                        }
                        if(Remaingtyime!=0)
                        {
                            
                            Remaingtyime = Remaingtyime+(hour*60);//+minutes;
                            
                            
                            
                            
                            NSString *userBlock =[NSString stringWithFormat:@"%@",[Record valueForKey:@"BlockId"]];
                            if (![userBlock isEqualToString:@"0"] && [[Record valueForKey:@"OppStatus"] isEqualToString:@"Live"]) {
                                cell.blockBtn.tag= 1;
                                
                                
                                if ([[Record valueForKey:@"BlockText"] isEqualToString:@"UnBlock"]) {
                                    [cell.blockBtn setImage:[UIImage imageNamed:blockIcon] forState:UIControlStateNormal];
                                    
                                }
                                else if([[Record valueForKey:@"BlockText"] isEqualToString:@"Blocked"])
                                {
                                    [cell.blockBtn setImage:[UIImage imageNamed:stopIcon] forState:UIControlStateNormal];
                                    
                                }
                                
                                else if([[Record valueForKey:@"BlockText"] isEqualToString:@"Claimed"])
                                {
                                    [cell.blockBtn setImage:[UIImage imageNamed:claimIcon] forState:UIControlStateNormal];
                                    cell.blockBtn.userInteractionEnabled = NO;
                                   
                                    
                                }
                                
                                //   [self.bLockBtn setBackgroundColor:[UIColor yellowColor]];
                                
                                
                            }
                            else if([userBlock isEqualToString:@"0"] && [[Record valueForKey:@"OppStatus"] isEqualToString:@"Live"])
                            {
                                //  [self.bLockBtn setBackgroundColor:[UIColor greenColor]];
                                [cell.blockBtn setImage:[UIImage imageNamed:blockIcon] forState:UIControlStateNormal];
                                
                             
                            }
                            else if ([[Record valueForKey:@"OppStatus"] isEqualToString:@"Expired"])
                            {
                                [cell.blockBtn setImage:[UIImage imageNamed:notifyIcon] forState:UIControlStateNormal];
                            
                                 if([[Record valueForKey:@"BlockText"] isEqualToString:@"Claimed"])
                                {
                                    [cell.blockBtn setImage:[UIImage imageNamed:claimIcon] forState:UIControlStateNormal];
                                     cell.blockBtn.userInteractionEnabled = NO;
                                    
                                }
                                else if ([[Record valueForKey:@"BlockText"] isEqualToString:@"Notify"])
                                {
                                    [cell.blockBtn setImage:[UIImage imageNamed:notifedIcon] forState:UIControlStateNormal];
                                    //cell.blockBtn.enabled = NO;
                                }
                                
                                
                            }
                            
                          
                            
                            

                            
                            [cell.blockBtn addTarget:self action:@selector(Block:) forControlEvents:UIControlEventTouchUpInside];
                            //[cell addSubview:blockBtn];
                            
                            TimeCoutDown = [[MZTimerLabel alloc] initWithLabel:cell.Timer andTimerType:MZTimerLabelTypeTimer];
                            [TimeCoutDown setCountDownTime:Remaingtyime*60];
                            [TimeCoutDown start];
                        }
                        
                        NSString *RegisterID =   [mPref objectForKey:USERREGISTERID];
                        if (RegisterID == [Record valueForKey:@"UserRegisterId"])
                        {
                            cell.blockBtn.hidden= YES;
                            
                        }
                        
                    }
                    else if ([[Record valueForKey:@"OppStatus"] isEqualToString:@"Expired"])
                    {
                        
                        
                        
                        
                        NSString *RegisterID =   [mPref objectForKey:USERREGISTERID];
                        if (RegisterID == [Record valueForKey:@"UserRegisterId"])
                        {
                            cell.blockBtn.hidden= YES;
                            
                        }
                        
                        cell.Timer.text = @"Expired!!";
                        //CGSize siz =CGSizeMake(63, 45);
                       // UIImage  *image=   [mTimecalculator image:[UIImage imageNamed:notifyIcon] scaledToSize:siz];
                        
                        if (![[Record valueForKey:@"BlockText"] isEqualToString:@"Notify"]) {
                           [cell.blockBtn setImage:[UIImage imageNamed:notifyIcon] forState:UIControlStateNormal];
                        }
                        
                      
                        
                        if ([[Record valueForKey:@"BlockText"] isEqualToString:@"Notify"])
                        {
                            [cell.blockBtn setImage:[UIImage imageNamed:notifedIcon] forState:UIControlStateNormal];
                            //cell.blockBtn.enabled = NO;
                        }

                        
                        
                      
                        
                        [cell.blockBtn addTarget:self action:@selector(Block:) forControlEvents:UIControlEventTouchUpInside];
                    }
                    
                    NSString *imageName = [NSString stringWithFormat:@"%@",[Record valueForKey:@"PhotoName"]];;
                    NSArray *imageAry = [imageName componentsSeparatedByString:@","];
                    NSString *ImageURL = [NSString stringWithFormat:@"%@%@",baseImageURL, [imageAry objectAtIndex:0]];
                    
                    if ([[imageAry objectAtIndex:0] isEqualToString:@""]) {
                        
                        imageName = [NSString stringWithFormat:@"%@",[Record valueForKey:@"CategoryImage"]];;
                        ImageURL = [NSString stringWithFormat:@"%@%@",baseImageURL, imageName];
                        
                        NSURL *imageURL = [NSURL URLWithString:ImageURL];
                        NSString *key = [ImageURL MD5Hash];
                        NSData *getData = [FTWCache objectForKey:key];
                        if (getData) {
                            UIImage *image = [UIImage imageWithData:getData];
                            cell.OpportunityImage.image  = image;
                        }
                        else {
                            cell.OpportunityImage.image  = [UIImage imageNamed:@"img_def"];
                            dispatch_queue_t queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_HIGH, 0ul);
                            dispatch_async(queue, ^{
                                NSData *newData = [NSData dataWithContentsOfURL:imageURL];
                                [FTWCache setObject:newData forKey:key];
                                UIImage *image = [UIImage imageWithData:newData];
                                dispatch_sync(dispatch_get_main_queue(), ^{
                                    cell.OpportunityImage.image  = image;
                                    
                                });
                            });
                        }
                        
                    }
                    
                    else {
                        
                        NSURL *imageURL = [NSURL URLWithString:ImageURL];
                        NSString *key = [ImageURL MD5Hash];
                        NSData *getData = [FTWCache objectForKey:key];
                        if (getData) {
                            UIImage *image = [UIImage imageWithData:getData];
                            cell.OpportunityImage.image  = image;
                        }
                        else {
                            cell.OpportunityImage.image  = [UIImage imageNamed:@"img_def"];
                            dispatch_queue_t queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_HIGH, 0ul);
                            dispatch_async(queue, ^{
                                NSData *newData = [NSData dataWithContentsOfURL:imageURL];
                                [FTWCache setObject:newData forKey:key];
                                UIImage *image = [UIImage imageWithData:newData];
                                dispatch_sync(dispatch_get_main_queue(), ^{
                                    cell.OpportunityImage.image  = image;
                                    
                                });
                            });
                        }
                        
                    }
                    UITapGestureRecognizer *singleTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(ImageTap:)];
                    singleTap.numberOfTapsRequired = 1;
                    [cell.OpportunityImage setUserInteractionEnabled:YES];
                    [cell.OpportunityImage addGestureRecognizer:singleTap];
                  
                    
                    cell.categoryType.text = [NSString stringWithFormat:@"%@",[Record valueForKey:@"SubCategory"]];
                    
                    if ([[Record valueForKey:@"Delivery"] isEqualToString:@"Home Delivery not Available"])
                    {
                     
                        cell.delivery.text = @"NA";
                        
                    }
                    else
                    {
                        cell.delivery.text = @"Free";
                    }
                    
                    
                  
                    
                    
                    return cell;

                    
                }
             
                else  if ([category isEqualToString:HEALTH] || [category isEqualToString:BANKING] || [category isEqualToString:PROFESSIONALHELP])
                {
                    Custom_OppCell *cell = (Custom_OppCell *)[tableView dequeueReusableCellWithIdentifier:@"Custom_OppCell"];
                    
                    
                    
                    if (cell == nil)
                    {
                        NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"Custom_OppCell" owner:self options:nil];
                        cell = [nib objectAtIndex:0];
                    }
                    
                    
                    
                    cell.selectionStyle = UITableViewCellSelectionStyleNone;
                    cell.backgroundColor = [UIColor clearColor];
                    //cell.view1.layer.borderColor = [[UIColor lightGrayColor] CGColor];
                    cell.layer.cornerRadius = 45/2;
                    
                    
                    //update tableview cell
                    
                    NSDictionary *Record = [GetOffers objectAtIndex:indexPath.section];

                    NSMutableAttributedString *actual=[[NSMutableAttributedString alloc]initWithString:[NSString stringWithFormat:@"%@ %@",CURRENCY_SYMBOL,[Record valueForKey:@"ActualPrice"]]];
                    [actual addAttribute:NSStrikethroughStyleAttributeName value:[NSNumber numberWithInt:2] range:NSMakeRange(0,[actual length])];
                    
                    cell.categoryType.text = [NSString stringWithFormat:@"%@",[Record valueForKey:@"SubCategory"]];
                    
                    
                    NSString *byenaem ;
                    if ([[Record valueForKey:@"VendorName"] isEqualToString:@""]) {
                        byenaem = [Record valueForKey:@"UserName"];
                    }
                    else byenaem =[Record valueForKey:@"VendorName"];
                    
                    cell.offerPostBy.text = [NSString stringWithFormat:@"By %@",byenaem];
                    
                    
                    
                   // cell.offerPostBy.text = [NSString stringWithFormat:@"By %@",[Record valueForKey:@"VendorName"]];
                    //VendorName
                    
                    [cell.shareBtn addTarget:self action:@selector(shareData:) forControlEvents:UIControlEventTouchUpInside];
                    cell.shareBtn.imageView.alpha=0.5;
                    
                    
                    [cell.spamBtn addTarget:self action:@selector(spamData:) forControlEvents:UIControlEventTouchUpInside];
                    cell.spamBtn.imageView.alpha=0.5;
                    
                    
                    
                    
                    UIColor *color;// = [UIColor greenColor];
                    
                    cell.opportunity.text =[NSString stringWithFormat:@"%@",[Record valueForKey:@"OpportunityName"]];
                    cell.Opdescription.text = [NSString stringWithFormat:@"%@",[Record valueForKey:@"OpportunityDescription"]];
                    cell.Location.text = [NSString stringWithFormat:@"%@",[Record valueForKey:@"AreaName"]];
                    
                    //[cell.blockBtn setBackgroundColor : catColour];
                    color = catColour;
                                      cell.categoryType.textColor = catColour;

                    [cell.Timer setTextColor:color];
                    
                    if ([[Record valueForKey:@"OppStatus"] isEqualToString:@"Live"]) {
                        NSString *satrtDate = [NSString stringWithFormat:@"%@",[Record valueForKey:@"EndDate"]];
                        
                        NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
                        [dateFormatter setDateFormat:@"yyyy-MM-dd'T'HH:mm:ss"];
                        NSTimeZone *gmt = [NSTimeZone timeZoneWithAbbreviation:@"UTC"];
                        [dateFormatter setTimeZone:gmt];
                        NSDate *date5 = [dateFormatter dateFromString:satrtDate];
                        
                        NSDictionary *startOffer;
                        if (date5!=nil) {
                            startOffer= [mTimePreference remaningTime:[NSDate date] endDate:date5];
                        }
                        else{
                            
                            NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
                            [dateFormatter setDateFormat:@"yyyy-MM-dd'T'HH:mm:ss.SSS"];
                            
                            NSTimeZone *gmt = [NSTimeZone timeZoneWithAbbreviation:@"UTC"];
                            [dateFormatter setTimeZone:gmt];
                            NSDate *date5 = [dateFormatter dateFromString:satrtDate];
                            startOffer= [mTimePreference remaningTime:[NSDate date] endDate:date5];
                            
                        }
                        
                        
                        int Remaingtyime = [[startOffer valueForKey:@"Time"] intValue];
                        int hour = [[startOffer valueForKey:@"Hour"] intValue];
                        int seconds = [[startOffer valueForKey:@"Seconds"] intValue];
                        if (seconds!=0) {
                            Remaingtyime = Remaingtyime+(seconds/60);
                        }
                        if(Remaingtyime!=0)
                        {
                            
                            Remaingtyime = Remaingtyime+(hour*60);//+minutes;
                            
                            Remaingtyime = Remaingtyime;
                            
                            NSString *userBlock =[NSString stringWithFormat:@"%@",[Record valueForKey:@"BlockId"]];
                            if (![userBlock isEqualToString:@"0"] && [[Record valueForKey:@"OppStatus"] isEqualToString:@"Live"]) {
                                cell.blockBtn.tag= 1;
                                
                                
                                if ([[Record valueForKey:@"BlockText"] isEqualToString:@"UnBlock"]) {
                                    [cell.blockBtn setImage:[UIImage imageNamed:blockIcon] forState:UIControlStateNormal];
                                    
                                }
                                else if([[Record valueForKey:@"BlockText"] isEqualToString:@"Blocked"])
                                {
                                    [cell.blockBtn setImage:[UIImage imageNamed:stopIcon] forState:UIControlStateNormal];
                                    
                                }
                                
                                else if([[Record valueForKey:@"BlockText"] isEqualToString:@"Claimed"])
                                {
                                    [cell.blockBtn setImage:[UIImage imageNamed:claimIcon] forState:UIControlStateNormal];
                                    cell.blockBtn.userInteractionEnabled = NO;
                                    
                                }
                                
                                
                            }
                            else if([userBlock isEqualToString:@"0"] && [[Record valueForKey:@"OppStatus"] isEqualToString:@"Live"])
                            {
                                //  [self.bLockBtn setBackgroundColor:[UIColor greenColor]];
                                [cell.blockBtn setImage:[UIImage imageNamed:blockIcon] forState:UIControlStateNormal];
                                
                                
                            }
                            else if ([[Record valueForKey:@"OppStatus"] isEqualToString:@"Expired"])
                            {
                                [cell.blockBtn setImage:[UIImage imageNamed:notifyIcon] forState:UIControlStateNormal];
                                
                                if([[Record valueForKey:@"BlockText"] isEqualToString:@"Claimed"])
                                {
                                    [cell.blockBtn setImage:[UIImage imageNamed:claimIcon] forState:UIControlStateNormal];
                                    cell.blockBtn.userInteractionEnabled = NO;
                                    
                                }
                                else if ([[Record valueForKey:@"BlockText"] isEqualToString:@"Notify"])
                                {
                                    [cell.blockBtn setImage:[UIImage imageNamed:notifedIcon] forState:UIControlStateNormal];
                                    cell.blockBtn.enabled = NO;
                                }
                                
                            }
                            
                            [cell.blockBtn addTarget:self action:@selector(Block:) forControlEvents:UIControlEventTouchUpInside];
                            //[cell addSubview:blockBtn];
                            
                            TimeCoutDown = [[MZTimerLabel alloc] initWithLabel:cell.Timer andTimerType:MZTimerLabelTypeTimer];
                            [TimeCoutDown setCountDownTime:Remaingtyime*60];
                            [TimeCoutDown start];
                        }
                        
                        
                        NSString *RegisterID =   [mPref objectForKey:USERREGISTERID];
                        if (RegisterID == [Record valueForKey:@"UserRegisterId"])
                        {
                            cell.blockBtn.hidden= YES;
                            
                        }
                        
                        
                        
                    }
                    else if ([[Record valueForKey:@"OppStatus"] isEqualToString:@"Expired"])
                    {
                        
                        
                        
                        
                        
                        NSString *RegisterID =   [mPref objectForKey:USERREGISTERID];
                        if (RegisterID == [Record valueForKey:@"UserRegisterId"])
                        {
                            cell.blockBtn.hidden= YES;
                            
                        }
                        
                        cell.Timer.text = @"Expired!!";
                        //  CGSize siz =CGSizeMake(63, 45);
                        //UIImage  *image=   [mTimecalculator image:[UIImage imageNamed:notifyIcon] scaledToSize:siz];
                        
                        [cell.blockBtn setImage:[UIImage imageNamed:notifyIcon]  forState:UIControlStateNormal];
                        
                        if (![[Record valueForKey:@"BlockText"] isEqualToString:@"Notify"]) {
                            [cell.blockBtn setImage:[UIImage imageNamed:notifyIcon] forState:UIControlStateNormal];
                        }
                        
                        
                        if ([[Record valueForKey:@"BlockText"] isEqualToString:@"Notify"])
                        {
                            [cell.blockBtn setImage:[UIImage imageNamed:notifedIcon] forState:UIControlStateNormal];
                            //cell.blockBtn.enabled = NO;
                        }
                        
                        
                        
                        
                        [cell.blockBtn addTarget:self action:@selector(Block:) forControlEvents:UIControlEventTouchUpInside];
                    }
                    
                    NSString *imageName = [NSString stringWithFormat:@"%@",[Record valueForKey:@"PhotoName"]];;
                    NSArray *imageAry = [imageName componentsSeparatedByString:@","];
                    NSString *ImageURL = [NSString stringWithFormat:@"%@%@",baseImageURL, [imageAry objectAtIndex:0]];
                    
                    if ([[imageAry objectAtIndex:0] isEqualToString:@""]) {
                        
                        imageName = [NSString stringWithFormat:@"%@",[Record valueForKey:@"CategoryImage"]];;
                        ImageURL = [NSString stringWithFormat:@"%@%@",baseImageURL, imageName];
                        
                        NSURL *imageURL = [NSURL URLWithString:ImageURL];
                        NSString *key = [ImageURL MD5Hash];
                        NSData *getData = [FTWCache objectForKey:key];
                        if (getData) {
                            UIImage *image = [UIImage imageWithData:getData];
                            cell.OpportunityImage.image  = image;
                        }
                        else {
                            cell.OpportunityImage.image  = [UIImage imageNamed:@"img_def"];
                            dispatch_queue_t queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_HIGH, 0ul);
                            dispatch_async(queue, ^{
                                NSData *newData = [NSData dataWithContentsOfURL:imageURL];
                                [FTWCache setObject:newData forKey:key];
                                UIImage *image = [UIImage imageWithData:newData];
                                dispatch_sync(dispatch_get_main_queue(), ^{
                                    cell.OpportunityImage.image  = image;
                                    
                                });
                            });
                        }
                        
                    }
                    
                    else {
                        
                        NSURL *imageURL = [NSURL URLWithString:ImageURL];
                        NSString *key = [ImageURL MD5Hash];
                        NSData *getData = [FTWCache objectForKey:key];
                        if (getData) {
                            UIImage *image = [UIImage imageWithData:getData];
                            cell.OpportunityImage.image  = image;
                        }
                        else {
                            cell.OpportunityImage.image  = [UIImage imageNamed:@"img_def"];
                            dispatch_queue_t queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_HIGH, 0ul);
                            dispatch_async(queue, ^{
                                NSData *newData = [NSData dataWithContentsOfURL:imageURL];
                                [FTWCache setObject:newData forKey:key];
                                UIImage *image = [UIImage imageWithData:newData];
                                dispatch_sync(dispatch_get_main_queue(), ^{
                                    cell.OpportunityImage.image  = image;
                                    
                                });
                            });
                        }
                        
                    }
                    UITapGestureRecognizer *singleTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(ImageTap:)];
                    singleTap.numberOfTapsRequired = 1;
                    [cell.OpportunityImage setUserInteractionEnabled:YES];
                    [cell.OpportunityImage addGestureRecognizer:singleTap];
                    
                    
                    return cell;

                    
                }
                
                
                else
                {
                    OpportunityCell *cell = (OpportunityCell *)[tableView dequeueReusableCellWithIdentifier:OPPORTUNITYCELL];
                    
                   
                    
                    if (cell == nil)
                    {
                        NSArray *nib = [[NSBundle mainBundle] loadNibNamed:OPPORTUNITYCELL owner:self options:nil];
                        cell = [nib objectAtIndex:0];
                    }

                    
                    
                    cell.selectionStyle = UITableViewCellSelectionStyleNone;
                    cell.backgroundColor = [UIColor clearColor];
                    //cell.view1.layer.borderColor = [[UIColor lightGrayColor] CGColor];
                    cell.layer.cornerRadius = 45/2;
                
                    
                    //update tableview cell
                    
                    NSDictionary *Record = [GetOffers objectAtIndex:indexPath.section];
                    
                    //
                    
                    NSMutableAttributedString *actual=[[NSMutableAttributedString alloc]initWithString:[NSString stringWithFormat:@"%@ %@",CURRENCY_SYMBOL,[Record valueForKey:@"ActualPrice"]]];
                    [actual addAttribute:NSStrikethroughStyleAttributeName value:[NSNumber numberWithInt:2] range:NSMakeRange(0,[actual length])];
                    
                    cell.categoryType.text = [NSString stringWithFormat:@"%@",[Record valueForKey:@"SubCategory"]];
                    
                    
                    NSString *byenaem ;
                    if ([[Record valueForKey:@"VendorName"] isEqualToString:@""]) {
                        byenaem = [Record valueForKey:@"UserName"];
                    }
                    else byenaem =[Record valueForKey:@"VendorName"];
                    
                    cell.offerPostBy.text = [NSString stringWithFormat:@"By %@",byenaem];
                    
                    
//                    
//                    cell.offerPostBy.text = [NSString stringWithFormat:@"By %@",[Record valueForKey:@"VendorName"]];
                    
                    
                       [cell.shareBtn addTarget:self action:@selector(shareData:) forControlEvents:UIControlEventTouchUpInside];
                    cell.shareBtn.imageView.alpha=0.5;
                    
                    
                    [cell.spamBtn addTarget:self action:@selector(spamData:) forControlEvents:UIControlEventTouchUpInside];
                    cell.spamBtn.imageView.alpha=0.5;
                    
                    
                    
                    UIColor *color;// = [UIColor greenColor];
                    
                    
                   
                   
                     if ([category isEqualToString:JOBS])
                    {
                        cell.opportunity.text =[NSString stringWithFormat:@"%@",[Record valueForKey:@"OpportunityName"]];
                        cell.description.text = [NSString stringWithFormat:@"%@",[Record valueForKey:@"OpportunityDescription"]];
                        cell.Location.text = [NSString stringWithFormat:@"%@",[Record valueForKey:@"AreaName"]];
                  
                        color = [UIColor colorWithRed:63.0/256.0 green:107.0/256.0 blue:178.0/256.0 alpha:1];
                        
                        NSString *availacnt =[Record valueForKey:@"Available"];
                        int count = [availacnt intValue];
                        if(count<0)
                        {
                            count = 0;
                        }
                        else count = count;
                        cell.Avialable.text =[NSString stringWithFormat:@"Available:%d",count];
                       //    cell.Price.text = [NSString stringWithFormat:@" -"];
                        cell.categoryType.textColor = catColour;
                        
                       // cell.deliverylabel.hidden= YES;
                       // cell.priceLabel.hidden= YES;
                      
                    }
                    else if([category isEqualToString:MEETINGS])
                    {
                        
                        cell.opportunity.text =[NSString stringWithFormat:@"%@",[Record valueForKey:@"OpportunityName"]];
                        cell.description.text = [NSString stringWithFormat:@"%@",[Record valueForKey:@"OpportunityDescription"]];
                        cell.Location.text = [NSString stringWithFormat:@"%@",[Record valueForKey:@"AreaName"]];
                       
                        
                        color =  catColour;
                        NSString *availacnt =[Record valueForKey:@"Available"];
                        int count = [availacnt intValue];
                        if(count<0)
                        {
                            count = 0;
                        }
                        else count = count;
                        cell.Avialable.text =[NSString stringWithFormat:@"Available:%d",count];
                         cell.categoryType.textColor = catColour;
                        
                        
                        cell.priceLabel.text = @"Price :";
//                        NSMutableAttributedString *actual=[[NSMutableAttributedString alloc]initWithString:[NSString stringWithFormat:@"%@ %@",CURRENCY_SYMBOL,[Record valueForKey:@"ActualPrice"]]];
//                        [actual addAttribute:NSStrikethroughStyleAttributeName value:[NSNumber numberWithInt:2] range:NSMakeRange(0,[actual length])];
                        cell.Price.text = [NSString stringWithFormat:@"%@ %@",CURRENCY_SYMBOL,[Record valueForKey:@"Price"]];
                        
                          // cell.Price.text = [NSString stringWithFormat:@" -"];
                        
                       // cell.Price.hidden= YES;
                      //  cell.deliverylabel.hidden= YES;
                      //  cell.priceLabel.hidden= YES;
                    }
                    else if([category isEqualToString:PROFESSIONALHELP])
                    {
                        cell.opportunity.text =[NSString stringWithFormat:@"%@",[Record valueForKey:@"OpportunityName"]];
                        cell.description.text = [NSString stringWithFormat:@"%@",[Record valueForKey:@"OpportunityDescription"]];
                        cell.Location.text = [NSString stringWithFormat:@"%@",[Record valueForKey:@"AreaName"]];
                        
                        color = catColour;
                        NSString *availacnt =[Record valueForKey:@"Available"];
                        int count = [availacnt intValue];
                        if(count<0)
                        {
                            count = 0;
                        }
                        else count = count;
                        cell.Avialable.text =[NSString stringWithFormat:@"Available:%d",count];
                       cell.categoryType.textColor = catColour;
                         //  cell.Price.text = [NSString stringWithFormat:@" -"];
                        
                      //  cell.Price.hidden= YES;
                      //  cell.deliverylabel.hidden= YES;
                      //  cell.priceLabel.hidden= YES;

                    }
                    
                    else if([category isEqualToString:BANKING])
                    {
                        cell.opportunity.text =[NSString stringWithFormat:@"%@",[Record valueForKey:@"OpportunityName"]];
                        cell.description.text = [NSString stringWithFormat:@"%@",[Record valueForKey:@"OpportunityDescription"]];
                        cell.Location.text = [NSString stringWithFormat:@"%@",[Record valueForKey:@"AreaName"]];
                        
                        //[cell.blockBtn setBackgroundColor : catColour];
                        color = catColour;
                        NSString *availacnt =[Record valueForKey:@"Available"];
                        int count = [availacnt intValue];
                        if(count<0)
                        {
                            count = 0;
                        }
                        else count = count;
                        cell.Avialable.text =[NSString stringWithFormat:@"Available:%d",count];
                         cell.categoryType.textColor = catColour;
                          // cell.Price.text = [NSString stringWithFormat:@" -"];
                    
                        
                       // cell.Price.hidden= YES;
                       // cell.deliverylabel.hidden= YES;
                       // cell.priceLabel.hidden= YES;

                    }
                    
                    
                    
                    else if([category isEqualToString:SPORTS])
                    {
                        cell.opportunity.text =[NSString stringWithFormat:@"%@",[Record valueForKey:@"OpportunityName"]];
                        cell.description.text = [NSString stringWithFormat:@"%@",[Record valueForKey:@"OpportunityDescription"]];
                        cell.Location.text = [NSString stringWithFormat:@"%@",[Record valueForKey:@"AreaName"]];
                       
                        color =  catColour;
                        NSString *availacnt =[Record valueForKey:@"Available"];
                        int count = [availacnt intValue];
                        if(count<0)
                        {
                            count = 0;
                        }
                        else count = count;
                        cell.Avialable.text =[NSString stringWithFormat:@"Available:%d",count];
                        cell.categoryType.textColor = catColour;
                          // cell.Price.text = [NSString stringWithFormat:@" -"];
                        
                        
                       // cell.Price.hidden= YES;
                       // cell.deliverylabel.hidden= YES;
                       // cell.priceLabel.hidden= YES;

                    }
                    
                    
                    else if([category isEqualToString:TRAVELS])
                    {
                        
                        NSArray *offername = [[Record valueForKey:@"OpportunityName"] componentsSeparatedByString:@"to"];
                        
                        NSArray *first = [[offername objectAtIndex:0] componentsSeparatedByString:@","];
                        NSArray *second = [[offername objectAtIndex:1] componentsSeparatedByString:@","];
                        cell.opportunity.text =[NSString stringWithFormat:@"From : %@  To : %@",[first objectAtIndex:0],[second objectAtIndex:0]];
                        [cell.opportunity setFont:[UIFont fontWithName:@"Roboto-Bold" size:14]];
                        
                        
                        cell.description.text = [NSString stringWithFormat:@"%@",[Record valueForKey:@"OpportunityDescription"]];
                        cell.Location.text = [NSString stringWithFormat:@"%@",[Record valueForKey:@"AreaName"]];
                       
                        color = catColour;
                        NSString *availacnt =[Record valueForKey:@"Available"];
                        int count = [availacnt intValue];
                        if(count<0)
                        {
                            count = 0;
                        }
                        else count = count;
                        cell.Avialable.text =[NSString stringWithFormat:@"Available:%d",count];
                        cell.Price.text = [NSString stringWithFormat:@"%@ %@",CURRENCY_SYMBOL,[Record valueForKey:@"Price"]];
                        
                         cell.categoryType.textColor = catColour;
                           cell.priceLabel.text = @"Price :";
                    
                    
                    
                    }
                    
                    else if ([category isEqualToString:REALESTATE])
                    {
                        cell.opportunity.text =[NSString stringWithFormat:@"%@",[Record valueForKey:@"OpportunityName"]];
                        cell.description.text = [NSString stringWithFormat:@"%@",[Record valueForKey:@"OpportunityDescription"]];
                        //cell.Location.text = [NSString stringWithFormat:@"%@",[Record valueForKey:@"AreaName"]];
               
                        color = catColour;
                        
                        
                    //    NSArray *subcat = [[Record valueForKey:@"OpportunityKeywords"] componentsSeparatedByString:@","];
                        
                        

                        NSString *availacnt =[Record valueForKey:@"Available"];
                        int count = [availacnt intValue];
                        if(count<0)
                        {
                            count = 0;
                        }
                        else count = count;
                        cell.Avialable.text =[NSString stringWithFormat:@"Available:%d",count];
                         cell.Location.text = [NSString stringWithFormat:@"%@",[Record valueForKey:@"AreaName"]];
                        
                      
//                        cell.value.text =[NSString stringWithFormat:@"Value:%@",[Record valueForKey:@"Price"]];
//                        [cell.value sizeToFit];
                        
                        
                         cell.categoryType.textColor = catColour;
                        cell.Price.text = [NSString stringWithFormat:@"%@ %@",CURRENCY_SYMBOL,[Record valueForKey:@"Price"]];
                        
                        cell.priceLabel.text =@"Value";
                        
                    //    cell.Price.hidden= YES;
                        cell.deliverylabel.hidden= YES;
                      //  cell.priceLabel.hidden= YES;

                    
                        
                        
                    }
                    
                    
                    else if ([category isEqualToString:HEALTH])
                    {
                        cell.opportunity.text =[NSString stringWithFormat:@"%@",[Record valueForKey:@"OpportunityName"]];
                        cell.description.text = [NSString stringWithFormat:@"%@",[Record valueForKey:@"OpportunityDescription"]];
                        cell.Location.text = [NSString stringWithFormat:@"%@",[Record valueForKey:@"AreaName"]];
                        
                        color =  catColour;
                        cell.Avialable.text =[NSString stringWithFormat:@"Available:%@",[Record valueForKey:@"Available"]];
                        cell.categoryType.textColor = catColour;
                        
                        
                        cell.Price.hidden= YES;
                        cell.deliverylabel.hidden= YES;
                        cell.priceLabel.hidden= YES;

                    
                    }
                    
                    [cell.Timer setTextColor:color];
                    
                    if ([[Record valueForKey:@"OppStatus"] isEqualToString:@"Live"]) {
                        NSString *satrtDate = [NSString stringWithFormat:@"%@",[Record valueForKey:@"EndDate"]];
                        
                        NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
                        [dateFormatter setDateFormat:@"yyyy-MM-dd'T'HH:mm:ss"];
                        NSTimeZone *gmt = [NSTimeZone timeZoneWithAbbreviation:@"UTC"];
                        [dateFormatter setTimeZone:gmt];
                        NSDate *date5 = [dateFormatter dateFromString:satrtDate];
                        
                        NSDictionary *startOffer;
                        if (date5!=nil) {
                            startOffer= [mTimePreference remaningTime:[NSDate date] endDate:date5];
                        }
                        else{
                            
                            NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
                            [dateFormatter setDateFormat:@"yyyy-MM-dd'T'HH:mm:ss.SSS"];
                            
                            NSTimeZone *gmt = [NSTimeZone timeZoneWithAbbreviation:@"UTC"];
                            [dateFormatter setTimeZone:gmt];
                            NSDate *date5 = [dateFormatter dateFromString:satrtDate];
                            startOffer= [mTimePreference remaningTime:[NSDate date] endDate:date5];
                            
                        }
                        
                        
                        int Remaingtyime = [[startOffer valueForKey:@"Time"] intValue];
                        int hour = [[startOffer valueForKey:@"Hour"] intValue];
                        int seconds = [[startOffer valueForKey:@"Seconds"] intValue];
                        if (seconds!=0) {
                            Remaingtyime = Remaingtyime+(seconds/60);
                        }
                        if(Remaingtyime!=0)
                        {
                            
                            Remaingtyime = Remaingtyime+(hour*60);//+minutes;
                            
                            Remaingtyime = Remaingtyime;
                            
                            NSString *userBlock =[NSString stringWithFormat:@"%@",[Record valueForKey:@"BlockId"]];
                            if (![userBlock isEqualToString:@"0"] && [[Record valueForKey:@"OppStatus"] isEqualToString:@"Live"]) {
                                cell.blockBtn.tag= 1;
                                
                                
                                if ([[Record valueForKey:@"BlockText"] isEqualToString:@"UnBlock"]) {
                                    [cell.blockBtn setImage:[UIImage imageNamed:blockIcon] forState:UIControlStateNormal];
                                    
                                }
                                else if([[Record valueForKey:@"BlockText"] isEqualToString:@"Blocked"])
                                {
                                    [cell.blockBtn setImage:[UIImage imageNamed:stopIcon] forState:UIControlStateNormal];
                                    
                                }
                                
                                else if([[Record valueForKey:@"BlockText"] isEqualToString:@"Claimed"])
                                {
                                    [cell.blockBtn setImage:[UIImage imageNamed:claimIcon] forState:UIControlStateNormal];
                                   cell.blockBtn.userInteractionEnabled = NO;
                                    
                                }
                                
                              
                            }
                            else if([userBlock isEqualToString:@"0"] && [[Record valueForKey:@"OppStatus"] isEqualToString:@"Live"])
                            {
                                //  [self.bLockBtn setBackgroundColor:[UIColor greenColor]];
                                [cell.blockBtn setImage:[UIImage imageNamed:blockIcon] forState:UIControlStateNormal];
                                
                                
                            }
                            else if ([[Record valueForKey:@"OppStatus"] isEqualToString:@"Expired"])
                            {
                                [cell.blockBtn setImage:[UIImage imageNamed:notifyIcon] forState:UIControlStateNormal];
                                
                                if([[Record valueForKey:@"BlockText"] isEqualToString:@"Claimed"])
                                {
                                    [cell.blockBtn setImage:[UIImage imageNamed:claimIcon] forState:UIControlStateNormal];
                                   cell.blockBtn.userInteractionEnabled = NO;
                                    
                                }
                                else if ([[Record valueForKey:@"BlockText"] isEqualToString:@"Notify"])
                                {
                                    [cell.blockBtn setImage:[UIImage imageNamed:notifedIcon] forState:UIControlStateNormal];
                                    cell.blockBtn.enabled = NO;
                                }
                                
                            }
                            
                            [cell.blockBtn addTarget:self action:@selector(Block:) forControlEvents:UIControlEventTouchUpInside];
                            //[cell addSubview:blockBtn];
                            
                            TimeCoutDown = [[MZTimerLabel alloc] initWithLabel:cell.Timer andTimerType:MZTimerLabelTypeTimer];
                            [TimeCoutDown setCountDownTime:Remaingtyime*60];
                            [TimeCoutDown start];
                        }
                        
                        
                        
                        
                        NSString *RegisterID =   [mPref objectForKey:USERREGISTERID];
                        if (RegisterID == [Record valueForKey:@"UserRegisterId"])
                        {
                            cell.blockBtn.hidden= YES;
                            
                        }
                        
                        
                        
                    }
                    else if ([[Record valueForKey:@"OppStatus"] isEqualToString:@"Expired"])
                    {
                        
                        
                        
                        
                        
                        NSString *RegisterID =   [mPref objectForKey:USERREGISTERID];
                        if (RegisterID == [Record valueForKey:@"UserRegisterId"])
                        {
                            cell.blockBtn.hidden= YES;
                            
                        }
                        
                        cell.Timer.text = @"Expired!!";
                      //  CGSize siz =CGSizeMake(63, 45);
                        //UIImage  *image=   [mTimecalculator image:[UIImage imageNamed:notifyIcon] scaledToSize:siz];
                        
                        [cell.blockBtn setImage:[UIImage imageNamed:notifyIcon]  forState:UIControlStateNormal];
                        
                        if (![[Record valueForKey:@"BlockText"] isEqualToString:@"Notify"]) {
                            [cell.blockBtn setImage:[UIImage imageNamed:notifyIcon] forState:UIControlStateNormal];
                        }

                        
                        if ([[Record valueForKey:@"BlockText"] isEqualToString:@"Notify"])
                        {
                            [cell.blockBtn setImage:[UIImage imageNamed:notifedIcon] forState:UIControlStateNormal];
                            //cell.blockBtn.enabled = NO;
                        }
                        
                        
                     
                        
                        [cell.blockBtn addTarget:self action:@selector(Block:) forControlEvents:UIControlEventTouchUpInside];
                    }
                   
                    NSString *imageName = [NSString stringWithFormat:@"%@",[Record valueForKey:@"PhotoName"]];;
                    NSArray *imageAry = [imageName componentsSeparatedByString:@","];
                    NSString *ImageURL = [NSString stringWithFormat:@"%@%@",baseImageURL, [imageAry objectAtIndex:0]];
                    
                    if ([[imageAry objectAtIndex:0] isEqualToString:@""]) {
                        
                        imageName = [NSString stringWithFormat:@"%@",[Record valueForKey:@"CategoryImage"]];;
                        ImageURL = [NSString stringWithFormat:@"%@%@",baseImageURL, imageName];
                        
                        NSURL *imageURL = [NSURL URLWithString:ImageURL];
                        NSString *key = [ImageURL MD5Hash];
                        NSData *getData = [FTWCache objectForKey:key];
                        if (getData) {
                            UIImage *image = [UIImage imageWithData:getData];
                            cell.OpportunityImage.image  = image;
                        }
                        else {
                            cell.OpportunityImage.image  = [UIImage imageNamed:@"img_def"];
                            dispatch_queue_t queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_HIGH, 0ul);
                            dispatch_async(queue, ^{
                                NSData *newData = [NSData dataWithContentsOfURL:imageURL];
                                [FTWCache setObject:newData forKey:key];
                                UIImage *image = [UIImage imageWithData:newData];
                                dispatch_sync(dispatch_get_main_queue(), ^{
                                    cell.OpportunityImage.image  = image;
                                    
                                });
                            });
                        }
                        
                    }
                    
                    else {
                        
                        NSURL *imageURL = [NSURL URLWithString:ImageURL];
                        NSString *key = [ImageURL MD5Hash];
                        NSData *getData = [FTWCache objectForKey:key];
                        if (getData) {
                            UIImage *image = [UIImage imageWithData:getData];
                            cell.OpportunityImage.image  = image;
                        }
                        else {
                            cell.OpportunityImage.image  = [UIImage imageNamed:@"img_def"];
                            dispatch_queue_t queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_HIGH, 0ul);
                            dispatch_async(queue, ^{
                                NSData *newData = [NSData dataWithContentsOfURL:imageURL];
                                [FTWCache setObject:newData forKey:key];
                                UIImage *image = [UIImage imageWithData:newData];
                                dispatch_sync(dispatch_get_main_queue(), ^{
                                    cell.OpportunityImage.image  = image;
                                    
                                });
                            });
                        }
                        
                    }
                    UITapGestureRecognizer *singleTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(ImageTap:)];
                    singleTap.numberOfTapsRequired = 1;
                    [cell.OpportunityImage setUserInteractionEnabled:YES];
                    [cell.OpportunityImage addGestureRecognizer:singleTap];
                    
                  
                    
                    
                    return cell;

                    
                    
                }
                
            
            }
            else if (tableView==autoComplete)
            {
                
                static NSString *CellIdentifier = @"Cell";
                // Reuse and create cell
                UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
                if (cell == nil) {
                    cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
                }
                NSString *Addreline = [autocompleteUrls objectAtIndex:indexPath.row];
                cell.textLabel.text = Addreline;
                return cell;
            }
            
            
            else if(tableView == table)
            {
                static NSString *CellIdentifier = @"Cell";
                // Reuse and create cell
                UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
                if (cell == nil) {
                    cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
                }
               NSString *Addreline = [[radiousArray objectAtIndex:indexPath.row] valueForKey:@"Value"];;
               
                cell.textLabel.text = Addreline;
                [cell.textLabel sizeToFit];
                [cell.textLabel setTextAlignment:NSTextAlignmentLeft];
                return cell;
            }
            
            
            
            return cell;
            
        }
        else if (!isOnlineStatus)
        {
            [self showAlertPop:@"No internet connection" expObj:nil];
        }
        
        
    }
    @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
}





- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
    
    @try {
        
        
        
        if (tableView == opportunityTable) {
            
            [mPref setValue:Key forKey:@"Key"];
            
            NSDictionary *SelectedItem = [GetOffers objectAtIndex:indexPath.section];
            // [self saveViewOpprtunity:SelectedItem];
            
            
            //
            //                                       Details_FoodAndSales *mDetails = [[Details_FoodAndSales alloc]initWithNibName:@"Details_FoodAndSales" bundle:nil];
            
            
            if([category isEqualToString:FOOD]||[category isEqualToString:SALES] ){
                
                
                //if ([[category valueForKey:FOOD] isEqualToString:FOOD] || [[category valueForKey:SALES] isEqualToString:SALES]) {
                
                
                Details_FoodAndSales *mDetails = [Details_FoodAndSales alloc];
                mDetails.SetSelectedOpportunity =SelectedItem;
                mDetails.Pagekey= @"ListCategory";
                
                Details_FoodAndSales *mDetailFoodandsale =[mDetails initWithNibName:@"Details_FoodAndSales" bundle:nil];
                [self presentViewController:mDetailFoodandsale animated:YES completion:nil];
            }
            
            //  }
            
            else if([category isEqualToString:PROFESSIONALHELP] || [category isEqualToString:BANKING])
            {
                
                Details_Events_Help_Banking *mDetails = [Details_Events_Help_Banking alloc];
                mDetails.SetSelectedOpportunity =SelectedItem;
                mDetails.setSelectedCategory =category;
                mDetails.Pagekey= @"ListCategory";
                
                Details_Events_Help_Banking *mDetailFoodandsale =[mDetails initWithNibName:@"Details_Events_Help_Banking" bundle:nil];
                [self presentViewController:mDetailFoodandsale animated:YES completion:nil];
            }
            
            else   if([category isEqualToString:TRAVELS]){
                
                
                //if ([[category valueForKey:FOOD] isEqualToString:FOOD] || [[category valueForKey:SALES] isEqualToString:SALES]) {
                
                
                Details_Travels *mDetails = [Details_Travels alloc];
                mDetails.SetSelectedOpportunity =SelectedItem;
                mDetails.Pagekey= @"ListCategory";
                
                Details_Travels *mDetailFoodandsale =[mDetails initWithNibName:@"Details_Travels" bundle:nil];
                [self presentViewController:mDetailFoodandsale animated:YES completion:nil];
            }
            
            else if ([category isEqualToString:REALESTATE])
            {
                
                
                Details_RealEstate *mDetails = [Details_RealEstate alloc];
                mDetails.SetSelectedOpportunity =SelectedItem;
                mDetails.Pagekey= @"ListCategory";
                
                Details_RealEstate *mDetailFoodandsale =[mDetails initWithNibName:@"Details_RealEstate" bundle:nil];
                [self presentViewController:mDetailFoodandsale animated:YES completion:nil];
                
                
            }
            
            
            else if ([category isEqualToString:JOBS] ||[category isEqualToString:SPORTS]|| [category isEqualToString:MEETINGS])
            {
                
                
                Details_GameandJobs *mDetails = [Details_GameandJobs alloc];
                mDetails.SetSelectedOpportunity =SelectedItem;
                mDetails.Pagekey= @"ListCategory";
                
                Details_GameandJobs *mDetailFoodandsale =[mDetails initWithNibName:@"Details_GameandJobs" bundle:nil];
                [self presentViewController:mDetailFoodandsale animated:YES completion:nil];
                
            }
            else if ( [category isEqualToString:HEALTH])
            {
                Details_Health *mDetails = [Details_Health alloc];
                mDetails.SetSelectedOpportunity =SelectedItem;
                mDetails.Pagekey= @"ListCategory";
                
                Details_Health *mDetailFoodandsale =[mDetails initWithNibName:@"Details_Health" bundle:nil];
                [self presentViewController:mDetailFoodandsale animated:YES completion:nil];
                
            }
            
        }
        
        else  if(tableView == autoComplete)
        {
            NSString *selectedAdress = [autocompleteUrls objectAtIndex:indexPath.row];
            [mPref setValue:selectedAdress forKey:@"StoredAddress"];
            
            searchText.text = selectedAdress;
            autoComplete.hidden= YES;
            [searchText resignFirstResponder];
            [self viewDidLoad];
            
        }
        
        else if (tableView== table)
        {
            table.hidden= YES;
            NSString   *selectedRadius =[[radiousArray objectAtIndex:indexPath.row] valueForKey:@"Radious"];
            [mPref setValue:selectedRadius forKey:@"TempRadius"];
            [self StoreRadios:selectedRadius];
            
           // table.hidden=YES;
            
            
        }
        
        
    }
    @catch (NSException *exception) {
        
    }
    @finally {
        
    }
}


-(void)ImageTap:(UIPinchGestureRecognizer *)recognizer{
    
    @try {
        
        
        UIImageView *tableGridImage = (UIImageView*)recognizer.view;
        [self customimageAlert:tableGridImage];
        
        
        
    } @catch (NSException *exception) {
        
    } @finally {
        
    }
    
    //ImageAlert = [CustomIOSAlertView ]
}


-(void)customimageAlert:(UIImageView*)tableGridImage
{
    @try {
        
        
        ImageAlert=[[CustomIOSAlertView alloc] init];
        UIView  *imageView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 300, 200)];
        [ImageAlert setContainerView:imageView];
        [ImageAlert setButtonTitles:[NSMutableArray arrayWithObjects:@"", nil]];
        
        [ImageAlert setDelegate:self];
        
        
        // You may use a Block, rather than a delegate.
        [ImageAlert setOnButtonTouchUpInside:^(CustomIOSAlertView *alertView, int buttonIndex) {
            NSLog(@"Block: Button at position %d is clicked on alertView %d.", buttonIndex, (int)[alertView tag]);
            [alertView close];
        }];
        
        [ImageAlert setUseMotionEffects:true];
        
        UIButton *cancel = [[UIButton alloc]initWithFrame:CGRectMake(275, 0, 20, 20)];
        
        [cancel setImage:[UIImage imageNamed:@"ic_close"] forState:UIControlStateNormal];
        [cancel addTarget:self action:@selector(cancel:) forControlEvents:UIControlEventTouchUpInside];
        
        
        UIImageView *VendorProfile = [[UIImageView alloc]initWithImage:tableGridImage.image];
        VendorProfile.frame = CGRectMake(0, 20, 300, 230);
        [imageView addSubview:cancel];
        [imageView addSubview:VendorProfile];
        
        [ImageAlert show];
        ImageAlert.tag = 2;
    }
    @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
}


-(void)cancel:(UIButton*)sender
{
    [ImageAlert close];
}


-(void)saveViewOpprtunity:(NSDictionary*)Offer
{
    @try {
        
        if (isOnlineStatus) {
            
            
            
           
            
            
            NSMutableDictionary *dic = [[NSMutableDictionary alloc]init];
            [dic setObject:[Offer valueForKey:@"OpportunityID"] forKey:@"OpportunityID"];
            [dic setObject:@"0" forKey:@"UserID"];
            [webService SaveUserViewedOpportunities:dic];
        }
        
        else if (!isOnlineStatus)
        {
            [self showAlertPop:@"No internet connection" expObj:nil];
        }
    }
    @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
}

-(void)Block:(UIButton*)sender
{
    
    
    @try {
        
        if (isOnlineStatus) {
            
            
            spinner = [[UIActivityIndicatorView alloc]
                       initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
            spinner.frame = CGRectMake(0, 0, 320, 560); // CGPointMake(160, 240);
            spinner.color = [UIColor blueColor];
            spinner.backgroundColor = [UIColor lightTextColor];
            spinner.transform = CGAffineTransformMakeScale(2, 2);
            // spinner.hidesWhenStopped = YES;
            [self.view addSubview:spinner];
            spinner.transform = CGAffineTransformMakeScale(2, 2);
            
            [spinner startAnimating];
            
            // how we stop refresh from freezing the main UI thread
            
            dispatch_async(
                           dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^{
                               
                               // back to the main thread for the UI call
                               dispatch_async(dispatch_get_main_queue(), ^{
                                   [spinner startAnimating];
                               });
                               dispatch_async(dispatch_get_main_queue(), ^{
                                   NSUserDefaults *prefss = [NSUserDefaults standardUserDefaults];
                                   
                                   CGPoint buttonPosition = [sender convertPoint:CGPointZero toView:opportunityTable];
                                   
                                   
                                   
                                   NSIndexPath *indexPath = [opportunityTable indexPathForRowAtPoint:buttonPosition];
                                   
                                   
                                   
                                   NSDictionary *BlockedItem = [GetOffers objectAtIndex:indexPath.section];
                                   NSString *RegisterID =   [prefss objectForKey:USERREGISTERID];
                                   
                                   if (RegisterID!=[BlockedItem valueForKey:@"UserRegisterId"] && RegisterID!=nil) {
                                       
                                       
                                       NSInteger availablecoutn = [[BlockedItem valueForKey:@"Available"] intValue];
                                       
                                       if (availablecoutn >= 1) {
                                           
                                           if([[BlockedItem valueForKey:@"OppStatus"] isEqualToString:@"Expired"])
                                           {
                                               UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"Right Place Right Time"
                                                                                                              message:@"Sorry! It's expired. Please click on notify to get notified in future."
                                                                                                       preferredStyle:UIAlertControllerStyleAlert];
                                               
                                               UIAlertAction* ok = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault
                                                                                          handler:^(UIAlertAction * action) {
                                                                                              
                                                                                              [self blockorNotify:buttonPosition];
                                                                                              
                                                                                          }];
                                               UIAlertAction* cancel = [UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleDefault
                                                                                              handler:^(UIAlertAction * action) {
                                                                                                  [alert dismissViewControllerAnimated:YES completion:nil];
                                                                                                  
                                                                                                  
                                                                                              }];
                                               
                                               [alert addAction:ok];
                                               [alert addAction:cancel];
                                               [self presentViewController:alert animated:YES completion:nil];
                                           }
                                           else
                                           {
                                               [self blockorNotify:buttonPosition];
                                               
                                           }
                                           
                                       }
                                       else
                                       {
                                           
                                               [self blockorNotify:buttonPosition];
                                               
                                        
                                       }
                                       
                                   }
                                   
                                   else if (RegisterID == [BlockedItem valueForKey:@"UserRegisterId"])
                                   {
                                       UIAlertController * login=   [UIAlertController
                                                                     alertControllerWithTitle:@"RPRT"
                                                                     message:@"Unable to Reserve the Offer"
                                                                     preferredStyle:UIAlertControllerStyleAlert];
                                       
                                       UIAlertAction* yesButton = [UIAlertAction
                                                                   actionWithTitle:@"OK"
                                                                   style:UIAlertActionStyleDefault
                                                                   handler:^(UIAlertAction * action)
                                                                   {
                                                                       [login dismissViewControllerAnimated:YES completion:nil];
                                                                       
                                                                       //[self dismissViewControllerAnimated:alert completion:nil];
                                                                   }];
                                       
                                       [login addAction:yesButton];
                                       
                                       
                                       //[self dismissViewControllerAnimated:YES completion:nil];
                                       [self presentViewController:login animated:YES completion:nil];
                                   }
                                   
                                   else if(RegisterID ==nil) {
                                       UIAlertController * alert=   [UIAlertController
                                                                     alertControllerWithTitle:@"RPRT"
                                                                     message:@"Please Register/Login"
                                                                     preferredStyle:UIAlertControllerStyleAlert];
                                       
                                       UIAlertAction* yesButton = [UIAlertAction
                                                                   actionWithTitle:@"OK"
                                                                   style:UIAlertActionStyleDefault
                                                                   handler:^(UIAlertAction * action)
                                                                   {
                                                                       [mPref setObject:@"List" forKey:@"PageName"];

                                                                       self.popViewController = [[PopUpViewController alloc] initWithNibName:@"PopUpViewController" bundle:nil];
                                                                       [self.popViewController setTitle:@"This is a popup view"];
                                                                       
                                                                       [self.popViewController showInView:self.view withImage:[UIImage imageNamed:@"rprt_usinfo.png"] withMessage:@"You just triggered a great popup window" animated:YES];
                                                                       
                                                                       
//                                                                       Login * mLogin = [[ Login alloc] initWithNibName:LOGIN bundle:nil];
//                                                                       [self presentViewController:mLogin animated:YES completion:nil];
                                                                       
                                                                       //[self dismissViewControllerAnimated:alert completion:nil];
                                                                   }];
                                       
                                       UIAlertAction* cancelBtn = [UIAlertAction
                                                                   actionWithTitle:@"Cancel"
                                                                   style:UIAlertActionStyleDefault
                                                                   handler:^(UIAlertAction * action)
                                                                   {
                                                                       //Handel your yes please button action here
                                                                       [self dismissViewControllerAnimated:alert completion:nil];
                                                                   }];
                                       
                                       
                                       
                                       [alert addAction:yesButton];
                                       [alert addAction:cancelBtn];
                                       
                                       
                                       [self presentViewController:alert animated:YES completion:nil];
                                       
                                   }
                                   
                                   [spinner stopAnimating];
                                   
                               });
                           });
        }
        else if (!isOnlineStatus)
        {
            [self showAlertPop:@"No internet connection" expObj:nil];
        }
        
    }
    @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
}

-(void)blockorNotify:(CGPoint)buttonPosition
{
    @try {
        
        if (isOnlineStatus) {
            
            NSIndexPath *indexPath = [opportunityTable indexPathForRowAtPoint:buttonPosition];
            NSDictionary *BlockedItem = [GetOffers objectAtIndex:indexPath.section];
            NSString *RegisterID =   [mPref objectForKey:USERREGISTERID];
            NSMutableDictionary *dic = [[NSMutableDictionary alloc]init];
            NSString *uniqueIdentifier = [[[UIDevice currentDevice] identifierForVendor] UUIDString];
            [dic setValue:[BlockedItem valueForKey:@"OpportunityID"] forKey:@"OpportunityId"];
            //[dic setValue:[BlockedItem valueForKey:@"KeyValue"] forKey:@"KeyValue"];
            
            if ([[BlockedItem valueForKey:@"OppStatus"] isEqualToString:@"Expired"])
            {
                [dic setValue:@"Notify" forKey:@"BlockText"];
                [dic setValue:@"0" forKey:@"BlockId"];
                [dic setValue:@"0" forKey:@"Quantity"];
            }
            
            
           else if ([[BlockedItem valueForKey:@"BlockId"] intValue] ==0 && [[BlockedItem valueForKey:@"OppStatus"] isEqualToString:@"Live"]) {
                [dic setValue:@"Blocked" forKey:@"BlockText"];
                [dic setValue:@"0" forKey:@"BlockId"];
               [dic setValue:@"1" forKey:@"Quantity"];
               if([category isEqualToString:HEALTH] || [category isEqualToString:REALESTATE] || [category isEqualToString:PROFESSIONALHELP] ||
                  [category isEqualToString:BANKING])
               {
                   [dic setValue:@"0" forKey:@"Quantity"];
               }

            }
          
            else if ([[BlockedItem valueForKey:@"BlockId"] intValue] !=0 && [[BlockedItem valueForKey:@"OppStatus"] isEqualToString:@"Live"])
            {
                
                if ([[BlockedItem valueForKey:@"BlockText"] isEqualToString:@"UnBlock"]) {
                    
                    [dic setValue:@"Blocked" forKey:@"BlockText"];
                    [dic setValue:[BlockedItem valueForKey:@"BlockId"] forKey:@"BlockId"];
                    [dic setValue:@"1" forKey:@"Quantity"];
                    if([category isEqualToString:HEALTH] || [category isEqualToString:REALESTATE] || [category isEqualToString:PROFESSIONALHELP] ||
                       [category isEqualToString:BANKING])
                    {
                        [dic setValue:@"0" forKey:@"Quantity"];
                    }

                }
                else if ([[BlockedItem valueForKey:@"BlockText"] isEqualToString:@"Blocked"])
                {
                    [dic setValue:@"UnBlock" forKey:@"BlockText"];
                    [dic setValue:[BlockedItem valueForKey:@"BlockId"] forKey:@"BlockId"];
                    [dic setValue:@"0" forKey:@"Quantity"];

                }
            }
            
            
            
            
            [dic setValue:uniqueIdentifier forKey:@"DeviceId"];
            [dic setValue:RegisterID forKey:@"BlockedUserId"];
            //
            [dic setValue:@""  forKey:@"ClaimedTime"];
            [dic setValue:@"" forKey:@"TransactionComplete"];
              NSString *keyValue = [NSString stringWithFormat:@"RPRT-%@-%@-%@",[BlockedItem valueForKey:@"OpportunityID"],RegisterID,[BlockedItem valueForKey:@"UserRegisterId"]];
            [dic setValue:keyValue forKey:@"KeyValue"];
            
            // NSString *OfferName =[NSString stringWithFormat:@"The selected %@ was blocked", [BlockedItem valueForKey:@"VendorName"]];
            NSDictionary *blockeditemResponse =[mWebService SaveBlockeditem:dic];
            if ((blockeditemResponse!=nil)) {
                
                  NSString * erroeMessage =[blockeditemResponse valueForKey:@"ErrorMessage"];
                
                if ( ( ![erroeMessage isEqual:[NSNull null]] ) && ( [erroeMessage length] != 0 ) ) {
                      [self showAlertPop:erroeMessage expObj:nil];
                }
                
                if (( [erroeMessage isEqual:[NSNull null]])) {
                    
                    
                    if ([[blockeditemResponse valueForKey:@"BlockText"] isEqualToString:@"Blocked"]) {
                        [self showAlertPop:@"Your request is placed, please be on time!!" expObj:nil];
                        
                    }
                    else if ([[blockeditemResponse valueForKey:@"BlockText"] isEqualToString:@"UnBlock"]) {
                        [self showAlertPop:@"Your Opportunities request is cancelled!" expObj:nil];
                        
                    }
                    
                    else if ([[blockeditemResponse valueForKey:@"BlockText"] isEqualToString:@"Notify"])
                    {
                        [self showAlertPop:@"This Opportunities will Notify you" expObj:nil];
                    }
                    
                }
                
                
              
                
                CGFloat imageSize = ceilf(self.view.bounds.size.width * 0.6f);
                UIImageView *imageView = [[UIImageView alloc] initWithFrame:CGRectMake(floorf(self.view.bounds.size.width * 0.5f - imageSize * 0.5f), floorf(self.view.bounds.size.height * 0.5f - imageSize * 0.5f), imageSize, imageSize)];
                // [viewController.view addSubview:imageView];
                
                [NSTimer scheduledTimerWithTimeInterval:1.0
                                                 target:self
                                               selector:@selector(doSomethingWhenTimeIsUp)
                                               userInfo:nil
                                                repeats:NO];
                
                imageView.image = [UIImage mdQRCodeForString:[blockeditemResponse valueForKey:@"keyValue"] size:imageView.bounds.size.width fillColor:[UIColor darkGrayColor]];
                
            }
        }
        else if (!isOnlineStatus)
        {
            [self showAlertPop:@"No internet connection" expObj:nil];
        }
        
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
    
}

-(void)doSomethingWhenTimeIsUp
{
    @try {
        [self viewDidLoad];
        
    }
    @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
}


-(NSDictionary*)getMyblocks
{
    @try {
        
        if (isOnlineStatus) {
            
            
            
            if ([mPref valueForKey:USERREGISTERID] !=nil) {
                
                NSString *ids = [mPref valueForKey:USERREGISTERID];
                NSDictionary   *GetBlocks = [[Web_Services GetSharedInstance]GetOpportinityReview:ids MethodName:GETRESERVEDOPPORTUNITIESBYUSERID];
                
                return GetBlocks;
                
            }
            else
            {
                return 0;
            }
        }
        else if (!isOnlineStatus)
        {
            [self showAlertPop:@"No internet connection" expObj:nil];
        }
        
        
    }
    @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
}

#pragma mark - floatMenuDelegate
-(void) didSelectMenuOptionAtIndex:(NSInteger)row
{
    @try {
        
        if (isOnlineStatus) {
            
            
            NSLog(@"%ld",(long)row);
            
            NSString *FloadBtsnString =[self.FloatBtn.labelArray objectAtIndex:row];
          
             if ([FloadBtsnString isEqualToString:@"Add"])
            {
                
                
                
                spinner = [[UIActivityIndicatorView alloc]
                           initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
                spinner.frame = CGRectMake(0, 0, 320, 560); // CGPointMake(160, 240);
                spinner.color = [UIColor blueColor];
                spinner.backgroundColor = [UIColor lightTextColor];
                spinner.transform = CGAffineTransformMakeScale(2, 2);
                // spinner.hidesWhenStopped = YES;
                [self.view addSubview:spinner];
                spinner.transform = CGAffineTransformMakeScale(2, 2);
                
                [spinner startAnimating];
                
                // how we stop refresh from freezing the main UI thread
                
                dispatch_async(
                               dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^{
                                   
                                   // back to the main thread for the UI call
                                   dispatch_async(dispatch_get_main_queue(), ^{
                                       [spinner startAnimating];
                                   });
                                   dispatch_async(dispatch_get_main_queue(), ^{
                                       if ([mPref valueForKey:USERREGISTERID] !=nil)
                                       {
                                           [self GotoPost];
                                       }
                                       else
                                       {
                                           [mPref setObject:@"Post" forKey:@"PageName"];
                                           
                                           self.popViewController = [[PopUpViewController alloc] initWithNibName:@"PopUpViewController" bundle:nil];
                                           [self.popViewController setTitle:@"This is a popup view"];
                                           
                                           [self.popViewController showInView:self.view withImage:[UIImage imageNamed:@"rprt_usinfo.png"] withMessage:@"You just triggered a great popup window" animated:YES];
                                       

                                           
                                           
//                                           Login *mLogin = [[Login alloc]initWithNibName:LOGIN bundle:nil];
//                                           [self presentViewController:mLogin animated:YES completion:nil];
                                       }
                                       [spinner stopAnimating];
                                       
                                   });
                               });
            }
            //FloadBtsnString rangeOfString:@"My Blocks"].location != NSNotFound)
            else if ([FloadBtsnString rangeOfString:@"My Blocks"].location != NSNotFound)
            {
                
                if ([mPref valueForKey:USERREGISTERID] !=nil) {
                    
                    MyBlocks *mMyBlocks = [[MyBlocks alloc]initWithNibName:MYBLOCKS bundle:nil];
                    [self presentViewController:mMyBlocks animated:YES completion:nil];
                }
                else
                {
                    self.popViewController = [[PopUpViewController alloc] initWithNibName:@"PopUpViewController" bundle:nil];
                    [self.popViewController setTitle:@"This is a popup view"];
                    
                    [self.popViewController showInView:self.view withImage:[UIImage imageNamed:@"rprt_usinfo.png"] withMessage:@"You just triggered a great popup window" animated:YES];
                    
                    
                    //                    Login *mLogin = [[Login alloc]initWithNibName:LOGIN bundle:nil];
//                    [self presentViewController:mLogin animated:YES completion:nil];
                }
            }
        }
        else if (!isOnlineStatus)
        {
            [self showAlertPop:@"No internet connection" expObj:nil];
        }
        
    }
    @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
}

-(void)GotoPost
{
    @try {
        
        if (isOnlineStatus) {
            
            
            
            NSString *ModuleId =[mPref valueForKey:MODULEID];
            
            if ([ModuleId isEqualToString:@"33"]) {
                Post_Food * mPosting = [[ Post_Food alloc] initWithNibName:PFOOD bundle:nil];
                [self presentViewController:mPosting animated:YES completion:nil];
                
            }
            else if ([ModuleId isEqualToString:@"34"])
            {
                // [mPref setValue:ModuleId forKey:MODULEID];
                Post_Sales * mPosting = [[ Post_Sales alloc] initWithNibName:PSALES bundle:nil];
                [self presentViewController:mPosting animated:YES completion:nil];
            }
            else if ([ModuleId isEqualToString:@"37"])
            {
                Post_Professional * mPosting = [[ Post_Professional alloc] initWithNibName:PPROFESSIONAL bundle:nil];
                [self presentViewController:mPosting animated:YES completion:nil];
            }
            else if ([ModuleId isEqualToString:@"38"])
            {
                Post_Sports * mPosting = [[ Post_Sports alloc] initWithNibName:PSPORTS bundle:nil];
                [self presentViewController:mPosting animated:YES completion:nil];
            }
            else if ([ModuleId isEqualToString:@"36"])
            {
                Post_Jobs * mPosting = [[ Post_Jobs alloc] initWithNibName:PJOBS bundle:nil];
                [self presentViewController:mPosting animated:YES completion:nil];
            }
            else if ([ModuleId isEqualToString:@"39"])
            {
                Post_Meetings * mPosting = [[ Post_Meetings alloc] initWithNibName:PMEETINGS bundle:nil];
                [self presentViewController:mPosting animated:YES completion:nil];
            }
            
            else if ([ModuleId isEqualToString:@"40"])
            {
                Post_Travels * mPosting = [[ Post_Travels alloc] initWithNibName:PTRAVELS bundle:nil];
                [self presentViewController:mPosting animated:YES completion:nil];
            }
            else if ([ModuleId isEqualToString:@"41"])
            {
                Post_RealEstate * mPosting = [[ Post_RealEstate alloc] initWithNibName:PREALESTATE bundle:nil];
                [self presentViewController:mPosting animated:YES completion:nil];
            }
            
            else if ([ModuleId isEqualToString:@"42"])
            {
                Post_banking_Finance * mPosting = [[ Post_banking_Finance alloc] initWithNibName:PBANKINGANDFINANCE bundle:nil];
                [self presentViewController:mPosting animated:YES completion:nil];
            }
            
            else if ([ModuleId isEqualToString:@"43"])
            {
                //Health_ViewPager
             //   Health_ViewPager * mPosting = [[ Health_ViewPager alloc] initWithNibName:@"Health_ViewPager" bundle:nil];
            //    [self presentViewController:mPosting animated:YES completion:nil];
                
                Post_Health * mPosting = [[ Post_Health alloc] initWithNibName:PHEALTH bundle:nil];
                [self presentViewController:mPosting animated:YES completion:nil];
            }
            
            else
            {
                self.popViewController = [[PopUpViewController alloc] initWithNibName:@"PopUpViewController" bundle:nil];
                [self.popViewController setTitle:@"This is a popup view"];
                
                [self.popViewController showInView:self.view withImage:[UIImage imageNamed:@"rprt_usinfo.png"] withMessage:@"You just triggered a great popup window" animated:YES];
                
                
//                Login * mLogin= [[ Login alloc] initWithNibName:LOGIN bundle:nil];
//                [self presentViewController:mLogin animated:YES completion:nil];
            }
        }
        else if (!isOnlineStatus)
        {
            [self showAlertPop:@"No internet connection" expObj:nil];
        }
        
    }
    @catch (NSException *exception) {
        
    }
    @finally {
        
    }
}

-(IBAction)floatButton:(id)sender
{
    spinner = [[UIActivityIndicatorView alloc]
               initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
    spinner.frame = CGRectMake(0, 0, 320, 560); // CGPointMake(160, 240);
    spinner.color = [UIColor blueColor];
    spinner.backgroundColor = [UIColor lightTextColor];
    spinner.transform = CGAffineTransformMakeScale(2, 2);
    // spinner.hidesWhenStopped = YES;
    [self.view addSubview:spinner];
    spinner.transform = CGAffineTransformMakeScale(2, 2);
    
    [spinner startAnimating];
    
    // how we stop refresh from freezing the main UI thread
    
    dispatch_async(
                   dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^{
                       
                       // back to the main thread for the UI call
                       dispatch_async(dispatch_get_main_queue(), ^{
                           [spinner startAnimating];
                       });
                       dispatch_async(dispatch_get_main_queue(), ^{
                           if ([mPref valueForKey:USERREGISTERID] !=nil)
                           {
                               [self GotoPost];
                           }
                           else
                           {
                               [mPref setObject:@"Post" forKey:@"PageName"];
                               
                               
                               self.popViewController = [[PopUpViewController alloc] initWithNibName:@"PopUpViewController" bundle:nil];
                               [self.popViewController setTitle:@"This is a popup view"];
                               
                               [self.popViewController showInView:self.view withImage:[UIImage imageNamed:@"rprt_usinfo.png"] withMessage:@"You just triggered a great popup window" animated:YES];
                               
                               
//                               Login *mLogin = [[Login alloc]initWithNibName:LOGIN bundle:nil];
//                               [self presentViewController:mLogin animated:YES completion:nil];
                           }
                           [spinner stopAnimating];
                           
                       });
                   });
}

-(void)StoreRadios:(NSString*)radious {
    @try {
        
        [Radious setTitle:radious forState:UIControlStateNormal];
        [mTimePreference StoreRadious:radious];
        [self RadiousBtnTitle];
        [self viewDidLoad];
        
    }
    @catch (NSException *exception) {
        NSLog(@"%@" , exception.description);
    }
    @finally {
        
    }
}

-(void)labelTapped {
    @try
    {
        spinner = [[UIActivityIndicatorView alloc]
                   initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
        spinner.frame = CGRectMake(0, 0, 320, 560); // CGPointMake(160, 240);
        spinner.color = [UIColor blueColor];
        spinner.backgroundColor = [UIColor lightTextColor];
        spinner.transform = CGAffineTransformMakeScale(2, 2);
        // spinner.hidesWhenStopped = YES;
        [self.view addSubview:spinner];
        spinner.transform = CGAffineTransformMakeScale(2, 2);
        
        [spinner startAnimating];
        
        // how we stop refresh from freezing the main UI thread
        
        dispatch_async(
                       dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^{ dispatch_async(dispatch_get_main_queue(), ^{
            
            [spinner startAnimating];
        });
                           dispatch_async(dispatch_get_main_queue(), ^{
                               ////Here you can update code for page nagivation
                               [self dismissViewControllerAnimated:YES completion:NULL];
                               
                               [spinner stopAnimating];
                               
                           });
                       });
        
        
        
        [self dismissViewControllerAnimated:YES completion:NULL];
        
    }
    @catch (NSException *exception) {
        
    }
    @finally {
        
    }
}


- (void) showAlertPop:(NSString*)alertText  expObj:(NSException*) exp{
    if(exp != nil)
    {
        NSLog(@"%@", exp.description);
    }
    NSLog(@"The Exception is %@",exp.description);
    UIAlertController *myAlertController =[mWebService  alert:alertText];
    [self presentViewController:myAlertController animated:YES completion:nil];
}

-(IBAction)map:(id)sender
{
    @try {
        
        table.hidden=YES;
        autoComplete.hidden=YES;
        
        [mPref setValue:@"List" forKey:@"Page"];
        
        
        Map *mMap= [Map alloc];
        mMap.SetOpportunities =GetOffers;
        
        Map *mMapview =
        [mMap initWithNibName:MAP bundle:nil];
        [self presentViewController:mMapview animated:YES completion:nil];
        
    }
    @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
}
- (IBAction)hideKeyBoardKeyWord:(id)sender {
    
    @try {
        autoComplete.hidden= YES;
        
        if ([searchText isFirstResponder]) {
            [searchText resignFirstResponder];
        }
    }
    @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    }
    @finally {
        
    }
    
}

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    [opportunityTable reloadData];
//   // [self viewDidLoad];

}

-(void)RadiousBtnTitle
{
    @try {
        NSString *btnTitle;
        
        if ([mPref valueForKey:@"TempRadius"] ==nil) {
            NSData *registerObjj = [mPref valueForKey:@"SaveRegisterDetails"];
            
            if (registerObjj!=nil) {
                NSDictionary *myDictionary =   (NSDictionary*) [NSKeyedUnarchiver unarchiveObjectWithData:registerObjj];
                
                btnTitle = [myDictionary valueForKey:@"DefaultRadius"];
                
                if (btnTitle==nil) {
                    NSString *btnTitle1 = [mPref valueForKey:@"Radious"];
                    if (btnTitle1==nil) {
                        btnTitle1 = @"500";
                        btnTitle= btnTitle1;
                    }
                    else{
                        btnTitle = btnTitle1;
                    }
                    
                }
            }
            
            else
            {
                NSString *btnTitle1 = [mPref valueForKey:@"Radious"];
                if (btnTitle1==nil) {
                    btnTitle1 = @"500";
                    btnTitle= btnTitle1;
                }
                btnTitle = btnTitle1;
                
            }
            
        }
        else
            btnTitle =[mPref valueForKey:@"TempRadius"];
       // [mPref setValue:nil forKey:@"TempRadius"];
        
        
        btnTitle = [NSString stringWithFormat:@"%@",btnTitle];
        
        
        if ([btnTitle isEqualToString:@"500"]) {
            btnTitle = @"0.5 Km";
        }
        else if ([btnTitle isEqualToString:@"1000"]) {
            btnTitle = @"1 Km";
        }
        else if ([btnTitle isEqualToString:@"3000"]) {
            btnTitle = @"3 Km";
        }
        else if ([btnTitle isEqualToString:@"5000"]) {
            btnTitle = @"5 Km";
        }
        else if ([btnTitle isEqualToString:@"10000"]) {
            btnTitle = @"10 Km";
        }
        else if(btnTitle==nil) btnTitle = @"0.5 Km";
        
        else if([btnTitle isEqualToString:@"(null)"])
        {
            btnTitle = @"0.5 Km";
            [mPref setValue:@"500" forKey:@"Radious"];
        }
        
        
        [Radious setTitle:btnTitle forState:UIControlStateNormal];
        
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
        
    } @finally {
        
    }
}

- (IBAction)selectClicked:(id)sender {
    
    @try {
        
        
        
        table = [[UITableView alloc]initWithFrame:CGRectMake(Radious.frame.origin.x+5, Radious.frame.origin.y+120, Radious.frame.size.width+12,250) style:UITableViewStylePlain];
        
        table.delegate = self;
        table.dataSource = self;
        table.scrollEnabled=NO;
        //  table.scrollEnabled = YES;
        //table.hidden = YES;
        [self.view addSubview:table];
        
        [table reloadData];
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
}
-(IBAction)btnMovePanelRight:(id)sender {
    
    @try {
        
        
        spinner = [[UIActivityIndicatorView alloc]
                   initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
        spinner.frame = CGRectMake(0, 0, 320, 560); // CGPointMake(160, 240);
        spinner.color = [UIColor blueColor];
        spinner.backgroundColor = [UIColor lightTextColor];
        spinner.transform = CGAffineTransformMakeScale(2, 2);
        // spinner.hidesWhenStopped = YES;
        [self.view addSubview:spinner];
        spinner.transform = CGAffineTransformMakeScale(2, 2);
        
        [spinner startAnimating];
        
        // how we stop refresh from freezing the main UI thread
        
        dispatch_async(
                       dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^{
                           
                           // back to the main thread for the UI call
                           dispatch_async(dispatch_get_main_queue(), ^{
                               
                               
                               [spinner startAnimating];
                           });
                           dispatch_async(dispatch_get_main_queue(), ^{
                               
                             //  [self dismissViewControllerAnimated:YES completion:nil];
                               
                               Home *mHome = [[Home alloc]initWithNibName:HOMEDASHBOARD bundle:nil];
                               [self presentViewController:mHome animated:YES completion:nil];
                               
                               [spinner stopAnimating];
                               
                           });
                       });
        
        
        //[self dismissViewControllerAnimated:YES completion:nil];
        
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
    
    
}

-(NSDictionary*)updateUserLocation
{
    @try {
        if (geoCode!=nil) {
            NSDictionary *userinfo=[mWebService SaveUserInfo:geoCode];
            return userinfo;
            
        }
        return nil;
        
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
}-(void) viewDidLayoutSubviews {
    
    @try {
        
        
        [super viewDidLayoutSubviews];
        [self.scrollview layoutIfNeeded];
        self.scrollview.contentSize=self.Contentview.bounds.size;
        UIGraphicsBeginImageContext(self.view.frame.size);
        UIImage *image = UIGraphicsGetImageFromCurrentImageContext();
        UIGraphicsEndImageContext();
        image= [UIImage imageNamed:@"bgerror.png"];
        self.Contentview.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"bgerror.png"]];
        
        
    
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
}

-(IBAction)myActivity:(id)sender
{
    if ([mPref valueForKey:USERREGISTERID] == nil) {
        
        self.popViewController = [[PopUpViewController alloc] initWithNibName:@"PopUpViewController" bundle:nil];
        [self.popViewController setTitle:@"This is a popup view"];
        
        [self.popViewController showInView:self.view withImage:[UIImage imageNamed:@"rprt_usinfo.png"] withMessage:@"You just triggered a great popup window" animated:YES];
        
        
//        Login * mLogin = [[ Login alloc] initWithNibName:LOGIN bundle:nil];
//        [self presentViewController:mLogin animated:YES completion:nil];
        
    }
    else
    {
        Retailer_Offer * mRetailer_Offer = [[ Retailer_Offer alloc] initWithNibName:RETAILER bundle:nil];
        [self presentViewController:mRetailer_Offer animated:YES completion:nil];
    }

}

-(NSString*)emailMessageText:(NSDictionary*)opporDetails
{
   
    
    NSString *satrtDate = [NSString stringWithFormat:@"%@",[opporDetails valueForKey:@"EndDate"]];
    
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"yyyy-MM-dd'T'HH:mm:ss"];
    NSTimeZone *gmt = [NSTimeZone timeZoneWithAbbreviation:@"UTC"];
    [dateFormatter setTimeZone:gmt];
    NSDate *date5 = [dateFormatter dateFromString:satrtDate];
    
    NSDictionary *startOffer;
    if (date5!=nil) {
        startOffer= [mTimePreference remaningTime:[NSDate date] endDate:date5];
    }
    else{
        
        NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
        [dateFormatter setDateFormat:@"yyyy-MM-dd'T'HH:mm:ss.SSS"];
        
        NSTimeZone *gmt = [NSTimeZone timeZoneWithAbbreviation:@"UTC"];
        [dateFormatter setTimeZone:gmt];
        NSDate *date5 = [dateFormatter dateFromString:satrtDate];
        startOffer= [mTimePreference remaningTime:[NSDate date] endDate:date5];
        
    }
    
    int Remaingtyime = [[startOffer valueForKey:@"Time"] intValue];
    int hour = [[startOffer valueForKey:@"Hour"] intValue];
    int seconds = [[startOffer valueForKey:@"Seconds"] intValue];
    
    if (seconds!=0) {
        Remaingtyime = Remaingtyime+(seconds/60);
    }
    if(Remaingtyime!=0)
    {
        
        Remaingtyime = Remaingtyime+(hour*60);
    }
    
    NSString *duration= [NSString stringWithFormat:@"%dh:%dm:%ds",[[startOffer valueForKey:@"Hour"] intValue], [[startOffer valueForKey:@"Time"] intValue],[[startOffer valueForKey:@"Seconds"] intValue]];
    NSString *opportunityname=[opporDetails valueForKey:@"OpportunityName"];
    NSString *areName=[opporDetails valueForKey:@"AreaName"];
    NSString *vendorName=[opporDetails valueForKey:@"UserName"];
    NSString *contactNumber = [opporDetails valueForKey:@"VendorMobile"];
    NSString *watsspptext;
    if ([category isEqualToString:FOOD]) {
        
        
        if (Remaingtyime==0) {
            watsspptext = [NSString stringWithFormat:@"Hi,\n%@ has posted an offer \"%@\" at %@.\nContact No: %@ \n\nFor further details download the app\n Play store: http://bit.ly/2fdqw6N\n App store: http://apple.co/2fdvEaV \n\nThanks,\nTeam Right Place Right Time",vendorName,opportunityname,areName,contactNumber];
        }
        else
        {
            watsspptext = [NSString stringWithFormat:@"Hi,\n%@ has posted an offer \"%@\" at %@. Time left is %@ \nContact No: %@.\n\nFor further details download the app\n Play store: http://bit.ly/2fdqw6N\n App store: http://apple.co/2fdvEaV\n\nThanks,\nTeam Right Place Right Time",vendorName,opportunityname,areName,duration,contactNumber];
        }
    }
    
    if ([category isEqualToString:SALES]) {
        
        if (Remaingtyime==0) {
            watsspptext = [NSString stringWithFormat:@"Hi,\n%@ has posted an offer \"%@\" at %@.\nContact No:  %@ \n\nFor further details download the app\n Play store: http://bit.ly/2fdqw6N\n App store: http://apple.co/2fdvEaV\n\nThanks,\nTeam Right Place Right Time",vendorName,opportunityname,areName,contactNumber];
        }
        else
            watsspptext = [NSString stringWithFormat:@"Hi,\n%@ has posted an offer \"%@\" at %@.Time left is %@\nContact No: %@ \n\nFor further details download the app\n Play store: http://bit.ly/2fdqw6N\n App store: http://apple.co/2fdvEaV\n\nThanks,\nTeam Right Place Right Time",vendorName,opportunityname,areName,duration,contactNumber];
        
    }
    if ([category isEqualToString:REALESTATE]) {
        
        NSString *property=[opporDetails valueForKey:@"SubCategory"];
        
        NSArray *subcat = [[opporDetails valueForKey:@"OpportunityKeywords"] componentsSeparatedByString:@","];
        
        NSString *share =[NSString stringWithFormat:@"%@",[subcat objectAtIndex:0]];
        
        NSString *areaName=[opporDetails valueForKey:@"AreaName"];
        NSString *vendorName=[opporDetails valueForKey:@"UserName"];
        
        
        if (Remaingtyime==0) {
            watsspptext = [NSString stringWithFormat:@"Hi,\n%@ is available for %@ at %@. Contact %@ at %@ for more details \n\n For further details download the app \n Play store: http://bit.ly/2fdqw6N\n App store: http://apple.co/2fdvEaV\n\nThanks,\nTeam Right Place Right Time",property,share,areaName,vendorName,contactNumber];
        }
        else
            watsspptext = [NSString stringWithFormat:@"Hi,\n%@ is available for %@ at %@. Contact %@ at   before %@ \nContact No:%@ \n\n For further details download the app \n Play store: http://bit.ly/2fdqw6N\n App store: http://apple.co/2fdvEaV\n\nThanks,\nTeam Right Place Right Time",property,share,areaName,vendorName,duration,contactNumber];
        
    }
    if ([category isEqualToString:JOBS]) {
        
        if (Remaingtyime==0) {
            watsspptext = [NSString stringWithFormat:@"Hi,\n%@ has posted a Job requirement. \"%@\" at %@. \nContact No: %@  \n\nFor further details download the app \n Play store: http://bit.ly/2fdqw6N\n App store: http://apple.co/2fdvEaV\n\nThanks,\nTeam Right Place Right Time",vendorName,opportunityname,areName,contactNumber];
        }
        else
            watsspptext = [NSString stringWithFormat:@"Hi,\n%@ has posted a Job requirement. \"%@\" at %@. Time left to apply is %@\nContact No: %@. \n\nFor further details download the app \n Play store: http://bit.ly/2fdqw6N\n App store: http://apple.co/2fdvEaV\n\nThanks,\nTeam Right Place Right Time",vendorName,opportunityname,areName,duration,contactNumber];
        
    }
    if ([category isEqualToString:TRAVELS]) {
        
        NSString *vehicletype = [opporDetails valueForKey:@"SubCategory"];
        NSArray *addres = [[opporDetails valueForKey:@"OpportunityName"] componentsSeparatedByString:@"to"];
        NSString *source = [addres objectAtIndex:0];
        NSString *destination =[addres objectAtIndex:1];
        NSString *seats = [opporDetails valueForKey:@"Available"];
        NSString *contactperson = [opporDetails valueForKey:@"UserName"];
        NSString *contactNumber = [opporDetails valueForKey:@"VendorMobile"];
        
        watsspptext = [NSString stringWithFormat:@"Hi,\nA %@ is going from %@ to %@ and there are %@ available.\nContact %@ at %@ for more details.\n\n For further details download the app \n Play store: http://bit.ly/2fdqw6N\n App store: http://apple.co/2fdvEaV\n\nThanks,\nTeam Right Place Right Time",vehicletype,source,destination,seats,contactperson,contactNumber];
        
    }
    if ([category isEqualToString:BANKING]) {
        
        
        if (Remaingtyime==0) {
            watsspptext = [NSString stringWithFormat:@"Hi,\n%@ has posted an offer \"%@\" at %@.\nContact No:  %@ \n\nFor further details download the app\n Play store: http://bit.ly/2fdqw6N\n App store: http://apple.co/2fdvEaV\n\nThanks,\nTeam Right Place Right Time",vendorName,opportunityname,areName,contactNumber];
        }
        else
            
            watsspptext = [NSString stringWithFormat:@"Hi,\n%@ has posted an offer \"%@\" at %@. Offer available till %@.\nContact No:  %@. \n\nFor further details download the app\n Play store: http://bit.ly/2fdqw6N\n App store: http://apple.co/2fdvEaV\n\nThanks,\nTeam Right Place Right Time",vendorName,opportunityname,areName,duration,contactNumber];
        
    }
    if ([category isEqualToString:MEETINGS]) {
        if (Remaingtyime==0) {
            watsspptext = [NSString stringWithFormat:@"Hi,\n%@ has posted an event \"%@\" at %@.\nContact No: %@ \n\nFor further details download the app  \n Play store: http://bit.ly/2fdqw6N\n App store: http://apple.co/2fdvEaV\n\nThanks,\nTeam Right Place Right Time",vendorName,opportunityname,areName,contactNumber];
        }
        else
            watsspptext = [NSString stringWithFormat:@"Hi,%@ has posted an event \"%@\" at %@.  Offer available till %@.\nContact No: %@\n\n For further details download the app  \n Play store: http://bit.ly/2fdqw6N\n App store: http://apple.co/2fdvEaV\n\nThanks,\nTeam Right Place Right Time",vendorName,opportunityname,areName,duration,contactNumber];
        
    }
    if ([category isEqualToString:PROFESSIONALHELP]) {
        NSString *experttype=[opporDetails valueForKey:@"SubCategory"];
        watsspptext = [NSString stringWithFormat:@"Hi,\n%@ is requesting for %@, \"%@\" at %@.\nContact No: %@ \n\nFor further details download the app \n Play store: http://bit.ly/2fdqw6N\n App store: http://apple.co/2fdvEaV\n\nThanks,\nTeam Right Place Right Time",vendorName,experttype,opportunityname,areName,contactNumber];
        
    }
    if ([category isEqualToString:SPORTS]) {
        NSString *sporttype=[opporDetails valueForKey:@"SubCategory"];
        
        watsspptext = [NSString stringWithFormat:@"Hi,\n%@ is looking for %@ players, \"%@\" at %@.\nContact No:  %@ \n\n For further details download the app\n Play store: http://bit.ly/2fdqw6N \n App store: http://apple.co/2fdvEaV\n\nThanks,\nTeam Right Place Right Time",vendorName,sporttype,opportunityname,areName,contactNumber];
        
    }
    
    if ([category isEqualToString:HEALTH]) {
        NSString *type=[opporDetails valueForKey:@"SubCategory"];
        watsspptext = [NSString stringWithFormat:@"Hi,\n%@ is requesting for %@, \"%@\" at %@. \nContact No: %@ \n\n For further details download the app\n Play store: http://bit.ly/2fdqw6N\n App store: http://apple.co/2fdvEaV\n\nThanks,\nTeam Right Place Right Time",vendorName,type,opportunityname,areName,contactNumber];
        
    }
    return watsspptext;
}



-(NSString*)whatsappMessageText:(NSDictionary*)opporDetails
{
    
    NSString *satrtDate = [NSString stringWithFormat:@"%@",[opporDetails valueForKey:@"EndDate"]];
    
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"yyyy-MM-dd'T'HH:mm:ss"];
    NSTimeZone *gmt = [NSTimeZone timeZoneWithAbbreviation:@"UTC"];
    [dateFormatter setTimeZone:gmt];
    NSDate *date5 = [dateFormatter dateFromString:satrtDate];
    
    NSDictionary *startOffer;
    if (date5!=nil) {
        startOffer= [mTimePreference remaningTime:[NSDate date] endDate:date5];
    }
    else{
        
        NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
        [dateFormatter setDateFormat:@"yyyy-MM-dd'T'HH:mm:ss.SSS"];
        
        NSTimeZone *gmt = [NSTimeZone timeZoneWithAbbreviation:@"UTC"];
        [dateFormatter setTimeZone:gmt];
        NSDate *date5 = [dateFormatter dateFromString:satrtDate];
        startOffer= [mTimePreference remaningTime:[NSDate date] endDate:date5];
        
    }
    
    int Remaingtyime = [[startOffer valueForKey:@"Time"] intValue];
    int hour = [[startOffer valueForKey:@"Hour"] intValue];
    int seconds = [[startOffer valueForKey:@"Seconds"] intValue];
    
    if (seconds!=0) {
        Remaingtyime = Remaingtyime+(seconds/60);
    }
    if(Remaingtyime!=0)
    {
        
        Remaingtyime = Remaingtyime+(hour*60);
    }
    
    NSString *duration= [NSString stringWithFormat:@"%dh:%dm:%ds",[[startOffer valueForKey:@"Hour"] intValue], [[startOffer valueForKey:@"Time"] intValue],[[startOffer valueForKey:@"Seconds"] intValue]];
    NSString *opportunityname=[opporDetails valueForKey:@"OpportunityName"];
    NSString *areName=[opporDetails valueForKey:@"AreaName"];
     NSString *vendorName=[opporDetails valueForKey:@"UserName"];
       NSString *contactNumber = [opporDetails valueForKey:@"VendorMobile"];
    NSString *watsspptext;
    if ([category isEqualToString:FOOD]) {
        
        
        if (Remaingtyime==0) {
             watsspptext = [NSString stringWithFormat:@" %@ has posted an offer \"%@\" at %@.\nContact No: %@ \n\nFor further details download the app\n Play store: http://bit.ly/2fdqw6N\n App store: http://apple.co/2fdvEaV",vendorName,opportunityname,areName,contactNumber];
        }
        else
        {
        watsspptext = [NSString stringWithFormat:@" %@ has posted an offer \"%@\" at %@.\nContact No: %@. Time left is %@ \n\nFor further details download the app\n Play store: http://bit.ly/2fdqw6N\n App store: http://apple.co/2fdvEaV",vendorName,opportunityname,areName,contactNumber,duration];
        }
    }
  
    if ([category isEqualToString:SALES]) {
        
        if (Remaingtyime==0) {
              watsspptext = [NSString stringWithFormat:@" %@ has posted an offer \"%@\" at %@.\nContact No:  %@ \n\nFor further details download the app\n Play store: http://bit.ly/2fdqw6N\n App store: http://apple.co/2fdvEaV",vendorName,opportunityname,areName,contactNumber];
        }
        else
        watsspptext = [NSString stringWithFormat:@" %@ has posted an offer \"%@\" at %@.\nContact No: %@ Time left is %@ \n\nFor further details download the app\n Play store: http://bit.ly/2fdqw6N\n App store: http://apple.co/2fdvEaV",vendorName,opportunityname,areName,contactNumber,duration];
        
    }
    if ([category isEqualToString:REALESTATE]) {
        
        NSString *property=[opporDetails valueForKey:@"SubCategory"];
        
        NSArray *subcat = [[opporDetails valueForKey:@"OpportunityKeywords"] componentsSeparatedByString:@","];
        
        NSString *share =[NSString stringWithFormat:@"%@",[subcat objectAtIndex:0]];
        
        NSString *areaName=[opporDetails valueForKey:@"AreaName"];
        NSString *vendorName=[opporDetails valueForKey:@"UserName"];
        
        
        if (Remaingtyime==0) {
             watsspptext = [NSString stringWithFormat:@"%@ is available for %@ at %@. Contact %@ at %@ for more details \n\n For further details download the app \n Play store: http://bit.ly/2fdqw6N\n App store: http://apple.co/2fdvEaV",property,share,areaName,vendorName,contactNumber];
        }
        else
        watsspptext = [NSString stringWithFormat:@"%@ is available for %@ at %@. Contact %@ at %@ for more details before %@ \n\n For further details download the app \n Play store: http://bit.ly/2fdqw6N\n App store: http://apple.co/2fdvEaV",property,share,areaName,vendorName,contactNumber,duration];
        
    }
    if ([category isEqualToString:JOBS]) {
        
        if (Remaingtyime==0) {
            watsspptext = [NSString stringWithFormat:@" %@ has posted a Job requirement. \"%@\" at %@. \nContact No: %@  \n\nFor further details download the app \n Play store: http://bit.ly/2fdqw6N\n App store: http://apple.co/2fdvEaV",vendorName,opportunityname,areName,contactNumber];
        }
        else
        watsspptext = [NSString stringWithFormat:@" %@ has posted a Job requirement. \"%@\" at %@.\nContact No: %@. Time left to apply is %@ \n\nFor further details download the app \n Play store: http://bit.ly/2fdqw6N\n App store: http://apple.co/2fdvEaV",vendorName,opportunityname,areName,contactNumber,duration];
        
    }
    if ([category isEqualToString:TRAVELS]) {
        
        NSString *vehicletype = [opporDetails valueForKey:@"SubCategory"];
        NSArray *addres = [[opporDetails valueForKey:@"OpportunityName"] componentsSeparatedByString:@"to"];
        NSString *source = [addres objectAtIndex:0];
        NSString *destination =[addres objectAtIndex:1];
        NSString *seats = [opporDetails valueForKey:@"Available"];
        NSString *contactperson = [opporDetails valueForKey:@"UserName"];
        NSString *contactNumber = [opporDetails valueForKey:@"VendorMobile"];
        
        watsspptext = [NSString stringWithFormat:@"A %@ is going from %@ to %@ and there are %@ available. Contact %@ at %@ for more details.\n\n For further details download the app \n Play store: http://bit.ly/2fdqw6N\n App store: http://apple.co/2fdvEaV",vehicletype,source,destination,seats,contactperson,contactNumber];
        
    }
    if ([category isEqualToString:BANKING]) {
        
        
        if (Remaingtyime==0) {
               watsspptext = [NSString stringWithFormat:@" %@ has posted an offer \"%@\" at %@.\nContact No:  %@ \n\nFor further details download the app\n Play store: http://bit.ly/2fdqw6N\n App store: http://apple.co/2fdvEaV",vendorName,opportunityname,areName,contactNumber];
        }
        else
        
        watsspptext = [NSString stringWithFormat:@" %@ has posted an offer \"%@\" at %@.\nContact No:  %@. Offer available till %@ \n\nFor further details download the app\n Play store: http://bit.ly/2fdqw6N\n App store: http://apple.co/2fdvEaV",vendorName,opportunityname,areName,contactNumber,duration];
        
    }
    if ([category isEqualToString:MEETINGS]) {
        if (Remaingtyime==0) {
             watsspptext = [NSString stringWithFormat:@"%@ has posted an event \"%@\" at %@.\nContact No: %@ \n\nFor further details download the app  \n Play store: http://bit.ly/2fdqw6N\n App store: http://apple.co/2fdvEaV",vendorName,opportunityname,areName,contactNumber];
        }
        else
        watsspptext = [NSString stringWithFormat:@"%@ has posted an event \"%@\" at %@.\nContact No: %@  Offer available till %@.\n\n For further details download the app  \n Play store: http://bit.ly/2fdqw6N\n App store: http://apple.co/2fdvEaV",vendorName,opportunityname,areName,contactNumber,duration];
        
    }
    if ([category isEqualToString:PROFESSIONALHELP]) {
        NSString *experttype=[opporDetails valueForKey:@"SubCategory"];
        watsspptext = [NSString stringWithFormat:@"%@ is requesting for %@, \"%@\" at %@.\nContact No: %@ \n\nFor further details download the app \n Play store: http://bit.ly/2fdqw6N\n App store: http://apple.co/2fdvEaV",vendorName,experttype,opportunityname,areName,contactNumber];
        
    }
    if ([category isEqualToString:SPORTS]) {
        NSString *sporttype=[opporDetails valueForKey:@"SubCategory"];
        
        watsspptext = [NSString stringWithFormat:@"%@ is looking for %@ players, \"%@\" at %@.\nContact No:  %@ \n\n For further details download the app\n Play store: http://bit.ly/2fdqw6N \n App store: http://apple.co/2fdvEaV",vendorName,sporttype,opportunityname,areName,contactNumber];
        
    }
    
    if ([category isEqualToString:HEALTH]) {
        NSString *type=[opporDetails valueForKey:@"SubCategory"];
        watsspptext = [NSString stringWithFormat:@"%@ is requesting for %@, \"%@\" at %@. \nContact No: %@ \n\n For further details download the app\n Play store: http://bit.ly/2fdqw6N\n App store: http://apple.co/2fdvEaV",vendorName,type,opportunityname,areName,contactNumber];
        
    }
    return watsspptext;
}


-(void)shareData:(id)sender
{
    CGPoint buttonPosition = [sender convertPoint:CGPointZero toView:opportunityTable];
   
    NSIndexPath *indexPath = [opportunityTable indexPathForRowAtPoint:buttonPosition];
    
    NSDictionary *BlockedItem = [GetOffers objectAtIndex:indexPath.section];
    
    UIAlertController * view=   [UIAlertController
                                 alertControllerWithTitle:@"Rigth Place Right Time"
                                 message:@"Select Sharing option"
                                 preferredStyle:UIAlertControllerStyleActionSheet];
    
    UIAlertAction* watsapp = [UIAlertAction
                            actionWithTitle:@"Share via Whatsapp"
                            style:UIAlertActionStyleDefault
                            handler:^(UIAlertAction * action)
                            {
                                
                                
                              
                                NSString *ursl =  [mTimecalculator whatspandSMSText:BlockedItem];//[NSString stringWithFormat:@"A new opportunity is posted at %@ \n%@ \nIf you do not have the app, please download it from Apple:https://itunes.apple.com/in/app/right-place-right-time/id1145309259?mt=8",areName,Addres];
                              
                                ursl =    (NSString*)CFBridgingRelease(CFURLCreateStringByAddingPercentEscapes(NULL,(CFStringRef) ursl, NULL,CFSTR("!*();:@&=+$,/?%#[]"),kCFStringEncodingUTF8));
                                
                                NSString * urlWhats = [NSString stringWithFormat:@"whatsapp://send?text=%@",ursl];
                                NSURL * whatsappURL = [NSURL URLWithString:urlWhats];
                                if ([[UIApplication sharedApplication] canOpenURL: whatsappURL]) {
                                    
                                    UIApplication *application = [UIApplication sharedApplication];
                                    [application openURL:whatsappURL options:@{} completionHandler:nil];

                                    
                                  //  [[UIApplication sharedApplication] openURL: whatsappURL];
                                } else {
                                        [self showAlertPop:@"Unable to share opportunity." expObj:nil];
                                    // can not share with whats app
                                }
                                
                            }];
    UIAlertAction* email = [UIAlertAction
                              actionWithTitle:@"Share via E-mail"
                              style:UIAlertActionStyleDefault
                              handler:^(UIAlertAction * action)
                              {
                                  NSString *ursl = [mTimecalculator emailText:BlockedItem];
                                  
                                      NSString *cat =[BlockedItem valueForKey:@"Category"];
                                  if ([cat isEqualToString:@"Professional Services"]) {
                                      cat= @"Expert Help";
                                  }
                                  else if ([cat isEqualToString:MEETINGS])
                                      cat= @"Events & Entertainments";
                                  
                                  NSString *subjectt = [NSString stringWithFormat:@"Right Place Right Time : %@",cat];
                                  
                                  if ([MFMailComposeViewController canSendMail]) {
                                      MFMailComposeViewController *mailController = [[MFMailComposeViewController alloc] init];
                                      [mailController setMailComposeDelegate:self];
                                      [mailController setSubject:subjectt];
                                      [mailController setToRecipients:@[@"email1", @"email2"]];
                                      [mailController setMessageBody:ursl isHTML:NO];
                                      [self presentViewController:mailController animated:YES completion:nil];
                                       }
                                  
                                  [view dismissViewControllerAnimated:YES completion:nil];
                                  
                              }];
   
    
    UIAlertAction* sms = [UIAlertAction
                              actionWithTitle:@"Share via iMessage"
                              style:UIAlertActionStyleDefault
                              handler:^(UIAlertAction * action)
                              {
                                  
                                  NSString *ursl =[mTimecalculator whatspandSMSText:BlockedItem];// [NSString stringWithFormat:@"A new opportunity is posted at %@ \n%@ \nIf you do not have the app, please download it from Apple:https://itunes.apple.com/in/app/right-place-right-time/id1145309259?mt=8",areName,Addres];
                                  
                                  if ([MFMessageComposeViewController canSendText]) {
                                      MFMessageComposeViewController *messageController = [[MFMessageComposeViewController alloc] init];
                                      [messageController setMessageComposeDelegate:self];
                                      [messageController setRecipients:nil];
                                      [messageController setBody:ursl];
                                      [self presentViewController:messageController animated:NO completion:nil];
                                  }
                                  
                                  [view dismissViewControllerAnimated:YES completion:nil];
                                  
                              }];
    
    UIAlertAction* cancel = [UIAlertAction
                             actionWithTitle:@"Cancel"
                             style:UIAlertActionStyleDefault
                             handler:^(UIAlertAction * action)
                             {
                                 [view dismissViewControllerAnimated:YES completion:nil];
                                 
                             }];
        [watsapp setValue:[[UIImage imageNamed:@"whatsapp.png"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal] forKey:@"image"];
    [email setValue:[[UIImage imageNamed:@"email.png"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal] forKey:@"image"];
    [sms setValue:[[UIImage imageNamed:@"sms.png"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal] forKey:@"image"];

    
    [view addAction:watsapp];
    [view addAction:email];
    [view addAction:sms];
    [view addAction:cancel];
    [self presentViewController:view animated:YES completion:nil];

   
}
- (void)mailComposeController:(MFMailComposeViewController*)controller didFinishWithResult:(MFMailComposeResult)result error:(NSError*)error {
    [self dismissViewControllerAnimated:YES completion:nil];
}

// Then implement the delegate method
- (void)messageComposeViewController:(MFMessageComposeViewController *)controller didFinishWithResult:(MessageComposeResult)result {
    [self dismissViewControllerAnimated:YES completion:nil];
}


// Report Spam for Opportunityd

-(void)spamData:(id)sender
{
    CGPoint buttonPosition = [sender convertPoint:CGPointZero toView:opportunityTable];
    
    NSIndexPath *indexPath = [opportunityTable indexPathForRowAtPoint:buttonPosition];
    
    NSDictionary *BlockedItem = [GetOffers objectAtIndex:indexPath.section];
    
    UIAlertController * view=   [UIAlertController
                                 alertControllerWithTitle:@"Rigth Place Right Time"
                                 message:@""
                                 preferredStyle:UIAlertControllerStyleActionSheet];
    
    UIAlertAction* reportSpam = [UIAlertAction
                              actionWithTitle:@"Report Spam"
                              style:UIAlertActionStyleDefault
                              handler:^(UIAlertAction * action)
                              {
                                  [self reportSpam:BlockedItem];
                                  
                              }];
    UIAlertAction* HideOffer = [UIAlertAction
                            actionWithTitle:@"Hide"
                            style:UIAlertActionStyleDefault
                            handler:^(UIAlertAction * action)
                            {
                                 [self HideOffer:BlockedItem];
                                
                            }];
    
    UIAlertAction* cancel = [UIAlertAction
                             actionWithTitle:@"Cancel"
                             style:UIAlertActionStyleDefault
                             handler:^(UIAlertAction * action)
                             {
                                 [view dismissViewControllerAnimated:YES completion:nil];
                                 
                             }];
    
    
    
    [reportSpam setValue:[[UIImage imageNamed:@"reportspam.png"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal] forKey:@"image"];
    [HideOffer setValue:[[UIImage imageNamed:@"hide.png"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal] forKey:@"image"];
    
    
//    hide.png
//    reportspam.png
    
    
    [view addAction:reportSpam];
    [view addAction:HideOffer];
   
    [view addAction:cancel];
    [self presentViewController:view animated:YES completion:nil];
    
    
}









-(void)reportSpam:(NSDictionary*)BlockedItem
{
    
    if([mPref valueForKey:USERREGISTERID])
    {
    
  
    
    NSString *OoportunityID = [BlockedItem valueForKey:@"OpportunityID"];
    NSString *UserRedID =[mPref valueForKey:USERREGISTERID];
    
        NSString *ids =[NSString stringWithFormat:@"%@/%@",UserRedID,OoportunityID];
        
        NSDictionary *response = [mWebService ReportSpam:ids Methodname:@"ReportSpam"];
        
        NSLog(@"%@",response);
         [opportunityTable reloadData];
        
        
        
        
    }
    
    
}






-(void)HideOffer:(NSDictionary*)BlockedItem
{
    
    NSString *OoportunityID = [BlockedItem valueForKey:@"OpportunityID"];
    NSString *UserRedID =[mPref valueForKey:USERREGISTERID];
    
    NSString *ids =[NSString stringWithFormat:@"%@/%@",UserRedID,OoportunityID];
    
    NSDictionary *response = [mWebService ReportSpam:ids Methodname:@"HideOffer"];
    
    [GetOffers  removeObject:BlockedItem];
    [opportunityTable reloadData];
    
NSLog(@"%@",response);
}







@end
