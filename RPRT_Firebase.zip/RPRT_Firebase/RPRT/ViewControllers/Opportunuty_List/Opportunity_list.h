//
//  Opportunity_list.h
//  RPRT
//
//  Created by sravanthi Gumma on 08/01/16.
//  Copyright © 2016 DevpointSolutions. All rights reserved.
//

#import "ViewPagerController.h"
#import "LeftPanelViewController.h"
#import "Offertabs.h"
#import "CustomIOSAlertView.h"

@protocol Opportunity_listDelegate <NSObject>

@optional
- (void)movePanelLeft;
- (void)movePanelRight;
@required
- (void)movePanelToOriginalPosition;
@end

@interface Opportunity_list : ViewPagerController<UIPageViewControllerDelegate,CLLocationManagerDelegate,CustomIOSAlertViewDelegate>
{
    
    CLLocationManager *locationManager;
    CLLocationCoordinate2D coordinate;
    UIActivityIndicatorView *spinner;

}

@property (nonatomic, strong) IBOutlet UIButton *leftButton;

@property (weak,nonatomic)IBOutlet UIButton *Settings;

@property(nonatomic , assign) NSDictionary *setOppList;

@property (nonatomic, strong) IBOutlet UILabel *distanceVal;


@property(nonatomic , assign) IBOutlet UIView *HeserView;

-(IBAction)back:(id)sender;

+(Opportunity_list *)GetSharedInstance;


-(void) slideShowHideMenu;

- (UIViewController *)viewPager:(ViewPagerController *)viewPager contentViewControllerForTabAtIndex:(NSUInteger)index ;

- (UIView *)viewPager:(ViewPagerController *)viewPager viewForTabAtIndex:(NSUInteger)index;

-(NSDictionary*)updateOpportunityTable:(NSDictionary*)currentlocation ;
@end
