//
//  Opportunity_list.m
//  RPRT
//
//  Created by sravanthi Gumma on 08/01/16.
//  Copyright © 2016 DevpointSolutions. All rights reserved.
//

#import "Opportunity_list.h"

@interface Opportunity_list ()<ViewPagerDataSource, ViewPagerDelegate,CLLocationManagerDelegate,Opportunity_listDelegate>
{
    NSMutableArray *tabs;
    NSMutableArray *CatImages;
    int btnTag;
    Web_Services *mWebService;
    NSDictionary *Opportutnity;
    UIView *RadiousView;
    UIView *contentView;
    NSString *SlideMenuTag;
    NSUserDefaults *mPref;
    NSDictionary *getOpportutnity;
    NSDictionary *getOppList;
    UIButton *radiousMenu;
    UIButton *CattegoryBtn;
    
}
@property(nonatomic) NSUInteger numberOfTabs;
@property(nonatomic, strong) NSMutableArray * titlesLabels;

@end

static Opportunity_list *OppShareInstance = nil;

@implementation Opportunity_list
@synthesize delegate, Settings,distanceVal,HeserView;


+(Opportunity_list *)GetSharedInstance
{
    if(OppShareInstance == nil)
    {
        OppShareInstance = [[Opportunity_list alloc] init];
    }
    return OppShareInstance;
}
// setup the imageview with our selected animal

-(void)drawerHome
{
    [delegate movePanelToOriginalPosition];
}


//- (void)animalSelected:(NSString*)ModuleID;
- (void)animalSelected:moduleID
{
     [delegate movePanelToOriginalPosition];

    @try {
        NSLog(@"index1 = %lu", (unsigned long)index);
        for (UILabel *label in self.titlesLabels){
            label.textColor = [UIColor grayColor];
        }
        UILabel *label = self.titlesLabels[0];
        label.textColor = [UIColor blueColor];
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {

    }
}

- (id)initWithNibName:(NSString *)nibNameOrNil
               bundle:(NSBundle *)nibBundleOrNil {
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {

        // Custom initialization
        getOppList = self.setOppList;
        
        GeoCodeLocation *geoCode = [GeoCodeLocation GetSharedInstance];
        
        NSMutableDictionary *locatioLatLon = [[NSMutableDictionary alloc]init];
        [locatioLatLon setValue:geoCode.Latitude forKey:@"Latitude"];
        [locatioLatLon setValue:geoCode.Longitude forKey:@"Longitude"];
        
        
        [self updateOpportunityTable:locatioLatLon ];
    }
    return self;
}

#pragma mark -
#pragma mark View Will/Did Appear

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
}

#pragma mark -
#pragma mark View Will/Did Disappear

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
}

- (void)viewDidDisappear:(BOOL)animated {
    [super viewDidDisappear:animated];
}

- (void)slideShowHideMenu {

    @try {

        if([SlideMenuTag isEqualToString:@"Show"])
        {
            SlideMenuTag = @"Hide";
            [delegate movePanelRight];
        }
        else if([SlideMenuTag isEqualToString:@"Hide"]){
            SlideMenuTag = @"Show";
            [delegate movePanelToOriginalPosition];
        }

    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
   
}


-(IBAction)btnMovePanelRight:(id)sender {

    [self slideShowHideMenu];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    @try {
        btnTag=0;
        SlideMenuTag = @"Show";

        NSString *path = [[NSBundle mainBundle] pathForResource:@"Category" ofType:@"plist"];
        NSMutableDictionary *dict = [NSMutableDictionary dictionaryWithContentsOfFile:path];
        tabs = [dict valueForKey:@"Category"];
        CatImages = [dict valueForKey:@"CategoryImages"];
        self.dataSource = self;
        self.delegate = self;
        self.title = @"View Pager";
        self.titlesLabels = [[NSMutableArray alloc] init];
        // Keeps tab bar below navigation bar on iOS 7.0+
        // if ([[[UIDevice currentDevice] systemVersion] floatValue] >= 7.0) {
        //     self.edgesForExtendedLayout = UIRectEdgeNone;
        // }
        self.indicatorColor = [[UIColor redColor] colorWithAlphaComponent:0.64];
        self.tabsViewBackgroundColor = [[UIColor lightGrayColor] colorWithAlphaComponent:0.32];
        self.contentViewBackgroundColor = [[UIColor darkGrayColor] colorWithAlphaComponent:0.32];
        self.dividerColor = [UIColor blackColor];
        self.startFromSecondTab = NO;
        self.centerCurrentTab = NO;
        self.tabLocation = ViewPagerTabLocationTop;
        self.tabHeight = 49;
        self.tabOffset = 40;
        self.tabWidth = UIInterfaceOrientationIsLandscape([[UIApplication sharedApplication] statusBarOrientation]) ? 128.0f : 110.0f;
        self.fixFormerTabsPositions = NO;
        self.fixLatterTabsPositions = NO;
        self.shouldShowDivider = YES;
        self.shouldAnimateIndicator = ViewPagerIndicatorAnimationWhileScrolling;
        self.numberOfTabs = 3;
        
        mPref = [NSUserDefaults standardUserDefaults];
        [self LoadCategory:[mPref objectForKey:@"Category"]];
        //[[Home alloc]loadView];
        
        
       
        
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {

    }


}

-(NSDictionary*)updateOpportunityTable:(NSDictionary*)currentlocation  {
    @try {

        mPref = [NSUserDefaults standardUserDefaults];
        NSString *radious;
        if ([mPref valueForKey:@"Radious"]==nil) {
            radious = @"500";
              distanceVal.text = @"Deals in 500 M Range";
        }
        else
            radious =[mPref valueForKey:@"Radious"];
        
        
        NSMutableDictionary *location = [[NSMutableDictionary alloc]init];
        [location setValue:[currentlocation valueForKey:@"Latitude"] forKey:@"Latitude"];
        [location setValue:[currentlocation valueForKey:@"Longitude"] forKey:@"Longitude"];
        [location setValue:[mPref valueForKey:@"ModuleID"] forKey:@"ModuleId"];
        [location setValue:radious forKey:@"Radious"];
        mWebService = [Web_Services GetSharedInstance];
        getOpportutnity =[mWebService GetOpportunities:location];

        self.setOppList = getOpportutnity;
        getOppList = getOpportutnity;
        
       // ViewPagerController *mViewPagerController = [[ViewPagerController alloc] init];

        return getOpportutnity;
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }

}

-(void)LoadCategory:(NSString*)CategoryName {
    @try {
        UIButton *categoryBtn = [[UIButton alloc]initWithFrame:CGRectMake(331, 67, 50, 45)];
        categoryBtn.layer.masksToBounds = YES;
        categoryBtn.layer.cornerRadius = 2;
        [categoryBtn setBackgroundColor:[UIColor clearColor]];
        if ([CategoryName isEqualToString:@"Food"]) {
            [categoryBtn setImage:[UIImage imageNamed:@"ic_food1.png"] forState:UIControlStateNormal];
        }
        else if ([CategoryName isEqualToString:@"Professional"])
        {
            [categoryBtn setImage:[UIImage imageNamed:@"ic_professional.png"] forState:UIControlStateNormal];
        }
        else if ([CategoryName isEqualToString:@"Sales"])
        {
            [categoryBtn setImage:[UIImage imageNamed:@"ic_sales.png"] forState:UIControlStateNormal];
        }
        else if ([CategoryName isEqualToString:@"Sports"])
        {
            [categoryBtn setImage:[UIImage imageNamed:@"ic_sports.png"] forState:UIControlStateNormal];
        }
        [categoryBtn addTarget:self action:@selector(Food:) forControlEvents:UIControlEventTouchUpInside];
        [self.view addSubview:categoryBtn];
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
}

-(void)Food:(UIButton*)sender {
    [self slideShowHideMenu];
}

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    
    //[self performSelector:@selector(loadContent) withObject:nil afterDelay:3.0];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Toolbarbuttons

- (void)loadView {
    [super loadView];
    UITapGestureRecognizer *settings = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(handleSettingtap:)];
       [Settings addGestureRecognizer:settings];
    //[Radious addGestureRecognizer:radious];
    

}
- (void) handleSettingtap:(UIGestureRecognizer *) gestureRecognizer {
    
    CGPoint location = [gestureRecognizer locationInView:[gestureRecognizer view]];
    
    UIMenuController *menuController = [UIMenuController sharedMenuController];
    
    UIMenuItem *Setting = [[UIMenuItem alloc] initWithTitle:@"Settings" action:@selector(SettingClick:)];
    UIMenuItem *Login ;
    
    if([mPref objectForKey:@"UserRegisterID"] == nil)
    {
        Login = [[UIMenuItem alloc] initWithTitle:@"Log In" action:@selector(Login:)];
        
    }
    else  if([mPref objectForKey:@"UserRegisterID"] != nil)
    {
        Login = [[UIMenuItem alloc] initWithTitle:@"Add" action:@selector(Login:)];
        
    }
    
    NSAssert([self becomeFirstResponder], @"Sorry, UIMenuController will not work with %@ since it cannot become first responder", self);
    
    [menuController setMenuItems:[NSArray arrayWithObjects:Setting,Login,nil]];
    [menuController setTargetRect:CGRectMake(location.x+10, location.y+20, 0.0f, 0.0f) inView:[gestureRecognizer view]];
    [menuController setMenuVisible:YES animated:YES];
    
}

- (void) SettingClick:(id) sender {
    
    Setting * mSetting = [[ Setting alloc] initWithNibName:@"Setting" bundle:nil];
    [self presentViewController:mSetting animated:YES completion:nil];
    
}
- (void) Login:(id) sender {
    if ([mPref valueForKey:@"UserRegisterID"]==nil) {
        Login * mLogin = [[ Login alloc] initWithNibName:@"Login" bundle:nil];
        [self presentViewController:mLogin animated:YES completion:nil];
    }
    else if([mPref valueForKey:@"UserRegisterID"]!=nil)
    {
        [self pagechangeforPostOffer];
    }
    
}
- (BOOL) canPerformAction:(SEL)selector withSender:(id) sender
{
    if (selector == @selector(SettingClick:))
    {
        return YES;
    }
    if (selector == @selector(Login:))
    {
        return YES;
    }
    if (selector == @selector(copy:))
    {
        return NO;
    }
    return NO;
}
- (BOOL) canBecomeFirstResponder {
    return YES;
}

-(void)pagechangeforPostOffer
{
    @try {
        
        NSString *ModuleId =[mPref valueForKey:@"ModuleID"];
        
        if ([ModuleId isEqualToString:@"33"]) {
            [mPref setValue:@"33" forKey:@"ModuleID"];
            Post_Food * mPosting = [[ Post_Food alloc] initWithNibName:@"Post_Food" bundle:nil];
            [self presentViewController:mPosting animated:YES completion:nil];
            
        }
        else if ([ModuleId isEqualToString:@"34"])
        {
            [mPref setValue:@"34" forKey:@"ModuleID"];
            Post_Sales * mPosting = [[ Post_Sales alloc] initWithNibName:@"Post_Sales" bundle:nil];
            [self presentViewController:mPosting animated:YES completion:nil];
        }
        else if ([ModuleId isEqualToString:@"37"])
        {
            [mPref setValue:@"37" forKey:@"ModuleID"];
            Post_Professional * mPosting = [[ Post_Professional alloc] initWithNibName:@"Post_Professional" bundle:nil];
            [self presentViewController:mPosting animated:YES completion:nil];
        }
        else if ([ModuleId isEqualToString:@"38"])
        {
            [mPref setValue:@"38" forKey:@"ModuleID"];
            Post_Sports * mPosting = [[ Post_Sports alloc] initWithNibName:@"Post_Sports" bundle:nil];
            [self presentViewController:mPosting animated:YES completion:nil];
        }
        else if ([ModuleId isEqualToString:@"36"])
        {
            [mPref setValue:@"36" forKey:@"ModuleID"];
            Post_Jobs * mPosting = [[ Post_Jobs alloc] initWithNibName:@"Post_Jobs" bundle:nil];
            [self presentViewController:mPosting animated:YES completion:nil];
        }
        else if ([ModuleId isEqualToString:@"39"])
        {
            [mPref setValue:@"39" forKey:@"ModuleID"];
            Post_Meetings * mPosting = [[ Post_Meetings alloc] initWithNibName:@"Post_Meetings" bundle:nil];
            [self presentViewController:mPosting animated:YES completion:nil];
        }
        else
        {
            Post_Food * mPosting = [[ Post_Food alloc] initWithNibName:@"Post_Food" bundle:nil];
            [self presentViewController:mPosting animated:YES completion:nil];
        }
        
    }
    @catch (NSException *exception) {
        
    }
    @finally {
        
    }
}

#pragma mark - Setters

- (void)setNumberOfTabs:(NSUInteger)numberOfTabs {
    // Set numberOfTabs
    _numberOfTabs = numberOfTabs;
    // Reload data
    [self reloadData];
    
}

#pragma mark - Helpers

- (void)selectTabWithNumberFive {
    [self selectTabAtIndex:0];
}

- (void)loadContent {
    self.numberOfTabs = 3;
}

#pragma mark - Interface Orientation Changes

- (void)willRotateToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation duration:(NSTimeInterval)duration {
    
    // Update changes after screen rotates
    [self performSelector:@selector(setNeedsReloadOptions) withObject:nil afterDelay:duration];
}

#pragma mark - ViewPagerDataSource

- (NSUInteger)numberOfTabsForViewPager:(ViewPagerController *)viewPager {
    return self.numberOfTabs;
}

- (UIView *)viewPager:(ViewPagerController *)viewPager viewForTabAtIndex:(NSUInteger)index {
    @try {
        UILabel *label = [UILabel new];
        label.backgroundColor = [UIColor clearColor];
        label.font = [UIFont systemFontOfSize:11.0];
        label.text = [NSString stringWithFormat:@"%@", tabs[index]];
        label.textAlignment = NSTextAlignmentCenter;
        label.textColor = [UIColor blackColor];
        [label sizeToFit];
        
        [self.titlesLabels insertObject:label atIndex:index];
        return label;
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }

}

- (UIViewController *)viewPager:(ViewPagerController *)viewPager contentViewControllerForTabAtIndex:(NSUInteger)index {
    @try {
        Offertabs *cvc = [[ Offertabs alloc] initWithNibName:@"Offertabs" bundle:nil];
        //getOppList = self.setOppList;
        cvc.SetOpportunities =self.setOppList;
        cvc.textLabel = [NSString stringWithFormat:@"%lu", (unsigned long)index];
        return cvc;
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }

}

- (void)viewPager:(ViewPagerController *)viewPager didChangeTabToIndex:(NSUInteger)index {
    @try {
        NSLog(@"index1 = %lu", (unsigned long)index);
        for (UILabel *label in self.titlesLabels){
            label.textColor = [UIColor grayColor];
        }
        UILabel *label = self.titlesLabels[index];
        label.textColor = [UIColor blueColor];
        
        
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
}





-(IBAction)back:(id)sender {
   @try
    {
    
    [self dismissViewControllerAnimated:YES completion:NULL];  
}
@catch (NSException *exception) {
    
}
@finally {
    
}
}
-(void)StoreRadios:(NSString*)rad
{
    @try {
        [[Preferences GetSharedInstance]StoreRadious:rad];
        [mPref setValue:@"List" forKey:@"SideMenu"];
        
        distanceVal.text = [NSString stringWithFormat:@"Deals in %@ Range" , rad ];

         //[opportunityTable reloadData];
        
         MainViewController * mOpportunity_list = [[ MainViewController alloc] initWithNibName:@"MainViewController" bundle:nil];
        [self presentViewController:self animated:YES completion:nil];
    }
    @catch (NSException *exception) {
         [self showAlertPop:@"Invalid UserName." expObj:exception];
    }
    @finally {
        
    }
}

- (void) showAlertPop:(NSString*)alertText  expObj:(NSException*) exp{
    if(exp != nil)
    {
        NSLog(@"%@", exp.description);
    }
    NSLog(@"The Exception is %@",exp.description);
    UIAlertController *myAlertController =[mWebService  alert:alertText];
    [self presentViewController:myAlertController animated:YES completion:nil];
}

@end
