//
//  Health_ViewPager.h
//  RPRT
//
//  Created by sravanthi Gumma on 30/10/1938 Saka.
//  Copyright © 1938 Saka DevpointSolutions. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Health_ViewPager : UIViewController<UIPageViewControllerDataSource>
@property (strong, nonatomic) UIPageViewController *pageController;
@property(strong,nonatomic)NSString *OppoDescription;

@end
