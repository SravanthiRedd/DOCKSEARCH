//
//  Health_ViewPager.m
//  RPRT
//
//  Created by sravanthi Gumma on 30/10/1938 Saka.
//  Copyright © 1938 Saka DevpointSolutions. All rights reserved.
//

#import "Health_ViewPager.h"
#import "Post_Health.h"
#import "TimeCalculator.h"
#import "CurrentLocation.h"
#import "Web_Services.h"
@interface Health_ViewPager ()
{
    NSUInteger pageIndex;
    Post_Health *initialViewController;
    TimeCalculator *mConverter;
    NSMutableArray *getSubCategory;
    CurrentLocation *Addre;
    NSUserDefaults *mPref;
    Web_Services *mWebService;
    NSDictionary *GetUserCounts;
    UIActivityIndicatorView *spinner;
    
}@end

@implementation Health_ViewPager

- (void)viewDidLoad {
    [super viewDidLoad];
    mConverter= [TimeCalculator GetSharedInstance];
    mPref= [NSUserDefaults standardUserDefaults];
    mWebService= [Web_Services GetSharedInstance];
   
    Addre = [CurrentLocation GetSharedInstance];
     [self getallservicesResonse];
    NSLog(@"%@",Addre.Address.AreaName);//
    
    
   // Addre.Address
    self.pageController = [[UIPageViewController alloc] initWithTransitionStyle:UIPageViewControllerTransitionStyleScroll navigationOrientation:UIPageViewControllerNavigationOrientationHorizontal options:nil];
    
    self.pageController.dataSource = self;
    [[self.pageController view] setFrame:CGRectMake(0, 80, 600, 500)];
    
     initialViewController = [self viewControllerAtIndex:0];
    
    NSArray *viewControllers = [NSArray arrayWithObject:initialViewController];
    
    [self.pageController setViewControllers:viewControllers direction:UIPageViewControllerNavigationDirectionForward animated:NO completion:nil];
    
    //[self addChildViewController:self.pageController];
    [[self view] addSubview:[self.pageController view]];
    [self.pageController didMoveToParentViewController:self];
    
    
    UIPageControl *pageControl = [UIPageControl appearance];
    
    pageControl.pageIndicatorTintColor = [UIColor blueColor];
    pageControl.currentPageIndicatorTintColor = [UIColor orangeColor];

}



-(void)getallservicesResonse
{
    getSubCategory = [mConverter getSubCategoryDetails:@"43"];
 
    GetUserCounts = [mConverter GetCounts:Addre.Address.Latitude Long:Addre.Address.Longitude];

}





- (Post_Health *)viewControllerAtIndex:(NSUInteger)index {
    
    Post_Health *childViewController = [[Post_Health alloc] initWithNibName:PHEALTH bundle:nil];
    childViewController.index = index;
    pageIndex= index;
    childViewController.getSubCategory=getSubCategory;
    childViewController.GetUserCounts= GetUserCounts;
    childViewController.LocationAddress = Addre.Address;
    return childViewController;
    
}

- (UIViewController *)pageViewController:(UIPageViewController *)pageViewController viewControllerBeforeViewController:(UIViewController *)viewController {
    
    NSUInteger index = [(ViewPager *)viewController index];
    pageIndex=index;
    if (index == 0) {
        return nil;
    }
    
    // Decrease the index by 1 to return
    index--;
    pageIndex=index;
    return [self viewControllerAtIndex:index];
    
}

- (UIViewController *)pageViewController:(UIPageViewController *)pageViewController viewControllerAfterViewController:(UIViewController *)viewController {
    
    NSUInteger index = [(ViewPager *)viewController index];
    
    index++;
    pageIndex=index;
    if (index == 4) {
        return nil;
    }
    
    return [self viewControllerAtIndex:index];
    
}

- (NSInteger)presentationCountForPageViewController:(UIPageViewController *)pageViewController {
    // The number of items reflected in the page indicator.
    return 4;
}

- (NSInteger)presentationIndexForPageViewController:(UIPageViewController *)pageViewController {
    // The selected item reflected in the page indicator.
    return 0;
}


-(IBAction)NextBtn:(id)sender
{
    
    if (pageIndex==4) {
        
    }
    else if(pageIndex==0)
    {
        pageIndex= pageIndex+1;
    }
    
    initialViewController = [self viewControllerAtIndex:1];
    
    NSArray *viewControllers = [NSArray arrayWithObject:initialViewController];
    
    [self.pageController setViewControllers:viewControllers direction:UIPageViewControllerNavigationDirectionForward animated:NO completion:nil];
}

-(IBAction)BackBtn:(id)sender
{
    
    //if (pageIndex==0) {
      //  pageIndex=0;
    //}
    //else
    //{
      //  pageIndex--;
    //}
    
   // initialViewController = [self viewControllerAtIndex:pageIndex];
    
    NSArray *viewControllers = [NSArray arrayWithObject:initialViewController];
    
    [self.pageController setViewControllers:viewControllers direction:UIPageViewControllerNavigationDirectionReverse animated:NO completion:nil];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(IBAction)SubMitBtn:(id)sender
{
    @try {
        
        if (isOnlineStatus) {
            
            if ([self textfieldvalidation]) {
                
                spinner = [[UIActivityIndicatorView alloc]
                           initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
                spinner.frame = CGRectMake(0, 0, 320, 560); // CGPointMake(160, 240);
                spinner.color = [UIColor blueColor];
                spinner.backgroundColor = [UIColor lightTextColor];
                spinner.transform = CGAffineTransformMakeScale(2, 2);
                // spinner.hidesWhenStopped = YES;
                [self.view addSubview:spinner];
                spinner.transform = CGAffineTransformMakeScale(2, 2);
                
                [spinner startAnimating];
                
                // how we stop refresh from freezing the main UI thread
                
                dispatch_async(
                               dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^{
                                   
                                   // back to the main thread for the UI call
                                   dispatch_async(dispatch_get_main_queue(), ^{
                                       
                                       
                                       [spinner startAnimating];
                                   });
                                   dispatch_async(dispatch_get_main_queue(), ^{
                                       if ()
                                           
                                       {
                                           
                                           NSString *selectedDateTime = [NSString stringWithFormat:@"%@ %@",Datelabel.text,Timelabel.text];
                                           
                                           NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
                                           [dateFormatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
                                           NSTimeZone *gmt = [NSTimeZone timeZoneWithAbbreviation:@"UTC"];
                                           [dateFormatter setTimeZone:gmt];
                                           mFinalDate = [dateFormatter dateFromString:selectedDateTime];
                                           
                                           [timeWithInterval setValue:mFinalDate forKeyPath:@"Date"];
                                           
                                           
                                           
                                           NSDictionary *GetDateTime=[mTimeCalculator GetTimeintervals:timeWithInterval];
                                           
                                           
                                           NSDictionary *GetModuleIDAndCatID = [mTimeCalculator GetCateGory:SelectedSubCat];
                                           NSDictionary *GetAddress = [mTimeCalculator GetAddress];
                                           
                                           NSDictionary *GetOpportunity = [self GetOpportunityDetails];
                                           NSString *location = [NSString stringWithFormat:@"%@,%@",[GetAddress valueForKey:LATITUDE],[GetAddress valueForKey:LONGITUDE]];
                                           
                                           NSString *remainingTime;
                                           
                                           
                                           remainingTime = Time;// [NSString stringWithFormat:@"%d",Times];
                                           
                                           //   NSString *userID =   [mPref objectForKey:@"SaveUserID"];
                                           NSString *RegisterID =   [mPref objectForKey:USERREGISTERID];
                                           
                                           NSString *DeviceID = [[[UIDevice currentDevice] identifierForVendor] UUIDString];
                                           
                                           NSString *gcmID = [mPref valueForKey:@"FCMID"];
                                           if ([gcmID isEqualToString:@""] || gcmID==nil) {
                                               gcmID=@"";
                                           }
                                           
                                           if ([OpportunityID isEqualToString:@"0"]) {
                                               ActionKey= @"Save";
                                           }
                                           else ActionKey= @"Update";
                                           
                                           
                                           //  NSDictionary *Opportunity = [[NSDictionary alloc]init];
                                           
                                           NSDictionary *  Opportunity  = @{@"OpportunityID":OpportunityID,
                                                                            @"OpportunityName":[GetOpportunity valueForKey:@"OpportunityName"],
                                                                            @"OpportunityDescription":[GetOpportunity valueForKey:@"OpportunityName"],
                                                                            @"OpportunityKeywords":[GetOpportunity valueForKey:@"OpportunityKeywords"],
                                                                            @"CategoryID":[GetModuleIDAndCatID valueForKey:@"CategoryID"],
                                                                            @"ModuleId":@"43",
                                                                            @"UserID":@"0",
                                                                            
                                                                            @"StartDate":[GetDateTime valueForKey:@"StartDate"],
                                                                            @"EndDate":[GetDateTime valueForKey:@"EndDate"],
                                                                            @"PromoCode":@"Promo",
                                                                            @"OpportunityType":OppForKey,
                                                                            @"DeviceId":DeviceID,
                                                                            @"PhotoName":[GetOpportunity valueForKey:@"PhotoName"],
                                                                            @"VendorAddressId":VendorAddressId,
                                                                            @"TimeInterval":[GetDateTime valueForKey:@"TimeInterval"],
                                                                            @"GcmId":gcmID,
                                                                            @"AddressName":[GetOpportunity valueForKey:@"AddressName"],
                                                                            @"IsPrimary":@"true",
                                                                            @"Address1":[GetAddress valueForKey:@"Address1"],
                                                                            @"Address3":[GetAddress valueForKey:@"Address3"],
                                                                            @"Address2":[GetAddress valueForKey:@"Address2"],
                                                                            @"AreaName":[GetAddress valueForKey:@"AreaName"],
                                                                            @"Quantity":@"",
                                                                            @"City":[GetAddress valueForKey:@"City"],
                                                                            @"State":[GetAddress valueForKey:@"State"],
                                                                            @"Country":[GetAddress valueForKey:@"Country"],
                                                                            LATITUDE:[GetAddress valueForKey:LATITUDE],
                                                                            LONGITUDE:[GetAddress valueForKey:LONGITUDE],
                                                                            @"KeyWords":@"",
                                                                            @"Time":remainingTime,
                                                                            @"PageSize":@"10",
                                                                            @"PageNo":@"1",
                                                                            @"radius":@"1000",
                                                                            @"LocationFlag":@"NotChanged",
                                                                            @"Location":location,
                                                                            @"Categories":@"",
                                                                            @"types":@"",
                                                                            @"UserRegisterId":RegisterID,
                                                                            @"Name":meetingDescription.text,
                                                                            @"Price":@"",
                                                                            @"ActualPrice":@"",
                                                                            @"Delivery":@"",
                                                                            @"Action":ActionKey
                                                                            
                                                                            };
                                           
                                           if (isOnlineStatus) {
                                               NSDictionary *Reponse =   [[Web_Services GetSharedInstance]PostOffer:Opportunity];
                                               if (Reponse!=nil && [Reponse count]>6) {
                                                   
                                                   
                                                   if ([SendSMSKey isEqualToString:@"1"]) {
                                                       NSString *StoreName =@"";
                                                       NSArray *phonenumbersarra;
                                                       
                                                       NSString   * UserRegID  =[NSString stringWithFormat:@"%@",[mPref valueForKey:USERREGISTERID]];
                                                       
                                                       if ([OppForKey isEqualToString:@"2"] || [OppForKey isEqualToString:@"1"]) {
                                                           UserRegID= [NSString stringWithFormat:@"%@/Customer",UserRegID];
                                                       }
                                                       else if ([OppForKey isEqualToString:@"3"])
                                                       {
                                                           UserRegID= [NSString stringWithFormat:@"%@/Business",UserRegID];
                                                       }
                                                       
                                                       
                                                       NSMutableArray *contactsArray = [mWebService GetMyCustomers:UserRegID];
                                                       phonenumbersarra = [contactsArray valueForKey:@"PhoneNo"];
                                                       //PhoneNo
                                                       NSLog(@"%@",contactsArray);
                                                       
                                                       NSData  *VendorData =    [mPref valueForKey:@"SaveRegisterDetails"];
                                                       NSDictionary *myDictionary =   (NSDictionary*) [NSKeyedUnarchiver unarchiveObjectWithData:VendorData];
                                                       NSLog(@"%@",myDictionary);
                                                       
                                                       ;
                                                       
                                                       // NSString *regName ;
                                                       if ([[mPref valueForKey:LOGINTYPE] isEqualToString:@"Business"]) {
                                                           StoreName=[myDictionary valueForKey:@"RegUserName"];
                                                       }
                                                       else if ([[mPref valueForKey:LOGINTYPE] isEqualToString:@"Individual"])
                                                           StoreName=[[myDictionary  valueForKey:@"BusinessDeatils"] valueForKey:@"ContactPerson"];
                                                       
                                                       self.smsPopUp = [[SMSController alloc] initWithNibName:@"SMSController" bundle:nil];
                                                       [self.smsPopUp setTitle:@"This is a popup view"];
                                                       
                                                       self.smsPopUp.StoreName.text =StoreName;
                                                       self.smsPopUp.CustomerNumbers=phonenumbersarra;
                                                       
                                                       self.smsPopUp.OppName=meetingDescription.text;
                                                       self.smsPopUp.messageView.text = meetingDescription.text;
                                                       self.smsPopUp.StoreNameText =StoreName;
                                                       
                                                       [self.smsPopUp showInView:self.view withImage:[UIImage imageNamed:@"rprt_usinfo.png"] withMessage:@"You just triggered a great popup window" animated:YES];
                                                       
                                                   }
                                                   
                                               }
                                               else
                                               {
                                                   [self showAlertPop:@"oops, We are unable to process your request! Please try after some time." expObj:nil];
                                               }
                                               
                                           }
                                           else
                                           {
                                               
                                               [self showAlertPop:@"No internet connection." expObj:nil];
                                               
                                               
                                           }
                                           
                                           //}
                                           
                                       }
                                       [spinner stopAnimating];
                                       
                                   });
                               });
            }
        }
        else
        {
            [self showAlertPop:@"No internet connection" expObj:nil];
        }
    }
    @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
        
    }
    @finally {
        
    }
    
}


/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
