//
//  Posting.h
//  RPRT
//
//  Created by sravanthi Gumma on 08/01/16.
//  Copyright © 2016 DevpointSolutions. All rights reserved.
//


#import <MapKit/MapKit.h>
#import <MobileCoreServices/MobileCoreServices.h>
#import "MainViewController.h"

@interface Posting : UIViewController<UIImagePickerControllerDelegate,UITextViewDelegate,UINavigationControllerDelegate,MKMapViewDelegate,CLLocationManagerDelegate>
{
    NSDictionary *GetLoginResponse;
    NSString  *Category;
    NSString  *Time;
    NSString  *TypeCategory;
    CLLocationManager *locationManager;
    CLLocationCoordinate2D currentCentre;
    int currenDist;
    BOOL firstLaunch;
    NSDictionary *EditOpp;
}

@property (weak, nonatomic) IBOutlet UITextField *Limit;
@property (weak, nonatomic) IBOutlet UIButton *TypeCat;
@property (weak, nonatomic) IBOutlet UIButton *SelectType;
@property (weak, nonatomic) IBOutlet UIButton *ActiveType;
@property (nonatomic,weak)IBOutlet UITextField *selectedDateLbl;
@property (nonatomic,weak)IBOutlet UITextField *selectedTimeLbl;
@property (weak, nonatomic) IBOutlet UITextField *Address;
@property (weak, nonatomic) IBOutlet UITextField *keyWords;
@property (weak, nonatomic) IBOutlet UITextField *SelectdAddress;
@property (weak, nonatomic) IBOutlet UITextView *Description;
@property (weak, nonatomic) IBOutlet MKMapView *mapView;
@property (nonatomic,strong) UIButton *submit;
@property (weak,nonatomic) IBOutlet UIButton *settingsBtn;
@property (weak,nonatomic) IBOutlet UIButton *Radious;

-(IBAction)selectDateBtn:(id)sender;
-(IBAction)selectTimeBtn:(id)sender;
-(IBAction)takePhoto:(id)sender;
-(IBAction)SelectType:(id)sender;
-(IBAction)TipeCategory:(id)sender;
-(IBAction)Back:(id)sender;

@property(nonatomic,strong) NSDictionary *SetLoginResponse;
@property (nonatomic, copy) NSMutableArray *chosenImages;
@property (nonatomic, strong) NSDictionary *EditOpportunity;



@end
