//
//  Posting.m
//  RPRT
//
//  Created by sravanthi Gumma on 08/01/16.
//  Copyright © 2016 DevpointSolutions. All rights reserved.
//

#import "Posting.h"


@interface Posting ()<UIImagePickerControllerDelegate,CLLocationManagerDelegate>
{
    UIGestureRecognizer *keyboard;
    UIDatePicker *datePicker;
    UIScrollView *PhotoScroll;
    UIImage *originalImage;
    UIDatePicker*  datepickerDate;
    UIView *Timepicker;
    UIView *Datepicker;
   
    Web_Services *mWebService;
    NSDictionary *GetCategoryresponse;
    GeoCodeLocation *Addre;
    NSString *StoredAddres;
    NSMutableArray *arrayOFAddress;
    NSMutableArray  *Images;
    UIView *contentView;
    UIView *RadiousView;
    NSUserDefaults *prefss;
    CGRect workingFrame;
    UIButton *radiousMenu;
    
}
@property (weak, nonatomic) IBOutlet UIView *Contentview;
@property (weak, nonatomic) IBOutlet UIScrollView *scrollview;
@end

@implementation Posting
@synthesize Description,selectedDateLbl,selectedTimeLbl,keyWords,Address,submit,SelectdAddress,chosenImages,Limit,TypeCat,SelectType,ActiveType,mapView,EditOpportunity,Radious,settingsBtn;


- (void)viewDidLoad {
    [super viewDidLoad];

    @try {
        GetLoginResponse = self.SetLoginResponse;
        NSDictionary *EditOpps= self.EditOpportunity;
        if (EditOpps!=nil) {
            [self DataforEdit:EditOpps];
        }
        mWebService =[Web_Services GetSharedInstance];
        prefss = [NSUserDefaults standardUserDefaults];
        
        //ModuleID
        
        if([[prefss valueForKey:MODULEID] isEqualToString:@"1"])
        {
            
        }
        
        
        keyboard= [[UIGestureRecognizer alloc]initWithTarget:self action:@selector(didtapanywhere:)];
        submit = [[UIButton alloc]init];
        [submit setTitle:@"Submit" forState:UIControlStateNormal];
        [submit setBackgroundColor:[UIColor colorWithRed:33.0/255.0 green:150.0/255.0 blue:243.0/255.0 alpha:1]];

        submit.frame = CGRectMake(16, 730, 330, 40);
        [submit addTarget:self action:@selector(Submit:) forControlEvents:UIControlEventTouchUpInside];
        [self.Contentview addSubview:submit];
        Addre = [ GeoCodeLocation  GetSharedInstance];
        [self SetBodertoView];
        mapView.delegate = self;
        // Ensure that we can view our own location in the map view.
        [mapView setShowsUserLocation:YES];
        //Instantiate a location object.
        locationManager = [[CLLocationManager alloc] init];
        locationManager.delegate = self;
        [locationManager setDesiredAccuracy:kCLLocationAccuracyBest];
        if ([[[UIDevice currentDevice] systemVersion] floatValue] >= 8) {
            [locationManager requestAlwaysAuthorization];
        }
        if ([[[UIDevice currentDevice] systemVersion] floatValue] >= 9.2) {
            locationManager.allowsBackgroundLocationUpdates = YES;
        }
        [locationManager startUpdatingLocation];
        CLLocation *location = [locationManager location];
        // coordinate = [location coordinate];
        CLLocationCoordinate2D centre = [mapView centerCoordinate];
        MKCoordinateRegion region;
        if (firstLaunch) {
            region = MKCoordinateRegionMakeWithDistance(locationManager.location.coordinate,1500,1500);
            firstLaunch=NO;
        }else {
            MKMapRect mRect = self.mapView.visibleMapRect;
            MKMapPoint eastMapPoint = MKMapPointMake(MKMapRectGetMinX(mRect), MKMapRectGetMidY(mRect));
            MKMapPoint westMapPoint = MKMapPointMake(MKMapRectGetMaxX(mRect), MKMapRectGetMidY(mRect));
            currenDist = MKMetersBetweenMapPoints(eastMapPoint, westMapPoint);
            region = MKCoordinateRegionMakeWithDistance(centre,currenDist,currenDist);
        }
        [mapView setRegion:region animated:YES];
        self.mapView.centerCoordinate = location.coordinate;
        UILongPressGestureRecognizer *longPressGesture = [[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(MapviewLongPress:)];
        [self.mapView addGestureRecognizer:longPressGesture];
        //  Get Vendor Address
        //NSUserDefaults *prefss = [NSUserDefaults standardUserDefaults];
        //SaveUserID
        //UserRegisterID
        NSString *RegisterID =   [prefss objectForKey:@"SaveUserID"];
        NSString *str = [NSString stringWithFormat:@"%@/%@",GETSTOREDADDRESS,RegisterID];
        NSDictionary *GetAddress = [[Web_Services GetSharedInstance]Getcategories:str];
        arrayOFAddress = [[NSMutableArray alloc]init];
        NSMutableArray *latti = [[NSMutableArray alloc]init];
        NSMutableArray *longi = [[NSMutableArray alloc]init];
        if((![GetAddress count])==0)
        {
            NSArray *address1 = [GetAddress valueForKey:@"Address1"];
            NSArray *address2 = [GetAddress valueForKey:@"Address2"];
            NSArray *address3 = [GetAddress valueForKey:@"Address3"];
            NSArray *latitude = [GetAddress valueForKey:@"Latitude"];
            NSArray *logitude = [GetAddress valueForKey:@"Longitude"];
            for (int i=0; i< [address1 count]; i++) {
                NSString *Adress = [NSString stringWithFormat:@"%@,%@,%@",address1[i],address2[i],address3[i]];
                [arrayOFAddress addObject:Adress];
                [latti addObject:latitude[i]];
                [longi addObject:logitude[i]];
            }

            if (arrayOFAddress[[address1 count]-1] !=nil) {
                Address.text =arrayOFAddress[[address1 count]-1];
                
                double lat =[latti[[latitude count]-1] floatValue];
                double lon = [longi[[logitude count]-1] floatValue];
                Addre = [[CurrentLocation GetSharedInstance]geoCodeArea:&lat Longitude:&lon];
            }
            else {
                double lat =location.coordinate.latitude;
                double lon = location.coordinate.longitude;
                Addre = [[CurrentLocation GetSharedInstance]geoCodeArea:&lat Longitude:&lon];
                Address.text = [NSString stringWithFormat:@"%@,%@,%@,%@",Addre.Address1,Addre.Address2,Addre.Address3,Addre.AreaName];
            }
        }
        else{
            
        }
        //[self LoadToolBar];

        
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {

    }
}

-(void)DataforEdit:(NSDictionary*)EditOpps {
    Description.text = [EditOpps valueForKey:@"OpportunityName"];
    Limit.text = [EditOpps valueForKey:@"Available"];
    keyWords.text =[EditOpps valueForKey:@"OpportunityKeywords"];
    NSString *startTime =[EditOpps valueForKey:@"StartDate"];
    NSArray *datetime = [startTime componentsSeparatedByString:@"T"];
    selectedDateLbl.text = [datetime objectAtIndex:0];
    selectedTimeLbl.text = [datetime objectAtIndex:1];
    [TypeCat setTitle:[EditOpps valueForKey:@"Category"] forState:UIControlStateNormal];
    
    //TypeCat.titleLabel.text =[EditOpps valueForKey:@"Category"];
    
    
}


-(void)AddMarkertoMap:(double)Lat lon:(double)lon coordinate:(CLLocationCoordinate2D)coordinate {
    @try {
        CLGeocoder *ceo = [[CLGeocoder alloc]init];
        CLLocation *loc = [[CLLocation alloc]initWithLatitude:Lat longitude:lon]; //insert your coordinates
        MKPointAnnotation *point1 = [[MKPointAnnotation alloc] init];
        point1.coordinate = coordinate;
        [ceo reverseGeocodeLocation:loc
                  completionHandler:^(NSArray *placemarks, NSError *error) {
                      point1.title = [NSString stringWithFormat:@"%@",Address.text];
                  }
         ];
        [self.mapView addAnnotation:point1];
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
}

-(void)SetBodertoView {
    @try {
        CALayer *borderTypeCat = [CALayer layer];
        //CGFloat borderWidth = 1;
        borderTypeCat.borderColor = [UIColor lightGrayColor].CGColor;
        [self SetBorderforButton:borderTypeCat Button:TypeCat];
        CALayer *borderselectType = [CALayer layer];
        //CGFloat borderWidth = 1;
        borderselectType.borderColor = [UIColor lightGrayColor].CGColor;
        [self SetBorderforButton:borderselectType Button:SelectType];
        CALayer *borderActiveType = [CALayer layer];
        //CGFloat borderWidth = 1;
        borderActiveType.borderColor = [UIColor lightGrayColor].CGColor;
        [self SetBorderforButton:borderActiveType Button:ActiveType];
        CALayer *borderlimit = [CALayer layer];
        borderlimit.borderColor = [UIColor lightGrayColor].CGColor;
        CALayer *borderAddress = [CALayer layer];
        borderAddress.borderColor = [UIColor lightGrayColor].CGColor;
        CALayer *borderKeyword = [CALayer layer];
        borderKeyword.borderColor = [UIColor lightGrayColor].CGColor;
        CALayer *borderActiveFor = [CALayer layer];
        borderActiveFor.borderColor = [UIColor lightGrayColor].CGColor;
        CALayer *borderSelectType = [CALayer layer];
        borderSelectType.borderColor = [UIColor lightGrayColor].CGColor;
        CALayer *borderDateLbl = [CALayer layer];
        borderDateLbl.borderColor = [UIColor lightGrayColor].CGColor;
        CALayer *borderTimeLbl = [CALayer layer];
        borderTimeLbl.borderColor = [UIColor lightGrayColor].CGColor;
        CALayer *borderSelectedAddress = [CALayer layer];
        borderSelectedAddress.borderColor = [UIColor lightGrayColor].CGColor;
        [self SetBorderToTextFieldL:borderKeyword Texfield:keyWords];
        [self SetBorderToTextFieldL:borderAddress Texfield:Address];
        [self SetBorderToTextFieldL:borderlimit Texfield:Limit];
        [self SetBorderToTextFieldL:borderDateLbl Texfield:selectedDateLbl];
        [self SetBorderToTextFieldL:borderTimeLbl Texfield:selectedTimeLbl];
        [self SetBorderToTextFieldL:borderSelectedAddress Texfield:SelectdAddress];
        
        NSDate *currentDateInLocal = [NSDate date];
        NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
        [dateFormatter setDateFormat:@"yyyy-MM-dd'T'HH:mm:SS"];
        NSString *currentLocalDateAsStr = [dateFormatter stringFromDate:currentDateInLocal];
        NSArray *date = [currentLocalDateAsStr componentsSeparatedByString:@"T"];
        
        selectedDateLbl.text = [NSString stringWithFormat:@"%@",[date objectAtIndex:0]];
        selectedTimeLbl.text = [NSString stringWithFormat:@"%@",[date objectAtIndex:1]];
        
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
}

-(void)SetBorderforButton:(CALayer*)Border Button:(UIButton*)Buttonname {
    @try {
        Border.borderColor = [UIColor lightGrayColor].CGColor;
        Border.frame = CGRectMake(0, Buttonname.frame.size.height - 1, Buttonname.frame.size.width, Buttonname.frame.size.height);
        Border.borderWidth = 1;//
        [Buttonname.layer addSublayer:Border];
        Buttonname.layer.masksToBounds = YES;
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
}

-(void)SetBorderToTextFieldL:(CALayer*)border Texfield:(UITextField*)TextfiedNam {
    @try {
        border.borderColor = [UIColor lightGrayColor].CGColor;
        border.frame = CGRectMake(0, TextfiedNam.frame.size.height - 1, TextfiedNam.frame.size.width, TextfiedNam.frame.size.height);
        border.borderWidth = 1;//
        [TextfiedNam.layer addSublayer:border];
        TextfiedNam.layer.masksToBounds = YES;
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
}

- (void)loadView {
    [super loadView];
    UITapGestureRecognizer *settings = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(handleSettingtap:)];
    UITapGestureRecognizer *radious = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(handleRadiousTap:)];
    [settingsBtn addGestureRecognizer:settings];
    [Radious addGestureRecognizer:radious];
    
    
}
- (void) handleSettingtap:(UIGestureRecognizer *) gestureRecognizer {
    
    CGPoint location = [gestureRecognizer locationInView:[gestureRecognizer view]];
    
    UIMenuController *menuController = [UIMenuController sharedMenuController];
    UIMenuItem *Setting = [[UIMenuItem alloc] initWithTitle:@"Settings" action:@selector(SettingClick:)];
    UIMenuItem *Home =[[UIMenuItem alloc] initWithTitle:HHOME action:@selector(Home:)];
    UIMenuItem *Post =[[UIMenuItem alloc] initWithTitle:@"Posts" action:@selector(Post:)];
    UIMenuItem *LogOut =[[UIMenuItem alloc] initWithTitle:@"LogOut" action:@selector(LogOut:)];
    
    
    NSAssert([self becomeFirstResponder], @"Sorry, UIMenuController will not work with %@ since it cannot become first responder", self);
    
    [menuController setMenuItems:[NSArray arrayWithObjects:Setting,Home,Post,LogOut,nil]];
    [menuController setTargetRect:CGRectMake(location.x+10, location.y+20, 0.0f, 0.0f) inView:[gestureRecognizer view]];
    [menuController setMenuVisible:YES animated:YES];
    
}
- (void) handleRadiousTap:(UIGestureRecognizer *) gestureRecognizer {
    
    CGPoint location = [gestureRecognizer locationInView:[gestureRecognizer view]];
    
    UIMenuController *menuController = [UIMenuController sharedMenuController];
    
    UIMenuItem *K500 = [[UIMenuItem alloc] initWithTitle:@"500 M" action:@selector(K500:)];
    UIMenuItem *K1000 = [[UIMenuItem alloc] initWithTitle:@"1 K" action:@selector(K1000:)];
    UIMenuItem *K2000 = [[UIMenuItem alloc] initWithTitle:@"2 K" action:@selector(K2000:)];
    UIMenuItem *K3000 = [[UIMenuItem alloc] initWithTitle:@"3 K" action:@selector(K3000:)];
    UIMenuItem *K5000 = [[UIMenuItem alloc] initWithTitle:@"4 K" action:@selector(K5000:)];
    
    
    NSAssert([self becomeFirstResponder], @"Sorry, UIMenuController will not work with %@ since it cannot become first responder", self);
    
    [menuController setMenuItems:[NSArray arrayWithObjects:K500,K1000,K2000,K3000,K5000,nil]];
    [menuController setTargetRect:CGRectMake(location.x+10, location.y+20, 0.0f, 0.0f) inView:[gestureRecognizer view]];
    [menuController setMenuVisible:YES animated:YES];
    
}

- (void) SettingClick:(id) sender {
    
    Setting * mSetting = [[ Setting alloc] initWithNibName:SETTINGS bundle:nil];
    [self presentViewController:mSetting animated:YES completion:nil];
    
}

- (void) LogOut:(id) sender {
    [prefss setValue:nil forKey:USERREGISTERID];
    [prefss setValue:nil forKey:@"SaveLoginUserDetails"];
    Login * mLogin = [[ Login alloc] initWithNibName:LOGIN bundle:nil];
    [self presentViewController:mLogin animated:YES completion:nil];
    
}
- (void) Post:(id) sender {
    Login * mLogin = [[ Login alloc] initWithNibName:LOGIN bundle:nil];
    [self presentViewController:mLogin animated:YES completion:nil];
    
}

- (void) Home:(id) sender {
    Login * mLogin = [[ Login alloc] initWithNibName:LOGIN bundle:nil];
    [self presentViewController:mLogin animated:YES completion:nil];
    
}


- (void) K500:(id) sender {
    [self StoreRadios:@"500"];
}
- (void) K1000:(id) sender {
    [self StoreRadios:@"1000"];
}

- (void) K2000:(id) sender {
    [self StoreRadios:@"2000"];
}

- (void) K3000:(id) sender {
    [self StoreRadios:@"3000"];
}
- (void) K5000:(id) sender {
    [self StoreRadios:@"5000"];
}
- (BOOL) canPerformAction:(SEL)selector withSender:(id) sender
{
    if (selector == @selector(SettingClick:))
    {
        return YES;
    }
    if (selector == @selector(Home:))
    {
        return YES;
    }
    if (selector == @selector(LogOut:))
    {
        return YES;
    }
    if (selector == @selector(Post:))
    {
        return YES;
    }
   
    
    if (selector == @selector(copy:))
    {
        return NO;
    }
    return NO;
}
- (BOOL) canBecomeFirstResponder {
    return YES;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void) viewDidLayoutSubviews {
    @try {
        [ super viewDidLayoutSubviews];
        [self.scrollview layoutIfNeeded];



//        CGFloat scrollViewHeight = 0.0f;
//
//        [self.scrollview setContentSize:(CGSizeMake(320, self.Contentview.bounds.size ))];


        //NSLog(@"%@" ,self.Contentview.bounds.size);
        self.scrollview.contentSize=self.Contentview.bounds.size ;

        UIGraphicsBeginImageContext(self.view.frame.size);
        UIImage *image = UIGraphicsGetImageFromCurrentImageContext();
        UIGraphicsEndImageContext();
        self.Contentview.backgroundColor = [UIColor colorWithPatternImage:image];
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
}

-(void)MapviewLongPress:(UIGestureRecognizer*)sender {
    @try {
        if (sender.state == UIGestureRecognizerStateEnded)
        {
            [self.mapView removeGestureRecognizer:sender];
        }
        else
        {
            CGPoint point = [sender locationInView:self.mapView];
            NSMutableArray * annotationsToRemove = [ self.mapView.annotations mutableCopy ] ;
            [ annotationsToRemove removeObject:self.mapView.userLocation ] ;
            [ self.mapView removeAnnotations:annotationsToRemove ] ;
            CLLocationCoordinate2D coordinate= [self.mapView convertPoint:point toCoordinateFromView:self.mapView];
            double lat = coordinate.latitude;
            double lon = coordinate.longitude;
            Addre = [[CurrentLocation GetSharedInstance]geoCodeArea:&lat Longitude:&lon];
            [self AddMarkertoMap:lat lon:lon coordinate:coordinate];
            Address.text = [NSString stringWithFormat:@"%@,%@,%@",Addre.Address1,Addre.Address2,Addre.Address3];
            
        }
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
}

- (void)textViewDidBeginEditing:(UITextView *)textView {
    @try {
        if ([Description.text isEqualToString:@"Description"]) {
            Description.text = @"";
            Description.textColor = [UIColor blackColor]; //optional
        }
        [Description becomeFirstResponder];
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
}

- (IBAction)hideKeyBoardTypecategory:(id)sender {

}

- (IBAction)hideKeyBoardKeyWord:(id)sender {
    
}

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event {
    @try {
        if ([keyWords isFirstResponder]) {
            [keyWords resignFirstResponder];
        }
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    }
}

-(void)didtapanywhere:(UIGestureRecognizer*)recog {
    [Description resignFirstResponder];
    [keyWords resignFirstResponder];
}


-(IBAction)selectDateBtn:(id)sender {
    @try {
        Datepicker = [[UIView alloc]initWithFrame:CGRectMake(10, 250,350, 400)];
        [Datepicker setBackgroundColor:[UIColor whiteColor]];
        datepickerDate =[[UIDatePicker alloc]initWithFrame:CGRectMake(0, 0,300, 200)];
        datepickerDate.datePickerMode=UIDatePickerModeDate;
        datepickerDate.hidden=NO;
        datepickerDate.date=[NSDate date];
        datepickerDate.layer.borderColor = [UIColor colorWithRed:240.0/255.0 green:240.0/255.0 blue:240.0/255.0 alpha:1].CGColor;
        [datepickerDate addTarget:self action:@selector(DatePickerDateChange:) forControlEvents:UIControlEventValueChanged];
        datepickerDate.layer.borderWidth = 1;
        datepickerDate.backgroundColor = [UIColor whiteColor];
        datepickerDate.layer.masksToBounds = YES;
        datepickerDate.layer.cornerRadius = 2;
        NSDateFormatter *dateformatter=[[NSDateFormatter alloc]init];
        [dateformatter setDateFormat:@"HH:mm:ss"];
        [Datepicker addSubview:datepickerDate];
        UIButton *Cancel = [[UIButton alloc]initWithFrame:CGRectMake(0, 210, 150, 35)];
        [Cancel setTitle:@"Cancel" forState:UIControlStateNormal];
        [Cancel addTarget:self action:@selector(DateCancel:) forControlEvents:UIControlEventTouchUpInside];
        [Cancel setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
        [Cancel setBackgroundColor:[UIColor whiteColor]];
        Cancel.layer.borderColor = [UIColor colorWithRed:240.0/255.0 green:240.0/255.0 blue:240.0/255.0 alpha:1].CGColor ;
        Cancel.layer.borderWidth = 1;
        Cancel.backgroundColor = [UIColor whiteColor];
        Cancel.layer.masksToBounds = YES;
        Cancel.layer.cornerRadius = 2;
        [Datepicker addSubview:Cancel];
        UIButton *Select = [[UIButton alloc]initWithFrame:CGRectMake(150, 210, 150, 35)];
        [Select setTitle:@"Select" forState:UIControlStateNormal];
        [Select addTarget:self action:@selector(DateSelect:) forControlEvents:UIControlEventTouchUpInside];
        [Select setTitleColor:[UIColor blueColor] forState:UIControlStateNormal];
        [Select setBackgroundColor:[UIColor whiteColor]];
        Select.layer.borderColor = [UIColor colorWithRed:240.0/255.0 green:240.0/255.0 blue:240.0/255.0 alpha:1].CGColor;
        Select.layer.borderWidth = 1;
        Select.backgroundColor = [UIColor whiteColor];
        Select.layer.masksToBounds = YES;
        Select.layer.cornerRadius = 2;
        [Datepicker addSubview:Select];
        [self.Contentview addSubview:Datepicker];
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
}

-(void)DateSelect:(UIButton*)sender {
    [Datepicker removeFromSuperview];
}

-(void)DateCancel:(UIButton*)sender {
    [Datepicker removeFromSuperview];
}

-(void)DatePickerDateChange:(UIButton*)sender {
    @try {
        NSDateFormatter *dateFormat=[[NSDateFormatter alloc]init];
        dateFormat.dateStyle=NSDateFormatterMediumStyle;
        [dateFormat setDateFormat:@"yyyy-MM-dd"];
        NSString *str=[NSString stringWithFormat:@"%@",[dateFormat  stringFromDate:datepickerDate.date]];
        selectedDateLbl.text = str;
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
}

-(IBAction)selectTimeBtn:(id)sender {
    @try {
        Timepicker = [[UIView alloc]initWithFrame:CGRectMake(10, 250,350, 400)];
        [Timepicker setBackgroundColor:[UIColor whiteColor]];
        datepickerDate =[[UIDatePicker alloc]initWithFrame:CGRectMake(0, 0,300, 200)];
        datepickerDate.datePickerMode=UIDatePickerModeTime;
        datepickerDate.hidden=NO;
        datepickerDate.date=[NSDate date];
        datepickerDate.layer.borderColor = [UIColor colorWithRed:240.0/255.0 green:240.0/255.0 blue:240.0/255.0 alpha:1].CGColor;
        [datepickerDate addTarget:self action:@selector(TimePickerTimeChange:) forControlEvents:UIControlEventValueChanged];
        datepickerDate.layer.borderWidth = 1;
        datepickerDate.backgroundColor = [UIColor whiteColor];
        datepickerDate.layer.masksToBounds = YES;
        datepickerDate.layer.cornerRadius = 2;
        NSDateFormatter *dateformatter=[[NSDateFormatter alloc]init];
        [dateformatter setDateFormat:@"HH:mm:ss"];
        [Timepicker addSubview:datepickerDate];
        UIButton *Cancel = [[UIButton alloc]initWithFrame:CGRectMake(0, 210, 150, 35)];
        [Cancel setTitle:@"Cancel" forState:UIControlStateNormal];
        [Cancel addTarget:self action:@selector(TimeCancel:) forControlEvents:UIControlEventTouchUpInside];
        [Cancel setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
        [Cancel setBackgroundColor:[UIColor whiteColor]];
        Cancel.layer.borderColor = [UIColor colorWithRed:240.0/255.0 green:240.0/255.0 blue:240.0/255.0 alpha:1].CGColor ;
        Cancel.layer.borderWidth = 1;
        Cancel.backgroundColor = [UIColor whiteColor];
        Cancel.layer.masksToBounds = YES;
        Cancel.layer.cornerRadius = 2;
        [Timepicker addSubview:Cancel];
        UIButton *Select = [[UIButton alloc]initWithFrame:CGRectMake(150, 210, 150, 35)];
        [Select setTitle:@"Select" forState:UIControlStateNormal];
        [Select addTarget:self action:@selector(TimeSelect:) forControlEvents:UIControlEventTouchUpInside];
        [Select setTitleColor:[UIColor blueColor] forState:UIControlStateNormal];
        [Select setBackgroundColor:[UIColor whiteColor]];
        Select.layer.borderColor = [UIColor colorWithRed:240.0/255.0 green:240.0/255.0 blue:240.0/255.0 alpha:1].CGColor;
        Select.layer.borderWidth = 1;
        Select.backgroundColor = [UIColor whiteColor];
        Select.layer.masksToBounds = YES;
        Select.layer.cornerRadius = 2;
        [Timepicker addSubview:Select];
        [self.Contentview addSubview:Timepicker];

    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
}

-(void)TimePickerTimeChange:(UIButton*)sender {
    @try {
        NSDateFormatter *dateFormat=[[NSDateFormatter alloc]init];
        dateFormat.dateStyle=UIDatePickerModeTime;

        [dateFormat setDateFormat:@"H:mm:ss"];
        NSString *str1=[NSString stringWithFormat:@"%@",[dateFormat  stringFromDate:datepickerDate.date]];
        selectedTimeLbl.text = str1;
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
}

-(void)TimeCancel:(UIButton*)sender {
    [Timepicker removeFromSuperview];
}

-(void)TimeSelect:(UIButton*)sender {
    [Timepicker removeFromSuperview];
}


-(void)save:(id)sender {
    self.navigationItem.rightBarButtonItem=nil;
    [datePicker removeFromSuperview];
}

-(IBAction)takePhoto:(id)sender {
    @try {
        UIImagePickerController *picker = [[UIImagePickerController alloc] init];
        picker.delegate = self;
        picker.allowsEditing = YES;
        picker.sourceType = UIImagePickerControllerSourceTypeCamera;

        [self presentViewController:picker animated:YES completion:NULL];
    } @catch (NSException *exception) {
[self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
}

- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info {
    @try {
        UIImage *chosenImage = info[UIImagePickerControllerEditedImage];
        UIImageView *imageview ;//= [[UIImageView alloc]initWithFrame:CGRectMake(16, 645, 335, 200)];
         imageview = [[UIImageView alloc] initWithImage:chosenImage];
        Images = [NSMutableArray arrayWithCapacity:[info count]];
        [Images addObject:chosenImage];
        imageview.image = chosenImage;
        [self.Contentview addSubview:submit];
        [self.Contentview addSubview:imageview];

        [picker dismissViewControllerAnimated:YES completion:NULL];

        if(PhotoScroll == nil)
        {
            PhotoScroll = [[UIScrollView alloc]initWithFrame:CGRectMake(16, 360, 335, 500)];
            workingFrame = PhotoScroll.frame;
            imageview.frame = workingFrame;
            [PhotoScroll addSubview:imageview];
            [self imageScrollCitentView];
        }
        else{
            imageview.frame = workingFrame;
            [PhotoScroll addSubview:imageview];
             workingFrame.origin.x = workingFrame.origin.x + workingFrame.size.width;
            [self imageScrollCitentView];
        }


    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
}

- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker {
    [picker dismissViewControllerAnimated:YES completion:NULL];
}


#pragma mark ELCImagePickerControllerDelegate Methods

- (void)imageScrollCitentView {

    [PhotoScroll setPagingEnabled:YES];
    
    [PhotoScroll setContentSize:CGSizeMake(workingFrame.origin.x, workingFrame.size.height)];
    UITapGestureRecognizer *singleTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(oneTap:)];
    [singleTap setNumberOfTapsRequired:1];
    [singleTap setNumberOfTouchesRequired:1];
    [submit addGestureRecognizer:singleTap];
      [self.Contentview addSubview:submit];
    [self.Contentview addSubview:PhotoScroll];
    submit.frame = CGRectMake(16, 870, 335, 40);
  
   // CGRect oldFrame = self.Contentview.frame;
     self.scrollview.contentSize= CGSizeMake(self.Contentview.frame.size.width,self.Contentview.frame.size.height+50);

    
}

- (void)oneTap:(UIGestureRecognizer *)gesture {
  //  int myViewTag = gesture.view.tag;  // now you know which view called
    // use myViewTag to specify individual actions;
}



- (IBAction)textFieldDidBeginEditing:(id)textField {
    //[self animateTextField:textField up:YES];
      //NSDictionary *GetCategoryresponse = [[Web_Services GetSharedInstance]Getcategories:@"GetCategories"];
}

-(IBAction)SelectType:(id)sender {
    
    @try {
        NSArray * arr = [[NSArray alloc] init];
        arr = [NSArray arrayWithObjects:@"SelectType",FOOD,PROFESSIONALHELP,SALES,SPORTS,nil];
        NSArray *img = [NSArray arrayWithObjects:@"Category",nil];

        if(dropDown == nil) {
            CGFloat f = 200;
            //  dropDown = [[NIDropDown alloc]showDropDownForActiveFor:sender :&f :arr :img :@"down"];
            dropDown = [[NIDropDown alloc]showDropDownForActiveFor:sender height:&f array:arr imgArr:img direction:@"down"];
            dropDown.delegate = self;
        }
        else {
            [dropDown hideDropDown:sender];
            [self rel];
        }
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
}

-(void)rel {
    
    dropDown = nil;
}

- (void) niDropDownDelegateMethod2: (NSString *) selectedindex {
    Category = [NSString stringWithFormat:@"%@", selectedindex];
    
}

-(IBAction)ActiveFor:(id)sender {
    @try {
        NSArray *activefor = [NSArray arrayWithObjects:@"15 Minits",@"30 Minits",@"45 Minits",@"60 Minits",nil];
        NSArray *img = [NSArray arrayWithObjects:@"Time",nil];
        if(dropDown == nil) {
            CGFloat f = 200;
            //dropDown = [[NIDropDown alloc]showDropDownForActiveFor:sender :&f :activefor :img :@"down"];
            
             dropDown = [[NIDropDown alloc]showDropDownForActiveFor:sender height:&f array:activefor imgArr:img direction:@"down"];
            
            dropDown.delegate = self;
        }
        else {
            [dropDown hideDropDown:sender];
            [self rel2];
        }
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
}

-(void)rel2{
    dropDown = nil;
}

- (void) niDropDownDelegateMethod1: (NSString *) selectedindex {
    Time = [NSString stringWithFormat:@"%@", selectedindex];
   
}

-(IBAction)TipeCategory:(id)sender {

    @try {
        GetCategoryresponse = [[Web_Services GetSharedInstance]Getcategories:@"GetCategories"];
        NSArray  *cat = [GetCategoryresponse valueForKey:CATEGORY];
        //dropDown=nil;
         NSArray *img = [NSArray arrayWithObjects:@"TypeCategory",nil];
        if(dropDown == nil) {
            CGFloat f = 200;
           // dropDown = [[NIDropDown alloc]showDropDownForActiveFor:sender :&f :cat :img :@"down"];
            
            dropDown = [[NIDropDown alloc]showDropDownForActiveFor:sender height:&f array:cat imgArr:img direction:@"down"];
            
            dropDown.delegate = self;
        }
        else {
            [dropDown hideDropDown:sender];
            [self rel1];
        }
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
}

-(void)rel1{
    dropDown = nil;
}

- (void) niDropDownDelegateMethod: (NSString *) selectedindex {
    TypeCategory = [NSString stringWithFormat:@"%@", selectedindex];
}

-(IBAction)GetLocations:(id)sender {
    @try {
        //dropDown=nil;
          NSArray *img = [NSArray arrayWithObjects:@"Address",nil];
        if(dropDown == nil) {
            CGFloat f = 200;
             dropDown = [[NIDropDown alloc]showDropDownForActiveFor:sender height:&f array:arrayOFAddress imgArr:img direction:@"down"];
            
           // dropDown = [[NIDropDown alloc]showDropDownForActiveFor:sender :&f :arrayOFAddress :img :@"down"];
            dropDown.delegate = self;
        }
        else {
            [dropDown hideDropDown:sender];
            [self rel1];
        }
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
}

- (void) niDropDownLocation:(NSString *)sender {
    StoredAddres = [NSString stringWithFormat:@"%@", sender];
    NSLog(@"%@",StoredAddres);
}

-(IBAction)Back:(id)sender {
    @try {
        
[self dismissViewControllerAnimated:YES completion:NULL];        
        

    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
}

// Upload data into Server
-(void)Submit:(UIButton*) sender {
    @try {
        
        if ([selectedDateLbl.text isEqualToString:@""] && [selectedTimeLbl.text isEqualToString:@""]) {
            
             [self showAlertPop:@"Please select Date and Time" expObj:nil];
        }
       else if ([Category isEqualToString:@""] && [TypeCategory isEqualToString:@""]) {
           [self showAlertPop:@"Please select Category and Type Category" expObj:nil];

           
        }
       else if ([Time  isEqualToString:@""]) {
             [self showAlertPop:@"Please select time limit" expObj:nil];
           
        }
        
       else if ([Limit.text isEqualToString:@""]) {
            [self showAlertPop:@"Please enter limit of your quantity" expObj:nil];
           
        }
      else  if ([Description.text isEqualToString:@""]) {
            [self showAlertPop:@"Please enter Description" expObj:nil];
          
        }
        
      else  if ([keyWords.text isEqualToString:@""]) {
          [self showAlertPop:@"Please enter Keywords" expObj:nil];

          
      }
        
      else  if (![selectedDateLbl.text isEqualToString:@""] && ![selectedTimeLbl.text isEqualToString:@""] && ![Category isEqualToString:@""] && ![TypeCategory isEqualToString:@""] && ![Time  isEqualToString:@""] && ![Limit.text isEqualToString:@""]) {
            
            NSDictionary *GetDateTime = [self GetDate:selectedDateLbl.text Time:selectedTimeLbl.text];
            NSDictionary *GetModuleIDAndCatID = [self GetCateGory:Category CategoryId:TypeCategory];
            NSDictionary *GetAddress = [self GetAddress];
            NSDictionary *GetOpportunity = [self GetOpportunityDetails];
            NSString *location = [NSString stringWithFormat:@"%@,%@",[GetAddress valueForKey:@"Latitude"],[GetAddress valueForKey:@"Longitude"]];
            
            
            NSString *remainingTime;
          NSString *time =[prefss objectForKey:@"TimeSlot"];
          NSLog(@"%@",time);
          
            if ([[prefss objectForKey:@"TimeSlot"] intValue]<[[GetDateTime valueForKey:@"Time"] intValue]) {
                [self showAlertPop:@"Time Exceeded" expObj:nil];

            }
//
            else
            {
                
                
                int Times = [[prefss objectForKey:@"TimeSlot"] intValue]-[[GetDateTime valueForKey:@"Time"] intValue];
                remainingTime = [NSString stringWithFormat:@"%d",Times];
                
                NSString *userID =   [prefss objectForKey:@"SaveUserID"];
                NSString *RegisterID =   [prefss objectForKey:USERREGISTERID];
                
                
                //NSString *addresname = [GetOpportunity valueForKey:@"AddressName"];
                
                
                NSString *DeviceID = [[[UIDevice currentDevice] identifierForVendor] UUIDString];
                NSDictionary *Opportunity  = @{@"OpportunityID":@"0",
                                               @"OpportunityName":[GetOpportunity valueForKey:@"OpportunityName"],
                                               @"OpportunityDescription":[GetOpportunity valueForKey:@"OpportunityName"],
                                               @"OpportunityKeywords":[GetOpportunity valueForKey:@"OpportunityKeywords"],
                                               @"CategoryID":[GetModuleIDAndCatID valueForKey:@"CategoryID"],
                                               @"ModuleId":[GetModuleIDAndCatID valueForKey:@"ModuleId"],
                                               @"UserID":userID,
                                               @"VendorAddressId":@"",
                                               @"StartDate":[GetDateTime valueForKey:@"StartDate"],
                                               @"EndDate":[GetDateTime valueForKey:@"EndDate"],
                                               @"PromoCode":@"Promo",
                                               @"OpportunityType":@"1",
                                               @"DeviceId":DeviceID,
                                               @"PhotoName":[GetOpportunity valueForKey:@"PhotoName"],
                                               @"VendorAddressId":@"",
                                               @"TimeInterval":[GetDateTime valueForKey:@"TimeInterval"],
                                               @"GcmId":@"",
                                               @"AddressName":[GetOpportunity valueForKey:@"AddressName"],
                                               @"IsPrimary":@"true",
                                               @"Address1":[GetAddress valueForKey:@"Address1"],
                                               @"Address3":[GetAddress valueForKey:@"Address3"],
                                               @"Address2":[GetAddress valueForKey:@"Address2"],
                                               @"AreaName":[GetAddress valueForKey:@"AreaName"],
                                               @"Quantity":[GetAddress valueForKey:@"Quantity"],
                                               @"City":[GetAddress valueForKey:@"City"],
                                               @"State":[GetAddress valueForKey:@"State"],
                                               @"Country":[GetAddress valueForKey:@"Country"],
                                               @"Latitude":[GetAddress valueForKey:@"Latitude"],
                                               @"Longitude":[GetAddress valueForKey:@"Longitude"],
                                               @"KeyWords":@"",
                                               @"Time":remainingTime,
                                               @"PageSize":@"10",
                                               @"PageNo":@"1",
                                               @"radius":@"500",
                                               @"LocationFlag":@"NotChanged",
                                               @"Location":location,
                                               @"Categories":@"",
                                               @"types":@"",
                                               @"UserRegisterId":RegisterID
                                               };
                
                NSDictionary *Reponse =   [[Web_Services GetSharedInstance]PostOffer:Opportunity];
                if (Reponse!=nil) {
                    [prefss setObject:remainingTime forKey:@"TimeSlot"];

                    Retailer_Offer * mOpportunity_list = [[ Retailer_Offer alloc] initWithNibName:RETAILER bundle:nil];
                    [self presentViewController:mOpportunity_list animated:YES completion:nil];
                }
                
            }
            
        }
        
       
        
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
}

-(NSDictionary*)GetDate:(NSString*)Date Time:(NSString*)selectedtime {
    @try {
        NSMutableDictionary *DateTime = [[NSMutableDictionary alloc]init];

        NSString* StartDate = [NSString stringWithFormat:@"%@ %@",Date,selectedtime];
        NSString *dat=selectedtime;
        NSDateFormatter *dateFormatter = [[NSDateFormatter alloc]init];
        [dateFormatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
        
        
        NSTimeZone *gmt = [NSTimeZone timeZoneWithAbbreviation:@"UTC"];
        [dateFormatter setTimeZone:gmt];
        
        
        NSDate * dateNotFormatted111  =[dateFormatter dateFromString:StartDate];
        StartDate = [dateFormatter stringFromDate:dateNotFormatted111];


        NSArray *arr = [dat componentsSeparatedByString:@":"];
        NSString *hou= [arr objectAtIndex:0];
        NSString *mm= [arr objectAtIndex:1];
        NSInteger hour = [hou intValue];
        NSInteger minute = [mm intValue];
        NSString *AddTime;
        NSString *TimeInterval;
        if ([Time isEqual:@"15 Minits"]) {
            AddTime = @"15";
            TimeInterval = @"1";
        }
        if ([Time isEqual:@"30 Minits"]) {
            AddTime = @"30";
            TimeInterval = @"2";
        }
        else if ([Time isEqual:@"45 Minits"]) {
            AddTime = @"45";
            TimeInterval = @"3";
        }
        else if ([Time isEqual:@"60 Minits"]) {
            AddTime = @"60";
            TimeInterval = @"4";
        }
        int Addvalue = [AddTime intValue];
        if (Addvalue<60) {
            minute = minute+Addvalue;
            
            if (minute>60) {
                hour = hour+1;
                minute= minute-60;
                if (minute==60) {
                    hour=hour+1;
                    minute=minute-60;
                }
            }
            else if (minute==60)
            {
                hour=hour+1;
                minute=minute-60;
            }
        }
        else if (Addvalue==60)
        {
            hour = hour+1;
        }
        NSString *str1=[NSString stringWithFormat:@"%@",Date];
        
        NSString *str=[NSString stringWithFormat:@"%@ %ld:%ld:00",str1,(long)hour,(long)minute];
        str = [str stringByReplacingOccurrencesOfString:@"+0000" withString:@""];




       NSDate * dateNotFormatted11  =[dateFormatter dateFromString:str];
        str = [dateFormatter stringFromDate:dateNotFormatted11];


        [DateTime setValue:StartDate forKey:@"StartDate"];
        [DateTime setValue:str forKey:@"EndDate"];
        [DateTime setValue:TimeInterval forKey:@"TimeInterval"];
        [DateTime setValue:AddTime forKey:@"Time"];
        
        return DateTime;
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
}

-(NSDictionary*)GetCateGory:(NSString*)ModuleType CategoryId:(NSString*)CategoryID {
    @try {
        NSMutableDictionary *ModuleIDCatID = [[NSMutableDictionary alloc]init];
        
        
        
        NSString *ModuleID;
        if ([Category isEqual:FOOD]) {
            ModuleID =@"1";
        }
        if ([Category isEqual:PROFESSIONALHELP]) {
            ModuleID =@"2";
        }
        else if ([Category isEqual:SALES]) {
            ModuleID =@"3";
        }
        else if ([Category isEqual:SPORTS]) {
            ModuleID =@"4";
        }
        NSString *CatID =  [self GetCategoryID:CategoryID];
        
        [ModuleIDCatID setValue:ModuleID forKey:@"ModuleId"];
        [ModuleIDCatID setValue:CatID forKey:@"CategoryID"];
        
        return ModuleIDCatID;
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
}

-(NSString*)GetCategoryID:(NSString*)CategoryName {
    @try {
        NSString *CategoryID;
        NSArray *Cat = [GetCategoryresponse valueForKey:CATEGORY];
        NSArray *CatID = [GetCategoryresponse  valueForKey:@"CategoryID"];
        for(int i=0 ;i<[GetCategoryresponse count];i++)
        {
            if ([CategoryName isEqualToString:Cat[i]]) {
                CategoryID = CatID[i];
            }
        }
        return CategoryID;
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
}

-(NSDictionary*)GetAddress {
    @try {
        NSMutableDictionary *AddresDic = [[NSMutableDictionary alloc]init];
        [AddresDic setObject:Addre.Address1 forKey:@"Address1"];
        [AddresDic setObject:Addre.Address2 forKey:@"Address2"];
        [AddresDic setObject:Addre.Address3 forKey:@"Address3"];
        [AddresDic setObject:Addre.AreaName forKey:@"AreaName"];
        [AddresDic setObject:Addre.City forKey:@"City"];
        [AddresDic setObject:Addre.State forKey:@"State"];
        [AddresDic setObject:Addre.Country forKey:@"Country"];
        [AddresDic setObject:Addre.Latitude forKey:@"Latitude"];
        [AddresDic setObject:Addre.Longitude forKey:@"Longitude"];
        [AddresDic setObject:Limit.text forKey:@"Quantity"];
        
        NSMutableArray *arra = [[NSMutableArray alloc]init];
        
        
        
        
        
        return AddresDic;
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
}

-(NSDictionary*)GetOpportunityDetails {
    @try {
        NSString *AddressName = [NSString stringWithFormat:@"%@,%@,%@,%@,%@,%@,%@",Addre.Address1,Addre.Address2,Addre.Address3,Addre.AreaName,Addre.City,Addre.State,Addre.Country];
        //NSUserDefaults *prefss = [NSUserDefaults standardUserDefaults];
        NSString *UserId;
        if ([prefss objectForKey:@"SaveUserID"]) {
            UserId =[prefss objectForKey:@"SaveUserID"];
        }
        NSMutableArray *imagebyteArray = [NSMutableArray array];
        UIImage *yourImage;NSString *imagename;
        
        
        if ([Images count]!=0) {
            
            for(int i=0; i < [Images count]; i++)
            {
                yourImage=[Images objectAtIndex:i];
                NSData *data = UIImagePNGRepresentation(yourImage);
                NSString *base64String = [data base64EncodedStringWithOptions:0];
                [imagebyteArray addObject:base64String];
            }
            if ([imagebyteArray count]==0) {
                imagename =@"";
            }
            else{
                imagename = [imagebyteArray componentsJoinedByString:@","];
            }
        }
        
        
        NSMutableDictionary *Opportunity = [[NSMutableDictionary alloc]init];
        [Opportunity setObject:Description.text forKey:@"OpportunityName"];
        [Opportunity setObject:Description.text forKey:@"OpportunityDescription"];
        [Opportunity setObject:keyWords.text forKey:@"OpportunityKeywords"];
        [Opportunity setObject:[prefss objectForKey:@"SaveUserID"] forKey:@"UserID"];
        [Opportunity setObject:@"Promo" forKey:@"PromoCode"];
        [Opportunity setObject:@"1" forKey:@"OpportunityType"];
        
        [Opportunity setObject:imagename forKey:@"PhotoName"];
        [Opportunity setObject:@"" forKey:@"VendorAddressId"];
        [Opportunity setObject:@"" forKey:@"GcmId"];
        [Opportunity setObject:AddressName forKey:@"AddressName"];
        [Opportunity setObject:@"true" forKey:@"IsPrimary"];
        [Opportunity setObject:@"" forKey:@"Categories"];
        [Opportunity setObject:@"" forKey:@"types"];
        return Opportunity;
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
}

- (void) showAlertPop:(NSString*)alertText  expObj:(NSException*) exp{
    if(exp != nil)
    {
        NSLog(@"%@", exp.description);
    }
    NSLog(@"The Exception is %@",exp.description);
    UIAlertController *myAlertController =[mWebService  alert:alertText];
    [self presentViewController:myAlertController animated:YES completion:nil];
}

- (void) showAlertForMissingparams:(NSString*)alertText {
    
   
    UIAlertController *myAlertController =[mWebService  alert:alertText];
    [self presentViewController:myAlertController animated:YES completion:nil];
}




-(void)StoreRadios:(NSString*)Radious
{
    @try {
        [[Preferences GetSharedInstance]StoreRadious:Radious];
        [prefss setValue:HLIST forKey:@"SideMenu"];
        MainViewController * mOpportunity_list = [[ MainViewController alloc] initWithNibName:MAINVIEWCONTROLLER bundle:nil];
        [self presentViewController:mOpportunity_list animated:YES completion:nil];}
    @catch (NSException *exception) {
        [self showAlertPop:@"Invalid UserName." expObj:exception];
    }
    @finally {
        
    }
}
@end
