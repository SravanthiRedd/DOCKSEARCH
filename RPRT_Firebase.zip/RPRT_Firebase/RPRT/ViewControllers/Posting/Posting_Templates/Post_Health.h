//
//  Post_Health.h
//  RPRT
//
//  Created by sravanthi Gumma on 21/09/16.
//  Copyright © 2016 DevpointSolutions. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MainViewController.h"
#import "Web_Services.h"
#import "SMSController.h"

@interface Post_Health :UIViewController<UITableViewDelegate,UITableViewDataSource,CLLocationManagerDelegate,MKMapViewDelegate,UITextFieldDelegate,UIImagePickerControllerDelegate,UINavigationControllerDelegate,UITextViewDelegate,MFMessageComposeViewControllerDelegate>
{
    NSDictionary *EditOpp;
    NSDictionary *GetUserCounts;
    
}



@property (weak, nonatomic) IBOutlet UIView *toolBarView;
@property(weak,nonatomic) IBOutlet UILabel *pageTitle;

@property (weak, nonatomic) IBOutlet UITextView *meetingDescription;
@property (weak, nonatomic) IBOutlet UITextField *Datelabel;
@property (weak, nonatomic) IBOutlet UITextField *Timelabel;
@property (weak, nonatomic) IBOutlet UITextField *Address;
@property (weak, nonatomic) IBOutlet UITextField *Type;
@property (weak, nonatomic) IBOutlet MKMapView *mapView;
@property (weak, nonatomic) IBOutlet UITextField *postName;


@property (nonatomic, strong) NSDictionary *EditOpportunity;

@property (weak,nonatomic) IBOutlet UIView *aboutOfferView;
@property (weak,nonatomic) IBOutlet UIView *offertypeView;
@property (weak,nonatomic) IBOutlet UIView *PostNameView;
@property (weak,nonatomic) IBOutlet UIView *datetimeVieww;
@property (weak,nonatomic) IBOutlet UIView *addresView;


@property (weak,nonatomic) IBOutlet UIButton *camera;
@property (weak, nonatomic) IBOutlet UIScrollView *PhotoScroll;
@property(weak,nonatomic) IBOutlet UIImageView *photoimage;


@property (weak,nonatomic) IBOutlet UIView *CheckView;
@property(strong,nonatomic) IBOutlet UIImageView *publicCheck;
@property(strong,nonatomic) IBOutlet UIImageView *CustomersCheck;

@property(strong,nonatomic) IBOutlet UILabel *thisislabel;
@property(strong,nonatomic) IBOutlet UILabel *userCnt;
@property(strong,nonatomic) IBOutlet UILabel *CustomerCnt;
//@property(strong,nonatomic) IBOutlet UILabel *myCircleCnt;
@property(strong,nonatomic) IBOutlet UIImageView *myCircleCheck;

@property(strong,nonatomic) IBOutlet UIImageView *chkSendSMS;
@property(strong,nonatomic) IBOutlet UILabel *sendSMSToCustomerlabel;


@property(weak,nonatomic) IBOutlet UIView *View1;
@property(weak,nonatomic) IBOutlet UIView *View2;
@property(weak,nonatomic) IBOutlet UIView *View3;
@property(weak,nonatomic) IBOutlet UIView *View4;


@property(weak,nonatomic) IBOutlet UIImageView *NextBtnImage;
@property(weak,nonatomic) IBOutlet UIButton *continueBtn;
@property(weak,nonatomic) IBOutlet UIButton *BackBtn;

@end
