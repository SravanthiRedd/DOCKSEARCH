//
//  Post_Sales.h
//  RPRT
//
//  Created by sravanthi Gumma on 09/03/16.
//  Copyright © 2016 DevpointSolutions. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Home.h"
#import <Messages/Messages.h>
#import <MessageUI/MessageUI.h>
#import "SMSPopUp.h"
#import "SMSController.h"
@interface Post_Sales : UIViewController<UIImagePickerControllerDelegate,UITableViewDataSource,UITableViewDelegate,CLLocationManagerDelegate,MKMapViewDelegate,UINavigationControllerDelegate,UITextViewDelegate,MFMessageComposeViewControllerDelegate>
{
    NSDictionary *EditOpp;
    NSDictionary *GetUserCounts;
   }
@property (weak, nonatomic) IBOutlet UIView *toolBarView;



@property (weak, nonatomic) IBOutlet UITextField *Storename;
@property (weak, nonatomic) IBOutlet UITextField *Offer;
@property (weak, nonatomic) IBOutlet UITextField *Price;
@property (weak, nonatomic) IBOutlet UITextField *Quantity;
@property (weak, nonatomic) IBOutlet UITextField *Datelabel;
@property (weak, nonatomic) IBOutlet UITextField *Timelabel;
@property (weak, nonatomic) IBOutlet UITextField *Address;
@property (weak, nonatomic) IBOutlet UITextView *Keywords;

@property (weak, nonatomic) IBOutlet UITextField *SelectType;

@property (weak,nonatomic) IBOutlet UIButton *camera;
@property (weak, nonatomic) IBOutlet UIScrollView *PhotoScroll;
@property (weak,nonatomic)IBOutlet UIImageView *imgs;

@property (nonatomic, strong) NSDictionary *EditOpportunity;
@property (weak, nonatomic) IBOutlet MKMapView *mapView;
@property(strong,nonatomic) IBOutlet UIImageView *delAvailImage;

@property (weak,nonatomic) IBOutlet UIView *offerNameView;
@property (weak,nonatomic) IBOutlet UIView *aboutOfferView;
@property (weak,nonatomic) IBOutlet UIView *offerpriceview;
@property (weak,nonatomic) IBOutlet UIView *offertypeView;
@property (weak,nonatomic) IBOutlet UIView *datetimeVieww;
@property (weak,nonatomic) IBOutlet UIView *addresView;


@property (weak,nonatomic) IBOutlet UIView *CheckView;
@property(strong,nonatomic) IBOutlet UIImageView *publicCheck;
@property(strong,nonatomic) IBOutlet UIImageView *CustomersCheck;

@property(strong,nonatomic) IBOutlet UILabel *userCnt;
@property(strong,nonatomic) IBOutlet UILabel *CustomerCnt;


@property(strong,nonatomic) IBOutlet UIImageView *myCircleCheck;

@property(strong,nonatomic) IBOutlet UIImageView *chkSendSMS;
@property(strong,nonatomic) IBOutlet UILabel *sendSMSToCustomerlabel;


@property(weak,nonatomic) IBOutlet UIView *View1;
@property(weak,nonatomic) IBOutlet UIView *View2;
@property(weak,nonatomic) IBOutlet UIView *View3;
@property(weak,nonatomic) IBOutlet UIView *View4;
@property(weak,nonatomic) IBOutlet UIButton *continueBtn;
@property(weak,nonatomic) IBOutlet UIButton *BackBtn;
@property(weak,nonatomic) IBOutlet UIImageView *NextBtnImage;
@end
