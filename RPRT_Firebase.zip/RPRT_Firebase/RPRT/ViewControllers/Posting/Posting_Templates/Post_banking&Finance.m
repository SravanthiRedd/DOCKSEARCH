//
//  Post_banking&Finance.m
//  RPRT
//
//  Created by sravanthi Gumma on 06/09/16.
//  Copyright © 2016 DevpointSolutions. All rights reserved.
//

#import "Post_banking&Finance.h"
#import "TimeCalculator.h"
#import "Preferences.h"

@interface Post_banking_Finance ()<UISearchBarDelegate,CustomIOSAlertViewDelegate>
{
    NSUserDefaults *mPref;
    CGRect workingFrame;
    UIImage *originalImage;
    NSMutableArray  *Images;
    NSMutableArray *chosenImages;
    Web_Services *mWebService;
    // UITableView *autoComplete;
    NSMutableArray *GetSubCat;
    NSMutableArray *arrayOFAddress;
    GeoCodeLocation *Addre;
    CLLocationManager *locationManager;
    CLLocationCoordinate2D currentCentre;
    int currenDist;
    BOOL firstLaunch;
    
    NSString *Time;
    NSDictionary *SelectedSubCat;
    
    UIDatePicker *TimePicker;
    UIDatePicker*  DatePicker;
    UIView *Datepicker;
    UIView *Timepicker;
    UIActivityIndicatorView *spinner;
    NSMutableArray *LatLon;
    TimeCalculator *mTimeCalculator;
    
    
    UIColor *selectedcolr;
    UIColor *nonseltcolor;
    
    NSMutableDictionary *timeWithInterval;
    UIAlertController *alertController;
    NSMutableArray *autocompleteAddress;
    UITableView *autoComplete;
    NSString *OpportunityID;
    NSString *VendorAddressId;
    
    UITableView *typetableView;
    NSMutableArray *searchString;
    NSArray *results;
    NSMutableArray *getSubCategory ;
    
    NSString *mDateTime;
    NSDate *mFinalDate;
    CustomIOSAlertView *offertypeAlert;
    UISearchBar *offerTypeSearch;
    BOOL isSearching;
    NSString *photoStatus;
    NSUInteger *photoposition;
        UIImageView *ImageView;
    NSString *ActionKey;
    NSString * OppForKey;// = @"";
     NSString *SendSMSKey;
    int PageCnt;
}
@property(strong,nonatomic) SMSController *smsPopUp;
@property (nonatomic, strong)IBOutlet UIButton *btn15;
@property (nonatomic, strong)IBOutlet UIButton *btn30;
@property (nonatomic, strong)IBOutlet UIButton *btn45;
@property (nonatomic, strong)IBOutlet UIButton *btn60;

@end

@implementation Post_banking_Finance

@synthesize Datelabel,Timelabel,Address,Type,mapView,toolBarView,meetingDescription;

@synthesize btn15,btn30,btn45,btn60,PhotoScroll;
@synthesize publicCheck,CustomersCheck,CheckView;

-(void)viewDidLoad {
    @try {
        
        
        [super viewDidLoad];
        
        OpportunityID= @"0";
        VendorAddressId =@"";
        photoposition=nil;
        photoStatus = @"";
          ActionKey = @"";
        OppForKey= @"1";
        SendSMSKey= @"";
        PageCnt=1;
        
        self.View2.hidden= YES;
        self.View3.hidden= YES;
        self.View4.hidden= YES;
        
         Images = [[NSMutableArray alloc]init];
        
        toolBarView.backgroundColor = [UIColor colorWithRed:0.0/256.0 green:149.0/256.0 blue:120.0/256.0 alpha:1];;
        
        selectedcolr = [UIColor colorWithRed:68.0/256.0 green:180./256.0 blue:73.0/256.0 alpha:1];
        
        timeWithInterval = [[NSMutableDictionary alloc]init];
        
        
        mTimeCalculator = [TimeCalculator GetSharedInstance];
        mPref = [NSUserDefaults standardUserDefaults];
        mWebService = [Web_Services GetSharedInstance];
        
        
        EditOpp = self.EditOpportunity;
        
        [self SetbordertoTextfields];
        
        UITapGestureRecognizer *tapGesture =
        [[UITapGestureRecognizer alloc] initWithTarget:self
                                                action:@selector(hideKeyboard)];
        tapGesture.cancelsTouchesInView = NO;
        
        //load tableview
        
        autoComplete = [[UITableView alloc] initWithFrame:
                        CGRectMake(self.addresView.frame.origin.x, self.addresView.frame.origin.y+42, self.addresView.frame.size.width, 150) style:UITableViewStylePlain];
        
        
        
        typetableView = [[UITableView alloc] initWithFrame:
                         CGRectMake(self.offertypeView.frame.origin.x, self.offertypeView.frame.origin.y+42, self.offertypeView.frame.size.width, 150) style:UITableViewStylePlain];
        
        
        
       
        autoComplete.delegate = self;
        autoComplete.dataSource = self;
        autoComplete.scrollEnabled = YES;
        autoComplete.hidden = YES;
        [self.view addSubview:autoComplete];
        
        
        
        typetableView.delegate = self;
        typetableView.dataSource = self;
        typetableView.scrollEnabled = YES;
        typetableView.hidden = YES;
        [self.view addSubview:typetableView];
        
        [self LoadUserAddress];
        
               
        
        
        NSDictionary *datetime =[mTimeCalculator incrementTime];
          mDateTime= [NSString stringWithFormat:@"%@ %@",[datetime valueForKey:@"Date"],[datetime valueForKey:@"Time"]];
        Datelabel.text = [NSString stringWithFormat:@"%@",[datetime valueForKey:@"Date"]];
        
        Timelabel.text = [NSString stringWithFormat:@"%@",[datetime valueForKey:@"Time"]];

       // self.scrollview.bounces = NO;
        
        [self addTimebuttons];
        [self getSubCategoryDetails:@"42"];
        PhotoScroll.hidden=YES;
        

        
        [self showGallery];
        
        UITapGestureRecognizer *imageGuester =
        [[UITapGestureRecognizer alloc] initWithTarget:self
                                                action:@selector(updateImage:)];
        self.photoimage.userInteractionEnabled = YES;
        //tapGesture.cancelsTouchesInView = NO;
        [self.photoimage addGestureRecognizer:imageGuester];
        
        
        
        UIImage *avalbleImage =nil;
        CGSize siz =CGSizeMake(22  , 22);
        
        
        avalbleImage = [UIImage imageNamed:@"check.png"];
        avalbleImage=   [mTimeCalculator image:avalbleImage scaledToSize:siz];
        publicCheck.image =  [avalbleImage imageWithTint:[UIColor darkTextColor]];
        
        
        
     
        
        if ([[mPref valueForKey:LOGINTYPE] isEqualToString:@"Business"]) {
            self.CheckView.hidden= NO;
            self.thisislabel.hidden= NO;
        }
        
        else if ([[mPref valueForKey:LOGINTYPE] isEqualToString:@"Individual"] ) {
            self.CheckView.hidden= YES;
            self.thisislabel.hidden= YES;
            OppForKey= @"1";
            mapView.frame = CGRectMake(mapView.frame.origin.x, self.addresView.frame.origin.y+100, mapView.frame.size.width, mapView.frame.size.height);
        }
      
         [self setViewDesign];
        if (EditOpp!=nil) {
            
            [self EditedDetils];
        }
        

     
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
}

-(void)setViewDesign
{
    
    [self setViewlayout:self.View1];
    [self setViewlayout:self.View2];
    [self setViewlayout:self.View3];
    [self setViewlayout:self.View4];
    
    UITapGestureRecognizer *publicGest =
    [[UITapGestureRecognizer alloc] initWithTarget:self
                                            action:@selector(publicCheck:)];
    publicCheck.userInteractionEnabled = YES;
    //tapGesture.cancelsTouchesInView = NO;
    [publicCheck addGestureRecognizer:publicGest];
    
    
    UITapGestureRecognizer *customerGesture =
    [[UITapGestureRecognizer alloc] initWithTarget:self
                                            action:@selector(CustomersCheck:)];
    CustomersCheck.userInteractionEnabled = YES;
    //tapGesture.cancelsTouchesInView = NO;
    [CustomersCheck addGestureRecognizer:customerGesture];
    
    UITapGestureRecognizer *Mycircle =
    [[UITapGestureRecognizer alloc] initWithTarget:self
                                            action:@selector(MyCircleNavGesture:)];
    self.myCircleCheck.userInteractionEnabled = YES;
    //tapGesture.cancelsTouchesInView = NO;
    [self.myCircleCheck addGestureRecognizer:Mycircle];
    
    
    
    UITapGestureRecognizer *chkSendSMS =
    [[UITapGestureRecognizer alloc] initWithTarget:self
                                            action:@selector(ChkSendSMS:)];
    self.chkSendSMS.userInteractionEnabled = YES;
    //tapGesture.cancelsTouchesInView = NO;
    [self.chkSendSMS addGestureRecognizer:chkSendSMS];
    
    
    if(GetUserCounts!=nil)
    {
        self.userCnt.text = [NSString stringWithFormat:@"Nearby users: %@",[GetUserCounts valueForKey:@"UserCount"]];
        self.CustomerCnt.text = [NSString stringWithFormat:@"( %@ )",[GetUserCounts valueForKey:@"CustomerCount"]];
        
        NSMutableAttributedString *text = [self.CustomerCnt.attributedText mutableCopy];
        [text addAttribute:NSUnderlineStyleAttributeName value:@(NSUnderlineStyleSingle) range:NSMakeRange(0, text.length)];
        self.CustomerCnt.attributedText = text;
        self.CustomerCnt.textColor = [UIColor colorWithRed:12.0/256.0 green:187.0/256.0 blue:210./256.0 alpha:1];
        
        [self.CustomerCnt setHidden:YES];
    }
    
    UITapGestureRecognizer *customerNavGesture =
    [[UITapGestureRecognizer alloc] initWithTarget:self
                                            action:@selector(customerNavGesture:)];
    self.CustomerCnt.userInteractionEnabled = YES;
    //tapGesture.cancelsTouchesInView = NO;
    [self.CustomerCnt addGestureRecognizer:customerNavGesture];
    
}


-(void)setViewlayout:(UIView*)View
{
    //View.layer.shadowColor = [UIColor lightGrayColor].CGColor;
   // View.layer.shadowOffset = CGSizeMake(0, 4);
   // View.layer.shadowOpacity = 1;
    View.layer.shadowRadius = 1.0;
    View.layer.borderColor=[UIColor lightGrayColor].CGColor;
    View.layer.borderWidth = 0.5;
}



-(void)customerNavGesture:(UIGestureRecognizer*)gestureReg
{
    MyContacts *mcontacts = [[MyContacts alloc] initWithNibName:@"MyContacts" bundle:nil];
    [self presentViewController:mcontacts animated:YES completion:nil];
}


-(void)showGallery
{
    @try {
        
        nonseltcolor = toolBarView.backgroundColor;
        //camera =[[UIButton alloc]initWithFrame:CGRectMake(50, 35, 40, 40)];
      //  self.camera.frame = CGRectMake(150, 70, self.camera.frame.size.width, self.camera.frame.size.height);
        
        
        self.camera.layer.cornerRadius = 0.5 * self.camera.bounds.size.width;
        [self.camera addTarget:self action:@selector(camera:) forControlEvents:UIControlEventTouchUpInside];
        self.camera.backgroundColor =nonseltcolor;
        [self.camera setImage:[UIImage imageNamed:@"camera.png"] forState:UIControlStateNormal];
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
}
-(void)updateImage:(UIPinchGestureRecognizer *)recognizer
{
    
    @try {
        
        
        [self callphtoEdit];
        
    }
    @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    }
    @finally {
        
    }
}

-(void)callphtoEdit
{
    UIAlertController * view=   [UIAlertController
                                 alertControllerWithTitle:@"Right Place Right Time"
                                 message:nil
                                 preferredStyle:UIAlertControllerStyleActionSheet];
    
    UIAlertAction* gallery = [UIAlertAction
                              actionWithTitle:@"Edit Photo"
                              style:UIAlertActionStyleDefault
                              handler:^(UIAlertAction * action)
                              {
                                  
                                  if ( [photoStatus isEqualToString:@"ScroolPhoto"]) {
                                      if (photoposition==NULL) {
                                          [Images removeObjectAtIndex:0];
                                          photoStatus = @"EditPhoto";
                                          [self callCamreaOptions];
                                          
                                      }
                                      else
                                      {
                                          NSInteger i =photoposition;
                                          
                                          if ([Images count]==1) {
                                              [Images removeAllObjects];
                                              photoStatus = @"EditPhoto";
                                              [self callCamreaOptions];
                                          }
                                          else
                                          {
                                              [Images removeObjectAtIndex:i];
                                              photoStatus = @"EditPhoto";
                                              [self callCamreaOptions];
                                          }
                                      }
                                  }
                                  else
                                  {
                                      [Images removeAllObjects];
                                      self.photoimage.image = nil;
                                      photoStatus = @"EditPhoto";
                                      [self callCamreaOptions];
                                  }
                                  
                                  //Images=nil;
                                  
                                  
                              }];
    
    UIAlertAction* delete = [UIAlertAction
                             actionWithTitle:@"Delete Photo"
                             style:UIAlertActionStyleDefault
                             handler:^(UIAlertAction * action)
                             {
                                 NSInteger i =photoposition;
                                 if ([Images count]==1) {
                                     [Images removeObjectAtIndex:0];
                                 }
                                 else
                                 {
                                     [Images removeObjectAtIndex:i];
                                 }
                                 if ([Images count]==0) {
                                     // Images=nil;
                                     PhotoScroll.hidden= YES;
                                     // Images=nil;
                                 //    self.scrollview.frame= CGRectMake(0,toolBarView.frame.origin.y+70, self.scrollview.frame.size.width, self.scrollview.frame.size.height+300);
                                   //  self.Contentview.frame = CGRectMake(self.scrollview.frame.origin.x,self.scrollview.frame.origin.y-10, self.Contentview.frame.size.width,self.Contentview.frame.size.height+200);
                                    // self.camera.frame = CGRectMake(150, 70, self.camera.frame.size.width, self.camera.frame.size.height);
                                     
                                     self.photoimage.image = nil;
                                     
                                     
                                 }
                                 else if ([Images count]==1) {
                                     
                                     [self setImageToImageFrame];
                                     
                                     
                                 }
                                 
                                 else if ([Images count]>1) {
                                     self.photoimage.image = nil;
                                     [self setImageToImageFrame];
                                 }
                                 
                             }];
    
    
    UIAlertAction* cancel = [UIAlertAction
                             actionWithTitle:@"Cancel"
                             style:UIAlertActionStyleDefault
                             handler:^(UIAlertAction * action)
                             {
                                 if ([Images count]==0) {
                                     PhotoScroll.hidden= YES;
                                     // Images=nil;
                                   //  self.scrollview.frame= CGRectMake(0,toolBarView.frame.origin.y+70, self.scrollview.frame.size.width, self.scrollview.frame.size.height+300);
                                     //self.Contentview.frame = CGRectMake(self.scrollview.frame.origin.x,self.scrollview.frame.origin.y-10, self.Contentview.frame.size.width,self.Contentview.frame.size.height+200);
                                   //  self.camera.frame = CGRectMake(150, 70, self.camera.frame.size.width, self.camera.frame.size.height);
                                     
                                     self.photoimage.image = nil;
                                     
                                 }
                                 
                                 [view dismissViewControllerAnimated:YES completion:nil];
                                 
                             }];
    
    [view addAction:gallery];
    [view addAction:delete];
    [view addAction:cancel];
    [self presentViewController:view animated:YES completion:nil];
}


-(void)callCamreaOptions
{
    @try {
        
        
        UIAlertController * view=   [UIAlertController
                                     alertControllerWithTitle:@"Right Place Right Time"
                                     message:nil
                                     preferredStyle:UIAlertControllerStyleActionSheet];
        
        UIAlertAction* photo = [UIAlertAction
                                actionWithTitle:@"Take Photo"
                                style:UIAlertActionStyleDefault
                                handler:^(UIAlertAction * action)
                                {
                                    //Do some thing here
                                    [view dismissViewControllerAnimated:YES completion:nil];
                                    
                                    UIImagePickerController *picker = [[UIImagePickerController alloc] init];
                                    picker.delegate = self;
                                    picker.allowsEditing = YES;
                                    picker.sourceType = UIImagePickerControllerSourceTypeCamera;
                                    
                                    [self presentViewController:picker animated:YES completion:NULL];
                                    
                                    
                                    
                                }];
        UIAlertAction* gallery = [UIAlertAction
                                  actionWithTitle:@"Chose from Gallery"
                                  style:UIAlertActionStyleDefault
                                  handler:^(UIAlertAction * action)
                                  {
                                      UIImagePickerController *picker = [[UIImagePickerController alloc] init];
                                      picker.delegate = self;
                                      picker.allowsEditing = YES;
                                      picker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
                                      
                                      [self presentViewController:picker animated:YES completion:NULL];
                                      
                                      
                                      
                                      [view dismissViewControllerAnimated:YES completion:nil];
                                      
                                  }];
        
        UIAlertAction* cancel = [UIAlertAction
                                 actionWithTitle:@"Cancel"
                                 style:UIAlertActionStyleDefault
                                 handler:^(UIAlertAction * action)
                                 {
                                     [view dismissViewControllerAnimated:YES completion:nil];
                                     
                                 }];
        
        
        
        [view addAction:photo];
        [view addAction:gallery];
        [view addAction:cancel];
        [self presentViewController:view animated:YES completion:nil];
        
    }
    @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    }
    @finally {
        
    }
}

-(void)imageTapped:(UIGestureRecognizer*)gesture
{
    photoStatus=@"ScroolPhoto";
    
    UIImageView *imageView1 = (UIImageView *)gesture.view;
    
    NSLog(@"1 %ld",(long)imageView1.tag);
    //    if (imageView.tag>1) {
    //        photoposition =1-imageView.tag;
    //    }
    if(imageView1.tag>=1)
    {
        photoposition= imageView1.tag-1;
    }
    else
    {
        photoposition =1-imageView1.tag;
    }
    [self callphtoEdit];
    
}
-(void)camera:(id)sender
{
    @try {
        
        
        UIAlertController * view=   [UIAlertController
                                     alertControllerWithTitle:@"Right Place Right Time"
                                     message:nil
                                     preferredStyle:UIAlertControllerStyleActionSheet];
        
        UIAlertAction* photo = [UIAlertAction
                                actionWithTitle:@"Take Photo"
                                style:UIAlertActionStyleDefault
                                handler:^(UIAlertAction * action)
                                {
                                    //Do some thing here
                                    [view dismissViewControllerAnimated:YES completion:nil];
                                    
                                    UIImagePickerController *picker = [[UIImagePickerController alloc] init];
                                    picker.delegate = self;
                                    picker.allowsEditing = YES;
                                    picker.sourceType = UIImagePickerControllerSourceTypeCamera;
                                    
                                    [self presentViewController:picker animated:YES completion:NULL];
                                    
                                    
                                    
                                }];
        UIAlertAction* gallery = [UIAlertAction
                                  actionWithTitle:@"Chose from Gallery"
                                  style:UIAlertActionStyleDefault
                                  handler:^(UIAlertAction * action)
                                  {
                                      UIImagePickerController *picker = [[UIImagePickerController alloc] init];
                                      picker.delegate = self;
                                      picker.allowsEditing = YES;
                                      picker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
                                      
                                      [self presentViewController:picker animated:YES completion:NULL];
                                      
                                      
                                      
                                      [view dismissViewControllerAnimated:YES completion:nil];
                                      
                                  }];
        
        UIAlertAction* cancel = [UIAlertAction
                                 actionWithTitle:@"Cancel"
                                 style:UIAlertActionStyleDefault
                                 handler:^(UIAlertAction * action)
                                 {
                                     [view dismissViewControllerAnimated:YES completion:nil];
                                     
                                 }];
        
        
        
        [view addAction:photo];
        [view addAction:gallery];
        [view addAction:cancel];
        [self presentViewController:view animated:YES completion:nil];
        
    }
    @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    }
    @finally {
        
    }
}

#pragma mark - Image Picker Controller delegate methods

- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info {
    @try {
        
        
        PhotoScroll.hidden= NO;
        
        
        
        UIImage *chosenImage = info[UIImagePickerControllerEditedImage];
        
        
        self.photoimage.image = nil;
        
        if ([photoStatus isEqualToString:@"EditPhoto"])
        {
            [Images addObject:chosenImage];
            
            if ([Images count]==1) {
                
                self.photoimage.image = chosenImage;
                photoStatus = @"";
            }
            else if ([Images count]>1) {
                self.photoimage.image = nil;
                [self setImageToImageFrame];
            }
            
        }
        
        else
        {
            [Images addObject:chosenImage];
            
            if ([Images count]==1) {
                self.photoimage.image = chosenImage;
                
            }
            
            else if ([Images count]>1) {
                self.photoimage.image = nil;
                [self setImageToImageFrame];
            }
        }
        
        [picker dismissViewControllerAnimated:YES completion:NULL];
    }
    @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    }
    @finally {
        
    }
    
}

-(void)setImageToImageFrame
{
    
    self.photoimage.image=nil;
    
    
    [PhotoScroll setPagingEnabled:YES];
    [PhotoScroll setAlwaysBounceVertical:NO];
    [PhotoScroll setScrollEnabled:YES];
    //NSArray *imagesArray = Images;
    UIImageView *imageView ;
    for (int i = 0; i < [Images count]; i++)
    {
        CGFloat xOrigin = i * PhotoScroll.frame.size.width;
        
        imageView = [[UIImageView alloc] initWithFrame:CGRectMake(xOrigin, 0, PhotoScroll.frame.size.width, PhotoScroll.frame.size.height)];
        [imageView setImage:[Images objectAtIndex:i]];
        [imageView setContentMode:UIViewContentModeScaleAspectFit];
        imageView.userInteractionEnabled=YES;
        
        
        UITapGestureRecognizer *imageTapping = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(imageTapped:)];
        [imageView addGestureRecognizer:imageTapping];
        
        [PhotoScroll addSubview:imageView];
    }
    
    [PhotoScroll setContentSize:CGSizeMake(PhotoScroll.frame.size.width * [Images count], PhotoScroll.frame.size.height)];
    
    
    

}

- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker {
    @try {
        
        [picker dismissViewControllerAnimated:YES completion:NULL];
    }
    @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    }
    @finally {
        
    }
}

-(void)addTimebuttons
{
    
    @try {
        
        
        Time= @"";
        
        nonseltcolor = [UIColor colorWithRed:153.0/256.0 green:153.0/256.0 blue:153.0/256.0 alpha:1];
        
        
        
        //btn15 =[[UIButton alloc]initWithFrame:CGRectMake(50, 35, 40, 40)];
        btn15.layer.cornerRadius = 0.5 * btn15.bounds.size.width;
        [btn15 addTarget:self action:@selector(btn15:) forControlEvents:UIControlEventTouchUpInside];
        
        
        //btn30 =[[UIButton alloc]initWithFrame:CGRectMake(btn15.frame.origin.x+75, 35, 40, 40)];
        btn30.layer.cornerRadius = 0.5 * btn30.bounds.size.width;
        // btn30.backgroundColor = nonseltcolor;
        [btn30 addTarget:self action:@selector(btn30:) forControlEvents:UIControlEventTouchUpInside];
        
        
        
        // btn45 =[[UIButton alloc]initWithFrame:CGRectMake(btn30.frame.origin.x+75, 35, 40, 40)];
        btn45.layer.cornerRadius = 0.5 * btn45.bounds.size.width;
        //  btn45.backgroundColor = nonseltcolor;
        [btn45 addTarget:self action:@selector(btn45:) forControlEvents:UIControlEventTouchUpInside];
        
        
        //btn60 =[[UIButton alloc]initWithFrame:CGRectMake(btn45.frame.origin.x+75, 35, 40, 40)];
        btn60.layer.cornerRadius = 0.5 * btn60.bounds.size.width;
        //  btn60.backgroundColor = nonseltcolor;
        [btn60 addTarget:self action:@selector(btn60:) forControlEvents:UIControlEventTouchUpInside];
        
        
        Time = @"15";
        [timeWithInterval setValue:@"15" forKey:@"Time"];
        [timeWithInterval setValue:@"1" forKey:@"TimeInterval"];
        [btn15 setImage:[UIImage imageNamed:@"green_tick.png"] forState:UIControlStateNormal];
        
        
        
        
    }
    @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    }
    @finally {
        
    }
}

-(void)btn15:(id)sender
{
    @try {
        
        // timeWithInterval= nil;
        Time = @"30";
        [timeWithInterval setValue:@"30" forKey:@"Time"];
        [timeWithInterval setValue:@"1" forKey:@"TimeInterval"];
        
        [btn15 setImage:[UIImage imageNamed:@"green_tick.png"] forState:UIControlStateNormal];
        [btn30 setImage:[UIImage imageNamed:@"gray_tick.png"] forState:UIControlStateNormal];
        [btn45 setImage:[UIImage imageNamed:@"gray_tick.png"] forState:UIControlStateNormal];
        [btn60 setImage:[UIImage imageNamed:@"gray_tick.png"] forState:UIControlStateNormal];
        
    }
    @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    }
    @finally {
        
    }
    
}
-(void)btn45:(id)sender
{
    @try {
        
        // timeWithInterval= nil;
        Time = @"120";
        [timeWithInterval setValue:@"120" forKey:@"Time"];
        [timeWithInterval setValue:@"3" forKey:@"TimeInterval"];
        
        [btn15 setImage:[UIImage imageNamed:@"gray_tick.png"] forState:UIControlStateNormal];
        [btn30 setImage:[UIImage imageNamed:@"gray_tick.png"] forState:UIControlStateNormal];
        [btn45 setImage:[UIImage imageNamed:@"green_tick.png"] forState:UIControlStateNormal];
        [btn60 setImage:[UIImage imageNamed:@"gray_tick.png"] forState:UIControlStateNormal];
        
        
    }
    @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    }
    @finally {
        
    }
    
}

-(void)btn60:(id)sender
{
    @try {
        
        
        //timeWithInterval= nil;
        Time = @"240";
        [timeWithInterval setValue:@"240" forKey:@"Time"];
        [timeWithInterval setValue:@"4" forKey:@"TimeInterval"];
        
        [btn15 setImage:[UIImage imageNamed:@"gray_tick.png"] forState:UIControlStateNormal];
        [btn30 setImage:[UIImage imageNamed:@"gray_tick.png"] forState:UIControlStateNormal];
        [btn45 setImage:[UIImage imageNamed:@"gray_tick.png"] forState:UIControlStateNormal];
        [btn60 setImage:[UIImage imageNamed:@"green_tick.png"] forState:UIControlStateNormal];
    }
    @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    }
    @finally {
        
    }
}

-(void)btn30:(id)sender
{
    
    @try {
        
        
        //timeWithInterval= nil;
        Time = @"60";
        [timeWithInterval setValue:@"60" forKey:@"Time"];
        [timeWithInterval setValue:@"2" forKey:@"TimeInterval"];
        [btn15 setImage:[UIImage imageNamed:@"gray_tick.png"] forState:UIControlStateNormal];
        [btn30 setImage:[UIImage imageNamed:@"green_tick.png"] forState:UIControlStateNormal];
        [btn45 setImage:[UIImage imageNamed:@"gray_tick.png"] forState:UIControlStateNormal];
        [btn60 setImage:[UIImage imageNamed:@"gray_tick.png"] forState:UIControlStateNormal];    }
    @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    }
    @finally {
        
    }
}


-(void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(void)hideKeyboard {
    @try {
        
        [meetingDescription resignFirstResponder];
        
        [Datelabel resignFirstResponder];
        [Timelabel resignFirstResponder];
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
    
}

- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField {
    // [self myMethod];
    
    if (textField == Type) {
        GetSubCat = getSubCategory;
        typetableView.hidden= NO;
        [typetableView reloadData];
        [self getOffertype];
        return NO;
    }
    
    if (Datelabel== textField) {
        [self DateBtn];
        return NO;
    }
    
    if (Timelabel == textField) {
        [self selectTimeBtn];
        return NO;
    }
    
    return YES;
    
}
-(void)SetbordertoTextfields {
    @try {
        
     
        
        self.aboutOfferView.layer.borderColor = [UIColor colorWithRed:198.0/256.0 green:198.0/256.0 blue:198.0/256.0 alpha:1].CGColor;
        self.aboutOfferView.layer.borderWidth=1;
        self.offertypeView.layer.borderColor = [UIColor colorWithRed:198.0/256.0 green:198.0/256.0 blue:198.0/256.0 alpha:1].CGColor;
        self.offertypeView.layer.borderWidth=1;
        self.datetimeVieww.layer.borderColor = [UIColor colorWithRed:198.0/256.0 green:198.0/256.0 blue:198.0/256.0 alpha:1].CGColor;
        self.datetimeVieww.layer.borderWidth=1;
        self.addresView.layer.borderColor = [UIColor colorWithRed:198.0/256.0 green:198.0/256.0 blue:198.0/256.0 alpha:1].CGColor;
        self.addresView.layer.borderWidth=1;
        
        self.CheckView.layer.borderColor = [UIColor colorWithRed:198.0/256.0 green:198.0/256.0 blue:198.0/256.0 alpha:1].CGColor;
        self.CheckView.layer.borderWidth=1;
        
        
        self.PostNameView.layer.borderColor = [UIColor colorWithRed:198.0/256.0 green:198.0/256.0 blue:198.0/256.0 alpha:1].CGColor;
        self.PostNameView.layer.borderWidth=1;

        
        
        mapView.layer.borderColor = [UIColor colorWithRed:198.0/256.0 green:198.0/256.0 blue:198.0/256.0 alpha:1].CGColor;
        mapView.layer.borderWidth=1;
        
    }
    @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    }
    @finally {
        
    }
}

-(void)SetBorderToTextFieldL:(CALayer*)border Texfield:(UITextField*)TextfiedNam {
    @try {
        border.borderColor = [UIColor lightGrayColor].CGColor;
        border.frame = CGRectMake(0, TextfiedNam.frame.size.height - 1, TextfiedNam.frame.size.width, TextfiedNam.frame.size.height);
        border.borderWidth = 1;//
        [TextfiedNam.layer addSublayer:border];
        TextfiedNam.layer.masksToBounds = YES;
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
}

-(void)SetBorderforButton:(CALayer*)Border Button:(UIButton*)Buttonname {
    @try {
        Border.borderColor = [UIColor lightGrayColor].CGColor;
        Border.frame = CGRectMake(0, Buttonname.frame.size.height - 1, Buttonname.frame.size.width, Buttonname.frame.size.height);
        Border.borderWidth = 1;//
        [Buttonname.layer addSublayer:Border];
        Buttonname.layer.masksToBounds = YES;
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
}


-(void)LoadUserAddress {
    @try {
        
        
        mapView.delegate = self;
        // Ensure that we can view our own location in the map view.
        [mapView setShowsUserLocation:YES];
        //Instantiate a location object.
        locationManager = [[CLLocationManager alloc] init];
        locationManager.delegate = self;
        [locationManager setDesiredAccuracy:kCLLocationAccuracyBest];
        if ([[[UIDevice currentDevice] systemVersion] floatValue] >= 8) {
            [locationManager requestAlwaysAuthorization];
        }
        if ([[[UIDevice currentDevice] systemVersion] floatValue] >= 9.2) {
            // locationManager.allowsBackgroundLocationUpdates = YES;
        }
        [locationManager startUpdatingLocation];
        CLLocation *location = [locationManager location];
        // coordinate = [location coordinate];
        CLLocationCoordinate2D centre = [mapView centerCoordinate];
        MKCoordinateRegion region;
        if (firstLaunch) {
            region = MKCoordinateRegionMakeWithDistance(locationManager.location.coordinate,1500,1500);
            firstLaunch=NO;
        }else {
            MKMapRect mRect = self.mapView.visibleMapRect;
            MKMapPoint eastMapPoint = MKMapPointMake(MKMapRectGetMinX(mRect), MKMapRectGetMidY(mRect));
            MKMapPoint westMapPoint = MKMapPointMake(MKMapRectGetMaxX(mRect), MKMapRectGetMidY(mRect));
            currenDist = MKMetersBetweenMapPoints(eastMapPoint, westMapPoint);
            region = MKCoordinateRegionMakeWithDistance(centre,currenDist,currenDist);
        }
        
        MKCoordinateSpan span;
        span.latitudeDelta  = 0; // Change these values to change the zoom
        span.longitudeDelta = 0;
        region.span = span;
        
        [mapView setRegion:region animated:YES];
        self.mapView.centerCoordinate = location.coordinate;
        double lat =location.coordinate.latitude;
        double lon =location.coordinate.longitude;
        GetUserCounts = [self GetCounts:lat Long:lon];

        
        Addre = [[CurrentLocation GetSharedInstance]geoCodeArea:&lat Longitude:&lon];
        Address.text = [NSString stringWithFormat:@"%@,%@,%@,%@",Addre.Address1,Addre.Address2,Addre.Address3,Addre.AreaName];
        
        
        UITapGestureRecognizer *longPressGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(MapviewLongPress:)];
        [self.mapView addGestureRecognizer:longPressGesture];
        
        NSString *RegisterID =   [mPref objectForKey:USERREGISTERID];
        NSString *str = [NSString stringWithFormat:@"%@/%@",GETSTOREDADDRESS,RegisterID];
        NSDictionary *GetAddress = [[Web_Services GetSharedInstance]Getcategories:str];
        arrayOFAddress = [[NSMutableArray alloc]init];
        LatLon = [[NSMutableArray alloc]init];
        NSMutableArray *latti = [[NSMutableArray alloc]init];
        NSMutableArray *longi = [[NSMutableArray alloc]init];
        if((![GetAddress count])==0)
        {
            NSArray *address1 = [GetAddress valueForKey:@"Address1"];
            NSArray *address2 = [GetAddress valueForKey:@"Address2"];
            NSArray *address3 = [GetAddress valueForKey:@"Address3"];
            NSArray *latitude = [GetAddress valueForKey:LATITUDE];
            NSArray *logitude = [GetAddress valueForKey:LONGITUDE];
            for (int i=0; i< [address1 count]; i++) {
                NSString *Adress = [NSString stringWithFormat:@"%@,%@,%@",address1[i],address2[i],address3[i]];
                [arrayOFAddress addObject:Adress];
                
                NSString *lat = [NSString stringWithFormat:@"%@,%@",latitude[i],logitude[i]];
                [LatLon addObject:lat];
                [latti addObject:latitude[i]];
                [longi addObject:logitude[i]];
            }
            
            if (arrayOFAddress[[address1 count]-1] !=nil) {
                Address.text =arrayOFAddress[[address1 count]-1];
                
                double lat =[latti[[latitude count]-1] floatValue];
                double lon = [longi[[logitude count]-1] floatValue];
                if (lat == 0 && lon == 0) {
                    
                    //   Addre = Addre;
                }
                else
                    
                    Addre = [[CurrentLocation GetSharedInstance]geoCodeArea:&lat Longitude:&lon];
            }
            else {
                double lat =location.coordinate.latitude;
                double lon = location.coordinate.longitude;
                Addre = [[CurrentLocation GetSharedInstance]geoCodeArea:&lat Longitude:&lon];
                //Address.text = [NSString stringWithFormat:@"%@,%@,%@,%@",Addre.Address1,Addre.Address2,Addre.Address3,Addre.AreaName];
            }
        }
        Address.text = [NSString stringWithFormat:@"%@,%@,%@,%@",Addre.Address1,Addre.Address2,Addre.Address3,Addre.AreaName];
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
}
-(NSDictionary*)GetCounts:(double)Lat  Long:(double)longi
{
    NSString *userRegID = [mPref valueForKey:USERREGISTERID];
    
    NSString *location= [NSString stringWithFormat:@"%f,%f",Lat,longi];
    NSDictionary *dic = @{@"UserRegisterId":userRegID,
                          @"Location":location,
                          @"radius":@"1000"
                          };
    NSDictionary *response = [mWebService GetCounts:dic];
    return response;
}


-(void)MapviewLongPress:(UIGestureRecognizer*)sender {
    @try {
        //        if (sender.state == UIGestureRecognizerStateEnded)
        //        {
        //            [self.mapView removeGestureRecognizer:sender];
        //        }
        //        else
        //        {
        CGPoint point = [sender locationInView:self.mapView];
        NSMutableArray * annotationsToRemove = [ self.mapView.annotations mutableCopy ] ;
        [ annotationsToRemove removeObject:self.mapView.userLocation ] ;
        [ self.mapView removeAnnotations:annotationsToRemove ] ;
        CLLocationCoordinate2D coordinate= [self.mapView convertPoint:point toCoordinateFromView:self.mapView];
        double lat = coordinate.latitude;
        double lon = coordinate.longitude;
        Addre = [[CurrentLocation GetSharedInstance]geoCodeArea:&lat Longitude:&lon];
        [self AddMarkertoMap:lat lon:lon coordinate:coordinate];
        Address.text = [NSString stringWithFormat:@"%@,%@,%@",Addre.Address1,Addre.Address2,Addre.Address3];
        
        // }
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
}

-(void)AddMarkertoMap:(double)Lat lon:(double)lon coordinate:(CLLocationCoordinate2D)coordinate {
    @try {
        CLGeocoder *ceo = [[CLGeocoder alloc]init];
        CLLocation *loc = [[CLLocation alloc]initWithLatitude:Lat longitude:lon]; //insert your coordinates
        MKPointAnnotation *point1 = [[MKPointAnnotation alloc] init];
        point1.coordinate = coordinate;
        [ceo reverseGeocodeLocation:loc
                  completionHandler:^(NSArray *placemarks, NSError *error) {
                      point1.title = [NSString stringWithFormat:@"%@",Address.text];
                  }
         ];
        [self.mapView addAnnotation:point1];
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
}


-(void)GetSubcatgoryById {
    @try {
        
        
        //GetTypesbyCategoryId
        [mPref valueForKey:MODULEID];
        GetSubCat = [[Web_Services GetSharedInstance]GetSubCategories:@"GetTypesbyCategoryId" CatgoryID:[mPref valueForKey:MODULEID]];
        
        UIViewController *controller = [[UIViewController alloc]init];
        UITableView *alertTableView;
        if (GetSubCat.count < 4) {
            CGRect rect = CGRectMake(0, 0, 272, 100);
            [controller setPreferredContentSize:rect.size];
            alertTableView  = [[UITableView alloc]initWithFrame:CGRectMake(0, 0, 272, 100)];
        }
        else if (GetSubCat.count < 6){
            CGRect rect = CGRectMake(0, 0, 272, 150);
            [controller setPreferredContentSize:rect.size];
            alertTableView  = [[UITableView alloc]initWithFrame:CGRectMake(0, 0, 272, 150)];
        }
        else if (GetSubCat.count < 8){
            CGRect rect = CGRectMake(0, 0, 272, 200);
            [controller setPreferredContentSize:rect.size];
            alertTableView  = [[UITableView alloc]initWithFrame:CGRectMake(0, 0, 272, 200)];
        }
        else{
            CGRect rect = CGRectMake(0, 0, 272, 250);
            [controller setPreferredContentSize:rect.size];
            alertTableView  = [[UITableView alloc]initWithFrame:CGRectMake(0, 0, 272, 250)];
        }
        
        alertTableView.delegate = self;
        alertTableView.dataSource = self;
        alertTableView.tableFooterView = [[UIView alloc]initWithFrame:CGRectZero];
        [alertTableView setSeparatorStyle:UITableViewCellSeparatorStyleSingleLine];
        [alertTableView setTag:1];
        [controller.view addSubview:alertTableView];
        [controller.view bringSubviewToFront:alertTableView];
        [controller.view setUserInteractionEnabled:YES];
        [alertTableView setUserInteractionEnabled:YES];
        [alertTableView setAllowsSelection:YES];
        alertController = [UIAlertController alertControllerWithTitle:@"" message:@"Select Sub-category" preferredStyle:UIAlertControllerStyleAlert];
        [alertController setValue:controller forKey:@"contentViewController"];
        
        UIAlertAction* cancel = [UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleDefault
                                                       handler:^(UIAlertAction * action) {
                                                           Type.text = @"";
                                                           [alertController dismissViewControllerAnimated:YES completion:nil];
                                                           
                                                           
                                                       }];
        [alertController addAction:cancel];
        
        [self presentViewController:alertController animated:YES completion:nil];
        
        //  [autoComplete reloadData];
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
    
}

-(void) viewDidLayoutSubviews {
    @try {
        [ super viewDidLayoutSubviews];
        // [self.scrollview layoutIfNeeded];
        // self.scrollview.contentSize=self.Contentview.bounds.size ;
        
        UIGraphicsBeginImageContext(self.view.frame.size);
        UIImage *image = UIGraphicsGetImageFromCurrentImageContext();
        image= [UIImage imageNamed:@"bg.png"];
        UIGraphicsEndImageContext();
        self.view.backgroundColor = [UIColor colorWithPatternImage:image];
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
}

#pragma mark -Hidekeyboard

- (void)textViewDidEndEditing:(UITextView *)textView{
     [self animateTextView:textView up:NO];
    [meetingDescription resignFirstResponder];
}

- (BOOL)textView:(UITextView *)txtView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text {
    if( [text rangeOfCharacterFromSet:[NSCharacterSet newlineCharacterSet]].location == NSNotFound ) {
        return YES;
    }
    
    [txtView resignFirstResponder];
    return NO;
}


-(IBAction)hideKeyBoardKeyWord:(id)sender {
  
    if ([meetingDescription isFirstResponder]) {
        [meetingDescription resignFirstResponder];
        if ([meetingDescription.text isEqualToString:@""]) {
            [self showAlertPop:@"Please enter description" expObj:nil];
        }
    }
    
    
    
    if ([Address isFirstResponder])
    {
        [Address resignFirstResponder];
        // autoComplete.hidden = YES;
        
    }
}

-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event {
    @try {
        if ([meetingDescription isFirstResponder]) {
            [meetingDescription resignFirstResponder];
        }
        else  if ([meetingDescription isFirstResponder]) {
            [meetingDescription resignFirstResponder];
        }
        else if ([Datelabel isFirstResponder])
        {
            [Datelabel resignFirstResponder];
        }
        else if ([Timelabel isFirstResponder])
        {
            [Timelabel resignFirstResponder];
        }
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    }
}

-(void)didtapanywhere:(UIGestureRecognizer*)recog {
    @try {
        
        [meetingDescription resignFirstResponder];
        [meetingDescription resignFirstResponder];
        [Timelabel resignFirstResponder];
        [Datelabel resignFirstResponder];
        [Address resignFirstResponder];
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string {
    @try {
        
        if (textField == Address) {
            autoComplete.hidden = NO;
            
            if ([Address.text isEqualToString:@""]) {
                autoComplete.hidden= YES;
            }
            
            else  if (![Address.text isEqualToString:@""]) {
                
                NSString *substring = [NSString stringWithString:Address.text];
                substring = [substring
                             stringByReplacingCharactersInRange:range withString:string];
                [self searchAutocompleteEntriesWithSubstring:substring];
                return YES;
            }
            
        }
        
        else if (textField == Type)
            
        {
            typetableView.hidden = NO;
            
            if ([Type.text isEqualToString:@""]) {
                
                if([Type.text length]==0)
                {
                    GetSubCat = getSubCategory;
                    [typetableView reloadData];
                    
                }
                // typetableView.hidden= YES;
            }
            else if (![Type.text isEqualToString:@""])
            {
                NSString *substring = [NSString stringWithString:Type.text];
                substring = [substring
                             stringByReplacingCharactersInRange:range withString:string];
                [self TypeAutocompleteEntriesWithSubstring:substring];
                return YES;
                
            }
        }
        
        return YES;
        
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
}

- (void)TypeAutocompleteEntriesWithSubstring:(NSString *)substring {
    @try {
        // Put anything that starts with this substring into the autocompleteUrls array
        // The items in this array is what will show up in the table view
        NSPredicate *predicate = [NSPredicate predicateWithFormat:@"SELF contains [cd] %@", substring];
        results = [searchString filteredArrayUsingPredicate:predicate];
        if ([results count]!=0) {
            
            NSMutableArray *array = [[NSMutableArray alloc]init];
            
            
            for (int i=0; i<[results count]; i++) {
                NSString  *str= [results objectAtIndex:i];
                
                for (int j=0; j<[GetSubCat count]; j++) {
                    NSString *str2 = [[GetSubCat objectAtIndex:j]  valueForKey:@"TypeName"];
                    if ([str isEqualToString:str2]) {
                        [array addObject:[GetSubCat objectAtIndex:j]];
                    }
                }
                
            }
            
            NSOrderedSet *orderedSet = [NSOrderedSet orderedSetWithArray:array];
            GetSubCat = [orderedSet mutableCopy];
            
            
            
            [typetableView reloadData];
            
        }
        //[autoComplete reloadData];
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
}


- (void)searchAutocompleteEntriesWithSubstring:(NSString *)substring {
    @try {
        // Put anything that starts with this substring into the autocompleteUrls array
        // The items in this array is what will show up in the table view
        NSString* urlpath;
        if (![substring isEqual:@""])
            //https://maps.googleapis.com/maps/api/place/autocomplete/json?key=AIzaSyBsB3SN513YgmJxs-md1zA2zWPgktPhczU&input=am
        {
            urlpath = [NSString stringWithFormat:@"https://maps.googleapis.com/maps/api/place/autocomplete/json?key=AIzaSyAM5zyy3xsgRWpye3fmXLEK1Hm18E_tj98&input=%@",substring];
            NSString *escapedUrlString = [urlpath stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet URLFragmentAllowedCharacterSet]];
            
            NSURL *RPRTUrlpath = [NSURL URLWithString:escapedUrlString];
            
            NSData *myData = [NSData dataWithContentsOfURL:RPRTUrlpath];
            
            NSError* error1;
            
            NSDictionary    * autocompleteUrls1 = [NSJSONSerialization
                                                   JSONObjectWithData:myData
                                                   options:kNilOptions
                                                   error:&error1];
            NSString  *prediction = [autocompleteUrls1 valueForKey:@"predictions"];
            autocompleteAddress= [prediction valueForKey:@"description"];
            
            [autoComplete reloadData];
        }
        else  if ([substring isEqual:@""])
            
        {
            
        }
        
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
}


#pragma mark -UITableview Datasource

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    @try {
        
        if (tableView == typetableView) {
            return  [GetSubCat count];
        }
        else if(tableView==autoComplete)
        {
            return [autocompleteAddress count];
        }
        return [autocompleteAddress count];
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
    
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    return 50;
    
}

// This will tell your UITableView what data to put in which cells in your table.
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    @try {
        
        
        UITableViewCell *cell= nil;
        if (tableView == typetableView) {
            static NSString *CellIdentifier = @"Cell";
            // Reuse and create cell
            UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
            if (cell == nil) {
                cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
            }
            NSDictionary *Cat = [GetSubCat objectAtIndex:indexPath.row];
            cell.textLabel.text = [Cat valueForKey:@"TypeName"];
            return cell;
            
        }
        else if (tableView==autoComplete)
        {
            
            static NSString *CellIdentifier = @"Cell";
            // Reuse and create cell
            UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
            if (cell == nil) {
                cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
            }
            NSString *Addreline = [autocompleteAddress objectAtIndex:indexPath.row];
            cell.textLabel.text = Addreline;
            return cell;
        }
        
        return cell;
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    @try {
        
        if (tableView == typetableView) {
            NSDictionary *selctedCategory = [GetSubCat objectAtIndex:indexPath.row];
            SelectedSubCat = selctedCategory;
            Type.text = [selctedCategory valueForKey:@"TypeName"];
            // [alertController dismissViewControllerAnimated:YES completion:nil];
            [offerTypeSearch resignFirstResponder];
            [offertypeAlert close];
            typetableView.hidden = YES;
            [Type resignFirstResponder];
        }
        else if (tableView==autoComplete)
        {
            
            NSString *selectedAdress = [autocompleteAddress objectAtIndex:indexPath.row];
            Address.text = selectedAdress;
            [Address resignFirstResponder];
            CLLocationCoordinate2D   center   =  [[CurrentLocation GetSharedInstance]getLocationFromAddressString:selectedAdress];
            
            Addre=[[CurrentLocation GetSharedInstance]geoCodeArea:&center.latitude Longitude:&center.longitude];
            
            
            // NSString   *seachlatlong = [NSString stringWithFormat:@"%f,%f",center.latitude,center.longitude];
            autoComplete.hidden= YES;
            [Address resignFirstResponder];
            
            for (id<MKAnnotation> annotation in mapView.annotations){
                MKAnnotationView* anView = [mapView viewForAnnotation: annotation];
                if (anView){
                    [mapView removeAnnotation:annotation];
                }
            }
            
            
            
            CLLocationCoordinate2D coord = CLLocationCoordinate2DMake(center.latitude, center.longitude);
            
            MKCoordinateSpan span = MKCoordinateSpanMake(0.1, 0.1);
            MKCoordinateRegion region = {coord, span};
            
            MKPointAnnotation *annotation = [[MKPointAnnotation alloc] init];
            [annotation setCoordinate:coord];
            
            [self.mapView setRegion:region];
            [self.mapView addAnnotation:annotation];
            
        }
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
    
}
-(IBAction)back:(id)sender {
    @try {
        //
        //        MainViewController *hHome = [[MainViewController alloc]initWithNibName:MAINVIEWCONTROLLER bundle:nil];
        //        [self presentViewController:hHome animated:YES completion:nil];
        [self dismissViewControllerAnimated:YES completion:NULL];
        
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
}
-(BOOL)textfieldvalidation
{
    //  [self timeValidation];
    
    if ([Datelabel.text isEqualToString:@""] && [Datelabel.text isEqualToString:@""]) {
        
        [self showAlertPop:@"Please select Date and Time" expObj:nil];
        return NO;
    }
    
    else if ([Time isEqualToString:@""]) {
        [self showAlertPop:@"Please select time limit" expObj:nil];
        return NO;
    }
    
    
    else  if ([meetingDescription.text isEqualToString:@""]) {
         [meetingDescription becomeFirstResponder];
        [self showAlertPop:@"Please enter Description" expObj:nil];
        return NO;
    }
    if (SelectedSubCat==nil) {
        [self showAlertPop:@" select request type" expObj:nil];
        return NO;
        
    }

    
    else if ([Type.text isEqualToString:@""]) {
        [self showAlertPop:@"select request type" expObj:nil];
        return NO;
        
    }
    
    else  if ([Address.text isEqualToString:@""]) {
         [Address becomeFirstResponder];
        [self showAlertPop:@"Please select area on map" expObj:nil];
        return NO;
        
    }
    
    
    return YES;
}

- (BOOL)validMobileNumber:(NSString *)mobilenumber {
    
    @try {
        
        BOOL isValid = NO;
        NSCharacterSet *alphaNumbersSet = [NSCharacterSet decimalDigitCharacterSet];
        NSCharacterSet *stringSet = [NSCharacterSet characterSetWithCharactersInString:mobilenumber];
        isValid = [alphaNumbersSet isSupersetOfSet:stringSet];
        return isValid;
        
        
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    }
}

// Upload data into Server
-(void)PostOpportunity {
    @try {
        
        if (isOnlineStatus) {
        
        if ([self textfieldvalidation]) {
            
            spinner = [[UIActivityIndicatorView alloc]
                       initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
            spinner.frame = CGRectMake(0, 0, 320, 560); // CGPointMake(160, 240);
            spinner.color = [UIColor blueColor];
            spinner.backgroundColor = [UIColor lightTextColor];
            spinner.transform = CGAffineTransformMakeScale(2, 2);
            // spinner.hidesWhenStopped = YES;
            [self.view addSubview:spinner];
            spinner.transform = CGAffineTransformMakeScale(2, 2);
            
            [spinner startAnimating];
            
            // how we stop refresh from freezing the main UI thread
            
            dispatch_async(
                           dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^{
                               
                               // back to the main thread for the UI call
                               dispatch_async(dispatch_get_main_queue(), ^{
                                   
                                   
                                   [spinner startAnimating];
                               });
                               dispatch_async(dispatch_get_main_queue(), ^{
                                   if (![Datelabel.text isEqualToString:@""] && ![meetingDescription.text isEqualToString:@""] && ![meetingDescription.text isEqualToString:@""] && ![Time isEqualToString:@""] && ![Type.text isEqualToString:@""] && ![Address.text isEqualToString:@""])
                                       
                                   {
                                       
                                       NSString *selectedDateTime = [NSString stringWithFormat:@"%@ %@",Datelabel.text,Timelabel.text];
                                       
                                       NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
                                       [dateFormatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
                                       NSTimeZone *gmt = [NSTimeZone timeZoneWithAbbreviation:@"UTC"];
                                       [dateFormatter setTimeZone:gmt];
                                       mFinalDate = [dateFormatter dateFromString:selectedDateTime];
                                       
                                       [timeWithInterval setValue:mFinalDate forKeyPath:@"Date"];

                                       
                                       NSDictionary *GetDateTime=[mTimeCalculator GetTimeintervals:timeWithInterval];
                                       
                                       
                                       NSDictionary *GetModuleIDAndCatID = [mTimeCalculator GetCateGory:SelectedSubCat];
                                       NSDictionary *GetAddress = [mTimeCalculator GetAddress];
                                       
                                       NSDictionary *GetOpportunity = [self GetOpportunityDetails];
                                       NSString *location = [NSString stringWithFormat:@"%@,%@",[GetAddress valueForKey:LATITUDE],[GetAddress valueForKey:LONGITUDE]];
                                       
                                       //                                       NSString *Timeleft = [NSString stringWithFormat:@"%@,%@",[mPref valueForKey:MODULEID],[mPref valueForKey:USERREGISTERID]];
                                       //
                                       //                                       NSDictionary *TimeLeftResponse = [mWebService GetTimeLeftUserByCategory:@"GetTimeleftbyIds" Id:Timeleft];
                                       //                                       NSString *timeleft = [TimeLeftResponse valueForKey:@"TimeLeft"];
                                       //
                                       //                                       if ([timeleft intValue]<[[GetDateTime valueForKey:@"Time"] intValue]) {
                                       //                                           [self showAlertPop:@"Time Exceeded" expObj:nil];
                                       //
                                       //                                       }
                                       //
                                       //                                       else
                                       //                                       {
                                       NSString *remainingTime;
                                       
                                       //  int Times = [timeleft intValue]-[Time intValue];
                                       remainingTime = Time;// [NSString stringWithFormat:@"%d",Times];
                                       
                                     //  NSString *userID =   [mPref objectForKey:@"SaveUserID"];
                                       NSString *RegisterID =   [mPref objectForKey:USERREGISTERID];
                                       
                                       NSString *DeviceID = [[[UIDevice currentDevice] identifierForVendor] UUIDString];
                                       
                                       NSString *gcmID = [mPref valueForKey:@"FCMID"];
                                       if ([gcmID isEqualToString:@""] || gcmID==nil) {
                                           gcmID=@"";
                                       }
                                       
                                       if ([OpportunityID isEqualToString:@"0"]) {
                                           ActionKey= @"Save";
                                       }
                                       else ActionKey= @"Update";

                                       
                                       
                                       //  NSDictionary *Opportunity = [[NSDictionary alloc]init];
                                       
                                       NSDictionary *  Opportunity  = @{@"OpportunityID":OpportunityID,
                                                                        @"OpportunityName":[GetOpportunity valueForKey:@"OpportunityName"],
                                                                        @"OpportunityDescription":[GetOpportunity valueForKey:@"OpportunityDescription"],
                                                                        @"OpportunityKeywords":[GetOpportunity valueForKey:@"OpportunityKeywords"],
                                                                        @"CategoryID":[GetModuleIDAndCatID valueForKey:@"CategoryID"],
                                                                        @"ModuleId":@"42",
                                                                        @"UserID":@"0",
                                                                        
                                                                        @"StartDate":[GetDateTime valueForKey:@"StartDate"],
                                                                        @"EndDate":[GetDateTime valueForKey:@"EndDate"],
                                                                        @"PromoCode":@"Promo",
                                                                        @"OpportunityType":OppForKey,
                                                                        @"DeviceId":DeviceID,
                                                                        @"PhotoName":[GetOpportunity valueForKey:@"PhotoName"],
                                                                        @"VendorAddressId":VendorAddressId,
                                                                        @"TimeInterval":[GetDateTime valueForKey:@"TimeInterval"],
                                                                        @"GcmId":gcmID,
                                                                        @"AddressName":[GetOpportunity valueForKey:@"AddressName"],
                                                                        @"IsPrimary":@"true",
                                                                        @"Address1":[GetAddress valueForKey:@"Address1"],
                                                                        @"Address3":[GetAddress valueForKey:@"Address3"],
                                                                        @"Address2":[GetAddress valueForKey:@"Address2"],
                                                                        @"AreaName":[GetAddress valueForKey:@"AreaName"],
                                                                        @"Quantity":@"",
                                                                        @"City":[GetAddress valueForKey:@"City"],
                                                                        @"State":[GetAddress valueForKey:@"State"],
                                                                        @"Country":[GetAddress valueForKey:@"Country"],
                                                                        LATITUDE:[GetAddress valueForKey:LATITUDE],
                                                                        LONGITUDE:[GetAddress valueForKey:LONGITUDE],
                                                                        @"KeyWords":@"",
                                                                        @"Time":remainingTime,
                                                                        @"PageSize":@"10",
                                                                        @"PageNo":@"1",
                                                                        @"radius":@"1000",
                                                                        @"LocationFlag":@"NotChanged",
                                                                        @"Location":location,
                                                                        @"Categories":@"",
                                                                        @"types":@"",
                                                                        @"UserRegisterId":RegisterID,
                                                                        @"Name":meetingDescription.text,
                                                                        @"Price":@"",
                                                                        @"ActualPrice":@"",
                                                                        @"Delivery":@"",
                                                                        @"Action":ActionKey
                                                                        
                                                                        };
                                       
                                       if (isOnlineStatus) {
                                           NSDictionary *Reponse =   [[Web_Services GetSharedInstance]PostOffer:Opportunity];
                                           if (Reponse!=nil && [Reponse count]>6) {
                                               
                                               
                                               if ([SendSMSKey isEqualToString:@"1"]) {
                                                   
                                                   NSString *StoreName =@"";
                                                   NSArray *phonenumbersarra;
                                                   
                                                   NSString   * UserRegID  =[NSString stringWithFormat:@"%@",[mPref valueForKey:USERREGISTERID]];
                                                   
                                                   if ([OppForKey isEqualToString:@"2"] || [OppForKey isEqualToString:@"1"]) {
                                                       UserRegID= [NSString stringWithFormat:@"%@/Customer",UserRegID];
                                                   }
                                                   else if ([OppForKey isEqualToString:@"3"])
                                                   {
                                                       UserRegID= [NSString stringWithFormat:@"%@/Business",UserRegID];
                                                   }
                                                   
                                                   
                                                   NSMutableArray *contactsArray = [mWebService GetMyCustomers:UserRegID];
                                                   phonenumbersarra = [contactsArray valueForKey:@"PhoneNo"];
                                                   //PhoneNo
                                                   NSLog(@"%@",contactsArray);
                                                   
                                                   NSData  *VendorData =    [mPref valueForKey:@"SaveRegisterDetails"];
                                                   NSDictionary *myDictionary =   (NSDictionary*) [NSKeyedUnarchiver unarchiveObjectWithData:VendorData];
                                                   NSLog(@"%@",myDictionary);
                                                   
                                                   ;
                                                   
                                                   // NSString *regName ;
                                                   if ([[mPref valueForKey:LOGINTYPE] isEqualToString:@"Business"]) {
                                                       StoreName=[myDictionary valueForKey:@"RegUserName"];
                                                   }
                                                   else if ([[mPref valueForKey:LOGINTYPE] isEqualToString:@"Individual"])
                                                       StoreName=[[myDictionary  valueForKey:@"BusinessDeatils"] valueForKey:@"ContactPerson"];
                                                   
                                                  self.smsPopUp = [[SMSController alloc] initWithNibName:@"SMSController" bundle:nil];
                                                   [self.smsPopUp setTitle:@"This is a popup view"];
                                                   
                                                   self.smsPopUp.StoreName.text =StoreName;
                                                   self.smsPopUp.CustomerNumbers=phonenumbersarra;
                                                   
                                                   self.smsPopUp.OppName=meetingDescription.text;
                                                   self.smsPopUp.messageView.text = meetingDescription.text;
                                                   self.smsPopUp.StoreNameText =StoreName;
                                                   
                                                   [self.smsPopUp showInView:self.view withImage:[UIImage imageNamed:@"rprt_usinfo.png"] withMessage:@"You just triggered a great popup window" animated:YES];
                                               
                                               }
                                               else
                                               {
                                                   UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"Right Place Right Time"
                                                                                                                  message:@"Your offer is posted successfully!"
                                                                                                           preferredStyle:UIAlertControllerStyleAlert];
                                                   
                                                   UIAlertAction* defaultAction = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault
                                                                                                         handler:^(UIAlertAction * action) {
                                                                                                             
                                                                                                             //  [mPref setObject:remainingTime forKey:@"TimeSlot"];
                                                                                                             Retailer_Offer * mOpportunity_list = [[ Retailer_Offer alloc] initWithNibName:RETAILER bundle:nil];
                                                                                                             [self presentViewController:mOpportunity_list animated:YES completion:nil];
                                                                                                             
                                                                                                         }];
                                                   
                                                   [alert addAction:defaultAction];
                                                   
                                                   [self presentViewController:alert animated:YES completion:nil];

                                               }
                                               
                                           }
                                           else
                                           {
                                               [self showAlertPop:@"oops, We are unable to process your request! Please try after some time." expObj:nil];
                                           }
                                           
                                       }
                                       else
                                       {
                                           
                                           [self showAlertPop:@"No internet connection." expObj:nil];
                                           
                                           
                                       }
                                       
                                       //}
                                       
                                   }
                                   [spinner stopAnimating];
                                   
                               });
                           });
        }
        }
        else
        {
            [self showAlertPop:@"No internet conncetion" expObj:nil];
        }
    }
    @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
        
    }
    @finally {
        
    }

}

-(NSDictionary*)GetOpportunityDetails {
    @try {
        //   NSString *AddressName = [NSString stringWithFormat:@"%@,%@,%@,%@,%@,%@,%@",Addre.Address1,Addre.Address2,Addre.Address3,Addre.AreaName,Addre.City,Addre.State,Addre.Country];
        //NSUserDefaults *prefss = [NSUserDefaults standardUserDefaults];
        NSString *UserId;
        if ([mPref objectForKey:@"SaveUserID"]) {
            UserId =[mPref objectForKey:@"SaveUserID"];
        }
        
        NSMutableArray *imagebyteArray = [NSMutableArray array];
        UIImage *yourImage;NSString *imagename;
        
        
        if ([Images count]!=0) {
            
            for(int i=0; i < [Images count]; i++)
            {
                yourImage=[Images objectAtIndex:i];
                
                yourImage = [self resizeImage:yourImage];
                NSData *data = UIImagePNGRepresentation(yourImage);
                NSString *base64String = [data base64EncodedStringWithOptions:0];
                [imagebyteArray addObject:base64String];
            }
            if ([imagebyteArray count]==0) {
                imagename =@"";
            }
            else{
                imagename = [imagebyteArray componentsJoinedByString:@","];
            }
        }
    
        
        
        NSMutableDictionary *Opportunity = [[NSMutableDictionary alloc]init];
        [Opportunity setObject:self.postName.text forKey:@"OpportunityName"];
        [Opportunity setObject:meetingDescription.text forKey:@"OpportunityDescription"];
        [Opportunity setObject:meetingDescription.text forKey:@"OpportunityKeywords"];
        [Opportunity setObject:@"0" forKey:@"UserID"];
        [Opportunity setObject:@"Promo" forKey:@"PromoCode"];
        [Opportunity setObject:OppForKey forKey:@"OpportunityType"];
        if (imagename!=nil) {
            [Opportunity setObject:imagename forKey:@"PhotoName"];
        }
        else [Opportunity setObject:@"" forKey:@"PhotoName"];
        
        
        [Opportunity setObject:@"" forKey:@"VendorAddressId"];
        [Opportunity setObject:@"" forKey:@"GcmId"];
        [Opportunity setObject:Addre.AddresName forKey:@"AddressName"];
        [Opportunity setObject:@"true" forKey:@"IsPrimary"];
        [Opportunity setObject:@"" forKey:@"Categories"];
        [Opportunity setObject:@"" forKey:@"types"];
        
        return Opportunity;
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
}

-(UIImage *)resizeImage:(UIImage *)image
{
    
    @try {
        
        
        float actualHeight = image.size.height;
        float actualWidth = image.size.width;
        float maxHeight = 300.0;
        float maxWidth = 400.0;
        float imgRatio = actualWidth/actualHeight;
        float maxRatio = maxWidth/maxHeight;
        float compressionQuality = 0.5;//50 percent compression
        
        if (actualHeight > maxHeight || actualWidth > maxWidth)
        {
            if(imgRatio < maxRatio)
            {
                //adjust width according to maxHeight
                imgRatio = maxHeight / actualHeight;
                actualWidth = imgRatio * actualWidth;
                actualHeight = maxHeight;
            }
            else if(imgRatio > maxRatio)
            {
                //adjust height according to maxWidth
                imgRatio = maxWidth / actualWidth;
                actualHeight = imgRatio * actualHeight;
                actualWidth = maxWidth;
            }
            else
            {
                actualHeight = maxHeight;
                actualWidth = maxWidth;
            }
        }
        
        CGRect rect = CGRectMake(0.0, 0.0, actualWidth, actualHeight);
        UIGraphicsBeginImageContext(rect.size);
        [image drawInRect:rect];
        UIImage *img = UIGraphicsGetImageFromCurrentImageContext();
        NSData *imageData = UIImageJPEGRepresentation(img, compressionQuality);
        UIGraphicsEndImageContext();
        
        return [UIImage imageWithData:imageData];
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
    
    
}

- (IBAction)textFieldDidBeginEditing:(id)textField {
    @try {
        
        [self animateTextField:textField up:YES];
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
}

- (IBAction)textFieldDidEndEditing:(id)textField {
    @try {
        
        [self animateTextField:textField up:NO];
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
}

-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    // [self animateTextField:textField up:NO];
    return YES;
}


-(void)textViewDidBeginEditing:(UITextView *)textView
{
    meetingDescription.text= @"";
    
    [self animateTextView:textView up:YES];
}


-(void)animateTextView:(UITextView*)textView up:(BOOL)up
{
    @try {
        
        int animatedDistance;
        //  int moveUpValue = textField.frame.origin.y + textField.frame.size.height;
        UIInterfaceOrientation orientation =
        [[UIApplication sharedApplication] statusBarOrientation];
        if (orientation == UIInterfaceOrientationPortrait ||
            orientation == UIInterfaceOrientationPortraitUpsideDown) {
            
            animatedDistance = 280 - (250 - 50 - 5);
        } else {
            animatedDistance = 162 - (320 - 50 - 5);
        }
        
        if (animatedDistance > 0) {
            NSString *deviceType = [[UIDevice currentDevice] model];
            
            if ([deviceType isEqualToString:@"iPad"]) {
            }
            
            const int movementDistance = animatedDistance;
            const float movementDuration = 0.3f;
            int movement = (up ? -movementDistance : movementDistance);
            [UIView beginAnimations:nil context:nil];
            [UIView setAnimationBeginsFromCurrentState:YES];
            [UIView setAnimationDuration:movementDuration];
            self.view.frame = CGRectOffset(self.view.frame, 0, movement);
            [UIView commitAnimations];
        }
        
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    }
}



- (void)animateTextField:(UITextField *)textField up:(BOOL)up {
    @try {
        
        
        
        int animatedDistance;
        //  int moveUpValue = textField.frame.origin.y + textField.frame.size.height;
        UIInterfaceOrientation orientation =
        [[UIApplication sharedApplication] statusBarOrientation];
        if (orientation == UIInterfaceOrientationPortrait ||
            orientation == UIInterfaceOrientationPortraitUpsideDown) {
            
            animatedDistance = 280 - (250 - 50 - 5);
        } else {
            animatedDistance = 162 - (320 - 50 - 5);
        }
        
        if (animatedDistance > 0) {
            NSString *deviceType = [[UIDevice currentDevice] model];
            
            if ([deviceType isEqualToString:@"iPad"]) {
            }
            
            const int movementDistance = animatedDistance;
            const float movementDuration = 0.3f;
            int movement = (up ? -movementDistance : movementDistance);
            [UIView beginAnimations:nil context:nil];
            [UIView setAnimationBeginsFromCurrentState:YES];
            [UIView setAnimationDuration:movementDuration];
            self.view.frame = CGRectOffset(self.view.frame, 0, movement);
            [UIView commitAnimations];
        }
        
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    }
}

-(void)EditedDetils
{
    @try {
        self.postName.text= [EditOpp valueForKey:@"OpportunityName"];
        meetingDescription.text = [EditOpp valueForKey:@"OpportunityDescription"];
         OppForKey=[NSString stringWithFormat:@"%@",[EditOpp valueForKey:@"OpportunityType"]];
        Time = @"30";
        [timeWithInterval setValue:@"30" forKey:@"Time"];
        [timeWithInterval setValue:@"1" forKey:@"TimeInterval"];
        btn15.backgroundColor = selectedcolr;
        NSString *opportunityId= [EditOpp valueForKey:@"OpportunityID"];
        OpportunityID =[NSString stringWithFormat:@"%@",[EditOpp valueForKey:@"OpportunityID"]];
        VendorAddressId= [NSString stringWithFormat:@"%@",[EditOpp valueForKey:@"VendorAddressId"]];
        
        NSDictionary *Oppor= [mTimeCalculator getEditeOpportunity:opportunityId];
        [mPref setValue:[NSString stringWithFormat:@"%@",[Oppor valueForKey:@"ModuleId"]] forKey:MODULEID];
        
        [self getSubCategoryDetails:[EditOpp valueForKey:@"ModuleId"]];
        
        
        for (int i=0; i<[GetSubCat count]; i++) {
            
            NSString *name=[NSString stringWithFormat:@"%@",[[GetSubCat objectAtIndex:i] valueForKey:@"TypeName"]];
            
            
            if ([name isEqualToString:[EditOpp valueForKey:@"SubCategory"]]) {
                
                SelectedSubCat = [GetSubCat objectAtIndex:i];
                Type.text = [SelectedSubCat valueForKey:@"TypeName"];
                
                
            }
            
        }
        
        NSString *imag = [EditOpp objectForKey:@"PhotoName"];
        NSArray *stringArray = [imag componentsSeparatedByString:@","];
        
        Images = [NSMutableArray arrayWithCapacity:[stringArray count]];
        
        if (stringArray!=0 && ![stringArray[0] isEqualToString:@""]) {
            for (NSDictionary *dict in stringArray)
            {
                if (![dict isEqual:@""])
                {
                    
                    NSMutableString* aString = [NSMutableString stringWithFormat:@"%@%@",baseImageURL,dict];
                    
                    
                    NSURL *imageURL = [NSURL URLWithString:aString];
                    
                    NSData *newData = [NSData dataWithContentsOfURL:imageURL];
                    UIImage *img = [UIImage imageWithData:newData];
                    [Images addObject:img];
                    
                    
                    
                }
                
                
            }
        }
        
        
        if ([Images count]!=0) {
            PhotoScroll.hidden= NO;
            
        }
        UIImage *avalbleImage =nil;
        CGSize siz =CGSizeMake(22  , 22);
        
        
        if ([OppForKey isEqualToString:@"1"]) {
            
            
            avalbleImage = [UIImage imageNamed:@"check.png"];
            avalbleImage=   [mTimeCalculator image:avalbleImage scaledToSize:siz];
            publicCheck.image =  [avalbleImage imageWithTint:[UIColor darkTextColor]];
            
        }
        else if ([OppForKey isEqualToString:@"2"])
        {
            
            avalbleImage = [UIImage imageNamed:@"check.png"];
            avalbleImage=   [mTimeCalculator image:avalbleImage scaledToSize:siz];
            CustomersCheck.image =  [avalbleImage imageWithTint:[UIColor darkTextColor]];
            
            UIImage  *avalble = [UIImage imageNamed:@"uncheck.png"];
            avalble=   [mTimeCalculator image:avalble scaledToSize:siz];
            publicCheck.image =  [avalble imageWithTint:[UIColor clearColor]];
            
            
            
        }
        else if ([OppForKey isEqualToString:@"3"])
        {
            avalbleImage = [UIImage imageNamed:@"check.png"];
            avalbleImage=   [mTimeCalculator image:avalbleImage scaledToSize:siz];
            self.myCircleCheck.image =  [avalbleImage imageWithTint:[UIColor darkTextColor]];
            
            UIImage  *avalble = [UIImage imageNamed:@"uncheck.png"];
            avalble=   [mTimeCalculator image:avalble scaledToSize:siz];
            publicCheck.image =  [avalble imageWithTint:[UIColor clearColor]];
        }

        
        
        
        
        
        if ([Images count]>1) {
            [self setImageToImageFrame];
        }
        else if([Images count]==1)
        {
            
            for (UIImage *img in Images)
            {
                self.photoimage.image = img;
                
            }
        }
        
        
        double lat =[[EditOpp valueForKey:LATITUDE] doubleValue];
        double lon =[[EditOpp valueForKey:LONGITUDE] doubleValue];
        Addre = [[CurrentLocation GetSharedInstance]geoCodeArea:&lat Longitude:&lon];
        
        Address.text = [NSString stringWithFormat:@"%@,%@,%@",Addre.Address1,Addre.Address2,Addre.Address3];
        CLLocationCoordinate2D pinlocation=mapView.userLocation.coordinate;
        
        pinlocation.latitude = lat;
        
        pinlocation.longitude  =lon;
        
        [self AddMarkertoMap:lat lon:lon coordinate:pinlocation];
        
    }
    @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
    
}

-(void)getSubCategoryDetails:(NSString*)ModuleId
{
    @try {
        searchString = [[NSMutableArray alloc]init];
        
        
        getSubCategory  = [[Web_Services GetSharedInstance]GetSubCategories:@"GetTypesbyCategoryId" CatgoryID:ModuleId];
        for (int i = 0; i<[getSubCategory count]; i++) {
            
            [searchString addObject:[[getSubCategory objectAtIndex:i] valueForKey:@"TypeName"]];
            
        }
        
        GetSubCat =getSubCategory;
        
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
    
}

#pragma mark -erroralert

- (void) showAlertPop:(NSString*)alertText  expObj:(NSException*) exp{
    if(exp != nil)
    {
        NSLog(@"%@", exp.description);
    }
    NSLog(@"The Exception is %@",exp.description);
    UIAlertController *myAlertController =[mWebService  alert:alertText];
    [self presentViewController:myAlertController animated:YES completion:nil];
}



#pragma mark -DatePicker
#pragma mark -DatePicker
-(void)DateBtn {
    @try {
        Datepicker = [[UIView alloc]initWithFrame:CGRectMake(10, 250,350, 400)];
        [Datepicker setBackgroundColor:[UIColor whiteColor]];
        DatePicker =[[UIDatePicker alloc]initWithFrame:CGRectMake(0, 0,300, 200)];
        DatePicker.datePickerMode=UIDatePickerModeDate;
        DatePicker.hidden=NO;
        DatePicker.date=[NSDate date];
        DatePicker.layer.borderColor = [UIColor colorWithRed:240.0/255.0 green:240.0/255.0 blue:240.0/255.0 alpha:1].CGColor;
        [DatePicker addTarget:self action:@selector(DatePickerDateChange:) forControlEvents:UIControlEventValueChanged];
        DatePicker.layer.borderWidth = 1;
        DatePicker.backgroundColor = [UIColor whiteColor];
        DatePicker.layer.masksToBounds = YES;
        DatePicker.layer.cornerRadius = 2;
        NSDateFormatter *dateformatter=[[NSDateFormatter alloc]init];
        [dateformatter setDateFormat:@"HH:mm:ss"];
        [Datepicker addSubview:DatePicker];
        UIButton *Cancel = [[UIButton alloc]initWithFrame:CGRectMake(0, 210, 150, 35)];
        [Cancel setTitle:@"Cancel" forState:UIControlStateNormal];
        [Cancel addTarget:self action:@selector(DateCancel:) forControlEvents:UIControlEventTouchUpInside];
        [Cancel setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
        [Cancel setBackgroundColor:[UIColor whiteColor]];
        Cancel.layer.borderColor = [UIColor colorWithRed:240.0/255.0 green:240.0/255.0 blue:240.0/255.0 alpha:1].CGColor ;
        Cancel.layer.borderWidth = 1;
        Cancel.backgroundColor = [UIColor whiteColor];
        Cancel.layer.masksToBounds = YES;
        Cancel.layer.cornerRadius = 2;
        [Datepicker addSubview:Cancel];
        UIButton *Select = [[UIButton alloc]initWithFrame:CGRectMake(150, 210, 150, 35)];
        [Select setTitle:@"Select" forState:UIControlStateNormal];
        [Select addTarget:self action:@selector(DateSelect:) forControlEvents:UIControlEventTouchUpInside];
        [Select setTitleColor:[UIColor blueColor] forState:UIControlStateNormal];
        [Select setBackgroundColor:[UIColor whiteColor]];
        Select.layer.borderColor = [UIColor colorWithRed:240.0/255.0 green:240.0/255.0 blue:240.0/255.0 alpha:1].CGColor;
        Select.layer.borderWidth = 1;
        Select.backgroundColor = [UIColor whiteColor];
        Select.layer.masksToBounds = YES;
        Select.layer.cornerRadius = 2;
        [Datepicker addSubview:Select];
        [self.view addSubview:Datepicker];
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
}

-(void)DateSelect:(UIButton*)sender {
    [Datepicker removeFromSuperview];
    [self timeValidation];

}

-(void)DateCancel:(UIButton*)sender {
    [Datepicker removeFromSuperview];
}

-(void)DatePickerDateChange:(UIButton*)sender {
    @try {
        NSDateFormatter *dateFormat=[[NSDateFormatter alloc]init];
        dateFormat.dateStyle=NSDateFormatterMediumStyle;
        [dateFormat setDateFormat:@"yyyy-MM-dd"];
        NSString *str=[NSString stringWithFormat:@"%@",[dateFormat  stringFromDate:DatePicker.date]];
        Datelabel.text = str;
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
}

#pragma mark -TimePicker

-(void)selectTimeBtn {
    @try {
        Timepicker = [[UIView alloc]initWithFrame:CGRectMake(10, 250,350, 400)];
        [Timepicker setBackgroundColor:[UIColor whiteColor]];
        TimePicker =[[UIDatePicker alloc]initWithFrame:CGRectMake(0, 0,300, 200)];
        TimePicker.datePickerMode=UIDatePickerModeTime;
        TimePicker.hidden=NO;
        TimePicker.date=[NSDate date];
        TimePicker.layer.borderColor = [UIColor colorWithRed:240.0/255.0 green:240.0/255.0 blue:240.0/255.0 alpha:1].CGColor;
        [TimePicker addTarget:self action:@selector(TimePickerTimeChange:) forControlEvents:UIControlEventValueChanged];
        TimePicker.layer.borderWidth = 1;
        TimePicker.backgroundColor = [UIColor whiteColor];
        TimePicker.layer.masksToBounds = YES;
        TimePicker.layer.cornerRadius = 2;
        NSDateFormatter *dateformatter=[[NSDateFormatter alloc]init];
        [dateformatter setDateFormat:@"HH:mm:ss"];
        [Timepicker addSubview:TimePicker];
        UIButton *Cancel = [[UIButton alloc]initWithFrame:CGRectMake(0, 210, 150, 35)];
        [Cancel setTitle:@"Cancel" forState:UIControlStateNormal];
        [Cancel addTarget:self action:@selector(TimeCancel:) forControlEvents:UIControlEventTouchUpInside];
        [Cancel setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
        [Cancel setBackgroundColor:[UIColor whiteColor]];
        Cancel.layer.borderColor = [UIColor colorWithRed:240.0/255.0 green:240.0/255.0 blue:240.0/255.0 alpha:1].CGColor ;
        Cancel.layer.borderWidth = 1;
        Cancel.backgroundColor = [UIColor whiteColor];
        Cancel.layer.masksToBounds = YES;
        Cancel.layer.cornerRadius = 2;
        [Timepicker addSubview:Cancel];
        UIButton *Select = [[UIButton alloc]initWithFrame:CGRectMake(150, 210, 150, 35)];
        [Select setTitle:@"Select" forState:UIControlStateNormal];
        [Select addTarget:self action:@selector(TimeSelect:) forControlEvents:UIControlEventTouchUpInside];
        [Select setTitleColor:[UIColor blueColor] forState:UIControlStateNormal];
        [Select setBackgroundColor:[UIColor whiteColor]];
        Select.layer.borderColor = [UIColor colorWithRed:240.0/255.0 green:240.0/255.0 blue:240.0/255.0 alpha:1].CGColor;
        Select.layer.borderWidth = 1;
        Select.backgroundColor = [UIColor whiteColor];
        Select.layer.masksToBounds = YES;
        Select.layer.cornerRadius = 2;
        [Timepicker addSubview:Select];
        [self.view addSubview:Timepicker];
        
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
}

-(void)TimeCancel:(UIButton*)sender {
    [Timepicker removeFromSuperview];
}

-(void)TimeSelect:(UIButton*)sender {
    [Timepicker removeFromSuperview];
    
    [self timeValidation];
    
    
}

-(void)TimePickerTimeChange:(UIButton*)sender {
    @try {
        NSDateFormatter *dateFormat=[[NSDateFormatter alloc]init];
        dateFormat.dateStyle=UIDatePickerModeTime;
        
        [dateFormat setDateFormat:@"HH:mm:ss"];
        NSString *str1=[NSString stringWithFormat:@"%@",[dateFormat  stringFromDate:TimePicker.date]];
        
        Timelabel.text = str1;
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
}

-(void)timeValidation
{
    NSString *selectedDateTime = [NSString stringWithFormat:@"%@ %@",Datelabel.text,Timelabel.text];
    
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
    NSTimeZone *gmt = [NSTimeZone timeZoneWithAbbreviation:@"UTC"];
    [dateFormatter setTimeZone:gmt];
    mFinalDate = [dateFormatter dateFromString:selectedDateTime];
    NSDate  *selectdat = [dateFormatter dateFromString:mDateTime];
    
    if (![[Preferences GetSharedInstance]timeValidatiostring:selectdat endDate:mFinalDate]) {
        NSArray *arrofTime = [mDateTime componentsSeparatedByString:@" "];
        Datelabel.text = [arrofTime objectAtIndex:0];
        Timelabel.text = [arrofTime objectAtIndex:1];
        [self showAlertPop:@"Date Time should be greater than current date" expObj:nil];
        
    }
    
}


#pragma mark - UISearchbar Delegate

-(void)getOffertype
{
    
    @try {
        
        offertypeAlert=[[CustomIOSAlertView alloc] init];
        UIView  *alertView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 300, 400)];
        [offertypeAlert setContainerView:alertView];
        [offertypeAlert setButtonTitles:[NSMutableArray arrayWithObjects:@"", nil]];
        
        [offertypeAlert setDelegate:self];
        
        
        // You may use a Block, rather than a delegate.
        [offertypeAlert setOnButtonTouchUpInside:^(CustomIOSAlertView *alertView, int buttonIndex) {
            NSLog(@"Block: Button at position %d is clicked on alertView %d.", buttonIndex, (int)[alertView tag]);
            [alertView close];
        }];
        
        [offertypeAlert setUseMotionEffects:true];
        
        UIButton *cancel = [[UIButton alloc]initWithFrame:CGRectMake(275, 0, 20, 20)];
        
        [cancel setImage:[UIImage imageNamed:@"ic_close"] forState:UIControlStateNormal];
        [cancel addTarget:self action:@selector(cancel:) forControlEvents:UIControlEventTouchUpInside];
        
        offerTypeSearch = [[UISearchBar alloc]initWithFrame:CGRectMake(0, 20, alertView.frame.size.width, 40)];
        offerTypeSearch.delegate= self;
        offerTypeSearch.backgroundColor= [UIColor colorWithRed:198.0/256.0 green:198.0/256.0 blue:198.0/256.0 alpha:1];
        
        typetableView.frame = CGRectMake(0, 60, 300, 380);
        [alertView addSubview:typetableView];
        typetableView.hidden= NO;
        [alertView addSubview: offerTypeSearch];
        [alertView addSubview:cancel];
        
        [offertypeAlert show];
        offertypeAlert.tag = 2;
        
        
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error in Data parsing." expObj:exception];
    } @finally {
        
    }
    
}

-(void)cancel:(UIButton*)sender
{
    [offertypeAlert close];
}

- (void)searchBarTextDidBeginEditing:(UISearchBar *)searchBar {
    isSearching = YES;
}

- (void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)seachtext {
    NSLog(@"Text change - %d",isSearching);
    
    //Remove all objects first.
    // [filteredContentList removeAllObjects];
    
    if([seachtext length] != 0) {
        isSearching = YES;
        [self seachOffer:seachtext];
    }
    else if([seachtext length]==0)
    {
        GetSubCat = getSubCategory;
        [typetableView reloadData];
    }
    else {
        isSearching = NO;
    }
    // [self.tblContentList reloadData];
}

- (void)seachOffer:(NSString *)substring {
    @try {
        // Put anything that starts with this substring into the autocompleteUrls array
        // The items in this array is what will show up in the table view
        NSPredicate *predicate = [NSPredicate predicateWithFormat:@"SELF contains [cd] %@", substring];
        results = [searchString filteredArrayUsingPredicate:predicate];
        if ([results count]!=0) {
            
            NSMutableArray *array = [[NSMutableArray alloc]init];
            
            
            for (int i=0; i<[results count]; i++) {
                NSString  *str= [results objectAtIndex:i];
                
                for (int j=0; j<[GetSubCat count]; j++) {
                    NSString *str2 = [[GetSubCat objectAtIndex:j]  valueForKey:@"TypeName"];
                    if ([str isEqualToString:str2]) {
                        [array addObject:[GetSubCat objectAtIndex:j]];
                    }
                }
                
            }
            
            NSOrderedSet *orderedSet = [NSOrderedSet orderedSetWithArray:array];
            GetSubCat = [orderedSet mutableCopy];
            
            
            
            [typetableView reloadData];
            
        }
        //[autoComplete reloadData];
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
}

- (void)searchBarSearchButtonClicked :(UISearchBar *)searchBar {
    NSLog(@"Search Clicked");
    
    [searchBar resignFirstResponder];
    //[searchBar setHidden:YES];
    //[checkview setHidden:NO];
    //[self searchTableList];
}


-(void)publicCheck:(UIPinchGestureRecognizer *)recognizer{
    UIImage *avalbleImage =nil;
    CGSize siz =CGSizeMake(22  , 22);
    OppForKey= @"1";
    avalbleImage = [UIImage imageNamed:@"check.png"];
    avalbleImage=   [mTimeCalculator image:avalbleImage scaledToSize:siz];
    publicCheck.image =  [avalbleImage imageWithTint:[UIColor darkTextColor]];
    avalbleImage = [UIImage imageNamed:@"uncheck.png"];
    avalbleImage=   [mTimeCalculator image:avalbleImage scaledToSize:siz];
    CustomersCheck.image =  [avalbleImage imageWithTint:[UIColor clearColor]];
     self.myCircleCheck.image =  [avalbleImage imageWithTint:[UIColor clearColor]];
     [self.CustomerCnt setHidden:YES];
}


-(void)ChkSendSMS:(UIPinchGestureRecognizer *)recognizer
{
    UIImage *avalbleImage =nil;
    CGSize siz =CGSizeMake(22  , 22);
    if ([SendSMSKey isEqualToString:@""]) {
        SendSMSKey = @"1";
        avalbleImage = [UIImage imageNamed:@"check.png"];
        avalbleImage=   [mTimeCalculator image:avalbleImage scaledToSize:siz];
        self.chkSendSMS.image =  [avalbleImage imageWithTint:[UIColor darkTextColor]];
        
    }
    else if([SendSMSKey isEqualToString:@"1"])
    {
        SendSMSKey = @"";
        avalbleImage = [UIImage imageNamed:@"uncheck.png"];
        avalbleImage=   [mTimeCalculator image:avalbleImage scaledToSize:siz];
        self.chkSendSMS.image =  [avalbleImage imageWithTint:[UIColor clearColor]];
    }
    
    //    SendSMSKey= @"1";
    //    avalbleImage = [UIImage imageNamed:@"check.png"];
    //    avalbleImage=   [mTimeCalculator image:avalbleImage scaledToSize:siz];
    //    self.chkSendSMS.image =  [avalbleImage imageWithTint:[UIColor darkTextColor]];
    //    avalbleImage = [UIImage imageNamed:@"uncheck.png"];
    //    avalbleImage=   [mTimeCalculator image:avalbleImage scaledToSize:siz];
    //    CustomersCheck.image =  [avalbleImage imageWithTint:[UIColor clearColor]];
    //    publicCheck.image =  [avalbleImage imageWithTint:[UIColor clearColor]];
    //    [self.CustomerCnt setHidden:YES];
    
}



-(void)CustomersCheck:(UIPinchGestureRecognizer *)recognizer{
    UIImage *avalbleImage =nil;
    CGSize siz =CGSizeMake(22  , 22);
    OppForKey= @"2";
    avalbleImage = [UIImage imageNamed:@"check.png"];
    avalbleImage=   [mTimeCalculator image:avalbleImage scaledToSize:siz];
    CustomersCheck.image =  [avalbleImage imageWithTint:[UIColor darkTextColor]];
    avalbleImage = [UIImage imageNamed:@"uncheck.png"];
    avalbleImage=   [mTimeCalculator image:avalbleImage scaledToSize:siz];
    publicCheck.image =  [avalbleImage imageWithTint:[UIColor clearColor]];
     self.myCircleCheck.image =  [avalbleImage imageWithTint:[UIColor clearColor]];
     [self.CustomerCnt setHidden:NO];
    self.sendSMSToCustomerlabel.text= @"SMS your Customers about this?";
}


-(void)MyCircleNavGesture:(UIPinchGestureRecognizer *)recognizer{
    UIImage *avalbleImage =nil;
    CGSize siz =CGSizeMake(22  , 22);
    OppForKey= @"3";
    avalbleImage = [UIImage imageNamed:@"check.png"];
    avalbleImage=   [mTimeCalculator image:avalbleImage scaledToSize:siz];
    self.myCircleCheck.image =  [avalbleImage imageWithTint:[UIColor darkTextColor]];
    avalbleImage = [UIImage imageNamed:@"uncheck.png"];
    avalbleImage=   [mTimeCalculator image:avalbleImage scaledToSize:siz];
    CustomersCheck.image =  [avalbleImage imageWithTint:[UIColor clearColor]];
    publicCheck.image =  [avalbleImage imageWithTint:[UIColor clearColor]];
    [self.CustomerCnt setHidden:YES];
    self.sendSMSToCustomerlabel.text= @"SMS your Business Circle about this?";
}


- (void)messageComposeViewController:(MFMessageComposeViewController *)controller didFinishWithResult:(MessageComposeResult)result
{
    
    switch (result)
    {
        case MessageComposeResultSent:
            
            
            
            break;
        case MessageComposeResultFailed:
            
            
            
            break;
        case MessageComposeResultCancelled:
            
            
            
            break;
            
        default:
            
            break;
    }
    
    [self dismissViewControllerAnimated:YES completion:nil];
    
    
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"Right Place Right Time"
                                                                   message:@"Your offer is posted successfully!"
                                                            preferredStyle:UIAlertControllerStyleAlert];
    
    UIAlertAction* defaultAction = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault
                                                          handler:^(UIAlertAction * action) {
                                                              
                                                              //  [mPref setObject:remainingTime forKey:@"TimeSlot"];
                                                              Retailer_Offer * mOpportunity_list = [[ Retailer_Offer alloc] initWithNibName:RETAILER bundle:nil];
                                                              [self presentViewController:mOpportunity_list animated:YES completion:nil];
                                                              
                                                          }];
    
    [alert addAction:defaultAction];
    
    [self presentViewController:alert animated:YES completion:nil];
    
    
    //   Retailer_Offer * mOpportunity_list = [[ Retailer_Offer alloc] initWithNibName:RETAILER bundle:nil];
    //   [self presentViewController:mOpportunity_list animated:YES completion:nil];
    
}



-(void)setLabelBorder:(UILabel*)Label
{
    Label.layer.cornerRadius = Label.frame.size.width/2;
    Label.layer.borderColor=[UIColor blackColor].CGColor;
    Label.layer.borderWidth = 1.0;
    Label.layer.masksToBounds = YES;
}

-(IBAction)ContinueBtn:(id)sender
{
    
    if (self.continueBtn.tag==4) {
        [self PostOpportunity];
    }
    else
    {
        if(PageCnt==1)
        {
            
            
            PageCnt=2;
            self.View1.hidden= YES;
            self.View2.hidden= NO;
            self.View3.hidden= YES;
            self.View4.hidden= YES;
            
            
            
        }
        else  if(PageCnt==2)
        {
            PageCnt=3;
            self.View1.hidden= YES;
            self.View2.hidden= YES;
            self.View3.hidden= NO;
            self.View4.hidden= YES;
            
        }
        else  if(PageCnt==3)
        {
            
            
            PageCnt=4;
            self.View1.hidden= YES;
            self.View2.hidden= YES;
            self.View3.hidden= YES;
            self.View4.hidden= NO;
            [self.continueBtn setTitle:@"Submit" forState:UIControlStateNormal];
            [self.NextBtnImage setImage:[UIImage imageNamed:@"submit.png"]];
            [self.continueBtn setTitleColor:[UIColor colorWithRed:89.0/256.0 green:165.0/256.0 blue:44.0/256.0 alpha:1] forState:UIControlStateNormal];
         
            
            self.continueBtn.tag=4;
            
        }
        else  if(PageCnt==4)
        {
            
            PageCnt=4;
            
            self.View1.hidden= YES;
            self.View2.hidden= YES;
            self.View3.hidden= YES;
            self.View4.hidden= NO;
            
        }
    }
    
}

-(IBAction)BackBtn:(UIButton *)BackBtn
{
    
    [self.continueBtn setTitle:@"Next" forState:UIControlStateNormal];
    [self.NextBtnImage setImage:[UIImage imageNamed:@"next.png"]];
    [self.continueBtn setTitleColor:[UIColor colorWithRed:3.0/256.0 green:156.0/256.0 blue:213.0/256.0 alpha:1] forState:UIControlStateNormal];
    if (PageCnt!=1) {
        
        PageCnt= PageCnt-1;
        self.continueBtn.tag=PageCnt;
    }
    if(PageCnt==1)
    {
        
        
        // PageCnt=2;
        self.View1.hidden= NO;
        self.View2.hidden= YES;
        self.View3.hidden= YES;
        self.View4.hidden= YES;
        
    }
    else  if(PageCnt==2)
    {
        
        //   PageCnt=3;
        self.View1.hidden= YES;
        self.View2.hidden= NO;
        self.View3.hidden= YES;
        self.View4.hidden= YES;
        
        
        
    }
    else  if(PageCnt==3)
    {
        
        // PageCnt=4;
        self.View1.hidden= YES;
        self.View2.hidden= YES;
        self.View3.hidden= NO;
        self.View4.hidden= YES;
    }
    
    
}





@end
