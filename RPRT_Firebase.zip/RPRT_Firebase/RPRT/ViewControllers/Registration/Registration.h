//
//  Registration.h
//  RPRT
//
//  Created by sravanthi Gumma on 08/01/16.
//  Copyright © 2016 DevpointSolutions. All rights reserved.
//



#import <UIKit/UIKit.h>
#import "Preferences.h"

@interface Registration : UIViewController
{
    NSString *encodecImage;
    NSDictionary *RegisterdObj;
     UIActivityIndicatorView *spinner;
}

@property (strong,nonatomic) IBOutlet UITextField *uName;
@property (strong,nonatomic) IBOutlet UITextField *password;
@property (strong,nonatomic) IBOutlet UITextField *emailID;
@property (strong,nonatomic) IBOutlet UITextField *mobileNumber;
@property (strong,nonatomic) IBOutlet UITextField *confirmPassword;
@property (strong,nonatomic) IBOutlet UIImageView *regUserImgView;


-(IBAction)hideKeyBoardUserName:(id)sender;
-(IBAction)hideKeyBoardEmailID:(id)sender;
-(IBAction)hideKeyBoardMobileNumber:(id)sender;
-(IBAction)hideKeyBoardPassWord:(id)sender;
-(IBAction)hideKeyBoardUserConfirmPassword:(id)sender;
-(IBAction)createAccount:(id)sender;


@property (weak, nonatomic) IBOutlet UIView *RegistationView;
@property (weak, nonatomic) IBOutlet UIView *UserNameView;
@property (weak, nonatomic) IBOutlet UIView *EmailView;
@property (weak, nonatomic) IBOutlet UIView *MobileNumberView;
@property (weak, nonatomic) IBOutlet UIView *PasswordView;
@property (weak, nonatomic) IBOutlet UIView *PassWordConfirmView;
@property (weak, nonatomic) IBOutlet UIView *NotificationView;
@property (weak, nonatomic) IBOutlet UIView *addressView;
@property (weak, nonatomic) IBOutlet UIView *radiusView;

@property(strong,nonatomic) NSDictionary *RegisteredObject;

@property(weak,nonatomic) IBOutlet UIView *toolBarView;
@property (weak,nonatomic)IBOutlet UIButton *Settings;
@property (weak,nonatomic)  IBOutlet UIButton *btnRegister;

@property (strong,nonatomic) IBOutlet UITextField *typelbl;
@property (strong,nonatomic) IBOutlet UITextField *conatctPersonName;
@property (weak, nonatomic) IBOutlet UIView *contactpersonView;


-(IBAction)selectCategory:(id)sender;
-(IBAction)seletcRadius:(id)sender;
-(IBAction)selectlocation:(id)sender;

@property(strong,nonatomic) UITableView *categoryTable;

@property(weak,nonatomic)IBOutlet UIButton *categoryBtn;
@property (weak,nonatomic) IBOutlet UITextField *addressField;
@property(weak,nonatomic)IBOutlet UIButton *radiusBtn;
@property (weak,nonatomic) IBOutlet UISwitch *notificationSwitch;

@property(weak,nonatomic) IBOutlet UIButton *cameraBtn;


@end
