//
//  MyBlockCell.h
//  RPRT
//
//  Created by sravanthi Gumma on 24/03/16.
//  Copyright © 2016 DevpointSolutions. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MyBlockCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UIImageView *UserImage;
@property (weak, nonatomic) IBOutlet UIImageView *QRimage;
@property (weak, nonatomic) IBOutlet UILabel *VendorName;
@property (weak, nonatomic) IBOutlet UILabel *VendorAddress;
@property (weak, nonatomic) IBOutlet UILabel *OfferTimer;
@property (weak, nonatomic) IBOutlet UILabel *KeyCode;
@property (weak, nonatomic) IBOutlet UILabel *blockedTime;
@property (weak, nonatomic) IBOutlet UILabel *blockstatus;
@property (weak,nonatomic) IBOutlet UIView *customview;


@end
