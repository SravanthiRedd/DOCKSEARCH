//
//  MyBlockCell.m
//  RPRT
//
//  Created by sravanthi Gumma on 24/03/16.
//  Copyright © 2016 DevpointSolutions. All rights reserved.
//

#import "MyBlockCell.h"

@implementation MyBlockCell
//static CGFloat radius = 2;
@synthesize VendorAddress = VendorAddress;
@synthesize VendorName = VendorName;
@synthesize UserImage = UserImage;
@synthesize OfferTimer = OfferTimer;
@synthesize KeyCode = KeyCode;
@synthesize  customview = customview;
@synthesize  blockedTime = blockedTime;
@synthesize blockstatus = blockstatus;
@synthesize QRimage= QRimage;

- (void)awakeFromNib {
    
 
    // Initialization code
}


-(void)layoutSubviews{
    
   // self.layer.cornerRadius = 45/2;
//    UIBezierPath *shadowPath = [UIBezierPath
//                                bezierPathWithRoundedRect: self.bounds
//                                cornerRadius: radius];
//    self.layer.masksToBounds = false;
//    self.layer.shadowColor = [UIColor blackColor].CGColor;
//    self.layer.shadowOffset = CGSizeMake(0, 4);
//    self.layer.shadowOpacity = 0.2;
//    self.layer.shadowPath = shadowPath.CGPath;
//    
//    self.customview.layer.cornerRadius=5;
    
    
    
    // self.layer.shadowColor = [UIColor lightGrayColor].CGColor;
    //self.layer.shadowOffset = CGSizeMake(0, 4);
    // self.layer.shadowOpacity = 1;
    //  self.layer.shadowRadius = 1.0;
    
    self.customview.layer.borderColor = [UIColor colorWithRed:198.0/256.0 green:198.0/256.0 blue:198.0/256.0 alpha:1].CGColor;
    self.customview.layer.borderWidth=1;
    
    
    
    self.UserImage.layer.cornerRadius = self.UserImage.frame.size.width/2;
    self.UserImage.layer.masksToBounds = YES;
    
    
//    self.layer.cornerRadius = 45/2;
//    UIBezierPath *shadowPath = [UIBezierPath
//                                bezierPathWithRoundedRect: self.bounds
//                                cornerRadius: radius];
//    
//    
//    self.layer.masksToBounds = false;
//    self.layer.shadowColor = [UIColor blackColor].CGColor;
//    self.layer.shadowOffset = CGSizeMake(0, 1);
//    self.layer.shadowOpacity = 0.2;
//    self.layer.shadowPath = shadowPath.CGPath;
//    
//    self.customview.layer.cornerRadius=5;
//    
//    self.UserImage.layer.cornerRadius = self.UserImage.frame.size.width/2;
//    self.UserImage.layer.masksToBounds = YES;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
