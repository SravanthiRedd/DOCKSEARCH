//
//  Retailer_Offer.h
//  RPRT
//
//  Created by sravanthi Gumma on 08/01/16.
//  Copyright © 2016 DevpointSolutions. All rights reserved.
//



#import "VendorCell.h"
#import "UserBlocks.h"

@interface Retailer_Offer : UIViewController<UITableViewDataSource,UITableViewDelegate,UISearchBarDelegate,UITabBarDelegate>
@property (nonatomic, retain) IBOutlet UITableView *TableView;

@property(weak,nonatomic) IBOutlet UIView *toolBarView;

@property(strong,nonatomic) IBOutlet UITabBar *tabBarView;


@property(strong,nonatomic) IBOutlet UISearchBar *searchBar;


@end
