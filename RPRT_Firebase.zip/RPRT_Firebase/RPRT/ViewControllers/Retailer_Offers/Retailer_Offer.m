//
//  Retailer_Offer.m
//  RPRT
//
//  Created by sravanthi Gumma on 08/01/16.
//  Copyright © 2016 DevpointSolutions. All rights reserved.
//

#import "Retailer_Offer.h"
#import "EditOpportunity.h"
#import "NearBy_Users.h"
#import "MyBlockCell.h"
#import "UIImage+MDQRCode.h"
#import "TimeCalculator.h"
#import "EditOpp.h"
#import <MessageUI/MessageUI.h>

@interface Retailer_Offer ()<CustomIOSAlertViewDelegate,MFMessageComposeViewControllerDelegate,MFMailComposeViewControllerDelegate>
{
    UIView *contentView;
    NSMutableArray*RetailerOpportunities;
    NSString *ButtonLbl;
    NSMutableArray *GetRetailerOpp;
    UIButton *LeftMenu;
    NSUserDefaults *mPref;
    UIActivityIndicatorView *spinner;
    MZTimerLabel *TimeCoutDown;
    UIButton *blockBtn;
    CustomIOSAlertView *ImageAlert;
    NSUserDefaults *prefss ;
    NSMutableArray *searchString;
    NSArray *results;
    NSMutableArray *totaloffer;
    NSMutableDictionary *editdictionary;
    Web_Services *mWebService;
    BOOL isSearching;
    NSMutableArray *GetRetailer;
    NSMutableArray   *GetBlocks;
    NSMutableArray   *GetBlocksArray;
    TimeCalculator *mConverter;
    NSString *ActionKey;
    UILabel *lbl;
  
    
}
@property (nonatomic, copy)  NSDictionary *setCache;
@end

@implementation Retailer_Offer
@synthesize TableView,toolBarView,searchBar,tabBarView;
- (void)viewDidLoad {
    @try {
       
    [super viewDidLoad];
            mPref = [NSUserDefaults standardUserDefaults];
        GetRetailerOpp = [[NSMutableArray alloc]init];
        totaloffer = [[NSMutableArray alloc]init];
        mWebService = [Web_Services GetSharedInstance];
        mConverter = [TimeCalculator GetSharedInstance];
        ActionKey = @"";
        [self loadToolbar];
        //[self.view setBackgroundColor:[UIColor whiteColor]];
    //load setting button
     self.setCache = [[NSMutableDictionary alloc] init];
       // tabBarView = [[UITabBar alloc]init];
      //  tabBarView.delegate= self;
        
        NSMutableArray *tabBarItems = [[NSMutableArray alloc] init];
        UITabBarItem *activityTab =  [[UITabBarItem alloc] initWithTitle:@"My Activities" image:[UIImage imageNamed:@"myactivities_.png"] tag:1];
          UITabBarItem *myBlockTab =  [[UITabBarItem alloc] initWithTitle:@"My Reservations" image:[UIImage imageNamed:@"myblocks_drw.png"] tag:2];
        [tabBarItems addObject:activityTab];
        [tabBarItems addObject:myBlockTab];
        tabBarView.items = tabBarItems;
        tabBarView.selectedItem = [tabBarItems objectAtIndex:0];
      //  NSUInteger *count = [GetBlocks count];
       // [[tabBarItems objectAtIndex:1] setBadge1];
        
       
        lbl = [[UILabel alloc]initWithFrame:CGRectMake(100, 200, 150, 25)];
        lbl.text =@"No Record Found!!";
        [self.view addSubview:lbl];
        
    searchString = [[NSMutableArray alloc]init];
     prefss = [NSUserDefaults standardUserDefaults];
    NSString *RegisterID =   [prefss objectForKey:USERREGISTERID];
      [self GetVendorOpportunities:RegisterID];
        [self GetUserBlock:RegisterID];
     [[tabBarView.items objectAtIndex:1] setBadgeValue:[NSString stringWithFormat:@"%lu",(unsigned long)[GetBlocks count]]];
  
        if([GetRetailer count]==0)
        {
            lbl.hidden= NO;
        }
        else
        {
            lbl.hidden= YES;
        }
        
        GetBlocks=nil;
        
        
    [searchBar setShowsCancelButton:NO animated:YES];
       
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
        
    } @finally {
        
    }

       // Do any additional setup after loading the view from its nib.
}



-(void)tabBar:(UITabBar *)tabBar didSelectItem:(UITabBarItem *)item
{
    
    
    
    if(item.tag==1)
    {
        GetBlocks= nil;
        GetRetailerOpp = GetRetailer;
      
        if([GetRetailerOpp count]==0)
        {
            lbl.hidden= NO;
           
        }
        
        
        [TableView reloadData];
     
    }
    else  if(item.tag==2)
    {
        lbl.hidden= YES;
        
        GetRetailerOpp= nil;
        GetBlocks = GetBlocksArray;
        [TableView reloadData];
    
    }
}




-(void)loadToolbar
{
    @try {
        
    
    
        NSData *colorData= [mPref valueForKey:@"COLOR"];
if (colorData == nil) {
            toolBarView.backgroundColor= [UIColor colorWithRed:0/256.0 green:186.0/256.0 blue:210/256.0 alpha:1];
        }
        else
          toolBarView.backgroundColor = [NSKeyedUnarchiver unarchiveObjectWithData:colorData];
        
        
    
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }

}
-(void)GetUserBlock:(NSString*)RegisterID
{
     GetBlocksArray = [mWebService GetOpportinityReview:RegisterID MethodName:GETRESERVEDOPPORTUNITIESBYUSERID];
    GetBlocks= GetBlocksArray;
    
}

-(void)GetVendorOpportunities:(NSString*)LoginRegisterId
{
    @try {
        
 GetRetailer = [mWebService GetOpportinityByUserID:LoginRegisterId];
        //GetRetailerOpp = [NSMutableArray arrayWithObjects:GetRetailer, nil];
        if (GetRetailer.count==0) {
            
            
        }
        else{
            for (int i=0; i<[GetRetailer count]; i++) {
               
            [searchString addObject:[[GetRetailer objectAtIndex:i] valueForKey:@"OpportunityName"]];
            }
            totaloffer =GetRetailer;
            GetRetailerOpp =GetRetailer;
        }
        
        
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
        
    } @finally {
        
    }

    
    //Review =[mWebService GetOpportinityReview:OfferId MethodName:GETFEEDBACKBYOPPORTUNITYID];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



#pragma mark -UITableViewDataSource

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    if (GetRetailerOpp!=nil) {
        return [GetRetailerOpp count];

    }
    else if (GetBlocks!=nil) {
        return [GetBlocks count];
        
    }
    
    else return 1;
   }

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    
//    if (GetBlocks!=nil) {
//        return [GetBlocks count];
//        
//    }
     return 1;
    
    
   // return 1;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    if (GetBlocks!=nil) {
       return 173;
        
    }
    else return 185;
    
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    //this is the space
    return 2;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    @try {
       
        if (GetBlocks==nil && [GetRetailerOpp count]>0) {
               static NSString *simpleTableIdentifier = @"VendorCell";
            VendorCell *cell = (VendorCell *)[tableView dequeueReusableCellWithIdentifier:simpleTableIdentifier];
            if (cell == nil)
            {
                NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"VendorCell" owner:self options:nil];
                cell = [nib objectAtIndex:0];
            }
            
            cell.selectionStyle = UITableViewCellSelectionStyleNone;
            cell.backgroundColor = [UIColor lightGrayColor];
            
            cell.layer.cornerRadius = 45/2;
            
            
            cell.selectionStyle = UITableViewCellSelectionStyleNone;
            cell.backgroundColor = [UIColor clearColor];
            //cell.view1.layer.borderColor = [[UIColor lightGrayColor] CGColor];
            cell.layer.cornerRadius = 45/2;
            
            
            NSDictionary *OpportunityDats =[GetRetailerOpp  objectAtIndex: indexPath.section];
            
            
            cell.opportunity.text =[NSString stringWithFormat:@"%@",[OpportunityDats valueForKey:@"OpportunityName"]];
            cell.description.text = [NSString stringWithFormat:@"%@",[OpportunityDats valueForKey:@"OpportunityDescription"]];
            cell.Location.text = [NSString stringWithFormat:@"%@",[OpportunityDats valueForKey:@"AreaName"]];
            cell.categoryType.text = [NSString stringWithFormat:@"%@",[OpportunityDats valueForKey:@"SubCategory"]];
            
            [cell.shareBtn addTarget:self action:@selector(shareData:) forControlEvents:UIControlEventTouchUpInside];
            cell.shareBtn.imageView.alpha=0.5;
            
            
            NSMutableAttributedString *actual=[[NSMutableAttributedString alloc]initWithString:[NSString stringWithFormat:@"%@",[OpportunityDats valueForKey:@"ActualPrice"]]];
            [actual addAttribute:NSStrikethroughStyleAttributeName value:[NSNumber numberWithInt:2] range:NSMakeRange(0,[actual length])];
            
            
            if ([[OpportunityDats valueForKey:@"Category"] isEqualToString:@"Banking & Financial"] || [[OpportunityDats valueForKey:@"Category"] isEqualToString:@"Jobs"]||
                [[OpportunityDats valueForKey:@"Category"] isEqualToString:@"Sports"]||
                [[OpportunityDats valueForKey:@"Category"] isEqualToString:MEETINGS]||
                [[OpportunityDats valueForKey:@"Category"] isEqualToString:PROFESSIONALHELP]) {
                cell.PriceLabel.text= @"";
                cell.DeliveryLabel.text = @"";
                
            }
            else
            {
                if ([[OpportunityDats valueForKey:@"Category"] isEqualToString:SALES]||
                    [[OpportunityDats valueForKey:@"Category"] isEqualToString:FOOD]
                    
                    ) {
                    
                    cell.PriceLabel.text= @"Price :";
                    cell.DeliveryLabel.text = @"Delivery :";
                    
                    cell.actualprice.attributedText = actual;
                    
                    cell.price.text =[NSString stringWithFormat:@"%@",[OpportunityDats valueForKey:@"Price"]];
                    cell.deliveryLbl.text = @"NA";
                    
                    // cell.deliveryLbl.textColor= [UIColor colorWithRed:204.0/256.0 green:40.0/256.0 blue:63.0/256.0 alpha:1];;
                    cell.price.textColor= [UIColor colorWithRed:204.0/256.0 green:40.0/256.0 blue:63.0/256.0 alpha:1];;
                    cell.categoryType.textColor = [UIColor colorWithRed:204.0/256.0 green:40.0/256.0 blue:63.0/256.0 alpha:1];;
                    
                }
                else if ([[OpportunityDats valueForKey:@"Category"] isEqualToString:REALESTATE])
                { cell.PriceLabel.text= @"Value";
                    cell.price.text =[NSString stringWithFormat:@"%@",[OpportunityDats valueForKey:@"Price"]];
                }
                else if ( [[OpportunityDats valueForKey:@"Category"] isEqualToString:TRAVELS])
                {
                    cell.PriceLabel.text = @"Price :";
                    cell.price.text =[NSString stringWithFormat:@"%@",[OpportunityDats valueForKey:@"Price"]];
                }
            }
            
            cell.Avialable.text =[NSString stringWithFormat:@"Available:%@",[OpportunityDats valueForKey:@"Available"]];
            
            
            
            cell.resrveCNT.text =[NSString stringWithFormat:@"Reservations %@",[OpportunityDats objectForKey:@"Reservations"]] ;
            
            
            cell.Avialable.text =[NSString stringWithFormat:@"Available:%@",[OpportunityDats valueForKey:@"Available"]];
            
            NSString *imageName = [NSString stringWithFormat:@"%@",[OpportunityDats valueForKey:@"PhotoName"]];;
            NSArray *imageAry = [imageName componentsSeparatedByString:@","];
            NSString *ImageURL = [NSString stringWithFormat:@"%@%@",baseImageURL, [imageAry objectAtIndex:0]];
            
            if ([[imageAry objectAtIndex:0] isEqualToString:@""]) {
                
                imageName = [NSString stringWithFormat:@"%@",[OpportunityDats valueForKey:@"CategoryImage"]];;
                ImageURL = [NSString stringWithFormat:@"%@%@",baseImageURL, imageName];
                
                NSURL *imageURL = [NSURL URLWithString:ImageURL];
                NSString *key = [ImageURL MD5Hash];
                NSData *getData = [FTWCache objectForKey:key];
                if (getData) {
                    UIImage *image = [UIImage imageWithData:getData];
                    cell.OpportunityImage.image  = image;
                }
                else {
                    cell.OpportunityImage.image  = [UIImage imageNamed:@"img_def"];
                    dispatch_queue_t queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_HIGH, 0ul);
                    dispatch_async(queue, ^{
                        NSData *newData = [NSData dataWithContentsOfURL:imageURL];
                        [FTWCache setObject:newData forKey:key];
                        UIImage *image = [UIImage imageWithData:newData];
                        dispatch_sync(dispatch_get_main_queue(), ^{
                            cell.OpportunityImage.image  = image;
                            
                        });
                    });
                }
                
            }
            else {
                
                NSURL *imageURL = [NSURL URLWithString:ImageURL];
                NSString *key = [ImageURL MD5Hash];
                NSData *getData = [FTWCache objectForKey:key];
                if (getData) {
                    UIImage *image = [UIImage imageWithData:getData];
                    cell.OpportunityImage.image  = image;
                }
                else {
                    cell.OpportunityImage.image  = [UIImage imageNamed:@"img_def"];
                    dispatch_queue_t queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_HIGH, 0ul);
                    dispatch_async(queue, ^{
                        NSData *newData = [NSData dataWithContentsOfURL:imageURL];
                        [FTWCache setObject:newData forKey:key];
                        UIImage *image = [UIImage imageWithData:newData];
                        dispatch_sync(dispatch_get_main_queue(), ^{
                            cell.OpportunityImage.image  = image;
                            
                        });
                    });
                }
                
            }
            UITapGestureRecognizer *singleTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(ImageTap:)];
            singleTap.numberOfTapsRequired = 1;
            [cell.OpportunityImage setUserInteractionEnabled:YES];
            [cell.OpportunityImage addGestureRecognizer:singleTap];
            
            
            
            NSString *satrtDate = [NSString stringWithFormat:@"%@",[OpportunityDats valueForKey:@"EndDate"]];
            
            NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
            [dateFormatter setDateFormat:@"yyyy-MM-dd'T'HH:mm:ss"];
            NSTimeZone *gmt = [NSTimeZone timeZoneWithAbbreviation:@"UTC"];
            [dateFormatter setTimeZone:gmt];
            NSDate *date5 = [dateFormatter dateFromString:satrtDate];
            
            NSDictionary *startOffer;
            if (date5!=nil) {
                startOffer= [[Preferences GetSharedInstance]remaningTime:[NSDate date] endDate:date5];
            }
            else{
                
                NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
                [dateFormatter setDateFormat:@"yyyy-MM-dd'T'HH:mm:ss.SSS"];
                
                NSTimeZone *gmt = [NSTimeZone timeZoneWithAbbreviation:@"UTC"];
                [dateFormatter setTimeZone:gmt];
                NSDate *date5 = [dateFormatter dateFromString:satrtDate];
                startOffer= [[Preferences GetSharedInstance]remaningTime:[NSDate date] endDate:date5];
                
            }
            
            
            int Remaingtyime = [[startOffer valueForKey:@"Time"] intValue];
            int hour = [[startOffer valueForKey:@"Hour"] intValue];
            int seconds = [[startOffer valueForKey:@"Seconds"] intValue];
            if (seconds!=0) {
                Remaingtyime = Remaingtyime+(seconds/60);
            }
            if(Remaingtyime!=0 || seconds !=0)
            {
                Remaingtyime = Remaingtyime+(hour*60);
                
                TimeCoutDown = [[MZTimerLabel alloc] initWithLabel:cell.Timer andTimerType:MZTimerLabelTypeTimer];
                [TimeCoutDown setCountDownTime:Remaingtyime*60];
                [TimeCoutDown start];
                
                
                
                
                [cell.blockBtn setImage:[UIImage imageNamed:@"list_cancelbtn.png"] forState:UIControlStateNormal];
                cell.blockBtn.tag= 1;
            }
            else
            {
                cell.Timer.text = @"Offer Expired!!";
                [cell.blockBtn setImage:[UIImage imageNamed:@"lis_restart.png"] forState:UIControlStateNormal];
                cell.blockBtn.tag=2;
                
            }
            
            [cell.blockBtn addTarget:self action:@selector(EditOpp:) forControlEvents:UIControlEventTouchUpInside];
            return cell;

        }
        else if (GetRetailerOpp==nil && [GetBlocks count]>0)
        {
            MyBlockCell *cell = (MyBlockCell *)[tableView dequeueReusableCellWithIdentifier:MYBLOCK];
            if (cell == nil)
            {
                NSArray *nib = [[NSBundle mainBundle] loadNibNamed:MYBLOCK owner:self options:nil];
                cell = [nib objectAtIndex:0];
            }
            //         cell.selectionStyle = UITableViewCellSelectionStyleNone;
            //        cell.backgroundColor = [UIColor clearColor];
            //        cell.layer.cornerRadius = 45/2;
            //        cell.customview.layer.cornerRadius= 45/2;
            //
            //         [cell updateConstraintsIfNeeded];
            
            NSDictionary *dic = [GetBlocks objectAtIndex:indexPath.section];
            cell.VendorName.text =[NSString stringWithFormat:@"%@",[dic valueForKey:@"OpportunityName"]];
            
            cell.blockstatus.text =[NSString stringWithFormat:@"%@",[dic valueForKey:@"BlockText"]];
            
            //RegUserName
            cell.VendorAddress.text = [NSString stringWithFormat:@"%@",[dic valueForKey:@"AreaName"]];
            cell.KeyCode.text = [NSString stringWithFormat:@"%@",[dic valueForKey:@"KeyValue"]];
            
            
            CGFloat imageSize = ceilf(self.view.bounds.size.width * 0.6f);
            UIImageView *imageView = [[UIImageView alloc] initWithFrame:CGRectMake(floorf(self.view.bounds.size.width * 0.5f - imageSize * 0.5f), floorf(self.view.bounds.size.height * 0.5f - imageSize * 0.5f), imageSize, imageSize)];
            
            
            NSArray *imagearr= [[dic valueForKey:@"PhotoName"] componentsSeparatedByString:@","];
            
            
             NSString *imageName = [NSString stringWithFormat:@"%@",[imagearr objectAtIndex:0]];;
            
            if ([[imagearr objectAtIndex:0] isEqualToString:@""]) {
                imageName= [dic valueForKey:@"CategoryImage"];
            }
            
            NSString *ImageURL = [NSString stringWithFormat:@"%@%@",baseImageURL, imageName];
            
            NSURL *imageURL = [NSURL URLWithString:ImageURL];
            NSString *key = [ImageURL MD5Hash];
            NSData *getData = [FTWCache objectForKey:key];
            if (getData) {
                UIImage *image = [UIImage imageWithData:getData];
                cell.UserImage.image  = image;
            }
            else {
                cell.UserImage.image  = [UIImage imageNamed:@"img_def"];
                dispatch_queue_t queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_HIGH, 0ul);
                dispatch_async(queue, ^{
                    NSData *newData = [NSData dataWithContentsOfURL:imageURL];
                    [FTWCache setObject:newData forKey:key];
                    UIImage *image = [UIImage imageWithData:newData];
                    dispatch_sync(dispatch_get_main_queue(), ^{
                        cell.UserImage.image  = image;
                        
                    });
                });
            }
            
            UITapGestureRecognizer *singleTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(ImageTap:)];
            singleTap.numberOfTapsRequired = 1;
            [cell.UserImage setUserInteractionEnabled:YES];
            [cell.UserImage addGestureRecognizer:singleTap];
            
            
            NSString *satrtDate = [NSString stringWithFormat:@"%@",[dic valueForKey:@"EndDate"]];
            
            NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
            [dateFormatter setDateFormat:@"yyyy-MM-dd'T'HH:mm:ss.SSS"];
            NSTimeZone *gmt = [NSTimeZone timeZoneWithAbbreviation:@"UTC"];
            [dateFormatter setTimeZone:gmt];
            NSDate *date5 = [dateFormatter dateFromString:satrtDate];
            
            
            NSDateFormatter *dateFormatter1 = [[NSDateFormatter alloc] init];
            [dateFormatter1 setDateFormat:@"yyyy-MM-dd'T'HH:mm:ss"];
            NSTimeZone *gmt1 = [NSTimeZone timeZoneWithAbbreviation:@"GMT"];
            [dateFormatter setTimeZone:gmt1];
            NSString *date = [dateFormatter1 stringFromDate:date5];
            
            date  = [date stringByReplacingOccurrencesOfString:@"T" withString:@" "];
            cell.blockedTime.text = date;
            
            
            NSDictionary *startOffer;
            if (date5!=nil) {
                
                // NSString *date =  [NSDate stringForDisplayFromDate:date5];
                
                NSString *str=  [dateFormatter stringFromDate:date5];
                cell.blockedTime.text  =[NSString stringWithFormat:@"%@",[str stringByReplacingOccurrencesOfString:@"T" withString:@" "]];
                
                startOffer= [[Preferences GetSharedInstance]remaningTime:[NSDate date] endDate:date5];
            }
            else{
                
                NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
                [dateFormatter setDateFormat:@"yyyy-MM-dd'T'HH:mm:ss"];
                
                NSTimeZone *gmt = [NSTimeZone timeZoneWithAbbreviation:@"UTC"];
                [dateFormatter setTimeZone:gmt];
                NSDate *date5 = [dateFormatter dateFromString:satrtDate];
                
                
                NSDateFormatter *dateFormatter1 = [[NSDateFormatter alloc] init];
                [dateFormatter1 setDateFormat:@"yyyy-MM-dd'T'HH:mm:ss"];
                NSTimeZone *gmt1 = [NSTimeZone timeZoneWithAbbreviation:@"GMT"];
                [dateFormatter setTimeZone:gmt1];
                NSString *date = [dateFormatter1 stringFromDate:date5];
                
                cell.blockedTime.text  = [date stringByReplacingOccurrencesOfString:@"T" withString:@" "];
                
                
                //            //NSString *str=  [dateFormatter stringFromDate:date5];
                //            cell.blockedTime.text  =[NSString stringWithFormat:@"%@",[str stringByReplacingOccurrencesOfString:@"T" withString:@" "]];
                
                //  cell.blockedTime.text = [NSString stringWithFormat:@"%@",date5];
                
                startOffer= [[Preferences GetSharedInstance]remaningTime:[NSDate date] endDate:date5];
                
            }
            
            
            // NSDictionary *startOffer= [[Preferences alloc]remaningTime:[NSDate date] endDate:date5];
            int remain = [[startOffer valueForKey:@"Time"] intValue];
            int hour = [[startOffer valueForKey:@"Hour"] intValue];
            // Timer.textColor = categoryColor;
            int seconds = [[startOffer valueForKey:@"Seconds"] intValue];
            if (seconds!=0)
                remain = remain+(seconds/60);
            
            if(remain!=0 || seconds !=0)
            {
                remain = remain+(hour*60);
                TimeCoutDown = [[MZTimerLabel alloc] initWithLabel:cell.OfferTimer andTimerType:MZTimerLabelTypeTimer];
                [TimeCoutDown setCountDownTime:remain*60];
                [TimeCoutDown start];
                //PRT,RPRT0662,Expaire,175
                NSString *qrString = [NSString stringWithFormat:@"%@",[dic valueForKey:@"KeyValue"]];
                cell.QRimage.image =[UIImage mdQRCodeForString:qrString size:imageView.bounds.size.width fillColor:[UIColor darkGrayColor]];
                
            }
            else
            {
                
                NSString *qrString =[dic valueForKey:@"KeyValue"];
                
                cell.QRimage.image =[UIImage mdQRCodeForString:qrString size:imageView.bounds.size.width fillColor:[UIColor darkGrayColor]];
                
                cell.OfferTimer.text = @"Expired!!";
            }
            
            
            
            return cell;
        }
        
       } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }

}




#pragma mark -UITableViewDelegate

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    @try {
        
          if (GetBlocks==nil && [GetRetailerOpp count]>0)
          {
      
        spinner = [[UIActivityIndicatorView alloc]
                   initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
        spinner.frame = CGRectMake(0, 0, 320, 560); // CGPointMake(160, 240);
        spinner.color = [UIColor blueColor];
        spinner.backgroundColor = [UIColor lightTextColor];
        spinner.transform = CGAffineTransformMakeScale(2, 2);
        // spinner.hidesWhenStopped = YES;
        [self.view addSubview:spinner];
        spinner.transform = CGAffineTransformMakeScale(2, 2);
        
        [spinner startAnimating];
        
        // how we stop refresh from freezing the main UI thread
        
        dispatch_async(
                       dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^{
                           
                           // back to the main thread for the UI call
                           dispatch_async(dispatch_get_main_queue(), ^{
                               [spinner startAnimating];
                           });
                           dispatch_async(dispatch_get_main_queue(), ^{

        
        
        EditOpp *mEditOppr = [[EditOpp alloc]initWithNibName:@"EditOpp" bundle:nil];
        
        mEditOppr.selectedOpportunity = [GetRetailerOpp objectAtIndex:indexPath.section];
        [self presentViewController:mEditOppr animated:YES completion:nil];
        
                               [spinner stopAnimating];
                               
                           });
                       });
          }
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
}

-(void)ImageTap:(UIPinchGestureRecognizer *)recognizer{
    
    @try {
        
        
        UIImageView *tableGridImage = (UIImageView*)recognizer.view;
        
        
        ImageAlert=[[CustomIOSAlertView alloc] init];
        UIView  *imageView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 300, 200)];
        [ImageAlert setContainerView:imageView];
        [ImageAlert setButtonTitles:[NSMutableArray arrayWithObjects:@"", nil]];
        
        [ImageAlert setDelegate:self];
        
        
        // You may use a Block, rather than a delegate.
        [ImageAlert setOnButtonTouchUpInside:^(CustomIOSAlertView *alertView, int buttonIndex) {
            NSLog(@"Block: Button at position %d is clicked on alertView %d.", buttonIndex, (int)[alertView tag]);
            [alertView close];
        }];
        
        [ImageAlert setUseMotionEffects:true];
        
        UIButton *cancel = [[UIButton alloc]initWithFrame:CGRectMake(275, 0, 20, 20)];
        
        [cancel setImage:[UIImage imageNamed:@"ic_close"] forState:UIControlStateNormal];
        [cancel addTarget:self action:@selector(cancel:) forControlEvents:UIControlEventTouchUpInside];
        
        
        UIImageView *VendorProfile = [[UIImageView alloc]initWithImage:tableGridImage.image];
        VendorProfile.frame = CGRectMake(0, 20, 300, 230);
        [imageView addSubview:cancel];
        [imageView addSubview:VendorProfile];
        
        [ImageAlert show];
        ImageAlert.tag = 2;
        
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
    
    //ImageAlert = [CustomIOSAlertView ]
}


-(void)cancel:(UIButton*)sender
{
    [ImageAlert close];
}


- (void) showAlertPop:(NSString*)alertText  expObj:(NSException*) exp{
    if(exp != nil)
    {
        NSLog(@"%@", exp.description);
    }
    NSLog(@"The Exception is %@",exp.description);
    UIAlertController *myAlertController =[[Web_Services GetSharedInstance]  alert:alertText];
    [self presentViewController:myAlertController animated:YES completion:nil];
}

-(IBAction)back:(id)sender {
    @try
    {
        
       // [mPref setValue:HOME forKey:@"SideMenu"];
        Home * mOpportunity_list = [[ Home alloc] initWithNibName:HOMEDASHBOARD bundle:nil];
        [self presentViewController:mOpportunity_list animated:YES completion:nil];
        
//[self dismissViewControllerAnimated:YES completion:NULL];
                                   
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }

}

#pragma mark - Toolbarbuttons

-(BOOL)opportunityStatus:(NSString*)enddate
{
    NSString *satrtDate = [NSString stringWithFormat:@"%@",enddate];
    
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"yyyy-MM-dd'T'HH:mm:ss"];
    NSTimeZone *gmt = [NSTimeZone timeZoneWithAbbreviation:@"UTC"];
    [dateFormatter setTimeZone:gmt];
    NSDate *date5 = [dateFormatter dateFromString:satrtDate];
    
    NSDictionary *startOffer;
    if (date5!=nil) {
        startOffer= [[Preferences GetSharedInstance]remaningTime:[NSDate date] endDate:date5];
    }
    else{
        
        NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
        [dateFormatter setDateFormat:@"yyyy-MM-dd'T'HH:mm:ss.SSS"];
        
        NSTimeZone *gmt = [NSTimeZone timeZoneWithAbbreviation:@"UTC"];
        [dateFormatter setTimeZone:gmt];
        NSDate *date5 = [dateFormatter dateFromString:satrtDate];
        startOffer= [[Preferences GetSharedInstance]remaningTime:[NSDate date] endDate:date5];
        
    }
    
    
    int Remaingtyime = [[startOffer valueForKey:@"Time"] intValue];
    int hour = [[startOffer valueForKey:@"Hour"] intValue];
    int seconds = [[startOffer valueForKey:@"Seconds"] intValue];
    if (seconds!=0) {
        Remaingtyime = Remaingtyime+(seconds/60);
    }
    if(Remaingtyime!=0 || seconds !=0)
    {
        Remaingtyime = Remaingtyime+(hour*60);
        
        return YES;
    }
    else
    {
        return NO;
        
    }

}


-(NSDictionary*)EditedDate:(NSDictionary*)opportunity
{
    NSMutableDictionary *DateTimeData = [[NSMutableDictionary alloc]init];
    @try {
        
         // [blockBtn setImage:[UIImage imageNamed:@"play.png"]
        
        BOOL valid=[self opportunityStatus:[opportunity valueForKey:@"EndDate"]];
        
        if (valid) {
            ActionKey= @"Stop";
            NSDate *currentDateInLocal = [NSDate date];
            
            NSDateFormatter *formatter = [[NSDateFormatter alloc]init];
            [formatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
            NSTimeZone *gmt = [NSTimeZone timeZoneWithAbbreviation:@"UTC"];
            [formatter setTimeZone:gmt];
            NSString *StartTimecon = [formatter stringFromDate:currentDateInLocal];
            [DateTimeData setValue:StartTimecon forKey:@"EndDate"];
            [DateTimeData setValue:@"15" forKey:@"Time"];
            
            
        }
        else{
            ActionKey= @"Restart";
            NSDate *currentDateInLocal = [NSDate date];
            NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
            [dateFormatter setDateFormat:@"yyyy-MM-dd'T'HH:mm:SS"];
            NSString *currentLocalDateAsStr = [dateFormatter stringFromDate:currentDateInLocal];
            NSArray *date = [currentLocalDateAsStr componentsSeparatedByString:@"T"];
            NSString  *Datelabel = [NSString stringWithFormat:@"%@",[date objectAtIndex:0]];
            NSString  *Timelabel = [NSString stringWithFormat:@"%@",[date objectAtIndex:1]];
            
            
            NSString *TimeInterval;
            NSString *dat=Timelabel;
            
            
            NSArray *arr = [dat componentsSeparatedByString:@":"];
            NSString *hou= [arr objectAtIndex:0];
            NSString *mm= [arr objectAtIndex:1];
            NSInteger hour = [hou intValue];
            NSInteger minute = [mm intValue];
            minute = minute+1;
            NSString *AddTime;
            
            //NSString *moduleid =[NSString stringWithFormat:@"%@",[EditOpportunity valueForKey:@"ModuleId"]];
            
            
            AddTime=@"15";
            
            
            
            // AddTime =    [offertime  valueForKey:@"Time"];
            
            TimeInterval = @"1";
            
            int Addvalue = [AddTime intValue];
            
            int minnit = Addvalue;
            
            NSInteger  endtimeH = hour;
            NSInteger   endtimeM = minute+minnit;
            
            if(endtimeM>60&&endtimeM<120)
            {
                endtimeH = hour+1;
                endtimeM = endtimeM-60;
            }
            else if(endtimeM<60)
            {
                endtimeH = hour;
                endtimeM = minute+minnit;
            }
            else if(endtimeM==60)
            {
                endtimeH = minute+1;
                endtimeM = 00;
            }
            
            else if(endtimeM<120&&endtimeM>60)
            {
                endtimeH = hour+1;
                endtimeM = (minute+minnit)-60;
            }
            
            NSString *str1=[NSString stringWithFormat:@"%@",Datelabel];
            
            NSString *str=[NSString stringWithFormat:@"%@ %ld:%ld:00",str1,(long)endtimeH,(long)endtimeM];
            str = [str stringByReplacingOccurrencesOfString:@"+0000" withString:@""];
            
            
            NSDateFormatter *Format = [[NSDateFormatter alloc]init];
            [Format setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
            
            
            NSDate *secondtime =[Format dateFromString:str];
            
            NSDateFormatter *formatter = [[NSDateFormatter alloc]init];
            [formatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
            
            
            
            NSTimeZone *gmt = [NSTimeZone timeZoneWithAbbreviation:@"UTC"];
            [formatter setTimeZone:gmt];
            
            
            NSString *SecondTime = [formatter stringFromDate:secondtime];
            
            
            
            
            [DateTimeData setValue:SecondTime forKey:@"EndDate"];
            [DateTimeData setValue:AddTime forKey:@"Time"];
            
        }
        
    return DateTimeData;
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }

    
}

- (void)tableView:(UITableView *)tableView
commitEditingStyle:(UITableViewCellEditingStyle)editingStyle
forRowAtIndexPath:(NSIndexPath *)indexPath {
    // Remove the row from data model
    
    @try {
        
        UIAlertController * alert=   [UIAlertController
                                      alertControllerWithTitle:@"Info"
                                      message:@"Are you sure want to delete Opportunity"
                                      preferredStyle:UIAlertControllerStyleAlert];
        
        UIAlertAction* ok = [UIAlertAction
                             actionWithTitle:@"OK"
                             style:UIAlertActionStyleDefault
                             handler:^(UIAlertAction * action)
                             {
                                  [self DeleteOpportunity:(int)indexPath.section];
                                 
                               //  [alert dismissViewControllerAnimated:YES completion:nil];
                                 
                             }];
        UIAlertAction* cancel = [UIAlertAction
                                 actionWithTitle:@"Cancel"
                                 style:UIAlertActionStyleDefault
                                 handler:^(UIAlertAction * action)
                                 {
                                     [alert dismissViewControllerAnimated:YES completion:nil];
                                     
                                 }];
        
        [alert addAction:ok];
        [alert addAction:cancel];
        
        [self presentViewController:alert animated:YES completion:nil];
        
        [tableView reloadData];
        
       
        
    } @catch (NSException *exception) {
        
    }
    
    // Request table view to reload
    
}





-(void)DeleteOpportunity:(int)index

{
   
    
        
        spinner = [[UIActivityIndicatorView alloc]
                   initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
        spinner.frame = CGRectMake(0, 0, 320, 560); // CGPointMake(160, 240);
        spinner.color = [UIColor blueColor];
        spinner.backgroundColor = [UIColor lightTextColor];
        spinner.transform = CGAffineTransformMakeScale(2, 2);
        
        // spinner.hidesWhenStopped = YES;
        [self.view addSubview:spinner];
        spinner.transform = CGAffineTransformMakeScale(2, 2);
        
        [spinner startAnimating];
        
        // how we stop refresh from freezing the main UI thread
        
        dispatch_async(
                       dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^{
                           
                           // back to the main thread for the UI call
                           dispatch_async(dispatch_get_main_queue(), ^{
                               [spinner startAnimating];
                           });
                           dispatch_async(dispatch_get_main_queue(), ^{
                               
                               
                               NSDictionary *selectedItem = [GetRetailerOpp objectAtIndex:index];
                              
                               
                               
                               NSString *opportunityId= [selectedItem valueForKey:@"OpportunityID"];
                               
                               
                               
                                 [[Web_Services GetSharedInstance]DeleteOpportunity:opportunityId];
                               
                                   NSString *RegisterID =   [prefss objectForKey:USERREGISTERID];
                                   [self viewDidLoad];
                                   [self GetVendorOpportunities:RegisterID];
                                   [TableView reloadData];
                               
                               
                               [spinner stopAnimating];
                               
                             
                               
                           });
                     
                       
                       });
                   
    
}


-(void)EditOpp:(UIButton*)sender
{
    @try
    {
        blockBtn.tag= sender.tag;
        
        spinner = [[UIActivityIndicatorView alloc]
                   initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
        spinner.frame = CGRectMake(0, 0, 320, 560); // CGPointMake(160, 240);
        spinner.color = [UIColor blueColor];
        spinner.backgroundColor = [UIColor lightTextColor];
        spinner.transform = CGAffineTransformMakeScale(2, 2);
        
        // spinner.hidesWhenStopped = YES;
        [self.view addSubview:spinner];
        spinner.transform = CGAffineTransformMakeScale(2, 2);
        
        [spinner startAnimating];
        
        // how we stop refresh from freezing the main UI thread
        
        dispatch_async(
                       dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^{
                           
                           // back to the main thread for the UI call
                           dispatch_async(dispatch_get_main_queue(), ^{
                               [spinner startAnimating];
                           });
                           dispatch_async(dispatch_get_main_queue(), ^{
                               
                               
                               
                               NSString *DeviceID = [[[UIDevice currentDevice] identifierForVendor] UUIDString];
                             
                               
                               CGPoint buttonPosition = [sender convertPoint:CGPointZero toView:TableView];
                               NSIndexPath *indexPath = [TableView indexPathForRowAtPoint:buttonPosition];
                               NSDictionary *selectedItem = [GetRetailerOpp objectAtIndex:indexPath.section];
                               NSDictionary *date = [self EditedDate:selectedItem];
                               
                               
                               NSString *opportunityId= [selectedItem valueForKey:@"OpportunityID"];
                               
                               
                               NSDictionary *Oppor= [self getEditeOpportunity:opportunityId];
                               
                               NSString *photoname  = [Oppor valueForKey:@"PhotoName"];
                               
                               photoname = [self getOpportunityimage:photoname];
                               
                               
                               NSString *AddressName= [NSString stringWithFormat:@"%@,%@,%@,%@",[selectedItem valueForKey:@"Address1"],[selectedItem valueForKey:@"Address2"],[selectedItem valueForKey:@"Address3"],[selectedItem valueForKey:@"AreaName"]];
                               
                               NSString *Location = [NSString stringWithFormat:@"%@,%@",[Oppor valueForKey:LATITUDE],[Oppor valueForKey:LONGITUDE]];
                               
                              
                               
                                   
                                   NSString *gcmID = [mPref valueForKey:@"FCMID"];
                                   if ([gcmID isEqualToString:@""] || gcmID==nil) {
                                       gcmID=@"";
                                   }
                               NSString *OopID;
                               
                               if ([ActionKey isEqualToString:@"Restart"]) {
                                   OopID = @"0";
                               }
                               else  OopID = [Oppor valueForKey:@"OpportunityID"];
                               
                               
                                   
                               
                               NSDictionary    *Opportunity  = @{@"OpportunityID":OopID,
                                                                 @"OpportunityName":[Oppor valueForKey:@"OpportunityName"],
                                                                 @"OpportunityDescription":[Oppor valueForKey:@"OpportunityDescription"],
                                                                 @"OpportunityKeywords":[Oppor valueForKey:@"OpportunityKeywords"],
                                                                 @"CategoryID":[Oppor valueForKey:@"CategoryID"],
                                                                 @"ModuleId":[Oppor valueForKey:@"ModuleId"],
                                                                 @"UserID":@"0",
                                                                 
                                                                 @"StartDate":[Oppor valueForKey:@"StartDate"],
                                                                 @"EndDate":[date valueForKey:@"EndDate"],
                                                                 @"PromoCode":@"Promo",
                                                                 @"OpportunityType":@"1",
                                                                 @"DeviceId":DeviceID,
                                                                 @"PhotoName":photoname,
                                                                 
                                                                 @"GcmId":gcmID,
                                                                 @"AddressName":AddressName,
                                                                 @"IsPrimary":@"true",
                                                                 @"Address1":[Oppor valueForKey:@"Address1"],
                                                                 @"Address3":[Oppor valueForKey:@"Address3"],
                                                                 @"Address2":[Oppor valueForKey:@"Address2"],
                                                                 @"AreaName":[Oppor valueForKey:@"AreaName"],
                                                                 @"Quantity":[Oppor valueForKey:@"Available"],
                                                                 @"City":[Oppor valueForKey:@"City"],
                                                                 @"State":[Oppor valueForKey:@"State"],
                                                                 @"Country":[Oppor valueForKey:@"Country"],
                                                                 LATITUDE:[Oppor valueForKey:LATITUDE],
                                                                 LONGITUDE:[Oppor valueForKey:LONGITUDE],
                                                                 @"KeyWords":@"",
                                                                 @"Time":@"15",
                                                                 @"PageSize":@"10",
                                                                 @"PageNo":@"1",
                                                                 @"radius":@"500",
                                                                 @"LocationFlag":@"NotChanged",
                                                                 @"Location":Location,
                                                                 @"Categories":@"",
                                                                 @"types":@"",
                                                                 @"UserRegisterId":[Oppor valueForKey:@"UserRegisterId"],
                                                                 @"Name":[Oppor valueForKey:@"OpportunityName"],
                                                                 @"Price":[Oppor valueForKey:@"Price"],
                                                                 @"ActualPrice":[Oppor valueForKey:@"ActualPrice"],
                                                                 @"Delivery":@"",
                                                                 @"Action":ActionKey
                                                                 
                                                                 };
                               
                               
                               NSDictionary *Reponse =  [[Web_Services GetSharedInstance]PostOffer:Opportunity];
                               if (Reponse!=nil) {
                                   NSString *RegisterID =   [prefss objectForKey:USERREGISTERID];
                                   [self viewDidLoad];
                                   [self GetVendorOpportunities:RegisterID];
                                   [TableView reloadData];
                               }
                               
                               [spinner stopAnimating];
                               
                               
                               
                               
                               if (blockBtn.tag ==1) {
                                   
                                   if ([[Oppor valueForKey:@"ModuleId"] isEqualToString:@"33"]) {
                                       [self showAlertPop:@"Your offer is stopped." expObj:nil];
                                   }
                                   else  if ([[Oppor valueForKey:@"ModuleId"] isEqualToString:@"34"]) {
                                       [self showAlertPop:@"Your offer is stopped." expObj:nil];
                                   }

                                   else  if ([[Oppor valueForKey:@"ModuleId"] isEqualToString:@"36"]) {
                                       [self showAlertPop:@"Your job requirement is stopped." expObj:nil];
                                   }
                                   
                                   else if ([[Oppor valueForKey:@"ModuleId"] isEqualToString:@"37"]) {
                                       [self showAlertPop:@"Your offer is stopped." expObj:nil];
                                   }
                                   else if ([[Oppor valueForKey:@"ModuleId"] isEqualToString:@"38"]) {
                                     [self showAlertPop:@"Your offer is stopped." expObj:nil];
                                   }
                                   else if ([[Oppor valueForKey:@"ModuleId"] isEqualToString:@"39"]) {
                                      [self showAlertPop:@"Your offer is stopped." expObj:nil];
                                   }
                                   else if ([[Oppor valueForKey:@"ModuleId"] isEqualToString:@"40"]) {
                                       [self showAlertPop:@"Your travel post is stopped." expObj:nil];
                                   }
                                   else if ([[Oppor valueForKey:@"ModuleId"] isEqualToString:@"41"]) {
                                      [self showAlertPop:@"Your property post is stopped." expObj:nil];
                                   }
                                   else if ([[Oppor valueForKey:@"ModuleId"] isEqualToString:@"42"]) {
                                       [self showAlertPop:@"Your offer is stopped." expObj:nil];
                                   }
                                   
                                   
                                   //Your offer request is cancelled!
                               }
                                if (blockBtn.tag ==2) {
                                   [self showAlertPop:@"Your offer is updated." expObj:nil];
                               }
                               
                           });
                           
                       });
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }

    
}



-(NSDictionary*)getEditeOpportunity:(NSString*)opportunityId
{
    @try {
        
    
    NSDictionary *Opportunity=[[Web_Services GetSharedInstance]GetOpportunityByID:opportunityId MethodName:@"GetOpportunityById"];
    
    return Opportunity;
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }

}

-(NSString*)getOpportunityimage:(NSString*)imagenames
{
    
    @try {
        
    
    NSArray *imagearr =[imagenames componentsSeparatedByString:@","];
    NSMutableArray *imagearray = [[NSMutableArray alloc]init];
    
    for (int i=0;i<[imagearr count]; i++) {
        
        NSString *dict= [imagearr objectAtIndex:i];
        
        if (![dict isEqual:@""])
        {
            
            
            NSMutableString* aString = [NSMutableString stringWithFormat:@"%@%@",baseImageURL,dict];
            NSURL *imageURL = [NSURL URLWithString:aString];
            
            NSData *getData = [NSData dataWithContentsOfURL:imageURL];
            
            NSString *base64String = [getData base64EncodedStringWithOptions:0];
            [imagearray addObject:base64String];
            
        }
        
    }
        
    if ([imagearray count]==0) {
        imagenames =@"";
    }
    else{
        imagenames = [imagearray componentsJoinedByString:@","];
    }
    
    
    
    return imagenames;
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }

}


#pragma SearchtextFiled

- (void)searchBarTextDidBeginEditing:(UISearchBar *)searchBar {
    isSearching = YES;
}

- (void)searchBar:(UISearchBar *)searchBarT textDidChange:(NSString *)seachtext {
    NSLog(@"Text change - %d",isSearching);
    
    //Remove all objects first.
    // [filteredContentList removeAllObjects];
    
      [searchBar setShowsCancelButton:YES animated:YES];
    
    if([seachtext length] != 0) {
        isSearching = YES;
        NSString *substring = [NSString stringWithString:seachtext];
        
        [self searchAutocompleteEntriesWithSubstring:substring];
    }
    else if([seachtext length]==0)
    {
        GetRetailerOpp= totaloffer;
        [TableView reloadData];

    }
    else {
        isSearching = NO;
    }
    // [self.tblContentList reloadData];
}





//- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string {
//    @try {
//        
//        
//        if ([string isEqualToString:@""]) {
//            GetRetailerOpp= totaloffer;
//            [TableView reloadData];
//        }
//        else
//        {
//        NSString *substring = [NSString stringWithString:string];
//       // substring = [substring stringByReplacingCharactersInRange:range withString:string];
//            
//            
//        [self searchAutocompleteEntriesWithSubstring:substring];
//        
//        }
//    return YES;
//    } @catch (NSException *exception) {
//        [self showAlertPop:@"Error while fetching data." expObj:exception];
//    } @finally {
//        
//    }
//    
//}

- (void)searchAutocompleteEntriesWithSubstring:(NSString *)substring {
    @try {
        // Put anything that starts with this substring into the autocompleteUrls array
        // The items in this array is what will show up in the table view
        NSPredicate *predicate = [NSPredicate predicateWithFormat:@"SELF contains [cd] %@", substring];
        results = [searchString filteredArrayUsingPredicate:predicate];
        if ([results count]!=0) {
            
            NSMutableArray *array = [[NSMutableArray alloc]init];
            
            
            for (int i=0; i<[results count]; i++) {
                NSString  *str= [results objectAtIndex:i];
                
                for (int j=0; j<[GetRetailerOpp count]; j++) {
                    NSString *str2 = [[GetRetailerOpp objectAtIndex:j]  valueForKey:@"OpportunityName"];
                    if ([str isEqualToString:str2]) {
                        [array addObject:[GetRetailerOpp objectAtIndex:j]];
                    }
                }
                
            }
            
            NSOrderedSet *orderedSet = [NSOrderedSet orderedSetWithArray:array];
            GetRetailerOpp = [orderedSet mutableCopy];
            
        
            
            [TableView reloadData];
            
        }
        //[autoComplete reloadData];
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
}

- (void)searchBarSearchButtonClicked :(UISearchBar *)searchBarT {
    NSLog(@"Search Clicked");
    
    [searchBarT resignFirstResponder];
    [searchBarT setShowsCancelButton:NO animated:YES];
 
}

- (void)searchBarCancelButtonClicked:(UISearchBar *)search{
    [search resignFirstResponder];
    [searchBar setShowsCancelButton:NO animated:YES];
   
}

-(IBAction)nearByUsers:(id)sender
{
    @try {
        
        NearBy_Users *mNearByUsers = [[NearBy_Users alloc]initWithNibName:@"NearBy_Users" bundle:nil];
        [self presentViewController:mNearByUsers animated:YES completion:nil];
        
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
        
    } @finally {
        
    }
}

-(void)shareData:(id)sender
{
    CGPoint buttonPosition = [sender convertPoint:CGPointZero toView:TableView];
    
    NSIndexPath *indexPath = [TableView indexPathForRowAtPoint:buttonPosition];
    
    NSDictionary *BlockedItem = [GetRetailerOpp objectAtIndex:indexPath.section];
    
//    NSString *Addres=[BlockedItem valueForKey:@"OpportunityName"];
//    NSString *areName=[BlockedItem valueForKey:@"AreaName"];
    
    
    UIAlertController * view=   [UIAlertController
                                 alertControllerWithTitle:@"Rigth Place Right Time"
                                 message:@"Select Sharing option"
                                 preferredStyle:UIAlertControllerStyleActionSheet];
    
    UIAlertAction* watsapp = [UIAlertAction
                              actionWithTitle:@"Share via Whatsapp"
                              style:UIAlertActionStyleDefault
                              handler:^(UIAlertAction * action)
                              {
                                  
                                  
                                  
                                  NSString *ursl =  [mConverter whatspandSMSText:BlockedItem];//[NSString stringWithFormat:@"A new opportunity is posted at %@ \n%@ \nIf you do not have the app, please download it from Apple:https://itunes.apple.com/in/app/right-place-right-time/id1145309259?mt=8",areName,Addres];
                                  
                                  ursl =    (NSString*)CFBridgingRelease(CFURLCreateStringByAddingPercentEscapes(NULL,(CFStringRef) ursl, NULL,CFSTR("!*();:@&=+$,/?%#[]"),kCFStringEncodingUTF8));
                                  
                                  NSString * urlWhats = [NSString stringWithFormat:@"whatsapp://send?text=%@",ursl];
                                  NSURL * whatsappURL = [NSURL URLWithString:urlWhats];
                                  if ([[UIApplication sharedApplication] canOpenURL: whatsappURL]) {
                                      UIApplication *application = [UIApplication sharedApplication];
                                      [application openURL:whatsappURL options:@{} completionHandler:nil];

                                      
                                    //  [[UIApplication sharedApplication] openURL: whatsappURL];
                                  } else {
                                      [self showAlertPop:@"Unable to share opportunity." expObj:nil];
                                      // can not share with whats app
                                  }
                                  
                              }];
    UIAlertAction* email = [UIAlertAction
                            actionWithTitle:@"Share via E-mail"
                            style:UIAlertActionStyleDefault
                            handler:^(UIAlertAction * action)
                            {
                                NSString *ursl = [mConverter emailText:BlockedItem];
                                
                                // NSString *ursl = [NSString stringWithFormat:@"%@",emailstring];
                                
                                NSString *cat =[BlockedItem valueForKey:@"Category"];
                                if ([cat isEqualToString:@"Professional Services"]) {
                                    cat= @"Expert Help";
                                }
                                else if ([cat isEqualToString:MEETINGS])
                                    cat= @"Events & Entertainments";
                                
                                NSString *subjectt = [NSString stringWithFormat:@"Right Place Right Time : %@",cat];
                                
                                if ([MFMailComposeViewController canSendMail]) {
                                    MFMailComposeViewController *mailController = [[MFMailComposeViewController alloc] init];
                                    [mailController setMailComposeDelegate:self];
                                    [mailController setSubject:subjectt];
                                    [mailController setToRecipients:@[@"email1", @"email2"]];
                                    [mailController setMessageBody:ursl isHTML:NO];
                                    [self presentViewController:mailController animated:YES completion:nil];
                                }
                                
                                [view dismissViewControllerAnimated:YES completion:nil];
                                
                            }];
    
    
    UIAlertAction* sms = [UIAlertAction
                          actionWithTitle:@"Share via iMessage"
                          style:UIAlertActionStyleDefault
                          handler:^(UIAlertAction * action)
                          {
                              
                              NSString *ursl =[mConverter whatspandSMSText:BlockedItem];// [NSString stringWithFormat:@"A new opportunity is posted at %@ \n%@ \nIf you do not have the app, please download it from Apple:https://itunes.apple.com/in/app/right-place-right-time/id1145309259?mt=8",areName,Addres];
                              
                              if ([MFMessageComposeViewController canSendText]) {
                                  MFMessageComposeViewController *messageController = [[MFMessageComposeViewController alloc] init];
                                  [messageController setMessageComposeDelegate:self];
                                  [messageController setRecipients:nil];
                                  [messageController setBody:ursl];
                                  [self presentViewController:messageController animated:NO completion:nil];
                              }
                              
                              [view dismissViewControllerAnimated:YES completion:nil];
                              
                          }];
    
    UIAlertAction* cancel = [UIAlertAction
                             actionWithTitle:@"Cancel"
                             style:UIAlertActionStyleDefault
                             handler:^(UIAlertAction * action)
                             {
                                 [view dismissViewControllerAnimated:YES completion:nil];
                                 
                             }];
    [watsapp setValue:[[UIImage imageNamed:@"whatsapp.png"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal] forKey:@"image"];
    [email setValue:[[UIImage imageNamed:@"email.png"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal] forKey:@"image"];
    [sms setValue:[[UIImage imageNamed:@"sms.png"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal] forKey:@"image"];
    
    
    [view addAction:watsapp];
    [view addAction:email];
    [view addAction:sms];
    [view addAction:cancel];
    [self presentViewController:view animated:YES completion:nil];
    
    
}
- (void)mailComposeController:(MFMailComposeViewController*)controller didFinishWithResult:(MFMailComposeResult)result error:(NSError*)error {
    [self dismissViewControllerAnimated:YES completion:nil];
}

// Then implement the delegate method
- (void)messageComposeViewController:(MFMessageComposeViewController *)controller didFinishWithResult:(MessageComposeResult)result {
    [self dismissViewControllerAnimated:YES completion:nil];
}




@end
