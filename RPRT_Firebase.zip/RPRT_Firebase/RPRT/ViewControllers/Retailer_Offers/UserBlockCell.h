//
//  UserBlockCell.h
//  RPRT
//
//  Created by sravanthi Gumma on 23/02/16.
//  Copyright © 2016 DevpointSolutions. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UserBlockCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UIImageView *UserImage;
@property (weak, nonatomic) IBOutlet UILabel *VendorName;
@property (weak, nonatomic) IBOutlet UILabel *vendorMobileNumber;
@property(weak,nonatomic)IBOutlet UILabel *blockTime;
@property (weak, nonatomic) IBOutlet UILabel *offerTimer;
@property (weak, nonatomic) IBOutlet UILabel *key;
@property (weak, nonatomic) IBOutlet UILabel *emaiId;
@property(weak,nonatomic) IBOutlet UIButton *callBtn;
@property (weak, nonatomic) IBOutlet UILabel *intrested;

@end
