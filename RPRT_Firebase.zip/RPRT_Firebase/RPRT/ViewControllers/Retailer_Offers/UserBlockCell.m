//
//  UserBlockCell.m
//  RPRT
//
//  Created by sravanthi Gumma on 23/02/16.
//  Copyright © 2016 DevpointSolutions. All rights reserved.
//

#import "UserBlockCell.h"

@implementation UserBlockCell
//static CGFloat radius = 2;
@synthesize vendorMobileNumber = vendorMobileNumber;
@synthesize VendorName = VendorName;
@synthesize UserImage = UserImage;
@synthesize offerTimer = offerTimer;
@synthesize blockTime = blockTime;
@synthesize key = key;
@synthesize emaiId = emaiId;
@synthesize  intrested =intrested;


- (void)awakeFromNib {
    // Initialization code
    [super awakeFromNib];
}

-(void)layoutSubviews{
    
    
    self.UserImage.layer.cornerRadius = self.UserImage.frame.size.width/2;
    self.UserImage.layer.masksToBounds = YES;
    self.layer.borderColor= [UIColor colorWithRed:196.0/256.0 green:196.0/256.0 blue:196.0/256.0 alpha:1].CGColor;
    self.layer.borderWidth=1;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
    
    // Configure the view for the selected state
}@end
