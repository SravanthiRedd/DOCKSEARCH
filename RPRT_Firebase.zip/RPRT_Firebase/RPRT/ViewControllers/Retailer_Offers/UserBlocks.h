//
//  UserBlocks.h
//  RPRT
//
//  Created by sravanthi Gumma on 23/02/16.
//  Copyright © 2016 DevpointSolutions. All rights reserved.
//



#import "UserBlockCell.h"

#import "MainViewController.h"
#import "MZTimerLabel.h"
@interface UserBlocks : UIViewController<UITableViewDataSource,UITableViewDelegate>

@property (nonatomic, retain) IBOutlet UITableView *TableView;
@property (assign ,nonatomic) NSString *opportunityID;

@property (weak, nonatomic) IBOutlet UIButton *Radious;
@property (weak,nonatomic)IBOutlet UIButton *Settings;

@property(weak,nonatomic) IBOutlet UIView *toolBarView;
@end
