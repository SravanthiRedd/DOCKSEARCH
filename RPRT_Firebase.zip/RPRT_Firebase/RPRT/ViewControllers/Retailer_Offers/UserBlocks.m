//
//  UserBlocks.m
//  RPRT
//
//  Created by sravanthi Gumma on 23/02/16.
//  Copyright © 2016 DevpointSolutions. All rights reserved.
//

#import "UserBlocks.h"
#import "UIImage+MDQRCode.h"
#import "TimeCalculator.h"

@interface UserBlocks ()
{
    NSMutableArray *GetBlockedUser;
    UIView *contentView;
    MZTimerLabel *TimeCoutDown;
    NSUserDefaults *mPref;
    UIActivityIndicatorView *spinner;
}
@property (nonatomic, copy)  NSDictionary *setCache;
@end

@implementation UserBlocks
@synthesize TableView,Settings,Radious,toolBarView;
- (void)viewDidLoad {
    @try {
       
    [super viewDidLoad];
        
          mPref = [NSUserDefaults standardUserDefaults];
        [self loadToolbar];
         self.setCache = [[NSMutableDictionary alloc] init];
    NSString *oppId = self.opportunityID;
        UIImageView *tempImageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"pagebg.jpg"]];
        [tempImageView setFrame:TableView.frame];
        TableView.backgroundColor = [UIColor clearColor];
        TableView.backgroundView = tempImageView;

 NSMutableArray   *GetBlocks = [[Web_Services GetSharedInstance]GetOpportinityReview:oppId MethodName:@"GetReservedOpportunitiesBYID"];
        GetBlockedUser =GetBlocks;
   
        
       
        
   
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }

    
}

-(void)loadToolbar
{
    @try {
        
    
    
        
        NSData *colorData= [mPref valueForKey:@"COLOR"];
if (colorData == nil) {
            toolBarView.backgroundColor= [UIColor colorWithRed:0/256.0 green:186.0/256.0 blue:210/256.0 alpha:1];
        }
        else
          toolBarView.backgroundColor = [NSKeyedUnarchiver unarchiveObjectWithData:colorData];
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }

}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)setStackIconClosed:(BOOL)closed {
    
    @try {
        UIImageView *icon = [[contentView subviews] objectAtIndex:0];
        float angle = closed ? 0 : (M_PI * (135) / 180.0);
        [UIView animateWithDuration:0.3 animations:^{
            [icon.layer setAffineTransform:CGAffineTransformRotate(CGAffineTransformIdentity, angle)];
        }];
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }

    
    
}

#pragma mark -UITableViewData Source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    
    return GetBlockedUser.count;
   // return 10;
    
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 120;
}

#pragma mark -UITableViewDelegate

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    @try {
        // static NSString *simpleTableIdentifier = @"MyBlockCell";
        
        UserBlockCell *cell = (UserBlockCell *)[tableView dequeueReusableCellWithIdentifier:USERBLOCKCELL];
        if (cell == nil)
        {
            NSArray *nib = [[NSBundle mainBundle] loadNibNamed:USERBLOCKCELL owner:self options:nil];
            cell = [nib objectAtIndex:0];
        }
        
       // [cell updateConstraintsIfNeeded];
        
        NSDictionary *dic = [GetBlockedUser objectAtIndex:indexPath.row];
        cell.VendorName.text =[NSString stringWithFormat:@"%@",[dic valueForKey:@"RegUserName"]];
        
        //RegUserName
        cell.emaiId.text = [NSString stringWithFormat:@"%@",[dic valueForKey:@"RegEmail"]];
        cell.key.text = [NSString stringWithFormat:@"%@",[dic valueForKey:@"KeyValue"]];
        
        
       // CGFloat imageSize = ceilf(self.view.bounds.size.width * 0.6f);
        //UIImageView *imageView = [[UIImageView alloc] initWithFrame:CGRectMake(floorf(self.view.bounds.size.width * 0.5f - imageSize * 0.5f), floorf(self.view.bounds.size.height * 0.5f - imageSize * 0.5f), imageSize, imageSize)];
        
        
        NSArray *imagearr= [[dic valueForKey:@"PhotoName"] componentsSeparatedByString:@","];
        cell.vendorMobileNumber.text= [NSString stringWithFormat:@"%@",[dic valueForKey:@"PhoneNo"]];
        
        UITapGestureRecognizer *singleTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(call:)];
        singleTap.numberOfTapsRequired = 1;
        [cell.vendorMobileNumber setUserInteractionEnabled:YES];
        [cell.vendorMobileNumber addGestureRecognizer:singleTap];
        
        
        
        
        // NSString *imageName = [NSString stringWithFormat:@"%@",[dic valueForKey:@"PhotoName"]];;
        
        NSString *ImageURL = [NSString stringWithFormat:@"%@%@",baseImageURL, [imagearr objectAtIndex:0]];
        
        NSURL *imageURL = [NSURL URLWithString:ImageURL];
        NSString *key = [ImageURL MD5Hash];
        NSData *getData = [FTWCache objectForKey:key];
        if (getData) {
            UIImage *image = [UIImage imageWithData:getData];
            cell.UserImage.image  = image;
        }
        else {
            cell.UserImage.image  = [UIImage imageNamed:@"img_def"];
            dispatch_queue_t queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_HIGH, 0ul);
            dispatch_async(queue, ^{
                NSData *newData = [NSData dataWithContentsOfURL:imageURL];
                [FTWCache setObject:newData forKey:key];
                UIImage *image = [UIImage imageWithData:newData];
                dispatch_sync(dispatch_get_main_queue(), ^{
                    cell.UserImage.image  = image;
                    
                });
            });
        }
        
        
        
        
        NSString *satrtDate = [NSString stringWithFormat:@"%@",[dic valueForKey:@"EndDate"]];
        
        NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
        [dateFormatter setDateFormat:@"yyyy-MM-dd'T'HH:mm:ss.SSS"];
        NSTimeZone *gmt = [NSTimeZone timeZoneWithAbbreviation:@"UTC"];
        [dateFormatter setTimeZone:gmt];
        NSDate *date5 = [dateFormatter dateFromString:satrtDate];
        
        NSDictionary *startOffer;
        if (date5!=nil) {
            
            // NSString *date =  [NSDate stringForDisplayFromDate:date5];
            
            NSDateFormatter *dateFormatter1 = [[NSDateFormatter alloc] init];
            [dateFormatter1 setDateFormat:@"yyyy-MM-dd'T'HH:mm:ss"];
            NSTimeZone *gmt1 = [NSTimeZone timeZoneWithAbbreviation:@"GMT"];
            [dateFormatter setTimeZone:gmt1];
            NSString *date = [dateFormatter1 stringFromDate:date5];
            
            cell.blockTime.text  = [date stringByReplacingOccurrencesOfString:@"T" withString:@" "];
            
            
            
//            NSString *str=  [dateFormatter stringFromDate:date5];
//            cell.blockTime.text  =[NSString stringWithFormat:@"%@",[str stringByReplacingOccurrencesOfString:@"T" withString:@" "]];
            startOffer= [[Preferences GetSharedInstance]remaningTime:[NSDate date] endDate:date5];
        }
        else{
            
            NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
            [dateFormatter setDateFormat:@"yyyy-MM-dd'T'HH:mm:ss"];
            
            NSTimeZone *gmt = [NSTimeZone timeZoneWithAbbreviation:@"UTC"];
            [dateFormatter setTimeZone:gmt];
            NSDate *date5 = [dateFormatter dateFromString:satrtDate];
            
            
            NSDateFormatter *dateFormatter1 = [[NSDateFormatter alloc] init];
            [dateFormatter1 setDateFormat:@"yyyy-MM-dd'T'HH:mm:ss"];
            NSTimeZone *gmt1 = [NSTimeZone timeZoneWithAbbreviation:@"GMT"];
            [dateFormatter setTimeZone:gmt1];
            NSString *date = [dateFormatter1 stringFromDate:date5];
            
            cell.blockTime.text  = [date stringByReplacingOccurrencesOfString:@"T" withString:@" "];
            
            
//            NSString *str=  [dateFormatter stringFromDate:date5];
//            cell.blockTime.text  =[NSString stringWithFormat:@"%@",[str stringByReplacingOccurrencesOfString:@"T" withString:@" "]];
            //  cell.blockedTime.text = [NSString stringWithFormat:@"%@",date5];
            
            startOffer= [[Preferences GetSharedInstance]remaningTime:[NSDate date] endDate:date5];
            
        }
        
        // NSDictionary *startOffer= [[Preferences alloc]remaningTime:[NSDate date] endDate:date5];
        int remain = [[startOffer valueForKey:@"Time"] intValue];
        int hour = [[startOffer valueForKey:@"Hour"] intValue];
        // Timer.textColor = categoryColor;
        int seconds = [[startOffer valueForKey:@"Seconds"] intValue];
        if (seconds!=0)
            remain = remain+(seconds/60);
        
        if(remain!=0 || seconds !=0)
        {
            remain = remain+(hour*60);
            TimeCoutDown = [[MZTimerLabel alloc] initWithLabel:cell.offerTimer andTimerType:MZTimerLabelTypeTimer];
            [TimeCoutDown setCountDownTime:remain*60];
            [TimeCoutDown start];
            
        }
        else
        {
            
            cell.offerTimer.text = @"Expired!!";
        }
        
        
        
        return cell;
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
}


- (void) showAlertPop:(NSString*)alertText  expObj:(NSException*) exp{
    @try {
        
    if(exp != nil)
    {
        NSLog(@"%@", exp.description);
    }
    NSLog(@"The Exception is %@",exp.description);
    UIAlertController *myAlertController =[[Web_Services GetSharedInstance]  alert:alertText];
    [self presentViewController:myAlertController animated:YES completion:nil];
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }

}

-(IBAction)back:(id)sender {
    @try
    {
    [self dismissViewControllerAnimated:YES completion:NULL];
   
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
    
}

-(void)call:(UIGestureRecognizer *)recognizer
{
    
      UILabel *tableGridImage = (UILabel*)recognizer.view;
    
    NSLog(@"%@",tableGridImage.text);

}

#pragma mark - Toolbarbuttons

@end
