//
//  Registration_Types.h
//  RPRT
//
//  Created by sravanthi Gumma on 14/09/1938 Saka.
//  Copyright © 1938 Saka DevpointSolutions. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Registration_Types : UIViewController
{
    NSDictionary *RegisterdObj;
    NSDictionary *editedDetils;
}
@property(strong,nonatomic) NSDictionary *RegisteredObject;
@property(strong,nonatomic) NSDictionary *EditRegisted;

@end
