//
//  Registration_Types.m
//  RPRT
//
//  Created by sravanthi Gumma on 14/09/1938 Saka.
//  Copyright © 1938 Saka DevpointSolutions. All rights reserved.
//

#import "Registration_Types.h"
#import "MainViewController.h"
#import "Sale_Registration.h"
#import "RegisterWithGoogle.h"
@interface Registration_Types ()
{
    Web_Services *mWebservice;
}
@end

@implementation Registration_Types

- (void)viewDidLoad {
    [super viewDidLoad];
    mWebservice = [Web_Services GetSharedInstance];
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(void) viewDidLayoutSubviews {
    
    @try {
        
        
        [super viewDidLayoutSubviews];
        //[self.scrollview layoutIfNeeded];
       // self.scrollview.contentSize=self.Contentview.bounds.size;
        UIGraphicsBeginImageContext(self.view.frame.size);
        UIImage *image = UIGraphicsGetImageFromCurrentImageContext();
        UIGraphicsEndImageContext();
        image= [UIImage imageNamed:@"bgerror.png"];
        self.view.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"bgerror.png"]];
        
        
        
    
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
}


- (void) showAlertPop:(NSString*)alertText expObj:(NSException*) exp{
    if(exp != nil)
    {
        NSLog(@"%@", exp.description);
    }
    UIAlertController *myAlertController =[mWebservice  alert:alertText];
    [self presentViewController:myAlertController animated:YES completion:nil];
}

-(IBAction)back:(id)sender
{
    [self dismissViewControllerAnimated:YES completion:nil];
}
-(IBAction)individualLogin:(id)sender
{
    RegisterWithGoogle *mRegisterWithGoogler = [RegisterWithGoogle alloc];
    mRegisterWithGoogler.RegisteredObject = self.RegisteredObject;
    
    RegisterWithGoogle *mRegistatrionGoogle =
    [mRegisterWithGoogler initWithNibName:@"RegistrationWithGoogle" bundle:nil];
    [self presentViewController:mRegistatrionGoogle animated:YES completion:nil];
    
    
    
//    RegisterWithGoogle *mRegisterWithGoogle = [[RegisterWithGoogle alloc]initWithNibName:@"RegisterWithGoogle" bundle:nil];
//    
//    mRegisterWithGoogle.RegisteredObject =self.RegisteredObject;
//    [self presentViewController:mRegisterWithGoogle animated:YES completion:nil];

}


-(IBAction)businessLogin:(id)sender
{
    Sale_Registration *mSalreRegistraion = [[Sale_Registration alloc]initWithNibName:@"Sale_Registration" bundle:nil];
    mSalreRegistraion.RegisteredObject = self.RegisteredObject;
    [self presentViewController:mSalreRegistraion animated:YES completion:nil];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
