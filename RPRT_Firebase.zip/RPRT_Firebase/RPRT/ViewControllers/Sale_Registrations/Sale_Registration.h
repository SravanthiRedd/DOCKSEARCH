//
//  Sale_Registration.h
//  RPRT
//
//  Created by sravanthi Gumma on 14/09/1938 Saka.
//  Copyright © 1938 Saka DevpointSolutions. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AVFoundation/AVFoundation.h>
@interface Sale_Registration : UIViewController<UIScrollViewDelegate,UITextViewDelegate,UITextFieldDelegate,AVCaptureMetadataOutputObjectsDelegate>
{
    NSDictionary *RegisterdObj;
    NSDictionary *editedDetils;
    AVCaptureSession *session;
    AVCaptureDevice *device;
    AVCaptureDeviceInput *input;
    AVCaptureMetadataOutput *output;
    AVCaptureVideoPreviewLayer *prevLayer;
    NSString *detectionString;
    UIView *highlightView;
}

@property(strong,nonatomic) NSDictionary *RegisteredObject;
@property(strong,nonatomic) NSDictionary *EditRegisted;


@property(weak,nonatomic) IBOutlet UIView *categoriesView;
@property(weak,nonatomic) IBOutlet UIView *StoreNameView;
@property(weak,nonatomic) IBOutlet UIView *DescriptionView;
@property(weak,nonatomic) IBOutlet UIView *BranchNameView;
@property(weak,nonatomic) IBOutlet UIView *LocationView;
@property(weak,nonatomic) IBOutlet UIView *ContactPersonView;
@property(weak,nonatomic) IBOutlet UIView *ContactNoView;
@property(weak,nonatomic) IBOutlet UIView *EmailIDView;
@property(weak,nonatomic) IBOutlet UIView *NotificationView;
@property(weak,nonatomic) IBOutlet UIView *RadiousView;
@property(weak,nonatomic) IBOutlet UIView *ActivationView;


@property(weak,nonatomic) IBOutlet UITextField *category;
@property(weak,nonatomic) IBOutlet UITextField *storeName;
@property(weak,nonatomic) IBOutlet UITextView *storeDescription;
@property(weak,nonatomic) IBOutlet UITextField *branchName;
@property(weak,nonatomic) IBOutlet UITextField *location;
@property(weak,nonatomic) IBOutlet UITextField *contactPerson;
@property(weak,nonatomic) IBOutlet UITextField *emailId;
@property(weak,nonatomic) IBOutlet UITextField *contactNumber;
@property(weak,nonatomic) IBOutlet UITextField *ActivationCode;

@property(weak,nonatomic) IBOutlet UIButton *notificationBtn;
@property(weak,nonatomic) IBOutlet UIButton *radiouBtn;
@property(weak,nonatomic) IBOutlet UIButton *submitBtn;



@property(weak,nonatomic) IBOutlet UIButton *cameraBtn;
@property(weak,nonatomic) IBOutlet UIButton *scanBtn;

@property(weak,nonatomic) IBOutlet UIImageView *photoImg;
@property(weak,nonatomic) IBOutlet UIScrollView *photoScroll;
@property(weak,nonatomic) IBOutlet UIScrollView *ScrollView;
@property(weak,nonatomic) IBOutlet UIView *ContentView;

//Then show the categories
//b. Store Name
//c. Description
//d. Branch Name
//e. Location
//f. Contact Person
//g. Contact No
//h. User settings


@end
