//
//  Sale_Registration.m
//  RPRT
//
//  Created by sravanthi Gumma on 14/09/1938 Saka.
//  Copyright © 1938 Saka DevpointSolutions. All rights reserved.
//

#import "Sale_Registration.h"
#import "Web_Services.h"
#import "CustomIOSAlertView.h"
#import "Setting_Cell.h"
#import "MainViewController.h"
#import "TimeCalculator.h"
#import "Setting_Maps.h"

@interface Sale_Registration ()<CustomIOSAlertViewDelegate,UITextFieldDelegate,UITableViewDelegate,UITableViewDataSource,UIImagePickerControllerDelegate,UINavigationControllerDelegate>
{
    UIActivityIndicatorView *spinner;
    Web_Services *mWebservice;
    NSArray *userTypes;
    CustomIOSAlertView *userTypeAlert;
    UITableView *userTypetable;
    UITableView *categoryTable;
    NSDictionary *SelectedType;
    NSString *latLong;
    CustomIOSAlertView *categoryAlert;
    
    NSArray *categoryItems;
    BOOL isMultipleSelection;
    NSArray *radiusItems;
    UITableView *radTable;
    NSString *selectedRadius;
    NSDictionary *selectedCategories;
    NSString *UserSettingsID;
    GeoCodeLocation *geoCode;
    
    
    UITableView *autocompleAddressTable;
    NSMutableArray  *autocompleAddress;
    NSMutableArray *checkedCateIds;
    NSMutableArray *finalCheckedarry;
    NSUserDefaults *mPref;
    NSMutableArray *checkedArray;
    NSString *encodecImage;
    NSMutableArray *Images;
    TimeCalculator *mTimeCalculator;
    NSString *UserRegistedID;
    NSString *UserSelectedCat;
    NSString *selectedCategoryID;
    NSString *LoginType;
    
    CustomIOSAlertView *scannerAlert;
    
    
}
@end

@implementation Sale_Registration

- (void)viewDidLoad {
    [super viewDidLoad];
    
   
    mWebservice =[Web_Services GetSharedInstance];
    mTimeCalculator = [TimeCalculator GetSharedInstance];
    latLong= @"";
    
     [self updateDesign];
    userTypes = [self getuserType];
    
    self.photoScroll.hidden=YES;
    mPref = [NSUserDefaults standardUserDefaults];
    checkedArray = [[NSMutableArray alloc]init];
    checkedCateIds = [[NSMutableArray alloc]init];
    finalCheckedarry = [[NSMutableArray alloc]init];
    encodecImage = @"";
    selectedRadius = @"";
    UserSettingsID = @"0";
    UserRegistedID = @"0";
    UserSelectedCat = @"Business";
    latLong= @"";
    LoginType= @"";
    selectedCategoryID = @"";
    Images = [[NSMutableArray alloc]init];
    
    NSString *path = [[NSBundle mainBundle] pathForResource:CATEGORY ofType:@"plist"];
    NSMutableDictionary *dict = [NSMutableDictionary dictionaryWithContentsOfFile:path];
    categoryItems = [dict valueForKey:@"Categories"];
    
     radiusItems = [dict valueForKey:@"Radious"];
    categoryTable = [[UITableView alloc]init];
    
    categoryTable.layer.borderColor = [UIColor colorWithRed:198.0/256.0 green:198.0/256.0 blue:198.0/256.0 alpha:1].CGColor;
    
    categoryTable.delegate= self;
    categoryTable.dataSource = self;
    
    
    radTable = [[UITableView alloc] init];
    radTable.layer.borderColor = [UIColor colorWithRed:198.0/256.0 green:198.0/256.0 blue:198.0/256.0 alpha:1].CGColor;
    radTable.delegate = self;
    radTable.dataSource = self;

    [self showGallery];
    
    GeoCodeLocation *geocode = [GeoCodeLocation GetSharedInstance];
    
    self.location.text = [NSString stringWithFormat:@"%@,%@",geocode.Address1,geocode.AreaName];
    latLong=[NSString stringWithFormat:@"%@,%@",geocode.Latitude,geocode.Longitude];
    
   

    if (checkedCateIds==nil)  {
        NSString *srt = [NSString stringWithFormat:@"33,34,36,37,38,39,40,41,42,43"];
        checkedCateIds = [[srt componentsSeparatedByString:@","] mutableCopy];
    }

    
//    RegisterdObj = self.RegisteredObject;
//    if (RegisterdObj !=nil) {
//        [self loadRegistrationDetails:RegisterdObj];
//    }

    editedDetils = self.EditRegisted;
    
    self.ScrollView.frame= CGRectMake(0,70, self.ScrollView.frame.size.width, self.ScrollView.frame.size.height+300);
    self.ContentView.frame = CGRectMake(self.ScrollView.frame.origin.x,self.ScrollView.frame.origin.y-10, self.ContentView.frame.size.width,self.ContentView.frame.size.height+200);
    
    if(editedDetils!=nil)
    {
        [self EditRegistedDetils];
    }
    
    [[NSNotificationCenter defaultCenter]
     addObserver:self
     selector:@selector(ToStoreRegister:)
     name:@"ToStoreRegister"
     object:nil];

    
    
    // Do any additional setup after loading the view from its nib.
}

-(void)loadRegistrationDetails:(NSDictionary*)registedObj
{
    
    
    self.contactPerson.text = [registedObj valueForKey:@"FullName"];
    self.emailId.text = [registedObj valueForKey:@"EmailID"];
    LoginType= [registedObj valueForKey:@"LoginType"];
    
    NSString *usertypename = [editedDetils valueForKey:@"LoggedUserType"];
    
  //  self.conatctPersonName.text = [editedDetils valueForKey:@"ContactPerson"];
    
    for (int i=0; i<[userTypes count]; i++) {
        if ([[[userTypes objectAtIndex:i] valueForKey:@"LookupValue"] isEqualToString:usertypename]) {
            SelectedType = [userTypes objectAtIndex:i];
            self.category.text = usertypename;
            
        }
    }
    
//    if ([[SelectedType valueForKey:@"LookupValue"] isEqualToString:@"Individual"]) {
//        [self.contactpersonView setHidden:YES];
//        
//    }
//    else
//    {
//        [self.contactpersonView setHidden:NO];
//    }
//    
    
    
    if([registedObj valueForKey:@"ImageUrl"])
    {
        [self.cameraBtn setImage:[UIImage imageNamed:@"Edit_photo.png"] forState:UIControlStateNormal];
        NSURL *imageURL = [NSURL URLWithString:[registedObj valueForKey:@"ImageUrl"]];
        NSString *key = [[registedObj valueForKey:@"ImageUrl"] MD5Hash];
        NSData *getData = [FTWCache objectForKey:key];
  //  self.photoImg.layer.cornerRadius = regUserImgView.frame.size.width/2;
   //     regUserImgView.layer.borderWidth = 3.0f;
    //    regUserImgView.layer.borderColor =[UIColor blueColor].CGColor;
    //    regUserImgView.clipsToBounds= YES;
        
        UIImage *image;
        if (getData) {
            image = [UIImage imageWithData:getData];
            self.photoImg.image  = image;
            
            //UIImage *image = [UIImage imageNamed:@"imageName.png"];
            NSData *imageData = [NSData dataWithData:UIImagePNGRepresentation(image)];
            encodecImage  =  [imageData base64EncodedStringWithOptions:0];
        }
        else {
            self.photoImg.image  = [UIImage imageNamed:@"img_def"];
            dispatch_queue_t queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_HIGH, 0ul);
            dispatch_async(queue, ^{
                NSData *newData = [NSData dataWithContentsOfURL:imageURL];
                [FTWCache setObject:newData forKey:key];
                UIImage  *image = [UIImage imageWithData:newData];
                dispatch_sync(dispatch_get_main_queue(), ^{
                    self.photoImg.image  = image;
                    NSData *imageData = [NSData dataWithData:UIImagePNGRepresentation(image)];
                    encodecImage  =  [imageData base64EncodedStringWithOptions:0];
                    
                });
                // encodecImage  =  [getData base64EncodedStringWithOptions:0];
            });
        }
        
    }
    
    [self getuserType];
    
}


-(void)EditRegistedDetils
{
        @try {
            
            
            NSString *userRedistedID =[NSString stringWithFormat:@"%@",[editedDetils valueForKey:@"BusinessRegisterID"]];
            NSDictionary *userProfile;
            if ([userRedistedID isEqualToString:@""]) {
                userRedistedID = @"";
                userProfile = nil;
                 [self.submitBtn  setTitle:@"Submit" forState:UIControlStateNormal];
            }
            else {
                   [self.submitBtn  setTitle:@"Submit" forState:UIControlStateNormal];
                userProfile =[mWebservice GetUsersRegisterBYID:userRedistedID];
            }
            
            [self setUserSetings:userRedistedID];
            
           
            LoginType= [editedDetils valueForKey:@"LoginType"];
            self.contactPerson.text = [editedDetils valueForKey:@"RegUserName"];
            self.contactNumber.text = [editedDetils valueForKey:@"PhoneNo"];
            self.emailId.text = [editedDetils valueForKey:@"RegEmail"];
            UserRegistedID = userRedistedID;
            
            if ([editedDetils valueForKey:@"BusinessDeatils"] !=nil) {
                NSDictionary *businessDeatils = [editedDetils valueForKey:@"BusinessDeatils"];
                
                self.storeDescription.text =[NSString stringWithFormat:@"%@",[businessDeatils valueForKey:@"StoreDescription"]];
                self.branchName.text =[NSString stringWithFormat:@"%@",[businessDeatils valueForKey:@"BranchName"]];
                self.storeName.text = [NSString stringWithFormat:@"%@",[businessDeatils valueForKey:@"ContactPerson"]];
                
            }
            
            self.location.text = [editedDetils valueForKey:@"DefaultAddress"];
            //self.branchName.text = [editedDetils valueForKey:@"BranchName"];
           // self.storeName.text = [editedDetils valueForKey:@"ContactPerson"];
           
            self.submitBtn .titleLabel.font=[UIFont fontWithName:@"Roboto-Medium" size:15.0];
            self.cameraBtn.layer.cornerRadius = 0.5 * self.cameraBtn.bounds.size.width;
            //            [self.cameraBtn addTarget:self action:@selector(camera:) forControlEvents:UIControlEventTouchUpInside];
            self.cameraBtn.backgroundColor =[UIColor cyanColor];
            [self.cameraBtn setImage:[UIImage imageNamed:@"camera.png"] forState:UIControlStateNormal];
            
            //  NSString *ImageURL = [NSString stringWithFormat:@"%@%@",baseImageURL, [userProfile valueForKey:@"PhotoName"]];
            
            if (userProfile!=nil) {
            
            
            NSString *imag = [userProfile objectForKey:@"PhotoName"];
            NSArray *stringArray = [imag componentsSeparatedByString:@","];
            
            Images = [NSMutableArray arrayWithCapacity:[stringArray count]];
            
            if (stringArray!=0 && ![stringArray[0] isEqualToString:@""]) {
                for (NSDictionary *dict in stringArray)
                {
                    if (![dict isEqual:@""])
                    {
                        
                        NSMutableString* aString = [NSMutableString stringWithFormat:@"%@%@",baseImageURL,dict];
                        NSURL *imageURL = [NSURL URLWithString:aString];
                        NSData *newData = [NSData dataWithContentsOfURL:imageURL];
                        UIImage *img = [UIImage imageWithData:newData];
                        [Images addObject:img];
                        
                    }
                    
                }
            }
            
            
            if ([Images count]!=0) {
                self.photoScroll.hidden= NO;
                
                self.ScrollView.frame= CGRectMake(0,self.photoScroll.frame.size.height+80, self.ScrollView.frame.size.width, self.ScrollView.frame.size.height+650);
                self.ContentView.frame = CGRectMake(self.ScrollView.frame.origin.x+5,6, self.ContentView.frame.size.width,self.ContentView.frame.size.height+650);
                self.cameraBtn.frame = CGRectMake(self.cameraBtn.frame.origin.x, self.cameraBtn.frame.origin.y+125, self.cameraBtn.frame.size.width, self.cameraBtn.frame.size.height);
                
            }
            
            if ([Images count]>1) {
                [self setImageToImageFrame];
            }
            else if([Images count]==1)
            {
                
                for (UIImage *img in Images)
                {
                    self.photoImg.image = img;
                    
                }
            }

            }
            //self.storeDescription.text =[NSString stringWithFormat:@"%@",[editedDetils valueForKey:@"StoreDescription"]];
            
            NSString *usertypename = [editedDetils valueForKey:@"LoggedUserType"];
            
            
            
            for (int i=0; i<[userTypes count]; i++) {
                if ([[[userTypes objectAtIndex:i] valueForKey:@"LookupValue"] isEqualToString:usertypename]) {
                    SelectedType = [userTypes objectAtIndex:i];
                    self.category.text=usertypename;// forState:UIControlStateNormal];//.text = usertypename;
                    
                }
            }
            
            
            
            //    UserId = 62;
            //    UserRegisterID = 104;
        } @catch (NSException *exception) {
            [self showAlertPop:@"Error while fetching data." expObj:exception];
        } @finally {
            
        }
    
}

-(void)setUserSetings:(NSString*)userRegisterID
{
    @try {
        
        
        NSString *regID = [editedDetils valueForKey:@"BusinessRegisterID"];
        
        int redIDNum = [regID intValue];
        
        if (redIDNum < 1) {
            regID = @"";
        }
        
        NSDictionary *getUserSettingsreponse = [mWebservice GetUserSettings:regID];
        
        if (getUserSettingsreponse!=nil) {
            selectedRadius =[NSString stringWithFormat:@"%@",[getUserSettingsreponse valueForKey:@"DefaultRadius"]];
            UserSettingsID = [NSString stringWithFormat:@"%@",[getUserSettingsreponse valueForKey:@"UserSettingsID"]];
            self.location.text = [getUserSettingsreponse valueForKey:@"DefaultAddress"];
            latLong =[NSString stringWithFormat:@"%@",[getUserSettingsreponse valueForKey:@"LatLong"]];
            
            checkedCateIds = [[[getUserSettingsreponse valueForKey:@"NotifyCategories"] componentsSeparatedByString:@","] mutableCopy];
            finalCheckedarry= checkedCateIds;
            [self.radiouBtn setTitle:[NSString stringWithFormat:@"%@",selectedRadius] forState:UIControlStateNormal];
            selectedCategoryID = [NSString stringWithFormat:@"%@",[checkedCateIds objectAtIndex:0]];
            
            [self.notificationBtn setTitle:[self selectedCategoryname:checkedCateIds] forState:UIControlStateNormal];
            [self.radiouBtn setTitle:[self selectedRadius:selectedRadius] forState:UIControlStateNormal];
        
        }
        
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
    
}


-(NSArray*)getuserType
{
    return [mWebservice UserTypes];
}

- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
    if (textField == self.category) {
    [self.category resignFirstResponder];
        [textField resignFirstResponder];
        [self getOffertype];
        userTypetable.hidden=NO;
        [userTypetable reloadData];
        return NO;

    }
    return YES;
}


-(void)getOffertype
{
    
    @try {
        
        userTypeAlert=[[CustomIOSAlertView alloc] init];
        UIView  *alertView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 300, 400)];
        [userTypeAlert setContainerView:alertView];
        [userTypeAlert setButtonTitles:[NSMutableArray arrayWithObjects:@"", nil]];
        
        [userTypeAlert setDelegate:self];
        
        
        // You may use a Block, rather than a delegate.
        [userTypeAlert setOnButtonTouchUpInside:^(CustomIOSAlertView *alertView, int buttonIndex) {
            NSLog(@"Block: Button at position %d is clicked on alertView %d.", buttonIndex, (int)[alertView tag]);
            [alertView close];
        }];
        
        [userTypeAlert setUseMotionEffects:true];
        
        UIButton *cancel = [[UIButton alloc]initWithFrame:CGRectMake(275, 0, 20, 20)];
        
        [cancel setImage:[UIImage imageNamed:@"ic_close"] forState:UIControlStateNormal];
        [cancel addTarget:self action:@selector(cancelcategory:) forControlEvents:UIControlEventTouchUpInside];
        
        //        offerTypeSearch = [[UISearchBar alloc]initWithFrame:CGRectMake(0, 20, alertView.frame.size.width, 40)];
        //        offerTypeSearch.delegate= self;
        //        offerTypeSearch.backgroundColor= [UIColor colorWithRed:198.0/256.0 green:198.0/256.0 blue:198.0/256.0 alpha:1];
        
        userTypetable = [[UITableView alloc]init];
        userTypetable.frame = CGRectMake(0, 60, 300, 380);
        userTypetable.hidden= NO;
        userTypetable.delegate= self;
        userTypetable.dataSource = self;
        [alertView addSubview:userTypetable];
        
        // [alertView addSubview: offerTypeSearch];
        [alertView addSubview:cancel];
        
        [userTypeAlert show];
        userTypeAlert.tag = 2;
        
        
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error in Data parsing." expObj:exception];
    } @finally {
        
    }
    
}

-(void)cancelcategory:(UIButton*)sender
{
    [userTypeAlert close];
}




-(void)updateDesign
{
    CALayer *border = [CALayer layer];
    CGFloat borderWidth = 1;
    border.borderColor = [UIColor lightGrayColor].CGColor;
    border.borderWidth = borderWidth;//
    
    [self setBorderToTextBox:self.StoreNameView];
    [self setBorderToTextBox:self.categoriesView];
    [self setBorderToTextBox:self.DescriptionView];
    [self setBorderToTextBox:self.BranchNameView];
    [self setBorderToTextBox:self.NotificationView];
    [self setBorderToTextBox:self.LocationView];
    [self setBorderToTextBox:self.ContactPersonView];
    [self setBorderToTextBox:self.ContactNoView];
    [self setBorderToTextBox:self.EmailIDView];
     [self setBorderToTextBox:self.ActivationView];
    [self setBorderToTextBox:self.RadiousView];

}

- (void) setBorderToTextBox:(UIView*)textBoxFeildName {
    @try {
        
        textBoxFeildName.layer.borderColor = [UIColor colorWithRed:198.0/256.0 green:198.0/256.0 blue:198.0/256.0 alpha:1].CGColor;
        textBoxFeildName.layer.borderWidth=1;
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
}

- (void) showAlertPop:(NSString*)alertText expObj:(NSException*) exp{
    if(exp != nil)
    {
        NSLog(@"%@", exp.description);
    }
    UIAlertController *myAlertController =[mWebservice  alert:alertText];
    [self presentViewController:myAlertController animated:YES completion:nil];
}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void) viewDidLayoutSubviews {
    
    @try {
        
        
        [super viewDidLayoutSubviews];
        [self.ScrollView layoutIfNeeded];
        self.ScrollView.contentSize=self.ContentView.bounds.size;
        UIGraphicsBeginImageContext(self.view.frame.size);
        UIImage *image = UIGraphicsGetImageFromCurrentImageContext();
        UIGraphicsEndImageContext();
        image= [UIImage imageNamed:@"bgerror.png"];
        self.ContentView.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"bgerror.png"]];
        self.view.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"bgerror.png"]];
        
       
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
}


-(void)showGallery
{
    @try {
        
       // nonseltcolor = toolBarView.backgroundColor;
        //camera =[[UIButton alloc]initWithFrame:CGRectMake(50, 35, 40, 40)];
        self.cameraBtn.frame = CGRectMake(300, 70, self.cameraBtn.frame.size.width, self.cameraBtn.frame.size.height);
        
        
        self.cameraBtn.layer.cornerRadius = 0.5 * self.cameraBtn.bounds.size.width;
        [self.cameraBtn addTarget:self action:@selector(camera:) forControlEvents:UIControlEventTouchUpInside];
        self.cameraBtn.backgroundColor =[UIColor cyanColor];
        [self.cameraBtn setImage:[UIImage imageNamed:@"camera.png"] forState:UIControlStateNormal];
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
}
-(void)camera:(id)sender
{
    @try {
        
        
        UIAlertController * view=   [UIAlertController
                                     alertControllerWithTitle:@"Right Place Right Time"
                                     message:nil
                                     preferredStyle:UIAlertControllerStyleActionSheet];
        
        UIAlertAction* photo = [UIAlertAction
                                actionWithTitle:@"Take Photo"
                                style:UIAlertActionStyleDefault
                                handler:^(UIAlertAction * action)
                                {
                                    //Do some thing here
                                    [view dismissViewControllerAnimated:YES completion:nil];
                                    
                                    UIImagePickerController *picker = [[UIImagePickerController alloc] init];
                                    picker.delegate = self;
                                    picker.allowsEditing = YES;
                                    picker.sourceType = UIImagePickerControllerSourceTypeCamera;
                                    
                                    [self presentViewController:picker animated:YES completion:NULL];
                                    
                                    
                                    
                                }];
        UIAlertAction* gallery = [UIAlertAction
                                  actionWithTitle:@"Chose from Gallery"
                                  style:UIAlertActionStyleDefault
                                  handler:^(UIAlertAction * action)
                                  {
                                      UIImagePickerController *picker = [[UIImagePickerController alloc] init];
                                      picker.delegate = self;
                                      picker.allowsEditing = YES;
                                      picker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
                                      
                                      [self presentViewController:picker animated:YES completion:NULL];
                                      
                                      
                                      
                                      [view dismissViewControllerAnimated:YES completion:nil];
                                      
                                  }];
        
        UIAlertAction* cancel = [UIAlertAction
                                 actionWithTitle:@"Cancel"
                                 style:UIAlertActionStyleDefault
                                 handler:^(UIAlertAction * action)
                                 {
                                     [view dismissViewControllerAnimated:YES completion:nil];
                                     
                                 }];
        
        
        
        [view addAction:photo];
        [view addAction:gallery];
        [view addAction:cancel];
        [self presentViewController:view animated:YES completion:nil];
        
    }
    @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    }
    @finally {
        
    }
}

- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info {
    @try {
        
        
        self.photoScroll.hidden= NO;
        
        self.ScrollView.frame= CGRectMake(0,self.photoScroll.frame.size.height+80, self.ScrollView.frame.size.width, self.ScrollView.frame.size.height+200);
        self.ContentView.frame = CGRectMake(self.ScrollView.frame.origin.x+5,6, self.ContentView.frame.size.width,self.ContentView.frame.size.height+270);
        
        
        
        UIImage *chosenImage = info[UIImagePickerControllerEditedImage];
        
        
        self.photoImg.image = nil;
        
                [Images addObject:chosenImage];
            
            if ([Images count]==1) {
                
                self.photoImg.image = chosenImage;
             
            }
            else if ([Images count]>1) {
                self.photoImg.image = nil;
                [self setImageToImageFrame];
            }
            
     //   }
    
//            if ([Images count]==1) {
//                self.photoImg.image = chosenImage;
//                self.camera.frame = CGRectMake(self.camera.frame.origin.x+100, self.camera.frame.origin.y+130, self.camera.frame.size.width, self.camera.frame.size.height);
//                
//            }
//            
//            else if ([Images count]>1) {
//                self.imgs.image = nil;
//                [self setImageToImageFrame];
//            }
       // }
        
        [picker dismissViewControllerAnimated:YES completion:NULL];
    }
    @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    }
    @finally {
        
    }
    
}

-(void)setImageToImageFrame
{
    
    //imgs.image = nil
    
    
    self.photoImg.image = nil;
    
    
    [self.photoScroll setPagingEnabled:YES];
    [self.photoScroll setAlwaysBounceVertical:NO];
    [self.photoScroll setScrollEnabled:YES];
    //NSArray *imagesArray = Images;
    UIImageView *imageView ;
    for (int i = 0; i < [Images count]; i++)
    {
        CGFloat xOrigin = i * self.photoScroll.frame.size.width;
        
        imageView = [[UIImageView alloc] initWithFrame:CGRectMake(xOrigin, 0, self.photoScroll.frame.size.width, self.photoScroll.frame.size.height)];
        [imageView setImage:[Images objectAtIndex:i]];
        [imageView setContentMode:UIViewContentModeScaleAspectFit];
        imageView.userInteractionEnabled=YES;
        
        
        UITapGestureRecognizer *imageTapping = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(imageTapped:)];
        [imageView addGestureRecognizer:imageTapping];
        
        [self.photoScroll addSubview:imageView];
    }
    
    [self.photoScroll setContentSize:CGSizeMake(self.photoScroll.frame.size.width * [Images count], self.self.photoScroll.frame.size.height)];
    

    
    
    
//    CGRect workingFrames =CGRectMake(self.photoScroll.frame.origin.x, self.photoScroll.frame.origin.y-70, self.photoScroll.frame.size.width+10, self.photoScroll.frame.size.height);
//    self.photoImg.hidden= YES;
//    self.photoImg.image = nil;
//    
//    //[ImageView setNeedsDisplay];
//    
//    
//UIImageView   *ImageView;
//    
//    for (int i=0 ; i<[Images count] ;i++)
//    {
//        ImageView.tag=[Images count]-i;
//        UIImage *im= [Images objectAtIndex:i];
//        
//        CGSize size = CGSizeMake(500, 500);//[self image:img scaledToSize:size]
//        
//        
//        ImageView = [[UIImageView alloc] initWithImage:[mTimeCalculator image:im scaledToSize:size]];
//        
//        [ImageView setContentMode:UIViewContentModeScaleAspectFit];
//        
//        ImageView.frame = workingFrames;
//        // ImageView.frame = CGRectMake(workingFrames.origin.x, 0, workingFrames.size.width+150, workingFrames.size.height+150);
//        
//        // NSLog(@"%@",workingFrame);
//        [self.photoScroll addSubview:ImageView];
//        
//        
////        ImageView.userInteractionEnabled=YES;
////        
////        
////        UITapGestureRecognizer *imageTapping = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(imageTapped:)];
////        [ImageView addGestureRecognizer:imageTapping];
//        
//        
//        workingFrames.origin.x = workingFrames.origin.x + workingFrames.size.width;
//        
//    }
//    
//    
//    [self.photoScroll setPagingEnabled:YES];
//    
//    [self.photoScroll setContentSize:CGSizeMake(workingFrames.origin.x, workingFrames.size.height)];
}



-(IBAction)back:(id)sender
{
    [self dismissViewControllerAnimated:YES completion:nil];
}


-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    @try {
        
        
        if (tableView == userTypetable) {
            
            return  [userTypes count];
        }
        
        if (categoryTable== tableView) {
            return [categoryItems count];
        }
        else if (radTable == tableView)
        {
            return  [radiusItems count];
        }
        
        else if (tableView == autocompleAddressTable)
        {
            return [autocompleAddress count];
        }
        
        
        // return [autocompleteAddress count];
    }
    @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    }
    @finally {
        
    }
    
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    return 50;
    
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    @try {
        
        // UITableViewCell *cell= nil;
        if (tableView == userTypetable) {
            static NSString *CellIdentifier = @"Cell";
            // Reuse and create cell
            UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
            if (cell == nil) {
                cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
            }
            NSDictionary     *type = [userTypes objectAtIndex:indexPath.row];
            cell.textLabel.text = [type valueForKey:@"LookupValue"];
            return cell;
            
        }
        
        if (tableView == categoryTable) {
            
          
            static NSString *CellIdentifier = @"Cell";
            // Reuse and create cell
            UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
            if (cell == nil) {
                cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
            }
            NSString *Addreline =[categoryItems[indexPath.row] valueForKey:@"CategoryName"];;
            cell.textLabel.text = Addreline;
            return cell;
            

            
            
            
            
            
            
//            Setting_Cell *cell = (Setting_Cell *)[tableView dequeueReusableCellWithIdentifier:@"Setting_Cell"];
//            if (cell == nil)
//            {
//                NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"Setting_Cell" owner:self options:nil];
//                cell = [nib objectAtIndex:0];
//            }
//            // tableView.backgroundColor = [UIColor blackColor];
//            
//            
//            
//            cell.categoryName.text = [categoryItems[indexPath.row] valueForKey:@"CategoryName"];
//            
//            if ([checkedCateIds containsObject:[categoryItems[indexPath.row] valueForKey:@"CategoryID"]]) {
//                cell.check.image=[UIImage imageNamed:@"aftercheck.png"];
//            }
//            else{
//                cell.check.image=[UIImage imageNamed:@"beforecheck.png"];
//            }
            
            
            //            if([self.checkedArray containsObject:indexPath]){
            //                cell.check.image=[UIImage imageNamed:@"aftercheck.png"];
            //                // cell.check.backgroundColor = [UIColor lightGrayColor];
            //            } else
            //                cell.check.image=[UIImage imageNamed:@"beforecheck.png"];//uncheck.png
            
            return cell;
        }
        
        else if (tableView == radTable)
        {
            static NSString *CellIdentifier = @"Cell";
            // Reuse and create cell
            UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
            if (cell == nil) {
                cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
            }
            NSString *Addreline = [[radiusItems objectAtIndex:indexPath.row] valueForKey:@"Value"];
            cell.textLabel.text = Addreline;
            return cell;
            
            
        }
        
        else if (tableView == autocompleAddressTable)
        {
            static NSString *CellIdentifier = @"Cell";
            // Reuse and create cell
            UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
            if (cell == nil) {
                cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
            }
            NSString *Addreline = [autocompleAddress objectAtIndex:indexPath.row];
            cell.textLabel.text = Addreline;
            return cell;
            
        }
        
        
        
    }
    @catch (NSException *exception) {
        
    } @finally {
        
    }
    
    
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
    @try {
        
        if (tableView == userTypetable) {
            
            NSDictionary *selctedCategory = [userTypes objectAtIndex:indexPath.row];
            SelectedType = selctedCategory;
            self.category.text = [selctedCategory valueForKey:@"LookupValue"];
//            self.conatctPersonName.placeholder = [NSString stringWithFormat:@"%@ name", [selctedCategory valueForKey:@"LookupValue"]];
            // [alertController dismissViewControllerAnimated:YES completion:nil];
            [userTypeAlert close];
            //autoComplete.hidden = YES;
            
            //[userTypes resignFirstResponder];
        }
        
        if (tableView == categoryTable) {
            
           // NSString *catId = [[categoryItems objectAtIndex:indexPath.row] valueForKey:@"CategoryID"];
            [self.notificationBtn setTitle:[[categoryItems objectAtIndex:indexPath.row] valueForKey:@"CategoryName"]  forState:UIControlStateNormal];
            selectedCategoryID =[NSString stringWithFormat:@"%@",[[categoryItems objectAtIndex:indexPath.row] valueForKey:@"CategoryID"]];
                [checkedArray addObject:indexPath];
            
            [categoryAlert close];
         //   [tableView reloadData];
            
        }
        else if (tableView == radTable)
        {
            selectedRadius =[[radiusItems objectAtIndex:indexPath.row] valueForKey:@"Radious"];
            // NSString   *selectedrad =[[radiusItems objectAtIndex:indexPath.row] valueForKey:@"Radious"];
            [self.radiouBtn setTitle:[[radiusItems objectAtIndex:indexPath.row] valueForKey:@"Value"] forState:UIControlStateNormal];
            [categoryAlert close];
            
            //[radTable setHidden:YES];
        }
        
        if (tableView == autocompleAddressTable) {
            
            autocompleAddressTable.hidden = YES;
            
            NSString *selectedAdress = [autocompleAddress objectAtIndex:indexPath.row];
            
            self.location.text = selectedAdress;
            [self.location resignFirstResponder];
            
            //-(CLLocationCoordinate2D) getLocationFromAddressString: (NSString*) addressStr
            
            CLLocationCoordinate2D coord = [[CurrentLocation alloc] getLocationFromAddressString:selectedAdress];
            
            latLong = [NSString stringWithFormat:@"%f,%f",coord.latitude,coord.longitude];
            
        }
        
    }
    @catch(NSException *ex)
    {
        
    }
    @finally
    {
        
    }
}


-(IBAction)selectCategory:(id)sender
{
    [self ImageTap];
}
-(IBAction)seletcRadius:(id)sender
{
    [self radiusTap];
    
}
-(IBAction)selectlocation:(id)sender
{
    
}
-(void)ImageTap{
    
    @try {
        
        categoryAlert=[[CustomIOSAlertView alloc] init];
        UIView  *imageView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 300, 400)];
        [categoryAlert setContainerView:imageView];
        [categoryAlert setButtonTitles:[NSMutableArray arrayWithObjects:@"", nil]];
        
        [categoryAlert setDelegate:self];
        
        
        // You may use a Block, rather than a delegate.
        [categoryAlert setOnButtonTouchUpInside:^(CustomIOSAlertView *alertView, int buttonIndex) {
            NSLog(@"Block: Button at position %d is clicked on alertView %d.", buttonIndex, (int)[alertView tag]);
            [alertView close];
        }];
        
        [categoryAlert setUseMotionEffects:true];
        
        UIButton *cancel = [[UIButton alloc]initWithFrame:CGRectMake(275, 0, 20, 20)];
        
        [cancel setImage:[UIImage imageNamed:@"ic_close"] forState:UIControlStateNormal];
        [cancel addTarget:self action:@selector(cancel:) forControlEvents:UIControlEventTouchUpInside];
        
        categoryTable.frame = CGRectMake(0, 20, 300, 400);
        [imageView addSubview:categoryTable];
        
        [imageView addSubview:cancel];
        
        
        [categoryAlert show];
        categoryAlert.tag = 2;
        
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error in Data parsing." expObj:exception];
    } @finally {
        
    }
    
    
    //ImageAlert = [CustomIOSAlertView ]
}

-(void)cancel:(UIButton*)sender
{
    [categoryAlert close];
    
    selectedCategories = [self selectedCategories];
    
    [self.notificationBtn setTitle: [NSString stringWithFormat:@"%@",[selectedCategories valueForKey:@"CategoryName"]] forState:UIControlStateNormal];
    [self.notificationBtn setTitle:[self selectedCategoryname:checkedCateIds] forState:UIControlStateNormal];
    
    
}

-(NSString*)selectedCategoryname:(NSMutableArray*)catIds
{
    NSMutableArray *catname= [[NSMutableArray alloc]init];
    for (int i=0; i<[catIds count]; i++) {
        
        for (int j=0; j<[categoryItems count]; j++) {
            
            if ([[[categoryItems objectAtIndex:j] valueForKey:@"CategoryID"] isEqualToString:[catIds objectAtIndex:i]]) {
                
                [catname addObject:[[categoryItems objectAtIndex:j] valueForKey:@"CategoryName"]];
                
            }
        }
        
        
    }
    
    
    return [catname componentsJoinedByString:@","];
}

-(NSString*)selectedRadius:(NSString*)radius
{
    
    radius =[NSString stringWithFormat:@"%@",radius];
    
    NSString *radio ;
    for (int i=0; i<[radiusItems count]; i++) {
        if ([[[radiusItems objectAtIndex:i] valueForKey:@"Radious"] isEqualToString:radius]) {
            radio =[[radiusItems  objectAtIndex:i] valueForKey:@"Value"];
            return radio;
        }
    }
    return radio;
}

- (IBAction)changeSwitch:(id)sender{
    
    if([sender isOn]){
        checkedCateIds = finalCheckedarry;
        [categoryTable reloadData];
        NSString *names=[self selectedCategoryname:checkedCateIds];
        if([checkedCateIds count]==0)
        {
            [self.notificationBtn setTitle:@"Select category" forState:UIControlStateNormal];
        }
        
        else [self.notificationBtn setTitle:names forState:UIControlStateNormal];
        
        NSLog(@"Switch is ON");
    } else{
        
        checkedCateIds =nil;
        [categoryTable reloadData];
        [self.notificationBtn setTitle:@"Select category" forState:UIControlStateNormal];
        NSLog(@"Switch is OFF");
    }
    
}


-(NSDictionary*)selectedCategories
{
    
    NSMutableArray *arryResponceData=[[NSMutableArray alloc]init];
    NSMutableArray *arryCatIDs=[[NSMutableArray alloc]init];
    
    
    
    for (int i=0; i<[checkedArray count]; i++) {
        NSIndexPath *path=[checkedArray objectAtIndex:i];
        NSString *res = [[categoryItems objectAtIndex:path.row] valueForKey:@"CategoryName"];
        
        [arryResponceData addObject:res];
        
        NSString *catId = [[categoryItems objectAtIndex:path.row] valueForKey:@"CategoryID"];
        [arryCatIDs addObject:catId];
        
        
    }
    
    NSMutableDictionary *category = [[NSMutableDictionary alloc]init];
    [category setValue:[arryResponceData componentsJoinedByString:@","]  forKey:@"CategoryName"];
    [category setValue:[arryCatIDs componentsJoinedByString:@","]  forKey:@"CategoryID"];
    
    
    //   NSString *categorystring =[arryResponceData componentsJoinedByString:@" & "];
    return category;
}


-(void)radiusTap{
    
    @try {
        
        categoryAlert=[[CustomIOSAlertView alloc] init];
        UIView  *imageView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 300, 300)];
        [categoryAlert setContainerView:imageView];
        [categoryAlert setButtonTitles:[NSMutableArray arrayWithObjects:@"", nil]];
        
        [categoryAlert setDelegate:self];
        
        
        // You may use a Block, rather than a delegate.
        [categoryAlert setOnButtonTouchUpInside:^(CustomIOSAlertView *alertView, int buttonIndex) {
            NSLog(@"Block: Button at position %d is clicked on alertView %d.", buttonIndex, (int)[alertView tag]);
            [alertView close];
        }];
        
        [categoryAlert setUseMotionEffects:true];
        
        UIButton *cancel = [[UIButton alloc]initWithFrame:CGRectMake(275, 0, 20, 20)];
        
        [cancel setImage:[UIImage imageNamed:@"ic_close"] forState:UIControlStateNormal];
        [cancel addTarget:self action:@selector(closeradius:) forControlEvents:UIControlEventTouchUpInside];
        
        radTable.frame = CGRectMake(0, 20, 300, 300);
        [imageView addSubview:radTable];
        
        [imageView addSubview:cancel];
        
        
        [categoryAlert show];
        categoryAlert.tag = 2;
        
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error in Data parsing." expObj:exception];
    } @finally {
        
    }
    
    
    //ImageAlert = [CustomIOSAlertView ]
}

-(void)closeradius:(UIButton*)sender
{
    [categoryAlert close];
    
    // selectedCategories = [self selectedCategories];
}

-(IBAction)hydeKeyBoard:(id)sender
{
    if ([self.storeName isFirstResponder]) {
        [self.storeName resignFirstResponder];
    }
    else if( [self.branchName isFirstResponder])
    {
        [self.branchName resignFirstResponder];
    }
    else if( [self.location isFirstResponder])
    {
        [self.location resignFirstResponder];
    }
    else if ([self.contactPerson isFirstResponder])
    {
        [self.contactPerson resignFirstResponder];
    }
    else if ([self.contactNumber isFirstResponder])
    {
        [self.contactNumber resignFirstResponder];
    }
    else if([self.emailId isFirstResponder])
    {
        [self.emailId resignFirstResponder];
    }
    
    else if([self.storeDescription isFirstResponder])
    {
        [self.storeDescription resignFirstResponder];
    }

}

-(void)textFieldDidEndEditing:(UITextField *)textField
{
    if (textField == self.storeName) {
        [self.storeName resignFirstResponder];
    }
    else if(textField == self.branchName)
    {
        [self.branchName resignFirstResponder];
    }
    else if(textField == self.location)
    {
        [self.location resignFirstResponder];
    }
    else if (textField == self.contactPerson)
    {
        [self.contactPerson resignFirstResponder];
    }
    else if (textField == self.contactNumber)
    {
        [self.contactNumber resignFirstResponder];
    }
    else if(textField == self.emailId)
    {
        [self.emailId resignFirstResponder];
    }
}

-(void)textViewDidEndEditing:(UITextView *)textView
{
    if (textView == self.storeDescription) {
        [self.storeDescription resignFirstResponder];
    }
}

#pragma mark -UITextFiledAnimations

- (IBAction)textFieldDidBeginEditing:(id)textField {
    @try {
        
        
        
        
        [self animateTextField:textField up:YES];
    }
    @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    }
    @finally {
        
    }
    
}

- (IBAction)textFieldDidEndEditing1:(id)textField {
    @try {
        
        [self animateTextField:textField up:NO];
    }
    @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    }
    @finally {
        
    }
}

- (void)animateTextField:(UITextField *)textField up:(BOOL)up {
    @try {
        
        if (textField== self.location || textField == self.contactNumber || textField== self.contactPerson || self.emailId== textField || textField== self.branchName) {
            
            int animatedDistance;
            // int moveUpValue = textField.frame.origin.y + textField.frame.size.height;
            UIInterfaceOrientation orientation =
            [[UIApplication sharedApplication] statusBarOrientation];
            if (orientation == UIInterfaceOrientationPortrait ||
                orientation == UIInterfaceOrientationPortraitUpsideDown) {
                
               // if (textField== Address)  animatedDistance = 280 - (250 - 130 - 5);
                
                 animatedDistance = 280 - (250 - 50 - 5);
            } else {
                
               // if (textField== Address)  animatedDistance = 162 - (320 - 80 - 5);
                
                  animatedDistance = 162 - (320 - 50 - 5);
            }
            
            if (animatedDistance > 0) {
                NSString *deviceType = [[UIDevice currentDevice] model];
                
                if ([deviceType isEqualToString:@"iPad"]) {
                }
                
                const int movementDistance = animatedDistance;
                const float movementDuration = 0.3f;
                int movement = (up ? -movementDistance : movementDistance);
                [UIView beginAnimations:nil context:nil];
                [UIView setAnimationBeginsFromCurrentState:YES];
                [UIView setAnimationDuration:movementDuration];
                self.ContentView.frame = CGRectOffset(self.ContentView.frame, 0, movement);
                [UIView commitAnimations];
            }
        }
        
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    }
}

-(void)getStoreImages
{
    NSMutableArray *imagebyteArray = [NSMutableArray array];
    UIImage *yourImage;
    
    
    if ([Images count]!=0) {
        
        for(int i=0; i < [Images count]; i++)
        {
            yourImage=[Images objectAtIndex:i];
            
            yourImage = [self resizeImage:yourImage];
            NSData *data = UIImagePNGRepresentation(yourImage);
            NSString *base64String = [data base64EncodedStringWithOptions:0];
            [imagebyteArray addObject:base64String];
        }
        if ([imagebyteArray count]==0) {
            encodecImage =@"";
        }
        else{
            encodecImage = [imagebyteArray componentsJoinedByString:@","];
        }
    }
    else
    {
        [self showAlertPop:@"Please select Photos" expObj:nil];
        
    }

}

-(UIImage *)resizeImage:(UIImage *)image
{
    
    @try {
        
        float actualHeight = image.size.height;
        float actualWidth = image.size.width;
        float maxHeight = 300.0;
        float maxWidth = 400.0;
        float imgRatio = actualWidth/actualHeight;
        float maxRatio = maxWidth/maxHeight;
        float compressionQuality = 0.5;//50 percent compression
        
        if (actualHeight > maxHeight || actualWidth > maxWidth)
        {
            if(imgRatio < maxRatio)
            {
                //adjust width according to maxHeight
                imgRatio = maxHeight / actualHeight;
                actualWidth = imgRatio * actualWidth;
                actualHeight = maxHeight;
            }
            else if(imgRatio > maxRatio)
            {
                //adjust height according to maxWidth
                imgRatio = maxWidth / actualWidth;
                actualHeight = imgRatio * actualHeight;
                actualWidth = maxWidth;
            }
            else
            {
                actualHeight = maxHeight;
                actualWidth = maxWidth;
            }
        }
        
        CGRect rect = CGRectMake(0.0, 0.0, actualWidth, actualHeight);
        UIGraphicsBeginImageContext(rect.size);
        [image drawInRect:rect];
        UIImage *img = UIGraphicsGetImageFromCurrentImageContext();
        NSData *imageData = UIImageJPEGRepresentation(img, compressionQuality);
        UIGraphicsEndImageContext();
        
        return [UIImage imageWithData:imageData];
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
    
    
}

-(IBAction)createAccount:(id)sender
{
    @try
    {
        
        if (isOnlineStatus) {
            
            [self getStoreImages];
            
            if ( [self textfieldValidation]) {
                
                spinner = [[UIActivityIndicatorView alloc]
                           initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
                spinner.frame = CGRectMake(0, 0, 375, 600); // CGPointMake(160, 240);
                spinner.color = [UIColor blueColor];
                spinner.backgroundColor = [UIColor lightTextColor];
                spinner.transform = CGAffineTransformMakeScale(2, 2);
                // spinner.hidesWhenStopped = YES;
                [self.view addSubview:spinner];
                spinner.transform = CGAffineTransformMakeScale(2, 2);
                
                [spinner startAnimating];
                
                // how we stop refresh from freezing the main UI thread
                
                dispatch_async(
                               dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^{
                                   
                                   // back to the main thread for the UI call
                                   dispatch_async(dispatch_get_main_queue(), ^{
                                       [spinner startAnimating];
                                   });
                                   dispatch_async(dispatch_get_main_queue(), ^{
                                       @try {
                                           //  if(![encodecImage isEqualToString:@""])
                                           //{
                                           
                                           //   if ( [self textfieldValidation]) {
                                           
                                           //  if ([self validateRegisteredPhoneNo]) {
                                           
                                           
                                           NSUserDefaults *pref = [NSUserDefaults standardUserDefaults];
                                           
                                           NSString *SaveUserID = [pref objectForKey:@"SaveUserID"];
                                           if (SaveUserID==nil) {
                                               SaveUserID= @"0";
                                           }
                                           UserRegistedID = [pref valueForKey:USERREGISTERID];
                                           
                                           if (UserRegistedID !=nil) {
                                               
                                           }
                                           else if (UserRegistedID ==nil) {
                                               UserRegistedID = @"0";
                                           }
                                           
                                           NSLog(@"name: %@", [[UIDevice currentDevice] name]);
                                           NSLog(@"systemName: %@", [[UIDevice currentDevice] systemName]);
                                           NSLog(@"systemVersion: %@", [[UIDevice currentDevice] systemVersion]);
                                           NSLog(@"model: %@", [[UIDevice currentDevice] model]);
                                           NSLog(@"localizedModel: %@", [[UIDevice currentDevice] localizedModel]);
                                           NSString *uniqueIdentifier = [[[UIDevice currentDevice] identifierForVendor] UUIDString];
                                           UserSelectedCat = @"Business";
                                           
                                           
//                                           { "UserRegisterID": 1, "UserID": 2, "UserSelectedCat": "sample string 3", "PhotoName": "sample string 4", "LandLine": "sample string 5", "ContactPerson": "sample string 6", "Password": "sample string 7", "Time": "sample string 8", "PhoneNo": "sample string 9", "RegUserName": "sample string 10", "RegEmail": "sample string 11", "UserType": 12, "DeviceOS": "sample string 13", "OsVersion": "sample string 14", "LoginType": "sample string 15", "DeviceId": "sample string 16", "AlreadyPresent": true, "DefaultRadius": 18, "DefaultAddress": "sample string 19", "LoggedUserType": "sample string 20", "UserBusinessType": "sample string 21", "CategoryId": 22, "StoreDescription": "sample string 23", "ActivationCode": "sample string 24", "BusinessPlan": "sample string 25", "RelatedId": 26, "BranchName": 27, "IsBranch": true, "ParentStore": 29 }
                                           
                                           UserRegistedID = [editedDetils valueForKey:@"BusinessRegisterID"];
                                           
                                           
                                           NSDictionary *locationInput  = @{
                                                                            @"UserRegisterID":UserRegistedID,
                                                                            @"UserID":@"0" ,
                                                                            @"UserSelectedCat":@"Business",
                                                                            @"PhotoName":encodecImage,
                                                                            @"LandLine":@"",
                                                                            @"ContactPerson":self.storeName.text,
                                                                            @"Password":@"",
                                                                            @"Time":@"60",
                                                                            @"PhoneNo":self.contactNumber.text,
                                                                            @"RegUserName":self.contactPerson.text,
                                                                            @"RegEmail":self.emailId.text,
                                                                            @"UserType":[SelectedType valueForKey:@"LookupID"],
                                                                            @"DeviceOS":[[UIDevice currentDevice] model],
                                                                            @"OsVersion":[[UIDevice currentDevice] systemVersion],
                                                                            @"LoginType":LoginType,
                                                                            @"DeviceId":uniqueIdentifier,
                                                                            @"AlreadyPresent": @"true",
                                                                            @"DefaultRadius": @"1000",
                                                                            @"DefaultAddress": self.location.text,
                                                                            @"LoggedUserType": [SelectedType valueForKey:@"LookupValue"],
                                                                            @"UserBusinessType": @"Business",
                                                                            @"CategoryId":selectedCategoryID,
                                                                            @"StoreDescription":self.storeDescription.text,
                                                                            @"ActivationCode":self.ActivationCode.text,
                                                                            @"BusinessPlan": @"",
                                                                            @"RelatedId": [editedDetils valueForKey:@"IndividualRegisterID"],
                                                                            @"BranchName": self.branchName.text,
                                                                            @"IsBranch": @"true",
                                                                            @"ParentStore": @""
                                                                            };
                                           
                                           NSDictionary *storeResponse = [mWebservice SaveStoreRegister:locationInput];
                                           
                                           
                                           
                                           NSDictionary *userSettingResponse = [self SaveuserSeetings:storeResponse];
                                           
                                           if([storeResponse valueForKey:USERREGISTERID]!=nil)
                                           {
                                               NSMutableArray *arryResponse = storeResponse;
                                               NSString *BusinessRegID;
                                               NSString *IndividualRegID;;
                                               
                                               if ([arryResponse count]==1) {
                                                    BusinessRegID = [[arryResponse objectAtIndex:0] valueForKey:@"UserRegisterID"];
                                                   
                                                   NSData  *VendorData =    [mPref valueForKey:@"SaveRegisterDetails"];
                                                  NSDictionary *myDictionary =   (NSDictionary*) [NSKeyedUnarchiver unarchiveObjectWithData:VendorData];

                                                   
                                                   
                                                    IndividualRegID = [myDictionary valueForKey:@"IndividualRegisterID"];
                                               }
                                               
                                               else
                                               {
                                               for (int i=0; i<[arryResponse count];i++) {
                                                   if ([[[arryResponse objectAtIndex:i] valueForKey:@"UserBusinessType"] isEqualToString:@"Business"]) {
                                                       BusinessRegID = [[arryResponse objectAtIndex:i] valueForKey:@"UserRegisterID"];
                                                   }
                                                   else  if ([[[arryResponse objectAtIndex:i] valueForKey:@"UserBusinessType"] isEqualToString:@"Individual"]) {
                                                       IndividualRegID = [[arryResponse objectAtIndex:i] valueForKey:@"UserRegisterID"];
                                                   }

                                               }
                                               }
                                               
                                               NSMutableDictionary *registerDatavia = [[NSMutableDictionary alloc]init];
                                               
                                               [registerDatavia setValue:[[arryResponse objectAtIndex:0] valueForKey:@"LoginType"] forKey:@"LoginType"];
                                               [registerDatavia setValue:BusinessRegID forKey:USERREGISTERID];
                                               [registerDatavia setValue:[[arryResponse objectAtIndex:0] valueForKey:@"DefaultRadius"] forKey:@"DefaultRadius"];

                                               [registerDatavia setValue:BusinessRegID forKey:@"BusinessRegisterID"];
                                               [registerDatavia setValue:IndividualRegID forKey:@"IndividualRegisterID"];
                                               [registerDatavia setValue:[[arryResponse objectAtIndex:0] valueForKey:@"PhotoName"] forKey:@"PhotoName"];
                                               //[registerDatavia setValue: forKey:@"PhotoName"];
                                               [registerDatavia setValue:[[arryResponse objectAtIndex:0] valueForKey:@"DefaultAddress"] forKey:@"DefaultAddress"];
                                               
                                               if ([arryResponse count]==1) {
                                                   NSDictionary *BusinessRecoed=@{@"StoreDescription":[[arryResponse objectAtIndex:0] valueForKey:@"StoreDescription"],
                                                                                  @"ContactPerson":[[arryResponse objectAtIndex:0] valueForKey:@"ContactPerson"],
                                                                                  @"BranchName":[[arryResponse objectAtIndex:0] valueForKey:@"BranchName"],
                                                                                  @"PhotoName":[[arryResponse objectAtIndex:0] valueForKey:@"PhotoName"]
                                                                                  };
                                                 
                                                   [registerDatavia setValue:BusinessRecoed forKey:@"BusinessDeatils"];
                                                   
                                                   
                                                   NSData  *VendorData =    [mPref valueForKey:@"SaveRegisterDetails"];
                                                   NSDictionary *myDictionary =   (NSDictionary*) [NSKeyedUnarchiver unarchiveObjectWithData:VendorData];
                                                   
                                                   NSDictionary *individualRecord=@{@"StoreDescription":[myDictionary valueForKey:@"StoreDescription"],
                                                                                  @"ContactPerson":[myDictionary valueForKey:@"ContactPerson"],
                                                                                  @"BranchName":[myDictionary valueForKey:@"BranchName"],
                                                                                  @"PhotoName":[myDictionary valueForKey:@"PhotoName"]
                                                                                  };

                                                   [registerDatavia setValue:individualRecord forKey:@"IndividualDeatils"];
                                               
                                               
                                               }
                                               
                                        
                                               
                                               
                                               
                                               
                                               
                                               [registerDatavia setValue:[[arryResponse objectAtIndex:0] valueForKey:@"RegUserName"] forKey:@"RegUserName"];
                                               [registerDatavia setValue:[[arryResponse objectAtIndex:0] valueForKey:@"LoggedUserType"] forKey:@"LoggedUserType"];
                                               [registerDatavia setValue:[[arryResponse objectAtIndex:0] valueForKey:@"ContactPerson"] forKey:@"ContactPerson"];
                                                [registerDatavia setValue:[[arryResponse objectAtIndex:0] valueForKey:@"BranchName"] forKey:@"BranchName"];
                                                [registerDatavia setValue:[[arryResponse objectAtIndex:0] valueForKey:@"StoreDescription"] forKey:@"StoreDescription"];
                                               [registerDatavia setValue:[userSettingResponse valueForKey:@"UserSettingsID"] forKey:@"UserSettingsID"];
                                                [mPref setValue:@"Business" forKey:LOGINTYPE];
                                               Preferences *mPreferences = [Preferences GetSharedInstance];
                                               
                                               [mPreferences SaveRegisterDeatils:registerDatavia];
                                               
                                               [mPref setObject:registerDatavia forKey:@"LoginType"];
                                             
                                               [mPreferences StoreSaveUserRegisterID:BusinessRegID];
                                               
                                               UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"Right Place Right Time"
                                                                                                              message:@"Registered Sucessfully!!"
                                                                                                       preferredStyle:UIAlertControllerStyleAlert];
                                               
                                               UIAlertAction* defaultAction = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault
                                                                                                     handler:^(UIAlertAction * action) {
                                                                                                         
                                                                                                         [self pagechangeforPostOffer];
                                                                                                         
                                                                                                         
                                                                                                     }];
                                               
                                               [alert addAction:defaultAction];
                                               
                                               [self presentViewController:alert animated:YES completion:nil];
                                               
                                               
                                               
                                               
                                               
                                               
                                               //                Posting * mPosting = [[ Posting alloc] initWithNibName:@"Posting" bundle:nil];
                                               //                [self presentViewController:mPosting animated:YES completion:nil];
                                           }
                                           NSLog(@"SaveRegister responce is %@",storeResponse);
                                           
                                           
                                           //}
                                           // }
                                           
                                           //                                           }
                                           //                                           else{
                                           //
                                           //                                               [self showAlertPop:@"Please capture profile photo." expObj:nil];
                                           //
                                           //
                                           //                                           }
                                       } @catch (NSException *exception) {
                                           [self showAlertPop:@"Error while fetching data." expObj:exception];
                                           
                                       } @finally {
                                           
                                       }
                                       
                                       [spinner stopAnimating];
                                       
                                   });
                               });
            }
        }
        else if (isOnlineStatus)
        {
            [self showAlertPop:@"the Network is down" expObj:nil];
        }
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
}

-(NSDictionary*)SaveuserSeetings:(NSDictionary*)registerResponse

{
    NSMutableArray *records = registerResponse;
    
    NSString *userRegistedId;
    
    for (int i=0; i<[records count];i++) {
        if ([[[records objectAtIndex:i] valueForKey:@"UserBusinessType"] isEqualToString:@"Business"]) {
            userRegistedId = [[records objectAtIndex:i] valueForKey:@"UserRegisterID"];
        }
    }
    
    
   // NSString *userRegistedId = [registerResponse valueForKey:USERREGISTERID];
    
    //NSString *catIds =[checkedCateIds componentsJoinedByString:@","];//[selectedCategories valueForKey:@"CategoryID"];
    
    
    NSDate *currentDateInLocal = [NSDate date];
    
    NSDateFormatter *formatter = [[NSDateFormatter alloc]init];
    [formatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
    NSTimeZone *gmt = [NSTimeZone timeZoneWithAbbreviation:@"UTC"];
    [formatter setTimeZone:gmt];
    NSString *StartTimecon = [formatter stringFromDate:currentDateInLocal];
    
    NSDictionary *usersettingObj = @{@"UserSettingsID":UserSettingsID,
                                     @"UserID":userRegistedId,
                                     @"SendNotifications":@"true",
                                     @"NotifyCategories":selectedCategoryID,
                                     @"DefaultRadius":selectedRadius,
                                     @"DefaultAddress":self.location.text,
                                     @"UserIdCreated":userRegistedId,
                                     @"CreatedDate":StartTimecon,
                                     @"UserIdModified":userRegistedId,
                                     @"ModifiedDate":StartTimecon,
                                     @"RowStatus":@"A",
                                     @"LatLong":latLong
                                     };
    NSDictionary *response = [mWebservice SaveUserSettings:usersettingObj];
    
    return response ;
}


-(void)pagechangeforPostOffer
{
    @try {
        //[mPref setValue:HHOME forKey:@"SideMenu"];
        Home * mHome = [[ Home alloc] initWithNibName:HOMEDASHBOARD bundle:nil];
        [self presentViewController:mHome animated:YES completion:nil];
        
    }
    @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    }
    @finally {
        
    }
}

- (BOOL)validMobileNumber:(NSString *)mobilenumber {
    
    @try {
        
        NSString *phoneRegex = @"^((\\+)|(00))[0-9]{6,14}$";
        NSPredicate *phoneTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", phoneRegex];
        
        return [phoneTest evaluateWithObject:mobilenumber];
        
        
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    }
}


-(void)textViewDidBeginEditing:(UITextView *)textView
{
    self.storeDescription.text = @"";
}


-(BOOL)textfieldValidation
{
    @try {
        
        if ([self.emailId.text isEqualToString:@""]) {
             [self showAlertPop:@" enter emailID" expObj:nil];
               return NO;
        }
        if ([self.contactPerson.text isEqualToString:@""]) {
            [self showAlertPop:@"enter Contact person name" expObj:nil];
            return NO;
        }
        if ([self.storeName.text isEqualToString:@""]) {
            [self showAlertPop:@"enter store name" expObj:nil];
            return NO;
        }
        if ([self.storeDescription.text isEqualToString:@""]) {
            
            
            [self showAlertPop:@"enter store description" expObj:nil];
            return NO;
        }
        
        if ([self.contactNumber.text isEqualToString:@""]) {
            [self showAlertPop:@"please enter MobileNumber" expObj:nil];
            return NO;
        }
        
        else  if ([self.contactNumber.text length] < 10 ) {
            [self.contactNumber resignFirstResponder];
            
            [self showAlertPop:@"Invalid Phone OR enter 10 no. only." expObj:nil];
            return NO;
        }
        else if([self validMobileNumber:self.contactNumber.text])
        {
            [self.contactNumber resignFirstResponder];
            
            [self showAlertPop:@"Invalid Phone number" expObj:nil];
            return NO;
        }
        
//        if([checkedCateIds count]==0)
//        {
//            [self showAlertPop:@"Select Atleast one category" expObj:nil];
//            return NO;
//        }
        
        if ([selectedRadius isEqualToString:@""]) {
            [self showAlertPop:@"Select radius" expObj:nil];
            return NO;
        }
        
        if ([self.location.text isEqualToString:@""]) {
            [self showAlertPop:@"Select address" expObj:nil];
            return NO;
        }
        if ([selectedCategoryID isEqualToString:@""]) {
            [self showAlertPop:@"Select Category" expObj:nil];
            return NO;
        }
        
        //        else if (![mobileNumber.text isEqualToString:@""]) {
        //            BOOL res =[self validateRegisteredPhoneNo];
        //
        //            if (!res) {
        //
        //                [self showAlertPop:@"Already Registered Mobile Number" expObj:nil];
        //                return NO;
        //            }
        //            // return NO;
        //        }
        
//        if([checkedCateIds count]==0)
//        {
//            [self showAlertPop:@"Select Atleast one category" expObj:nil];
//            return NO;
//        }
        
        
        
        
        if (SelectedType!=nil) {
          
        }
        
        
        
        
        //         if([self.conatctPersonName.text isEqualToString:@""])
        //        {
        //            [self showAlertPop:@"Please enter name " expObj:nil];
        //            return NO;
        //
        //        }
        
        
        return YES;
        
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }}

-(IBAction)scanBtn:(id)sender
{
        
        @try {
            
            categoryAlert=[[CustomIOSAlertView alloc] init];
            UIView  *imageView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 350, 300)];
            [categoryAlert setContainerView:imageView];
            [categoryAlert setButtonTitles:[NSMutableArray arrayWithObjects:@"", nil]];
            
            [categoryAlert setDelegate:self];
            
            
            // You may use a Block, rather than a delegate.
            [categoryAlert setOnButtonTouchUpInside:^(CustomIOSAlertView *alertView, int buttonIndex) {
                NSLog(@"Block: Button at position %d is clicked on alertView %d.", buttonIndex, (int)[alertView tag]);
                [alertView close];
            }];
            
            [categoryAlert setUseMotionEffects:true];
            
            UIButton *cancel = [[UIButton alloc]initWithFrame:CGRectMake(275, 0, 20, 20)];
            
            [cancel setImage:[UIImage imageNamed:@"ic_close"] forState:UIControlStateNormal];
            [cancel addTarget:self action:@selector(cancel:) forControlEvents:UIControlEventTouchUpInside];
            
            highlightView = [[UIView alloc] init];
            highlightView.autoresizingMask = UIViewAutoresizingFlexibleTopMargin |
            UIViewAutoresizingFlexibleLeftMargin |
            UIViewAutoresizingFlexibleRightMargin |
            UIViewAutoresizingFlexibleBottomMargin;
            highlightView.layer.borderColor = [UIColor greenColor].CGColor;
            highlightView.layer.borderWidth = 3;
            //highlightView.frame= CGRectMake(10,50,360,550);
            [self.view addSubview:highlightView];
            
            
            session = [[AVCaptureSession alloc] init];
            device = [AVCaptureDevice defaultDeviceWithMediaType:AVMediaTypeVideo];
            NSError *error = nil;
            
            input = [AVCaptureDeviceInput deviceInputWithDevice:device error:&error];
            if (input) {
                [session addInput:input];
            } else {
                NSLog(@"Error: %@", error);
            }
            
            output = [[AVCaptureMetadataOutput alloc] init];
            [output setMetadataObjectsDelegate:self queue:dispatch_get_main_queue()];
            [session addOutput:output];
            
            output.metadataObjectTypes = [output availableMetadataObjectTypes];
            highlightView.layer.borderColor = [UIColor redColor].CGColor;
            highlightView.frame = CGRectMake(20, 100, 280, 100);

            
            prevLayer = [AVCaptureVideoPreviewLayer layerWithSession:session];
            prevLayer.frame =  CGRectMake(5, 20, 345, 325);
            prevLayer.videoGravity = AVLayerVideoGravityResizeAspectFill;
            [imageView.layer addSublayer:prevLayer];
            [imageView bringSubviewToFront:highlightView];
            [session startRunning];
            
            [imageView addSubview:cancel];
            
            
            
            [categoryAlert show];
            categoryAlert.tag = 2;
            
        } @catch (NSException *exception) {
            [self showAlertPop:@"Error in Data parsing." expObj:exception];
        } @finally {
            
        }
        
        
        //ImageAlert = [CustomIOSAlertView ]
    
 
    
}

#pragma mark - IBAction method implementation

- (void)captureOutput:(AVCaptureOutput *)captureOutput
didOutputMetadataObjects:(NSArray *)metadataObjects
       fromConnection:(AVCaptureConnection *)connection {
    @try {
        
        CGRect highlightViewRect = CGRectZero;
        AVMetadataMachineReadableCodeObject *barCodeObject;
        detectionString = nil;
        NSArray *barCodeTypes = @[
                                  AVMetadataObjectTypeUPCECode,
                                  AVMetadataObjectTypeCode39Code,
                                  AVMetadataObjectTypeCode39Mod43Code,
                                  AVMetadataObjectTypeEAN13Code,
                                  AVMetadataObjectTypeEAN8Code,
                                  AVMetadataObjectTypeCode93Code,
                                  AVMetadataObjectTypeCode128Code,
                                  AVMetadataObjectTypePDF417Code,
                                  AVMetadataObjectTypeQRCode,
                                  AVMetadataObjectTypeAztecCode
                                  ];
        
        for (AVMetadataObject *metadata in metadataObjects) {
            for (NSString *type in barCodeTypes) {
                if ([metadata.type isEqualToString:type]) {
                    barCodeObject = (AVMetadataMachineReadableCodeObject *)[prevLayer
                                                                            transformedMetadataObjectForMetadataObject:
                                                                            (AVMetadataMachineReadableCodeObject *)metadata];
                    highlightViewRect = barCodeObject.bounds;
                    detectionString =
                    [(AVMetadataMachineReadableCodeObject *)metadata stringValue];
                    
                    break;
                }
            }
            
            if (detectionString != nil) {
                
                [session stopRunning];
                
                
         UIAlertController      * alert = [UIAlertController
                         alertControllerWithTitle:@"RPRT"
                         message:detectionString
                         preferredStyle:UIAlertControllerStyleAlert];
                
                UIAlertAction *defaultAction =
                [UIAlertAction actionWithTitle:@"OK"
                                         style:UIAlertActionStyleDefault
                                       handler:^(UIAlertAction *action) {
                                           
                                           spinner = [[UIActivityIndicatorView alloc]
                                                      initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
                                           spinner.frame = CGRectMake(0, 0, 320, 560); // CGPointMake(160, 240);
                                           spinner.color = [UIColor blueColor];
                                           spinner.backgroundColor = [UIColor lightTextColor];
                                           spinner.transform = CGAffineTransformMakeScale(2, 2);
                                           // spinner.hidesWhenStopped = YES;
                                           [self.view addSubview:spinner];
                                           spinner.transform = CGAffineTransformMakeScale(2, 2);
                                           
                                           [spinner startAnimating];
                                           
                                           // how we stop refresh from freezing the main UI thread
                                           
                                           dispatch_async(
                                                          dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^{ dispatch_async(dispatch_get_main_queue(), ^{
                                               
                                               [spinner startAnimating];
                                           });
                                                              dispatch_async(dispatch_get_main_queue(), ^{
                                                                  NSCharacterSet *quoteCharset = [NSCharacterSet characterSetWithCharactersInString:@"\""];
                                                                  NSString *trimmedString = [detectionString stringByTrimmingCharactersInSet:quoteCharset];
                                                                  
//                                                                  [detectionString stringByReplacingOccurrencesOfString:@"\"" withString:@""];
//                                                                   [detectionString stringByReplacingOccurrencesOfString:@""" withString:@""];
                                                                  self.ActivationCode.text = trimmedString;
                                                                  
                                                                  [categoryAlert close];
                                                                  
                                                                  [spinner stopAnimating];
                                                                  
                                                              });
                                                          });
                                           
                                           
                                           //[session startRunning];
                                           
                                           highlightView.layer.borderColor = [UIColor clearColor].CGColor;
                                           highlightView.frame = highlightViewRect;
                                           ////                                           [self ScanBarCode:detectionString];
                                           
                                       }];
                
                [alert addAction:defaultAction];
                
                [self presentViewController:alert animated:YES completion:nil];
                //
                
                break;
            } else if (detectionString == nil)
                
            {
                [session startRunning];
                //detectionString = itemNumber.text;
            }
        }
        highlightView.layer.borderColor = [UIColor greenColor].CGColor;
        highlightView.frame = highlightViewRect;
        
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }}

-(IBAction)fromLocation:(id)sender
{
    Setting_Maps *mMapSettings = [[Setting_Maps alloc]initWithNibName:@"Setting_Maps" bundle:nil];
    mMapSettings.location= @"RegisterFromGoogle";
    [self presentViewController:mMapSettings animated:YES completion:nil];
    
}

-(void)ToStoreRegister:(NSNotification*)notification
{
    
    NSDictionary *addres = notification.userInfo;
    self.location.text =[addres valueForKey:@"Address"];
    latLong =[addres valueForKey:@"LatLong"];
    
    //self.addressField.text = notification.userInfo;
}


/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
