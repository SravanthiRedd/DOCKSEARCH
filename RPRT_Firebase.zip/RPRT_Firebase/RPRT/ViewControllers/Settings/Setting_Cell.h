//
//  Setting_Cell.h
//  RPRT
//
//  Created by sravanthi Gumma on 03/10/16.
//  Copyright © 2016 DevpointSolutions. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Setting_Cell : UITableViewCell

@property (weak,nonatomic) IBOutlet UIImageView *check;
@property (weak,nonatomic) IBOutlet UILabel *categoryName;


@end
