//
//  Setting_Cell.m
//  RPRT
//
//  Created by sravanthi Gumma on 03/10/16.
//  Copyright © 2016 DevpointSolutions. All rights reserved.
//

#import "Setting_Cell.h"

@implementation Setting_Cell
@synthesize check= check;
@synthesize categoryName = categoryName;

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
