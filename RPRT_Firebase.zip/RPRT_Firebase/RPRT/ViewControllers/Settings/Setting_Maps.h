//
//  Setting_Maps.h
//  RPRT
//
//  Created by sravanthi Gumma on 04/10/16.
//  Copyright © 2016 DevpointSolutions. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MapKit/MapKit.h>
@interface Setting_Maps : UIViewController<MKMapViewDelegate,CLLocationManagerDelegate>
{
    CLLocationManager *locationManager;
    CLLocationCoordinate2D currentCentre;
    int currenDist;
    BOOL firstLaunch;
   
    
    
}

@property (strong,nonatomic) NSString *location;

@property (strong, nonatomic) IBOutlet MKMapView *mapView;



@property(weak,nonatomic) IBOutlet UIView *toolBarView;

@end
