//
//  Setting_Maps.m
//  RPRT
//
//  Created by sravanthi Gumma on 04/10/16.
//  Copyright © 2016 DevpointSolutions. All rights reserved.
//

#import "Setting_Maps.h"
#import "Web_Services.h"
#import "Settings.h"

@interface Setting_Maps ()
{
    Web_Services *mWebService;
    NSUserDefaults *mPref;
    NSString *locationFor;
    GeoCodeLocation *Addre;
}

@end

@implementation Setting_Maps

@synthesize mapView;

- (void)viewDidLoad {
    
    @try {
        [super viewDidLoad];
        
      //  imageName = @"";
        mPref = [NSUserDefaults standardUserDefaults];
       // [self loadToolbar];
        //NSMutableArray *arra = self.SetOpportunities;
        
        //GetAllOpportunities = self.SetOpportunities;
        // NSLog(@"%@ Latlong",GetAllOpportunities);
        // if (GetAllOpportunities.count>0) {
        //       [self plotPositions:GetAllOpportunities];
        // }
        
        
        mapView.delegate = self;
        mWebService = [Web_Services GetSharedInstance];
        // Ensure that we can view our own location in the map view.
        [mapView setShowsUserLocation:YES];
        
        //Instantiate a location object.
        
        locationManager = [[CLLocationManager alloc] init];
        locationManager.delegate = self;
        [locationManager setDesiredAccuracy:kCLLocationAccuracyBest];
        if ([[[UIDevice currentDevice] systemVersion] floatValue] >= 8) {
            [locationManager requestAlwaysAuthorization];
        }
        if ([[[UIDevice currentDevice] systemVersion] floatValue] >= 9.2) {
            //locationManager.allowsBackgroundLocationUpdates = YES;
        }
        [locationManager startUpdatingLocation];
        
        CLLocation *location = [locationManager location];
        // coordinate = [location coordinate];
        CLLocationCoordinate2D centre = [mapView centerCoordinate];
        MKCoordinateRegion region;
        if (firstLaunch) {
            region = MKCoordinateRegionMakeWithDistance(locationManager.location.coordinate,100,100);
            firstLaunch=YES;
        }else {
            //Set the center point to the visible region of the map and change the radius to match the search radius passed to the Google query string.
            MKMapRect mRect = self.mapView.visibleMapRect;
            MKMapPoint eastMapPoint = MKMapPointMake(MKMapRectGetMinX(mRect), MKMapRectGetMidY(mRect));
            MKMapPoint westMapPoint = MKMapPointMake(MKMapRectGetMaxX(mRect), MKMapRectGetMidY(mRect));
            currenDist = MKMetersBetweenMapPoints(eastMapPoint, westMapPoint);
            //region = MKCoordinateRegionMakeWithDistance(locationManager.location.coordinate,1500,1500);
            region = MKCoordinateRegionMakeWithDistance(centre,15000,15000);
        }
        
        
        //Set the visible region of the map.
        
        [mapView setRegion:region animated:YES];
        self.mapView.centerCoordinate = location.coordinate;
        
        
        UITapGestureRecognizer *longPressGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(MapviewLongPress:)];
        longPressGesture.numberOfTapsRequired= 1;
        [mapView addGestureRecognizer:longPressGesture];
        locationFor = self.location;
        
        
    }
    @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." exceptionVal:exception];
    }
    @finally {
        
    }
    
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(IBAction)Back:(id)sender
{
    @try {
        
   UIActivityIndicatorView     *spinner = [[UIActivityIndicatorView alloc]
                   initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
        spinner.frame = CGRectMake(0, 0, 320, 560); // CGPointMake(160, 240);
        spinner.color = [UIColor blueColor];
        spinner.backgroundColor = [UIColor lightTextColor];
        spinner.transform = CGAffineTransformMakeScale(2, 2);
        // spinner.hidesWhenStopped = YES;
        [self.view addSubview:spinner];
        spinner.transform = CGAffineTransformMakeScale(2, 2);
        
        [spinner startAnimating];
        
        // how we stop refresh from freezing the main UI thread
        
        dispatch_async(
                       dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^{
                           
                           // back to the main thread for the UI call
                           dispatch_async(dispatch_get_main_queue(), ^{
                               
                               
                               [spinner startAnimating];
                           });
                           dispatch_async(dispatch_get_main_queue(), ^{
                                 Post_Travels *mTravel = [[Post_Travels alloc]init];
                               if ([locationFor isEqualToString: @"From"]) {
                                 
                                     NSString *fromAddress =[NSString stringWithFormat:@"%@,%@,%@",Addre.Address1,Addre.Address2,Addre.Address3];
                                   
                                   [[NSNotificationCenter defaultCenter]
                                    postNotificationName:@"FromAddressNotification"
                                    object:nil
                                    userInfo:fromAddress];
                                   
                                   
                                 
                                   
                                   mTravel.fromAddress.text=fromAddress;
                                   mTravel.address = fromAddress;
                                   [mTravel updateLabel];
                               }
                               else if ([locationFor isEqualToString: @"To"])
                               {
                                   //ToAddressNotification
                                   
                                   
                                   NSString *toaddress =[NSString stringWithFormat:@"%@,%@,%@",Addre.Address1,Addre.Address2,Addre.Address3];
                                   

                                   
                                   [[NSNotificationCenter defaultCenter]
                                    postNotificationName:@"ToAddressNotification"
                                    object:nil
                                    userInfo:toaddress];
                                mTravel.toAddress.text=toaddress;
                               }
                               
                               
                               else if([locationFor isEqualToString:@"RegisterFromGoogle"])
                               {
                                   
                                    NSString *toaddress =[NSString stringWithFormat:@"%@,%@,%@",Addre.Address1,Addre.Address2,Addre.Address3];
                                   NSString *latlong = [NSString stringWithFormat:@"%@,%@",Addre.Latitude,Addre.Longitude];
                                   NSMutableDictionary *address = [[NSMutableDictionary alloc]init];
                                   [address setValue:toaddress forKey:@"Address"];
                                    [address setValue:latlong forKey:@"LatLong"];
                                   
                                   
                                   [[NSNotificationCenter defaultCenter]
                                    postNotificationName:@"ToRegister"
                                    object:nil
                                    userInfo:address];
                                   
                                   
                              
                               }
                               else if([locationFor isEqualToString:@"SignUp"])
                               {
                                   
                                   NSString *toaddress =[NSString stringWithFormat:@"%@,%@,%@",Addre.Address1,Addre.Address2,Addre.Address3];
                                   NSString *latlong = [NSString stringWithFormat:@"%@,%@",Addre.Latitude,Addre.Longitude];
                                   NSMutableDictionary *address = [[NSMutableDictionary alloc]init];
                                   [address setValue:toaddress forKey:@"Address"];
                                   [address setValue:latlong forKey:@"LatLong"];
                                   
                                   
                                   [[NSNotificationCenter defaultCenter]
                                    postNotificationName:@"ToRegisterSignUp"
                                    object:nil
                                    userInfo:address];
                                   
                                   
                                   
                               }
                               else
                               {
                                   NSString *toaddress =[NSString stringWithFormat:@"%@,%@,%@",Addre.Address1,Addre.Address2,Addre.Address3];
                                   NSString *latlong = [NSString stringWithFormat:@"%@,%@",Addre.Latitude,Addre.Longitude];
                                   NSMutableDictionary *address = [[NSMutableDictionary alloc]init];
                                   [address setValue:toaddress forKey:@"Address"];
                                   [address setValue:latlong forKey:@"LatLong"];

                                   
                                   
                                   [[NSNotificationCenter defaultCenter]
                                    postNotificationName:@"ToStoreRegister"
                                    object:nil
                                    userInfo:address];

                               }

                               
                               
                               [self dismissViewControllerAnimated:YES completion:nil];
                                   
                               [spinner stopAnimating];
                               
                           });
                       });
        
        
        //[self dismissViewControllerAnimated:YES completion:NULL];
        
    }
    @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." exceptionVal:exception];
    }
    @finally {
        
    }
    
}
- (void) showAlertPop:(NSString*)alertText exceptionVal:(NSException*)ex {
    //mWeservice
    UIAlertController *myAlertController =[mWebService  alert:alertText];
    [self presentViewController:myAlertController animated:YES completion:nil];
    if(ex != nil)
    {
        NSLog(@"%@", ex.description);
    }
}


#pragma mark - Toolbarbuttons

#pragma mark - MKMapViewDelegate methods.



- (MKOverlayView *)mapView:(MKMapView *)map viewForOverlay:(id <MKOverlay>)overlay
{
    
    @try {
        
        MKCircleRenderer *circleView = [[MKCircleRenderer alloc] initWithOverlay:overlay];
        circleView.strokeColor = [UIColor blueColor];
        circleView.fillColor = [[UIColor blueColor] colorWithAlphaComponent:0.4];
        circleView.lineWidth = 2;
        
    }
    @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." exceptionVal:exception];
    }
    @finally {
        
    }
    
}


- (void)mapView:(MKMapView *)mv didAddAnnotationViews:(NSArray *)views
{
    @try {
        
        //Zoom back to the user location after adding a new set of annotations.
        
        //Get the center point of the visible map.
        CLLocationCoordinate2D centre = [mv centerCoordinate];
        
        MKCoordinateRegion region;
        
        //If this is the first launch of the app then set the center point of the map to the user's location.
        if (firstLaunch) {
            region = MKCoordinateRegionMakeWithDistance(locationManager.location.coordinate,1000,1000);
            firstLaunch=NO;
        }else {
            //Set the center point to the visible region of the map and change the radius to match the search radius passed to the Google query string.
            region = MKCoordinateRegionMakeWithDistance(centre,currenDist,currenDist);
        }
        
        //Set the visible region of the map.
        [mv setRegion:region animated:YES];
    }
    @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." exceptionVal:exception];
    }
    @finally {
        
    }
    
}

-(void)MapviewLongPress:(UIGestureRecognizer*)sender {
    
    @try {
        CGPoint point = [sender locationInView:self.mapView];
        NSMutableArray * annotationsToRemove = [ self.mapView.annotations mutableCopy ] ;
        [ annotationsToRemove removeObject:self.mapView.userLocation ] ;
        [ self.mapView removeAnnotations:annotationsToRemove ] ;
        CLLocationCoordinate2D coordinate= [self.mapView convertPoint:point toCoordinateFromView:self.mapView];
        double lat = coordinate.latitude;
        double lon = coordinate.longitude;
       Addre = [[CurrentLocation GetSharedInstance]geoCodeArea:&lat Longitude:&lon];
        [self AddMarkertoMap:lat lon:lon coordinate:coordinate];
        
        //[mPref setValue:[NSString stringWithFormat:@"%@,%@,%@",Addre.Address1,Addre.Address2,Addre.Address3] forKey:@"StoredAddress"];
//        
//        NSMutableDictionary *location = [[NSMutableDictionary alloc]init];
//        [location setValue:[NSString stringWithFormat:@"%@,%@",Addre.Address1,Addre.AddresName] forKey:@"Address"];
//         [location setValue:[NSString stringWithFormat:@"%@,%@",Addre.Latitude,Addre.Longitude] forKey:@"Address"];
        
        
        
        
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." exceptionVal:exception];
    } @finally {
        
    }
    
}

-(void)AddMarkertoMap:(double)Lat lon:(double)lon coordinate:(CLLocationCoordinate2D)coordinate {
    @try {
        CLGeocoder *ceo = [[CLGeocoder alloc]init];
        CLLocation *loc = [[CLLocation alloc]initWithLatitude:Lat longitude:lon]; //insert your coordinates
        MKPointAnnotation *point1 = [[MKPointAnnotation alloc] init];
        point1.coordinate = coordinate;
        [ceo reverseGeocodeLocation:loc
                  completionHandler:^(NSArray *placemarks, NSError *error) {
                      point1.title = [NSString stringWithFormat:@"Address"];
                  }
         ];
        [self.mapView addAnnotation:point1];
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." exceptionVal:exception];
    } @finally {
        
    }
}




-(void)disclosureTapped
{
    NSLog(@"Hi");
}

- (void)mapView:(MKMapView *)mapView regionDidChangeAnimated:(BOOL)animated {
    
    
    @try {
        
        
        //Get the east and west points on the map so we calculate the distance (zoom level) of the current map view.
        MKMapRect mRect = self.mapView.visibleMapRect;
        MKMapPoint eastMapPoint = MKMapPointMake(MKMapRectGetMinX(mRect), MKMapRectGetMidY(mRect));
        MKMapPoint westMapPoint = MKMapPointMake(MKMapRectGetMaxX(mRect), MKMapRectGetMidY(mRect));
        
        //Set our current distance instance variable.
        currenDist = MKMetersBetweenMapPoints(eastMapPoint, westMapPoint);
        
        //Set our current centre point on the map instance variable.
        currentCentre = self.mapView.centerCoordinate;
        
        
    }
    @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." exceptionVal:exception];
    }
    @finally {
        
    }
}


@end
