//
//  Store_Details.h
//  RPRT
//
//  Created by sravanthi Gumma on 08/09/1938 Saka.
//  Copyright © 1938 Saka DevpointSolutions. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Store_Details : UIViewController<UITabBarDelegate,UITableViewDelegate,UITableViewDataSource,UIScrollViewDelegate>
{
    NSDictionary *SetStoreDeatils;
}
@property(nonatomic,strong) NSDictionary *GetStoreDeatils;
@property(weak,nonatomic) IBOutlet UIView *VendorView;
@property(weak,nonatomic) IBOutlet UILabel *VendorName;
@property(weak,nonatomic) IBOutlet UILabel *StoreName;
@property(weak,nonatomic) IBOutlet UILabel *EmailID;
@property(weak,nonatomic) IBOutlet UILabel *ContactNumber;
@property(weak,nonatomic) IBOutlet UILabel *Address;
@property(weak,nonatomic) IBOutlet UIImageView *VendorProfile;
@property(weak,nonatomic) IBOutlet UILabel *placeRequest;
@property(weak,nonatomic) IBOutlet UILabel *StoreDescription;

@property(strong,nonatomic) IBOutlet UITabBar *tabBar;
@property(strong,nonatomic) IBOutlet UITableView *StoreOppTable;
@property(strong,nonatomic) IBOutlet UITableView *StoreLikeTable;
@property(weak,nonatomic) IBOutlet UIButton *LikeBtn;
@property(weak,nonatomic) IBOutlet UIButton *feedbackBtn;
@property(weak,nonatomic) IBOutlet UIButton *editBusiness;
@property(weak,nonatomic) IBOutlet UIButton *ConnectBusiness;

@property(weak,nonatomic) IBOutlet UIScrollView *scrollview;
@property(weak,nonatomic) IBOutlet UIScrollView *photoScroll;
@property(weak,nonatomic) IBOutlet UIPageControl *pageControls;
@property(weak,nonatomic) IBOutlet UIView *contentView;



@end
