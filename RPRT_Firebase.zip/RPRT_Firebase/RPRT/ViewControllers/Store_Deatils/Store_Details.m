//
//  Store_Details.m
//  RPRT
//
//  Created by sravanthi Gumma on 08/09/1938 Saka.
//  Copyright © 1938 Saka DevpointSolutions. All rights reserved.
//

#import "Store_Details.h"
#import "AppDelegate.h"
#import "MainViewController.h"
#import "MainViewController.h"
#import "Exclusive_Cell.h"
#import "TimeCalculator.h"
#import <MessageUI/MessageUI.h>
#import "Direction_Map.h"
#import "UIImage+Color.h"
#import "UIImage+MDQRCode.h"
#import "MainViewController.h"
#import "Details_Health.h"
#import "HCSStarRatingView.h"
#import "PopUpViewController.h"
#import "Customer_Request.h"
#import "Sale_Registration.h"
#import "MuCustomer_Cell.h"
#import "ContactForm.h"
@interface Store_Details ()<UIAlertViewDelegate,MFMailComposeViewControllerDelegate,MFMessageComposeViewControllerDelegate,CustomIOSAlertViewDelegate,UITextViewDelegate>
{
    NSMutableArray *StoreOppArray;
    MZTimerLabel *TimeCoutDown;
    Preferences *mTimePreference;
    Web_Services *mWebService;
    NSUserDefaults *mPref;
    NSString *CURRENCY_SYMBOL;
    GeoCodeLocation *geoCode;
    TimeCalculator *mTimecalculator;
    CustomIOSAlertView *ImageAlert;
    
    NSString * notifyIcon;
    NSString * blockIcon ;
    NSString * stopIcon;
    NSString * claimIcon;
    NSString * notifedIcon;
    UIActivityIndicatorView *spinner;
    NSString *Key;
    UITextView *requesttext;
    UIButton *priorityBtn;
    NSMutableArray *Images;
    //TimeCalculator *mConverter;
    
    NSMutableArray *storeLikeArray;
    NSMutableArray *StoreLikesFinalarray;
    NSMutableArray *StoreOffersFinalarray;
    NSDictionary *inviteContact;
    NSString *ConnectOrLikeKeyWord;
    
}
@property(strong,nonatomic) PopUpViewController *popViewController;
@property (nonatomic,strong)IBOutlet HCSStarRatingView *starRatingView;
@end

@implementation Store_Details

- (void)viewDidLoad {
    [super viewDidLoad];
    Key=@"";
    ConnectOrLikeKeyWord = @"";
    mTimePreference = [Preferences GetSharedInstance];
    mWebService = [Web_Services GetSharedInstance];
    geoCode = [GeoCodeLocation GetSharedInstance];
    mTimecalculator = [TimeCalculator GetSharedInstance];
    mPref = [NSUserDefaults standardUserDefaults];
    SetStoreDeatils= self.GetStoreDeatils;
    notifyIcon = @"intrested.png";
    blockIcon = @"list_reserve.png";
    stopIcon= @"list_cancelbtn.png";
    claimIcon= @"list_claim.png";
    notifedIcon= @"list_notified.png";
    NSMutableArray *tabBarItems = [[NSMutableArray alloc] init];
    UITabBarItem *activityTab =  [[UITabBarItem alloc] initWithTitle:@"Details" image:[UIImage imageNamed:@"myactivities_.png"] tag:1];
    UITabBarItem *myBlockTab =  [[UITabBarItem alloc] initWithTitle:@"Posted Opportunities" image:[UIImage imageNamed:@"myblocks_drw.png"] tag:2];
    UITabBarItem *StoreLikeTab =  [[UITabBarItem alloc] initWithTitle:@"Store Likes" image:[UIImage imageNamed:@"myblocks_drw.png"] tag:3];
    
    [tabBarItems addObject:activityTab];
    [tabBarItems addObject:myBlockTab];
    [tabBarItems addObject:StoreLikeTab];
    self.tabBar.items = tabBarItems;
    self.tabBar.selectedItem = [tabBarItems objectAtIndex:0];
    self.tabBar.backgroundColor = [UIColor colorWithRed:12.0/256.0 green:187.0/256.0 blue:210./256.0 alpha:1];
     NSString *countryIdentifier = [[NSLocale currentLocale] objectForKey: NSLocaleCountryCode];
    if (geoCode.countryCode== nil) {
        geoCode.countryCode =countryIdentifier;
    }
    
    NSDictionary *components = [NSDictionary dictionaryWithObject:geoCode.countryCode forKey:NSLocaleCountryCode];
    NSString *localeIdent = [NSLocale localeIdentifierFromComponents:components];
    NSLocale *locale = [[NSLocale alloc] initWithLocaleIdentifier:localeIdent];
    CURRENCY_SYMBOL = [locale objectForKey:NSLocaleCurrencySymbol];
    self.StoreOppTable.hidden= YES;
        
    if (SetStoreDeatils!=nil) {
        StoreOffersFinalarray = [SetStoreDeatils valueForKey:@"Offers"];
        [self updateStoreDetails:SetStoreDeatils];
    }
     [[self.tabBar.items objectAtIndex:1] setBadgeValue:[NSString stringWithFormat:@"%lu",(unsigned long)[StoreOffersFinalarray count]]];
    StoreLikesFinalarray = [[NSMutableArray alloc]init];
    
 NSString  * UserRegID  =[NSString stringWithFormat:@"%@",[mPref valueForKey:USERREGISTERID]];
    if (UserRegID!=nil && ![UserRegID isEqualToString:@""]) {
      NSMutableArray  *storeLike = [mWebService GetMyCustomers:UserRegID];
        if(storeLike!=nil){
        for (int i=0; i<[storeLike count]; i++) {
            if ([[[storeLike objectAtIndex:i] valueForKey:@"CustType"] isEqualToString:@"Store Like"]) {
                [StoreLikesFinalarray addObject:[storeLike objectAtIndex:i]];
            }
        }
        }
        
    }
    [[self.tabBar.items objectAtIndex:2] setBadgeValue:[NSString stringWithFormat:@"%lu",(unsigned long)[StoreLikesFinalarray count]]];
    
    
    StoreOppArray =nil;
    storeLikeArray =nil;
    
    NSData  *VendorData =    [mPref valueForKey:@"SaveRegisterDetails"];
 NSDictionary  *myDictionary =   (NSDictionary*) [NSKeyedUnarchiver unarchiveObjectWithData:VendorData];
    if (myDictionary==nil) {
  
        NSString *LogregID =[NSString stringWithFormat:@"%@",[SetStoreDeatils valueForKey:@"UserRegisterId"]];
        NSString *UserRegID = [NSString stringWithFormat:@"%@",[myDictionary valueForKey:@"BusinessRegisterID"]];
        
        if ([LogregID isEqualToString:UserRegID]) {
            self.editBusiness.hidden= NO;
             self.LikeBtn.hidden = YES;
        }
        else
             self.ConnectBusiness.hidden = YES;
            //self.editBusiness.hidden= YES;
    }
    else
    {
        NSString *LogregID =[NSString stringWithFormat:@"%@",[SetStoreDeatils valueForKey:@"UserRegisterId"]];
        NSString *UserRegID = [NSString stringWithFormat:@"%@",[myDictionary valueForKey:@"BusinessRegisterID"]];
        
        if ([LogregID isEqualToString:UserRegID]) {
           
            self.LikeBtn.hidden = YES;
        }

    }
    
//    }else
//    {
//        self.editBusiness.hidden= YES;
//    }

    [self.feedbackBtn addTarget:self action:@selector(placeRequest:) forControlEvents:UIControlEventTouchUpInside];

    
//      if ([[mPref valueForKey:LOGINTYPE] isEqualToString:@"Business"])
//      {
//          
//          //ConnectOrLikeKeyWord= @"Connect";
//          [self.LikeBtn setImage:[UIImage imageNamed:@"connect.png"] forState:UIControlStateNormal];
//      }
//     else if ([[mPref valueForKey:LOGINTYPE] isEqualToString:@"Individual"] ) {
//     
//      // ConnectOrLikeKeyWord= @"";
//         [self.LikeBtn setImage:[UIImage imageNamed:@"like_store.png"] forState:UIControlStateNormal];
//     }
    
    
//    if ([[mPref valueForKey:LOGINTYPE] isEqualToString:@"Business"])
//    {
//        
//        
//        if([[SetStoreDeatils valueForKey:@"CustomerReaction"] isEqualToString:@"Connect"] && [[SetStoreDeatils valueForKey:@"RequestStatus"] isEqualToString:@"Connected"])
//        {
//            
//            [self.LikeBtn setImage:[UIImage imageNamed:@"disconnect.png"] forState:UIControlStateNormal];
//            
//        }
//        if([[SetStoreDeatils valueForKey:@"CustomerReaction"] isEqualToString:@"Connect"] && [[SetStoreDeatils valueForKey:@"RequestStatus"] isEqualToString:@""])
//        {
//            [self.LikeBtn setImage:[UIImage imageNamed:@"disconnect.png"] forState:UIControlStateNormal];
//            self.LikeBtn.userInteractionEnabled= NO;
//            
//        }
//        
//        if([[SetStoreDeatils valueForKey:@"CustomerReaction"] isEqualToString:@""] && [[SetStoreDeatils valueForKey:@"RequestStatus"] isEqualToString:@""])
//        {
//            [self.LikeBtn setImage:[UIImage imageNamed:@"connect.png"] forState:UIControlStateNormal];
//        }
//        
//        
//        
//        
////        if ([[SetStoreDeatils valueForKey:@"CustomerReaction"] isEqualToString:@"Connect"]) {
////            //likeKey= @"DisConnect";
////             [self.LikeBtn setImage:[UIImage imageNamed:@"disconnect.png"] forState:UIControlStateNormal];
////        }
////        else{ //likeKey = @"Connect";
////            [self.LikeBtn setImage:[UIImage imageNamed:@"connect.png"] forState:UIControlStateNormal];
////            
////        }
//        //  likeKey= @"Connect";
//        
//    }
//    else if ([[mPref valueForKey:LOGINTYPE] isEqualToString:@"Individual"] )
//        
//    {
//        if ([[SetStoreDeatils valueForKey:@"CustomerReaction"] isEqualToString:@"Store Like"]) {
//             [self.LikeBtn setImage:[UIImage imageNamed:@"like_store2.png"] forState:UIControlStateNormal];
//        }
//        else
//        {
//             [self.LikeBtn setImage:[UIImage imageNamed:@"like_store.png"] forState:UIControlStateNormal];
//        }
//    }
//
    
    
    if ([[mPref valueForKey:LOGINTYPE] isEqualToString:@"Business"])
    {
        
        if([[SetStoreDeatils valueForKey:@"CustomerReaction"] isEqualToString:@"Connect"] && [[SetStoreDeatils valueForKey:@"RequestStatus"] isEqualToString:@"Connected"])
        {
            
            [self.LikeBtn setImage:[UIImage imageNamed:@"disconnect.png"] forState:UIControlStateNormal];
            
        }
        else  if([[SetStoreDeatils valueForKey:@"CustomerReaction"] isEqualToString:@"Connect"] && [[SetStoreDeatils valueForKey:@"RequestStatus"] isEqualToString:@""])
        {
            [self.LikeBtn setImage:[UIImage imageNamed:@"disconnect.png"] forState:UIControlStateNormal];
            self.LikeBtn.userInteractionEnabled= NO;
            
        }
        
        else  if([[SetStoreDeatils valueForKey:@"CustomerReaction"] isEqualToString:@""] && [[SetStoreDeatils valueForKey:@"RequestStatus"] isEqualToString:@""])
        {
            [self.LikeBtn setImage:[UIImage imageNamed:@"connect.png"] forState:UIControlStateNormal];
        }
        else
        {
            [self.LikeBtn setImage:[UIImage imageNamed:@"connect.png"] forState:UIControlStateNormal];
        }
        
        
        
    }
    else if ([[mPref valueForKey:LOGINTYPE] isEqualToString:@"Individual"] ) {
        
        
        
        if ([[SetStoreDeatils valueForKey:@"CustomerReaction"] isEqualToString:@"Store Like"] && [[SetStoreDeatils valueForKey:@"RequestStatus"] isEqualToString:@"Accepted"]) {
            
            [self.LikeBtn setImage:[UIImage imageNamed:@"like_store2.png"] forState:UIControlStateNormal];
            
        }//like_store2.png
        
        else  if ([[SetStoreDeatils valueForKey:@"CustomerReaction"] isEqualToString:@"Store Like"] && [[SetStoreDeatils valueForKey:@"RequestStatus"] isEqualToString:@""]) {
            [self.LikeBtn setImage:[UIImage imageNamed:@"like_store.png"] forState:UIControlStateNormal];
            self.LikeBtn.userInteractionEnabled= NO;
        }
        
        else if ([[SetStoreDeatils valueForKey:@"CustomerReaction"] isEqualToString:@"Store Unlike"] && [[SetStoreDeatils valueForKey:@"RequestStatus"] isEqualToString:@""])
        {
            [self.LikeBtn setImage:[UIImage imageNamed:@"like_store.png"] forState:UIControlStateNormal];//like_store2.png
        }
        else if ([[SetStoreDeatils valueForKey:@"CustomerReaction"] isEqualToString:@""] && [[SetStoreDeatils valueForKey:@"RequestStatus"] isEqualToString:@""])
        {
            [self.LikeBtn setImage:[UIImage imageNamed:@"like_store.png"] forState:UIControlStateNormal];
        }
        
        
    }

    
    
   
    
    
}



-(void)placeRequest:(UIButton*)geature
{
    
    Customer_Request *mRequest = [[Customer_Request alloc]initWithNibName:@"Customer_Request" bundle:nil];
    mRequest.StoreInfo =SetStoreDeatils;
    [self presentViewController:mRequest animated:YES completion:nil];//:YES completion:nil];

    
 

}

-(void)priorityBtn:(UIButton*)sender
{
    
}

-(void)sendBtn:(UIButton*)sender
{
   
//    NSString *storeID = [SetStoreDeatils valueForKey:@"UserRegisterId"];
//    NSString *customerId = [mPref valueForKey:USERREGISTERID];
//    
//    NSData  *VendorData =    [mPref valueForKey:@"SaveRegisterDetails"];
// NSDictionary   *myDictionary =   (NSDictionary*) [NSKeyedUnarchiver unarchiveObjectWithData:VendorData];
//   
//   NSString *Customer =  [myDictionary valueForKey:@"RegUserName"];
//    NSString *storeName = [SetStoreDeatils valueForKey:@"RegUserName"];
//    NSDateFormatter *dateFormat = [[NSDateFormatter alloc] init];
//    [dateFormat setDateFormat: @"yyyy-MM-dd HH:mm:ss"];
//    
//    //Optionally for time zone conversions
//    [dateFormat setTimeZone:[NSTimeZone timeZoneWithAbbreviation:@"UTC"]];
//    
//    NSString *stringFromDate = [dateFormat stringFromDate:[NSDate date]];
//
//    
//    
//    NSDictionary *dic =   @{ @"RequestId": @"0",
//                             @"StoreId": storeID,
//                             @"CustomerId": customerId,
//                             @"OpportunityId": @"",
//                             @"RequestType": @"Request",
//                             @"RequestDescription": requesttext.text,
//                             @"RequestDate": stringFromDate,
//                             @"ParentId": @"",
//                             @"RequestPriority": @"1",
//                             @"RowStatus": @"A",
//                             @"StoreName": storeName,
//                             @"Customer": Customer
//                             };
//    
//    NSDictionary *response = [mWebService SaveRequestReply:dic];
//    
//    NSLog(@"%@",response);
    
    Customer_Request *mRequest = [[Customer_Request alloc]initWithNibName:@"Customer_Request" bundle:nil];
    mRequest.StoreInfo =SetStoreDeatils;
    [self presentViewController:mRequest animated:YES completion:nil];//:YES completion:nil];
    
    
}

-(void)textViewDidEndEditing:(UITextView *)textView
{
    [textView resignFirstResponder];
}


-(void)didChangeValue:(HCSStarRatingView*)value
{
   self.starRatingView.value = value.value;
}


-(void)updateStoreDetails:(NSDictionary*)storeDetails
{
    
    self.VendorName.text = [storeDetails valueForKey:@"RegUserName"];
     self.EmailID.text = [storeDetails valueForKey:@"RegEmail"];
    // self.StoreType.text = [storeDetails valueForKey:@"UserType"];
     self.Address.text = [storeDetails valueForKey:@"DefaultAddress"];
     self.ContactNumber.text = [storeDetails valueForKey:@"PhoneNo"];
    self.StoreDescription.text = [storeDetails valueForKey:@"StoreDescription"];
    if ([[storeDetails valueForKey:@"ContactPerson"] isEqualToString:@""]) {
        self.StoreName.text = [storeDetails valueForKey:@"UserType"];

    }
    else
    
     self.StoreName.text =[NSString stringWithFormat:@"%@ ( %@ )",[storeDetails valueForKey:@"ContactPerson"], [storeDetails valueForKey:@"UserType"]];
    
    
//    if ([[storeObj valueForKey:@"CustomerReaction"] isEqualToString:@"Store Like"]) {
//        [cell.likeBtn setImage:[UIImage imageNamed:@"like_store2.png"] forState:UIControlStateNormal];
//    }//like_store2.png
//    else
//    {
//        [cell.likeBtn setImage:[UIImage imageNamed:@"like_store.png"] forState:UIControlStateNormal];//like_store2.png
//    }
    
    
    
    if ([[SetStoreDeatils valueForKey:@"CustomerReaction"] isEqualToString:@"Store Like"])
    {
        [self.LikeBtn setImage:[UIImage imageNamed:@"like_store2.png"] forState:UIControlStateNormal];
       // [self.LikeBtn]
    }
    else [self.LikeBtn setImage:[UIImage imageNamed:@"like_store.png"] forState:UIControlStateNormal];
    
    
    
    
    
    
    NSString *imageName = [NSString stringWithFormat:@"%@",[storeDetails valueForKey:@"PhotoName"]];;
    NSArray *imageAry = [imageName componentsSeparatedByString:@","];
    
    Images  =[[NSMutableArray alloc]init];
    
    if (imageAry!=0 && ![imageAry[0] isEqualToString:@""]) {
        for (NSDictionary *dict in imageAry)
        {
            if (![dict isEqual:@""])
            {
                UIImage *image;
                
                
                NSMutableString* aString = [NSMutableString stringWithFormat:@"%@%@",baseImageURL,dict];
                
                
                NSURL *imageURL = [NSURL URLWithString:aString];
                NSString *key = [aString MD5Hash];
                NSData *getData = [FTWCache objectForKey:key];
                if (getData) {
                    image = [UIImage imageWithData:getData];
                    
                    [Images addObject:image];
                    
                }
                else {
                    //cell.OpportunityImage.image  = [UIImage imageNamed:@"img_def"];
                    dispatch_queue_t queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_HIGH, 0ul);
                    dispatch_async(queue, ^{
                        NSData *newData = [NSData dataWithContentsOfURL:imageURL];
                        [FTWCache setObject:newData forKey:key];
                        UIImage *image = [UIImage imageWithData:newData];
                        dispatch_sync(dispatch_get_main_queue(), ^{
                            [Images addObject:image];
                        });
                    });
                }
                
            }
        }
    }
    CGRect workingFrames =CGRectMake(self.photoScroll.frame.origin.x-15, self.photoScroll.frame.origin.y-50, self.photoScroll.frame.size.width+30, self.photoScroll.frame.size.height);
    
    UIImageView *ImageView;
    
    for (int i=0 ; i<[Images count] ;i++)
    {
        
        UIImage *im= [Images objectAtIndex:i];
        
        
        //CGFloat width = im.size.width;
        //CGFloat height = im.size.height;
        
        CGSize size = CGSizeMake(im.size.width, im.size.height);//[self image:img scaledToSize:size]
        
        //[mConverter image:im scaledToSize:size]
        ImageView = [[UIImageView alloc] initWithImage:[mTimecalculator image:im scaledToSize:size]];
        ImageView.tag= i;
        [ImageView setUserInteractionEnabled:YES];
       // UITapGestureRecognizer *singleTap = [[UITapGestureRecognizer alloc] initWithTarget: self action:@selector (changeImg:)];
       // [ImageView addGestureRecognizer: singleTap];
        
        
        [ImageView setContentMode:UIViewContentModeScaleAspectFit];
        
        ImageView.frame = workingFrames;
         ImageView.frame = CGRectMake(workingFrames.origin.x, 0, workingFrames.size.width, workingFrames.size.height+30);
        
        // NSLog(@"%@",workingFrame);
        [self.photoScroll addSubview:ImageView];
        
        workingFrames.origin.x = workingFrames.origin.x + workingFrames.size.width-25
        ;
        workingFrames.origin.x= workingFrames.origin.x-5;
    }
    
    [self.photoScroll setPagingEnabled:YES];
    
    [self.photoScroll setContentSize:CGSizeMake(workingFrames.origin.x, workingFrames.size.height)];
    
    
    self.pageControls.numberOfPages = [Images count];
     self.pageControls.currentPage = 0;
     self.pageControls.pageIndicatorTintColor = [UIColor blueColor];
  //  [ self.pageControls addTarget:self action:@selector(changePage:) forControlEvents:UIControlEventTouchUpInside];
    
}

-(void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    if (scrollView== self.photoScroll) {
        int cardIndex = (int)(scrollView.contentOffset.x / scrollView.frame.size.width);
        self.pageControls.currentPage = cardIndex;
    }

    
}

-(void)tabBar:(UITabBar *)tabBar didSelectItem:(UITabBarItem *)item
{
    if(item.tag==1)
    {
        [self.scrollview setHidden:NO];
        [self.StoreOppTable setHidden:YES];
        
    }
    else  if(item.tag==2)
    {
      
        [self.scrollview setHidden:YES];
        [self.StoreOppTable setHidden:NO];
        StoreOppArray =StoreOffersFinalarray;
        storeLikeArray = nil;
        
        if ([StoreOppArray count]==0) {
            [self.StoreOppTable setHidden:YES];
        }
        else
        {
              [self.StoreOppTable reloadData];
        }
        
    }
    else if (item.tag == 3)
    {
        storeLikeArray =StoreLikesFinalarray;
         StoreOppArray = nil;
        [self.scrollview setHidden:YES];
        [self.StoreOppTable setHidden:NO];
      //  [self.StoreOppTable reloadData];
        
        
        if ([storeLikeArray count]==0) {
            [self.StoreOppTable setHidden:YES];
        }
        else
        {
            [self.StoreOppTable reloadData];
        }

        
       
    }
}


- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    
    if ([StoreOppArray count]>0) {
         return StoreOppArray.count;
    }
    else if ([storeLikeArray count]>0)
    {
        return [storeLikeArray count];
    }
    return StoreOppArray.count;
   
    
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if ([StoreOppArray count]>0) {
        return 190;
    }
    else if ([storeLikeArray count]>0)
    {
        return 80;
    }
    return 80;
    
    
   // return 190;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    @try {
        
        if ([StoreOppArray count]>0) {
        
        
        Exclusive_Cell *cell = (Exclusive_Cell *)[tableView dequeueReusableCellWithIdentifier:@"Exclusive_Cell"];
        
        //OpportunityCell *cell =(OpportunityCell *) [tableView dequeueReusableCellWithIdentifier:simpleTableIdentifier forIndexPath:indexPath];
        
        if (cell == nil)
        {
            NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"Exclusive_Cell" owner:self options:nil];
            cell = [nib objectAtIndex:0];
        }
        
          tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
        
        NSDictionary *ExclusiveOpp = [StoreOppArray objectAtIndex:indexPath.row];
        
        //
//        NSIndexPath *indexPath = [NSIndexPath indexPathForRow:1 inSection: 1];
//        
//        [tableView selectRowAtIndexPath:indexPath animated:NO scrollPosition:UITableViewScrollPositionNone];
        
        
        [cell.shareBtn addTarget:self action:@selector(shareData:) forControlEvents:UIControlEventTouchUpInside];
        cell.shareBtn.imageView.alpha=0.5;
        
        cell.opportunity.text = [ExclusiveOpp valueForKey:@"OpportunityName"];
        cell.description.text = [ExclusiveOpp valueForKey:@"OpportunityDescription"];
        cell.Location.text = [ExclusiveOpp valueForKey:@"AreaName"];
        cell.categoryType.text=[ExclusiveOpp valueForKey:@"SubCategory"];
        cell.offerpostBy.text=[ExclusiveOpp valueForKey:@"UserName"];
        
        NSString *imageName = [NSString stringWithFormat:@"%@",[ExclusiveOpp valueForKey:@"PhotoName"]];;
        NSArray *imageAry = [imageName componentsSeparatedByString:@","];
        NSString *ImageURL = [NSString stringWithFormat:@"%@%@",baseImageURL, [imageAry objectAtIndex:0]];
        
        if ([[imageAry objectAtIndex:0] isEqualToString:@""]) {
            
            imageName = [NSString stringWithFormat:@"%@",[ExclusiveOpp valueForKey:@"CategoryImage"]];;
            ImageURL = [NSString stringWithFormat:@"%@%@",baseImageURL, imageName];
            
            NSURL *imageURL = [NSURL URLWithString:ImageURL];
            NSString *key = [ImageURL MD5Hash];
            NSData *getData = [FTWCache objectForKey:key];
            if (getData) {
                UIImage *image = [UIImage imageWithData:getData];
                cell.OpportunityImage.image  = image;
            }
            else {
                cell.OpportunityImage.image  = [UIImage imageNamed:@"img_def"];
                dispatch_queue_t queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_HIGH, 0ul);
                dispatch_async(queue, ^{
                    NSData *newData = [NSData dataWithContentsOfURL:imageURL];
                    [FTWCache setObject:newData forKey:key];
                    UIImage *image = [UIImage imageWithData:newData];
                    dispatch_sync(dispatch_get_main_queue(), ^{
                        cell.OpportunityImage.image  = image;
                        
                    });
                });
            }
            
        }
        
        else {
            
            NSURL *imageURL = [NSURL URLWithString:ImageURL];
            NSString *key = [ImageURL MD5Hash];
            NSData *getData = [FTWCache objectForKey:key];
            if (getData) {
                UIImage *image = [UIImage imageWithData:getData];
                cell.OpportunityImage.image  = image;
            }
            else {
                cell.OpportunityImage.image  = [UIImage imageNamed:@"img_def"];
                dispatch_queue_t queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_HIGH, 0ul);
                dispatch_async(queue, ^{
                    NSData *newData = [NSData dataWithContentsOfURL:imageURL];
                    [FTWCache setObject:newData forKey:key];
                    UIImage *image = [UIImage imageWithData:newData];
                    dispatch_sync(dispatch_get_main_queue(), ^{
                        cell.OpportunityImage.image  = image;
                        
                    });
                });
            }
            
        }
        UITapGestureRecognizer *singleTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(ImageTap:)];
        singleTap.numberOfTapsRequired = 1;
        [cell.OpportunityImage setUserInteractionEnabled:YES];
        [cell.OpportunityImage addGestureRecognizer:singleTap];
        
        
        if ([[ExclusiveOpp valueForKey:@"Category"] isEqualToString:FOOD] || [[ExclusiveOpp valueForKey:@"Category"] isEqualToString:@"Sale"]) {
            
//            if ([[ExclusiveOpp valueForKey:@"Delivery"] isEqualToString:@"Home Delivery Available"]) {
//                cell.delivery.text= @"Free";
//            }
//            else
                cell.delivery.text= @"NA";
            
            NSMutableAttributedString *actual=[[NSMutableAttributedString alloc]initWithString:[NSString stringWithFormat:@"%@ %@",CURRENCY_SYMBOL,[ExclusiveOpp valueForKey:@"ActualPrice"]]];
            [actual addAttribute:NSStrikethroughStyleAttributeName value:[NSNumber numberWithInt:2] range:NSMakeRange(0,[actual length])];
            
            cell.actualprice.attributedText = actual;
            
            cell.price.text =[NSString stringWithFormat:@"%@ %@",CURRENCY_SYMBOL,[ExclusiveOpp valueForKey:@"Price"]];
            cell.Avialable.text= [NSString stringWithFormat:@"Available: %@",[ExclusiveOpp valueForKey:@"Available"]];
        }
        
        else  if ([[ExclusiveOpp valueForKey:@"Category"] isEqualToString:HEALTH] || [[ExclusiveOpp valueForKey:@"Category"] isEqualToString:@"Banking & Financial"] || [[ExclusiveOpp valueForKey:@"Category"] isEqualToString:@"Professional Services"])
        {
            
            [cell.deliveryLbl setHidden:YES];
            [cell.delivery setHidden:YES];
            [cell.price setHidden:YES];
            [cell.priceLbl setHidden:YES];
            [cell.actualprice setHidden:YES];
            [cell.Avialable setHidden:YES];
            [cell.Timer setHidden:NO];
            CGRect labelFrame = [cell.Timer frame];
            labelFrame.origin.x = 121; // set to whatever you want
            labelFrame.origin.y = 83;
            [cell.Timer setFrame:labelFrame];
            // [cell.Timer set]
        }
        
        
        else if ([[ExclusiveOpp valueForKey:@"Category"] isEqualToString:@"RealEstate"] || [[ExclusiveOpp valueForKey:@"Category"] isEqualToString:@"Meetings"] || [[ExclusiveOpp valueForKey:@"Category"] isEqualToString:@"Travel"])
            
        {
            cell.Avialable.text= [NSString stringWithFormat:@"Available: %@",[ExclusiveOpp valueForKey:@"Available"]];
            [cell.deliveryLbl setHidden:YES];
            [cell.delivery setHidden:YES];
            
            if ([[ExclusiveOpp valueForKey:@"Category"] isEqualToString:@"RealEstate"]) {
                cell.actualprice.text= @"Value";
                [cell.actualprice setTextColor:[UIColor colorWithRed:237.0/256 green:65.0/256.0 blue:53.0/256.0 alpha:1]];
                [cell.priceLbl setHidden:YES];
                cell.price.text = [NSString stringWithFormat:@"%@ %@",CURRENCY_SYMBOL,[ExclusiveOpp valueForKey:@"Price"]];
            }
            
            else   if ([[ExclusiveOpp valueForKey:@"Category"] isEqualToString:@"Meetings"] || [[ExclusiveOpp valueForKey:@"Category"] isEqualToString:@"Travel"]) {
                cell.actualprice.text= @"Fee";
                [cell.actualprice setTextColor:[UIColor colorWithRed:237.0/256 green:65.0/256.0 blue:53.0/256.0 alpha:1]];
                [cell.priceLbl setHidden:YES];
                cell.price.text = [NSString stringWithFormat:@"%@ %@",CURRENCY_SYMBOL,[ExclusiveOpp valueForKey:@"Price"]];
            }
            
            if ([[ExclusiveOpp valueForKey:@"Category"] isEqualToString:@"Travel"]) {
                NSArray *offername = [[ExclusiveOpp valueForKey:@"OpportunityName"] componentsSeparatedByString:@"to"];
                
                NSArray *first = [[offername objectAtIndex:0] componentsSeparatedByString:@","];
                NSArray *second = [[offername objectAtIndex:1] componentsSeparatedByString:@","];
                cell.opportunity.text =[NSString stringWithFormat:@"From : %@  To : %@",[first objectAtIndex:0],[second objectAtIndex:0]];
                [cell.opportunity setFont:[UIFont fontWithName:@"Roboto-Bold" size:14]];
            }

            
        }
        
        else if ([[ExclusiveOpp valueForKey:@"Category"] isEqualToString:@"Jobs"] || [[ExclusiveOpp valueForKey:@"Category"] isEqualToString:@"Sports"])
        {
            cell.Avialable.text= [NSString stringWithFormat:@"Available: %@",[ExclusiveOpp valueForKey:@"Available"]];
            [cell.deliveryLbl setHidden:YES];
            [cell.delivery setHidden:YES];
            [cell.price setHidden:YES];
            [cell.priceLbl setHidden:YES];
            [cell.actualprice setHidden:YES];
            
            
        }
        
        // OFFER TIMER
        
        // OFFER TIMER
        
        if ([[ExclusiveOpp valueForKey:@"OppStatus"] isEqualToString:@"Live"]) {
            NSString *satrtDate = [NSString stringWithFormat:@"%@",[ExclusiveOpp valueForKey:@"EndDate"]];
            
            NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
            [dateFormatter setDateFormat:@"yyyy-MM-dd'T'HH:mm:ss"];
            NSTimeZone *gmt = [NSTimeZone timeZoneWithAbbreviation:@"UTC"];
            [dateFormatter setTimeZone:gmt];
            NSDate *date5 = [dateFormatter dateFromString:satrtDate];
            
            NSDictionary *startOffer;
            if (date5!=nil) {
                startOffer= [mTimePreference remaningTime:[NSDate date] endDate:date5];
            }
            else{
                
                NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
                [dateFormatter setDateFormat:@"yyyy-MM-dd'T'HH:mm:ss.SSS"];
                
                NSTimeZone *gmt = [NSTimeZone timeZoneWithAbbreviation:@"UTC"];
                [dateFormatter setTimeZone:gmt];
                NSDate *date5 = [dateFormatter dateFromString:satrtDate];
                startOffer= [mTimePreference remaningTime:[NSDate date] endDate:date5];
                
            }
            
            
            int Remaingtyime = [[startOffer valueForKey:@"Time"] intValue];
            int hour = [[startOffer valueForKey:@"Hour"] intValue];
            int seconds = [[startOffer valueForKey:@"Seconds"] intValue];
            if (seconds!=0) {
                Remaingtyime = Remaingtyime+(seconds/60);
            }
            if(Remaingtyime!=0)
            {
                
                Remaingtyime = Remaingtyime+(hour*60);//+minutes;
                
                
                
                
                NSString *userBlock =[NSString stringWithFormat:@"%@",[ExclusiveOpp valueForKey:@"BlockId"]];
                if (![userBlock isEqualToString:@"0"] && [[ExclusiveOpp valueForKey:@"OppStatus"] isEqualToString:@"Live"]) {
                    cell.blockBtn.tag= 1;
                    
                    
                    if ([[ExclusiveOpp valueForKey:@"BlockText"] isEqualToString:@"UnBlock"]) {
                        [cell.blockBtn setImage:[UIImage imageNamed:blockIcon] forState:UIControlStateNormal];
                        
                    }
                    else if([[ExclusiveOpp valueForKey:@"BlockText"] isEqualToString:@"Blocked"])
                    {
                        [cell.blockBtn setImage:[UIImage imageNamed:stopIcon] forState:UIControlStateNormal];
                        
                    }
                    
                    else if([[ExclusiveOpp valueForKey:@"BlockText"] isEqualToString:@"Claimed"])
                    {
                        [cell.blockBtn setImage:[UIImage imageNamed:claimIcon] forState:UIControlStateNormal];
                        cell.blockBtn.userInteractionEnabled = NO;
                        
                        
                    }
                    
                    //   [self.bLockBtn setBackgroundColor:[UIColor yellowColor]];
                    
                    
                }
                else if([userBlock isEqualToString:@"0"] && [[ExclusiveOpp valueForKey:@"OppStatus"] isEqualToString:@"Live"])
                {
                    //  [self.bLockBtn setBackgroundColor:[UIColor greenColor]];
                    [cell.blockBtn setImage:[UIImage imageNamed:blockIcon] forState:UIControlStateNormal];
                    
                    
                }
                else if ([[ExclusiveOpp valueForKey:@"OppStatus"] isEqualToString:@"Expired"])
                {
                    [cell.blockBtn setImage:[UIImage imageNamed:notifyIcon] forState:UIControlStateNormal];
                    
                    if([[ExclusiveOpp valueForKey:@"BlockText"] isEqualToString:@"Claimed"])
                    {
                        [cell.blockBtn setImage:[UIImage imageNamed:claimIcon] forState:UIControlStateNormal];
                        cell.blockBtn.userInteractionEnabled = NO;
                        
                    }
                    else if ([[ExclusiveOpp valueForKey:@"BlockText"] isEqualToString:@"Notify"])
                    {
                        [cell.blockBtn setImage:[UIImage imageNamed:notifedIcon] forState:UIControlStateNormal];
                        //cell.blockBtn.enabled = NO;
                    }
                    
                    
                }
                
                
                [cell.blockBtn addTarget:self action:@selector(Block:) forControlEvents:UIControlEventTouchUpInside];
                //[cell addSubview:blockBtn];
                
                
                
                TimeCoutDown = [[MZTimerLabel alloc] initWithLabel:cell.Timer andTimerType:MZTimerLabelTypeTimer];
                [TimeCoutDown setCountDownTime:Remaingtyime*60];
                [TimeCoutDown start];
            }
            
            NSString *RegisterID =   [mPref objectForKey:USERREGISTERID];
            if (RegisterID == [ExclusiveOpp valueForKey:@"UserRegisterId"])
            {
                cell.blockBtn.hidden= YES;
                
            }
            
        }
        else if ([[ExclusiveOpp valueForKey:@"OppStatus"] isEqualToString:@"Expired"])
        {
            
            NSString *RegisterID =   [mPref objectForKey:USERREGISTERID];
            if (RegisterID == [ExclusiveOpp valueForKey:@"UserRegisterId"])
            {
                cell.blockBtn.hidden= YES;
                
            }
            
            else  if ([[ExclusiveOpp valueForKey:@"Category"] isEqualToString:HEALTH] || [[ExclusiveOpp valueForKey:@"Category"] isEqualToString:@"Banking & Financial"] || [[ExclusiveOpp valueForKey:@"Category"] isEqualToString:@"Professional Services"])
            {
                
                cell.actualprice.text = @"Expired!!";
            }
            else  cell.Timer.text = @"Expired!!";
            //CGSize siz =CGSizeMake(63, 45);
            // UIImage  *image=   [mTimecalculator image:[UIImage imageNamed:notifyIcon] scaledToSize:siz];
            
            if (![[ExclusiveOpp valueForKey:@"BlockText"] isEqualToString:@"Notify"]) {
                [cell.blockBtn setImage:[UIImage imageNamed:notifyIcon] forState:UIControlStateNormal];
            }
            
            if ([[ExclusiveOpp valueForKey:@"BlockText"] isEqualToString:@"Notify"])
            {
                [cell.blockBtn setImage:[UIImage imageNamed:notifedIcon] forState:UIControlStateNormal];
                //cell.blockBtn.enabled = NO;
            }
            
            
            [cell.blockBtn addTarget:self action:@selector(Block:) forControlEvents:UIControlEventTouchUpInside];
        }
        //}
      
        
        
        
        
        return cell;
        
        }
        else if ([storeLikeArray count]>0)
        {
            MuCustomer_Cell *cell = (MuCustomer_Cell *)[tableView dequeueReusableCellWithIdentifier:@"MuCustomer_Cell"];
            if (cell == nil)
            {
                NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"MuCustomer_Cell" owner:self options:nil];
                cell = [nib objectAtIndex:0];
            }
            tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
            
            NSDictionary *conObj = [storeLikeArray objectAtIndex:indexPath.row];
            
//            NSString *OppIDv = [NSString stringWithFormat:@"%@",[self.CustomerObj valueForKey:@"OppId"]];
//            NSString *CustomerID = [NSString stringWithFormat:@"%@",[conObj valueForKey:@"CustomerID"]];
//            if([OppIDv isEqualToString:CustomerID])
//            {
//                NSLog(@"%@",self.CustomerObj);
//                
//                
//                
//                cell.custView.layer.backgroundColor = [UIColor whiteColor].CGColor;
//                
//                [UIView animateWithDuration:2.0 animations:^{
//                    cell.custView.layer.backgroundColor = [UIColor colorWithRed:250.0/256.0 green:250.0/256.0 blue:250./256.0 alpha:1].CGColor;
//                } completion:NULL];
//                
//                
//                
//                // NSIndexPAth *path = [NSIndexPath indexPathWithIndex:k];//if u hav single section or u can use other class method
//                
//            }
            
            NSString *IsNew =[NSString stringWithFormat:@"%@",[conObj valueForKey:@"IsNew"]];
            cell.contactName.text = [conObj valueForKey:@"Name"];
            if ([IsNew isEqualToString:@"1"]) {
                [cell.contactName setFont:[UIFont fontWithName:@"Roboto-Medium" size:16]];
            }
            
            NSString *mem =[NSString stringWithFormat:@"%@",[conObj valueForKey:@"AlreadyMember"]];
            
            int *alreadynumber = [mem intValue];
            if (alreadynumber>0) {
                //  cell.alreadyMember.hidden= NO;
                [cell.RequestBtn setImage:[UIImage imageNamed:@"alreadymembe-2r.png"] forState:UIControlStateNormal];
                //alreadymembe-2r.png
                cell.RequestBtn.userInteractionEnabled= false;
            }
            else {
                
                [cell.RequestBtn setImage:[UIImage imageNamed:@"36_invitation.png"] forState:UIControlStateNormal];
                //36_invitation.png
                //  cell.alreadyMember.hidden= YES;
                //  [cell.RequestBtn setHidden:NO];
            }
            cell.PhoneNumber.text = [conObj valueForKey:@"PhoneNo"];
            if (![[conObj valueForKey:@"PhotoName"] isEqualToString:@""]) {
                
                NSString *imageName = [NSString stringWithFormat:@"%@",[conObj valueForKey:@"PhotoName"]];;
                NSArray *imageAry = [imageName componentsSeparatedByString:@","];
                NSString *ImageURL = [NSString stringWithFormat:@"%@%@",baseImageURL, [imageAry objectAtIndex:0]];
                
                NSURL *imageURL = [NSURL URLWithString:ImageURL];
                NSString *key = [ImageURL MD5Hash];
                NSData *getData = [FTWCache objectForKey:key];
                if (getData) {
                    UIImage *image = [UIImage imageWithData:getData];
                    cell.mPhoto.image  = image;
                }
                else {
                    cell.mPhoto.image  = [UIImage imageNamed:@"img_def"];
                    dispatch_queue_t queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_HIGH, 0ul);
                    dispatch_async(queue, ^{
                        NSData *newData = [NSData dataWithContentsOfURL:imageURL];
                        [FTWCache setObject:newData forKey:key];
                        UIImage *image = [UIImage imageWithData:newData];
                        dispatch_sync(dispatch_get_main_queue(), ^{
                            cell.mPhoto.image  = image;
                            
                        });
                    });
                }
                
            }
            
            
            [cell.EditBtn addTarget:self action:@selector(EditBtn:) forControlEvents:UIControlEventTouchUpInside];
            [cell.deleteBtn addTarget:self action:@selector(deleteBtn:) forControlEvents:UIControlEventTouchUpInside];
            [cell.RequestBtn addTarget:self action:@selector(RequestBtn:) forControlEvents:UIControlEventTouchUpInside];
          //  NSString *Invited = [NSString stringWithFormat:@"%@",[conObj valueForKey:@"Invited"]];
            
         
            
            return cell;

        }
        
        
    }
    @catch (NSException *exception) {
       // [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
}

-(void)deleteBtn:(UIButton*)sender
{
    CGPoint buttonPosition = [sender convertPoint:CGPointZero toView:self.StoreOppTable];
    
    NSIndexPath *indexPath = [self.StoreOppTable indexPathForRowAtPoint:buttonPosition];
    
    NSDictionary *selCustomer = [storeLikeArray objectAtIndex:indexPath.row];
    
    NSMutableArray *customArray= [[NSMutableArray alloc]init];
    
    NSDictionary *CistObj = @{@"CustomerID":[selCustomer valueForKey:@"CustomerID"],
                              @"UserRegisterID":[selCustomer valueForKey:@"UserRegisterID"],
                              @"Name":[selCustomer valueForKey:@"Name"],
                              @"PhoneNo":[selCustomer valueForKey:@"PhoneNo"],
                              @"Email":@"",
                              @"RowStatus":@"D",
                              @"Invited":@"false",
                              @"InvitedDate":@"",
                              @"AlreadyMember":@"",
                              @"PhotoName":@""
                              };
    
    [customArray addObject:CistObj];
    
    NSDictionary *myDeletCustomeObj = @{@"Customers":customArray};
    
    [mWebService SaveCustomer:myDeletCustomeObj];
    NSString *UserRegID = [mPref valueForKey:USERREGISTERID];
    storeLikeArray = [mWebService GetMyCustomers:UserRegID];
    [self.StoreOppTable reloadData];
    
    
    
}




-(void)EditBtn:(UIButton*)sender
{
    CGPoint buttonPosition = [sender convertPoint:CGPointZero toView:self.StoreOppTable];
    
    NSIndexPath *indexPath = [self.StoreOppTable indexPathForRowAtPoint:buttonPosition];
    
    NSDictionary *selCustomer = [storeLikeArray objectAtIndex:indexPath.row];
    
    ContactForm *mContsctForm = [[ContactForm alloc]initWithNibName:@"ContactForm" bundle:nil];
    
    mContsctForm.EditedContact = selCustomer;
    
    [self presentViewController:mContsctForm animated:YES completion:nil];
    
}

-(void)RequestBtn:(UIButton*)sender
{
    CGPoint buttonPosition = [sender convertPoint:CGPointZero toView:self.StoreOppTable];
    
    NSIndexPath *indexPath = [self.StoreOppTable indexPathForRowAtPoint:buttonPosition];
    
    inviteContact = [storeLikeArray objectAtIndex:indexPath.row];
    
    NSDateFormatter *dateFormat = [[NSDateFormatter alloc] init];
    [dateFormat setDateFormat: @"yyyy-MM-dd HH:mm:ss"];
    
    //Optionally for time zone conversions
    [dateFormat setTimeZone:[NSTimeZone timeZoneWithAbbreviation:@"UTC"]];
    
    NSString *stringFromDate = [dateFormat stringFromDate:[NSDate date]];
    NSMutableArray *customArray = [[NSMutableArray alloc]init];
    
    NSString *PhoneNumver = [inviteContact valueForKey:@"PhoneNo"];
    NSString * InVited = @"true";
    NSDictionary *CistObj = @{@"CustomerID":[inviteContact valueForKey:@"CustomerID"],
                              @"UserRegisterID":[inviteContact valueForKey:@"UserRegisterID"],
                              @"Name":[inviteContact valueForKey:@"Name"],
                              @"PhoneNo":[inviteContact valueForKey:@"PhoneNo"],
                              @"Email":@"",
                              @"RowStatus":@"A",
                              @"Invited":InVited,
                              @"InvitedDate":stringFromDate,
                              @"AlreadyMember":@"",
                              @"PhotoName":@""
                              };
    
    [customArray addObject:CistObj];
    
    NSDictionary *myDeletCustomeObj = @{@"Customers":customArray};
    
    [mWebService SaveCustomer:myDeletCustomeObj];
    NSString *UserRegID = [mPref valueForKey:USERREGISTERID];
    storeLikeArray = [mWebService GetMyCustomers:UserRegID];
    [self.StoreOppTable reloadData];
    
    MFMessageComposeViewController *controller = [[MFMessageComposeViewController alloc] init];
    if([MFMessageComposeViewController canSendText])
    {
        
        NSData  *VendorData =    [mPref valueForKey:@"SaveRegisterDetails"];
        NSDictionary *myDictionary =   (NSDictionary*) [NSKeyedUnarchiver unarchiveObjectWithData:VendorData];
        NSLog(@"%@",myDictionary);
        
        NSString *StoreName =@"";
        if ([[myDictionary valueForKey:@"ContactPerson"] isEqualToString:@""]) {
            StoreName= [myDictionary valueForKey:@"RegUserName"];
        }
        else StoreName= [myDictionary valueForKey:@"ContactPerson"];
        
        controller.body =[NSString stringWithFormat:@"Hi,\nI am using Right Place Right Time mobile app to post the Opportunities of mystore.\nInstall the app from\nPlay store: http://bit.ly/2fdqw6N\n App store: http://apple.co/2fdvEaV\n\nRegards,\n%@",StoreName];
        controller.recipients = [NSArray arrayWithObjects:PhoneNumver, nil];
        controller.messageComposeDelegate = self;
        
        [self presentViewController:controller animated:YES completion:nil];
    }
    
}


- (void)messageComposeViewController:(MFMessageComposeViewController *)controller didFinishWithResult:(MessageComposeResult)result
{
    
    switch (result)
    {
        case MessageComposeResultSent:
            
            break;
        case MessageComposeResultFailed:
            
            break;
        case MessageComposeResultCancelled:
            
            break;
            
        default:
            
            break;
    }
    
    [self dismissViewControllerAnimated:YES completion:nil];
}






- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
    
    @try {
       // [mPref setValue:Key forKey:@"Key"];
        
        NSDictionary *SelectedItem = [StoreOppArray objectAtIndex:indexPath.row];
        // [self saveViewOpprtunity:SelectedItem];
        
        NSString *category = [SelectedItem valueForKey:@"Category"];
        
        
        
        if([category isEqualToString:FOOD]||[category isEqualToString:SALES] ){
            
            
            Details_FoodAndSales *mDetails = [Details_FoodAndSales alloc];
            mDetails.SetSelectedOpportunity =SelectedItem;
            //mDetails.Pagekey= @"Exclusive";
            Details_FoodAndSales *mDetailFoodandsale =[mDetails initWithNibName:@"Details_FoodAndSales" bundle:nil];
            [self presentViewController:mDetailFoodandsale animated:YES completion:nil];
        }
        
       
        
        else if([category isEqualToString:PROFESSIONALHELP] || [category isEqualToString:BANKING])
        {
            
            Details_Events_Help_Banking *mDetails = [Details_Events_Help_Banking alloc];
            mDetails.SetSelectedOpportunity =SelectedItem;
            mDetails.setSelectedCategory =category;
           // mDetails.Pagekey= @"Exclusive";
            Details_Events_Help_Banking *mDetailFoodandsale =[mDetails initWithNibName:@"Details_Events_Help_Banking" bundle:nil];
            [self presentViewController:mDetailFoodandsale animated:YES completion:nil];
        }
        
        else   if([category isEqualToString:TRAVELS]){
            
            
            //if ([[category valueForKey:FOOD] isEqualToString:FOOD] || [[category valueForKey:SALES] isEqualToString:SALES]) {
            
            
            Details_Travels *mDetails = [Details_Travels alloc];
            mDetails.SetSelectedOpportunity =SelectedItem;
            //mDetails.Pagekey= @"Exclusive";
            Details_Travels *mDetailFoodandsale =[mDetails initWithNibName:@"Details_Travels" bundle:nil];
            [self presentViewController:mDetailFoodandsale animated:YES completion:nil];
        }
        
        else if ([category isEqualToString:REALESTATE])
        {
            
            
            Details_RealEstate *mDetails = [Details_RealEstate alloc];
            mDetails.SetSelectedOpportunity =SelectedItem;
         //   mDetails.Pagekey= @"Exclusive";
            Details_RealEstate *mDetailFoodandsale =[mDetails initWithNibName:@"Details_RealEstate" bundle:nil];
            [self presentViewController:mDetailFoodandsale animated:YES completion:nil];
            
            
        }
        
        
        else if ([category isEqualToString:JOBS] ||[category isEqualToString:SPORTS]|| [category isEqualToString:MEETINGS])
        {
            
            
            Details_GameandJobs *mDetails = [Details_GameandJobs alloc];
            mDetails.SetSelectedOpportunity =SelectedItem;
           // mDetails.Pagekey= @"Exclusive";
            Details_GameandJobs *mDetailFoodandsale =[mDetails initWithNibName:@"Details_GameandJobs" bundle:nil];
            [self presentViewController:mDetailFoodandsale animated:YES completion:nil];
            
        }
        else if ( [category isEqualToString:HEALTH])
        {
            Details_Health *mDetails = [Details_Health alloc];
            mDetails.SetSelectedOpportunity =SelectedItem;
        //    mDetails.Pagekey= @"Exclusive";
            Details_Health *mDetailFoodandsale =[mDetails initWithNibName:@"Details_Health" bundle:nil];
            [self presentViewController:mDetailFoodandsale animated:YES completion:nil];
            
        }
        
        
        
    }
    @catch (NSException *exception) {
        
    }
    @finally {
        
    }
}




-(void)Block:(UIButton*)sender
{
    
    
    @try {
        
        if (isOnlineStatus) {
            
            
            spinner = [[UIActivityIndicatorView alloc]
                       initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
            spinner.frame = CGRectMake(0, 0, 320, 560); // CGPointMake(160, 240);
            spinner.color = [UIColor blueColor];
            spinner.backgroundColor = [UIColor lightTextColor];
            spinner.transform = CGAffineTransformMakeScale(2, 2);
            // spinner.hidesWhenStopped = YES;
            [self.view addSubview:spinner];
            spinner.transform = CGAffineTransformMakeScale(2, 2);
            
            [spinner startAnimating];
            
            // how we stop refresh from freezing the main UI thread
            
            dispatch_async(
                           dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^{
                               
                               // back to the main thread for the UI call
                               dispatch_async(dispatch_get_main_queue(), ^{
                                   [spinner startAnimating];
                               });
                               dispatch_async(dispatch_get_main_queue(), ^{
                                   NSUserDefaults *prefss = [NSUserDefaults standardUserDefaults];
                                   
                                   CGPoint buttonPosition = [sender convertPoint:CGPointZero toView:self.StoreOppTable];
                                   
                                   
                                   
                                   NSIndexPath *indexPath = [self.StoreOppTable indexPathForRowAtPoint:buttonPosition];
                                   
                                   
                                   
                                   NSDictionary *BlockedItem = [StoreOppArray objectAtIndex:indexPath.row];
                                   NSString *RegisterID =   [prefss objectForKey:USERREGISTERID];
                                   
                                   if (RegisterID!=[BlockedItem valueForKey:@"UserRegisterId"] && RegisterID!=nil) {
                                       
                                       
                                       NSInteger availablecoutn = [[BlockedItem valueForKey:@"Available"] intValue];
                                       
                                       if (availablecoutn >= 1) {
                                           
                                           if([[BlockedItem valueForKey:@"OppStatus"] isEqualToString:@"Expired"])
                                           {
                                               UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"Right Place Right Time"
                                                                                                              message:@"Sorry! It's expired. Please click on notify to get notified in future."
                                                                                                       preferredStyle:UIAlertControllerStyleAlert];
                                               
                                               UIAlertAction* ok = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault
                                                                                          handler:^(UIAlertAction * action) {
                                                                                              
                                                                                              [self blockorNotify:buttonPosition];
                                                                                              
                                                                                          }];
                                               UIAlertAction* cancel = [UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleDefault
                                                                                              handler:^(UIAlertAction * action) {
                                                                                                  [alert dismissViewControllerAnimated:YES completion:nil];
                                                                                                  
                                                                                                  
                                                                                              }];
                                               
                                               [alert addAction:ok];
                                               [alert addAction:cancel];
                                               [self presentViewController:alert animated:YES completion:nil];
                                           }
                                           else
                                           {
                                               [self blockorNotify:buttonPosition];
                                               
                                           }
                                           
                                       }
                                       else
                                       {
                                           
                                           [self blockorNotify:buttonPosition];
                                           
                                           
                                       }
                                       
                                   }
                                   
                                   else if (RegisterID == [BlockedItem valueForKey:@"UserRegisterId"])
                                   {
                                       UIAlertController * login=   [UIAlertController
                                                                     alertControllerWithTitle:@"RPRT"
                                                                     message:@"Unable to Reserve the Offer"
                                                                     preferredStyle:UIAlertControllerStyleAlert];
                                       
                                       UIAlertAction* yesButton = [UIAlertAction
                                                                   actionWithTitle:@"OK"
                                                                   style:UIAlertActionStyleDefault
                                                                   handler:^(UIAlertAction * action)
                                                                   {
                                                                       [login dismissViewControllerAnimated:YES completion:nil];
                                                                       
                                                                       //[self dismissViewControllerAnimated:alert completion:nil];
                                                                   }];
                                       
                                       [login addAction:yesButton];
                                       
                                       
                                       //[self dismissViewControllerAnimated:YES completion:nil];
                                       [self presentViewController:login animated:YES completion:nil];
                                   }
                                   
                                   else if(RegisterID ==nil) {
                                       UIAlertController * alert=   [UIAlertController
                                                                     alertControllerWithTitle:@"RPRT"
                                                                     message:@"Please Register/Login"
                                                                     preferredStyle:UIAlertControllerStyleAlert];
                                       
                                       UIAlertAction* yesButton = [UIAlertAction
                                                                   actionWithTitle:@"OK"
                                                                   style:UIAlertActionStyleDefault
                                                                   handler:^(UIAlertAction * action)
                                                                   {
                                                                       [mPref setObject:@"List" forKey:@"PageName"];
                                                                       
                                                                       

                                                                       self.popViewController = [[PopUpViewController alloc] initWithNibName:@"PopUpViewController" bundle:nil];
                                                                       [self.popViewController setTitle:@"This is a popup view"];
                                                                       
                                                                       [self.popViewController showInView:self.view withImage:[UIImage imageNamed:@"rprt_usinfo.png"] withMessage:@"You just triggered a great popup window" animated:YES];
                                                                       
                                                                       
                                                                       
                                                                       
//                                                                       
//                                                                       Login * mLogin = [[ Login alloc] initWithNibName:LOGIN bundle:nil];
//                                                                       [self presentViewController:mLogin animated:YES completion:nil];
                                                                       
                                                                       //[self dismissViewControllerAnimated:alert completion:nil];
                                                                   }];
                                       
                                       UIAlertAction* cancelBtn = [UIAlertAction
                                                                   actionWithTitle:@"Cancel"
                                                                   style:UIAlertActionStyleDefault
                                                                   handler:^(UIAlertAction * action)
                                                                   {
                                                                       //Handel your yes please button action here
                                                                       [self dismissViewControllerAnimated:alert completion:nil];
                                                                   }];
                                       
                                       
                                       
                                       [alert addAction:yesButton];
                                       [alert addAction:cancelBtn];
                                       
                                       
                                       [self presentViewController:alert animated:YES completion:nil];
                                       
                                   }
                                   
                                   [spinner stopAnimating];
                                   
                               });
                           });
        }
        else if (!isOnlineStatus)
        {
            [self showAlertPop:@"No internet connection" expObj:nil];
        }
        
    }
    @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
}

-(void)blockorNotify:(CGPoint)buttonPosition
{
    @try {
        
        if (isOnlineStatus) {
            
            NSIndexPath *indexPath = [self.StoreOppTable indexPathForRowAtPoint:buttonPosition];
            NSDictionary *BlockedItem = [StoreOppArray objectAtIndex:indexPath.row];
            NSString *RegisterID =   [mPref objectForKey:USERREGISTERID];
            NSMutableDictionary *dic = [[NSMutableDictionary alloc]init];
            NSString *uniqueIdentifier = [[[UIDevice currentDevice] identifierForVendor] UUIDString];
            [dic setValue:[BlockedItem valueForKey:@"OpportunityID"] forKey:@"OpportunityId"];
            
            NSString *category = [dic valueForKey:@"Category"];
            //[dic setValue:[BlockedItem valueForKey:@"KeyValue"] forKey:@"KeyValue"];
            
            if ([[BlockedItem valueForKey:@"OppStatus"] isEqualToString:@"Expired"])
            {
                [dic setValue:@"Notify" forKey:@"BlockText"];
                [dic setValue:@"0" forKey:@"BlockId"];
                [dic setValue:@"0" forKey:@"Quantity"];
            }
            
            
            else if ([[BlockedItem valueForKey:@"BlockId"] intValue] ==0 && [[BlockedItem valueForKey:@"OppStatus"] isEqualToString:@"Live"]) {
                [dic setValue:@"Blocked" forKey:@"BlockText"];
                [dic setValue:@"0" forKey:@"BlockId"];
                [dic setValue:@"1" forKey:@"Quantity"];
                if([category isEqualToString:HEALTH] || [category isEqualToString:REALESTATE] || [category isEqualToString:PROFESSIONALHELP] ||
                   [category isEqualToString:BANKING])
                {
                    [dic setValue:@"0" forKey:@"Quantity"];
                }
                
            }
            
            else if ([[BlockedItem valueForKey:@"BlockId"] intValue] !=0 && [[BlockedItem valueForKey:@"OppStatus"] isEqualToString:@"Live"])
            {
                
                if ([[BlockedItem valueForKey:@"BlockText"] isEqualToString:@"UnBlock"]) {
                    
                    [dic setValue:@"Blocked" forKey:@"BlockText"];
                    [dic setValue:[BlockedItem valueForKey:@"BlockId"] forKey:@"BlockId"];
                    [dic setValue:@"1" forKey:@"Quantity"];
                    if([category isEqualToString:HEALTH] || [category isEqualToString:REALESTATE] || [category isEqualToString:PROFESSIONALHELP] ||
                       [category isEqualToString:BANKING])
                    {
                        [dic setValue:@"0" forKey:@"Quantity"];
                    }
                    
                }
                else if ([[BlockedItem valueForKey:@"BlockText"] isEqualToString:@"Blocked"])
                {
                    [dic setValue:@"UnBlock" forKey:@"BlockText"];
                    [dic setValue:[BlockedItem valueForKey:@"BlockId"] forKey:@"BlockId"];
                    [dic setValue:@"0" forKey:@"Quantity"];
                    
                }
            }
            
            
            
            
            [dic setValue:uniqueIdentifier forKey:@"DeviceId"];
            [dic setValue:RegisterID forKey:@"BlockedUserId"];
            //
            [dic setValue:@""  forKey:@"ClaimedTime"];
            [dic setValue:@"" forKey:@"TransactionComplete"];
            NSString *keyValue = [NSString stringWithFormat:@"RPRT-%@-%@-%@",[BlockedItem valueForKey:@"OpportunityID"],RegisterID,[BlockedItem valueForKey:@"UserRegisterId"]];
            [dic setValue:keyValue forKey:@"KeyValue"];
            
            // NSString *OfferName =[NSString stringWithFormat:@"The selected %@ was blocked", [BlockedItem valueForKey:@"VendorName"]];
            NSDictionary *blockeditemResponse =[mWebService SaveBlockeditem:dic];
            if ((blockeditemResponse!=nil)) {
                
                NSString * erroeMessage =[blockeditemResponse valueForKey:@"ErrorMessage"];
                
                if ( ( ![erroeMessage isEqual:[NSNull null]] ) && ( [erroeMessage length] != 0 ) ) {
                    [self showAlertPop:erroeMessage expObj:nil];
                }
                
                if (( [erroeMessage isEqual:[NSNull null]])) {
                    
                    
                    if ([[blockeditemResponse valueForKey:@"BlockText"] isEqualToString:@"Blocked"]) {
                        [self showAlertPop:@"Your request is placed, please be on time!!" expObj:nil];
                        
                    }
                    else if ([[blockeditemResponse valueForKey:@"BlockText"] isEqualToString:@"UnBlock"]) {
                        [self showAlertPop:@"Your offer request is cancelled!" expObj:nil];
                        
                    }
                    
                    else if ([[blockeditemResponse valueForKey:@"BlockText"] isEqualToString:@"Notify"])
                    {
                        [self showAlertPop:@"This offer will Notify you" expObj:nil];
                    }
                    
                }
                
                
                
                
                CGFloat imageSize = ceilf(self.view.bounds.size.width * 0.6f);
                UIImageView *imageView = [[UIImageView alloc] initWithFrame:CGRectMake(floorf(self.view.bounds.size.width * 0.5f - imageSize * 0.5f), floorf(self.view.bounds.size.height * 0.5f - imageSize * 0.5f), imageSize, imageSize)];
                // [viewController.view addSubview:imageView];
                
                [NSTimer scheduledTimerWithTimeInterval:1.0
                                                 target:self
                                               selector:@selector(doSomethingWhenTimeIsUp)
                                               userInfo:nil
                                                repeats:NO];
                
                imageView.image = [UIImage mdQRCodeForString:[blockeditemResponse valueForKey:@"keyValue"] size:imageView.bounds.size.width fillColor:[UIColor darkGrayColor]];
                
            }
        }
        else if (!isOnlineStatus)
        {
            [self showAlertPop:@"No internet connection" expObj:nil];
        }
        
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
    
}

-(void)doSomethingWhenTimeIsUp
{
    @try {
        [self viewDidLoad];
        
    }
    @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
}


-(NSDictionary*)getMyblocks
{
    @try {
        
        if (isOnlineStatus) {
            
            
            
            if ([mPref valueForKey:USERREGISTERID] !=nil) {
                
                NSString *ids = [mPref valueForKey:USERREGISTERID];
                NSDictionary   *GetBlocks = [[Web_Services GetSharedInstance]GetOpportinityReview:ids MethodName:GETRESERVEDOPPORTUNITIESBYUSERID];
                
                return GetBlocks;
                
            }
            else
            {
                return 0;
            }
        }
        else if (!isOnlineStatus)
        {
            [self showAlertPop:@"No internet connection" expObj:nil];
        }
        
        
    }
    @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
}


-(IBAction)Navigation:(id)sender
{
    
    Direction_Map *mMap= [Direction_Map alloc];
    mMap.direction =SetStoreDeatils;
    Direction_Map *mMapview =
    [mMap initWithNibName:DIRECTIONMAP bundle:nil];
    [self presentViewController:mMapview animated:YES completion:nil];
    
}

-(IBAction)call:(id)sender
{
    NSString *contNumber=[SetStoreDeatils valueForKey:@"PhoneNo"];
    @try {
        UIDevice *device = [UIDevice currentDevice];
        if ([[device model] isEqualToString:@"iPhone"]) {
            
            NSURL *phoneUrl = [NSURL
                               URLWithString:[NSString stringWithFormat:@"telprompt:%@", contNumber]];
            
            if ([[UIApplication sharedApplication] canOpenURL:phoneUrl]) {
                
                UIApplication *application = [UIApplication sharedApplication];
                [application openURL:phoneUrl options:@{} completionHandler:nil];

                
              //  [[UIApplication sharedApplication] openURL:phoneUrl];
            }
            
        } else {
            
            UIAlertController *myAlertController =
            [mWebService alert:@"Your device doesn't support this feature."];
            [self presentViewController:myAlertController
                               animated:YES
                             completion:nil];
        }
    } @catch (NSException *exception) {
        //NSLog(EXCEPTIONCON, exception.reason);
        UIAlertController *myAlertController =
        [mWebService alert:@"Error while fetching data"];
        [self presentViewController:myAlertController animated:YES completion:nil];
    }
    
}



-(void)ImageTap:(UIPinchGestureRecognizer *)recognizer{
    
    @try {
        
        
        UIImageView *tableGridImage = (UIImageView*)recognizer.view;
        [self customimageAlert:tableGridImage];
        
        
        
    } @catch (NSException *exception) {
        
    } @finally {
        
    }
    
    //ImageAlert = [CustomIOSAlertView ]
}


-(void)customimageAlert:(UIImageView*)tableGridImage
{
    @try {
        
        
        ImageAlert=[[CustomIOSAlertView alloc] init];
        UIView  *imageView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 300, 200)];
        [ImageAlert setContainerView:imageView];
        [ImageAlert setButtonTitles:[NSMutableArray arrayWithObjects:@"", nil]];
        
        [ImageAlert setDelegate:self];
        
        
        // You may use a Block, rather than a delegate.
        [ImageAlert setOnButtonTouchUpInside:^(CustomIOSAlertView *alertView, int buttonIndex) {
            NSLog(@"Block: Button at position %d is clicked on alertView %d.", buttonIndex, (int)[alertView tag]);
            [alertView close];
        }];
        
        [ImageAlert setUseMotionEffects:true];
        
        UIButton *cancel = [[UIButton alloc]initWithFrame:CGRectMake(275, 0, 20, 20)];
        
        [cancel setImage:[UIImage imageNamed:@"ic_close"] forState:UIControlStateNormal];
        [cancel addTarget:self action:@selector(cancel:) forControlEvents:UIControlEventTouchUpInside];
        
        
        UIImageView *VendorProfile = [[UIImageView alloc]initWithImage:tableGridImage.image];
        VendorProfile.frame = CGRectMake(0, 20, 300, 230);
        [imageView addSubview:cancel];
        [imageView addSubview:VendorProfile];
        
        [ImageAlert show];
        ImageAlert.tag = 2;
    }
    @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
}


-(void)cancel:(UIButton*)sender
{
    [ImageAlert close];
}


-(void)shareData:(id)sender
{
    CGPoint buttonPosition = [sender convertPoint:CGPointZero toView:self.StoreOppTable];
    
    NSIndexPath *indexPath = [self.StoreOppTable indexPathForRowAtPoint:buttonPosition];
    
    NSDictionary *BlockedItem = [StoreOppArray objectAtIndex:indexPath.row];
    
    UIAlertController * view=   [UIAlertController
                                 alertControllerWithTitle:@"Rigth Place Right Time"
                                 message:@"Select Sharing option"
                                 preferredStyle:UIAlertControllerStyleActionSheet];
    
    UIAlertAction* watsapp = [UIAlertAction
                              actionWithTitle:@"Share via Whatsapp"
                              style:UIAlertActionStyleDefault
                              handler:^(UIAlertAction * action)
                              {
                                  
                                  
                                  
                                  NSString *ursl =  [mTimecalculator whatspandSMSText:BlockedItem];//[NSString stringWithFormat:@"A new opportunity is posted at %@ \n%@ \nIf you do not have the app, please download it from Apple:https://itunes.apple.com/in/app/right-place-right-time/id1145309259?mt=8",areName,Addres];
                                  
                                  ursl =    (NSString*)CFBridgingRelease(CFURLCreateStringByAddingPercentEscapes(NULL,(CFStringRef) ursl, NULL,CFSTR("!*();:@&=+$,/?%#[]"),kCFStringEncodingUTF8));
                                  
                                  NSString * urlWhats = [NSString stringWithFormat:@"whatsapp://send?text=%@",ursl];
                                  NSURL * whatsappURL = [NSURL URLWithString:urlWhats];
                                  if ([[UIApplication sharedApplication] canOpenURL: whatsappURL]) {
                                      [[UIApplication sharedApplication] openURL: whatsappURL];
                                  } else {
                                      [self showAlertPop:@"Unable to share opportunity." expObj:nil];
                                      // can not share with whats app
                                  }
                                  
                              }];
    UIAlertAction* email = [UIAlertAction
                            actionWithTitle:@"Share via E-mail"
                            style:UIAlertActionStyleDefault
                            handler:^(UIAlertAction * action)
                            {
                                NSString *ursl = [mTimecalculator emailText:BlockedItem];
                                
                                NSString *cat =[BlockedItem valueForKey:@"Category"];
                                if ([cat isEqualToString:@"Professional Services"]) {
                                    cat= @"Expert Help";
                                }
                                else if ([cat isEqualToString:MEETINGS])
                                    cat= @"Events & Entertainments";
                                
                                NSString *subjectt = [NSString stringWithFormat:@"Right Place Right Time : %@",cat];
                                
                                if ([MFMailComposeViewController canSendMail]) {
                                    MFMailComposeViewController *mailController = [[MFMailComposeViewController alloc] init];
                                    [mailController setMailComposeDelegate:self];
                                    [mailController setSubject:subjectt];
                                    [mailController setToRecipients:@[@"email1", @"email2"]];
                                    [mailController setMessageBody:ursl isHTML:NO];
                                    [self presentViewController:mailController animated:YES completion:nil];
                                }
                                
                                [view dismissViewControllerAnimated:YES completion:nil];
                                
                            }];
    
    
    UIAlertAction* sms = [UIAlertAction
                          actionWithTitle:@"Share via iMessage"
                          style:UIAlertActionStyleDefault
                          handler:^(UIAlertAction * action)
                          {
                              
                              NSString *ursl =[mTimecalculator whatspandSMSText:BlockedItem];// [NSString stringWithFormat:@"A new opportunity is posted at %@ \n%@ \nIf you do not have the app, please download it from Apple:https://itunes.apple.com/in/app/right-place-right-time/id1145309259?mt=8",areName,Addres];
                              
                              if ([MFMessageComposeViewController canSendText]) {
                                  MFMessageComposeViewController *messageController = [[MFMessageComposeViewController alloc] init];
                                  [messageController setMessageComposeDelegate:self];
                                  [messageController setRecipients:nil];
                                  [messageController setBody:ursl];
                                  [self presentViewController:messageController animated:NO completion:nil];
                              }
                              
                              [view dismissViewControllerAnimated:YES completion:nil];
                              
                          }];
    
    UIAlertAction* cancel = [UIAlertAction
                             actionWithTitle:@"Cancel"
                             style:UIAlertActionStyleDefault
                             handler:^(UIAlertAction * action)
                             {
                                 [view dismissViewControllerAnimated:YES completion:nil];
                                 
                             }];
    [watsapp setValue:[[UIImage imageNamed:@"whatsapp.png"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal] forKey:@"image"];
    [email setValue:[[UIImage imageNamed:@"email.png"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal] forKey:@"image"];
    [sms setValue:[[UIImage imageNamed:@"sms.png"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal] forKey:@"image"];
    
    
    [view addAction:watsapp];
    [view addAction:email];
    [view addAction:sms];
    [view addAction:cancel];
    [self presentViewController:view animated:YES completion:nil];
    
    
}
- (void)mailComposeController:(MFMailComposeViewController*)controller didFinishWithResult:(MFMailComposeResult)result error:(NSError*)error {
    [self dismissViewControllerAnimated:YES completion:nil];
}

// Then implement the delegate method
//- (void)messageComposeViewController:(MFMessageComposeViewController *)controller didFinishWithResult:(MessageComposeResult)result {
//    [self dismissViewControllerAnimated:YES completion:nil];
//}




- (void) showAlertPop:(NSString*)alertText  expObj:(NSException*) exp{
    if(exp != nil)
    {
        NSLog(@"%@", exp.description);
    }
    NSLog(@"The Exception is %@",exp.description);
    UIAlertController *myAlertController =[mWebService  alert:alertText];
    [self presentViewController:myAlertController animated:YES completion:nil];
}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(IBAction)storeLikeBtn:(id)sender
{
    
    if ([mPref valueForKey:USERREGISTERID]) {
        
        
        //CGPoint buttonPosition = [sender convertPoint:CGPointZero toView:storeTable];
        
        //NSIndexPath *indexPath = [storeTable indexPathForRowAtPoint:buttonPosition];
        
        //NSDictionary *BlockedItem = [storesReponseList objectAtIndex:indexPath.row];
        
        NSString *likeKey= @"";
//        
//        if ([[SetStoreDeatils valueForKey:@"CustomerReaction"] isEqualToString:@"Store Like"]) {
//            likeKey= @"UnLike";
//        }
//        else likeKey = @"Like";
        
        if ([[mPref valueForKey:LOGINTYPE] isEqualToString:@"Business"])
        {
            //likeKey= @"Connect";
            
            if ([[SetStoreDeatils valueForKey:@"CustomerReaction"] isEqualToString:@"Connect"]) {
                likeKey= @"DisConnect";
            }
            else likeKey = @"Connect";

            
            
            
        }
        else if ([[mPref valueForKey:LOGINTYPE] isEqualToString:@"Individual"] )
            
        {
            if ([[SetStoreDeatils valueForKey:@"CustomerReaction"] isEqualToString:@"Store Like"]) {
                likeKey= @"UnLike";
            }
            else likeKey = @"Like";
        }

        
        
        
        
        
        
        
        NSDictionary *storeLikUnlikeObj = @{@"userRegisterId":[SetStoreDeatils      valueForKey:@"UserRegisterId"],
                                            @"memberId":[mPref valueForKey:USERREGISTERID],
                                            @"Reaction":likeKey
                                            };
        
         [mWebService StoreLikeUnlike:storeLikUnlikeObj];
        NSString *VenDorRedID= [SetStoreDeatils valueForKey:@"UserRegisterId"];
        NSString *FinalId = [NSString stringWithFormat:@"%@/%@",VenDorRedID,[mPref valueForKey:USERREGISTERID]];
        SetStoreDeatils=nil;
        SetStoreDeatils =[ mWebService GetStoreDetails:FinalId];
        
        [self updateStoreDetails:SetStoreDeatils];
        
        //[self viewDidLoad];
        
    }
    else
    {
        self.popViewController = [[PopUpViewController alloc] initWithNibName:@"PopUpViewController" bundle:nil];
        [self.popViewController setTitle:@"This is a popup view"];
        
        [self.popViewController showInView:self.view withImage:[UIImage imageNamed:@"rprt_usinfo.png"] withMessage:@"You just triggered a great popup window" animated:YES];

        
        
//        Login  *mLogin = [[Login alloc]initWithNibName:LOGIN bundle:nil];
//        [self presentViewController:mLogin animated:YES completion:nil];
        
    }

    
}


-(void) viewDidLayoutSubviews {
    
    @try {
        
        
        [super viewDidLayoutSubviews];
        [self.scrollview layoutIfNeeded];
        self.scrollview.contentSize=self.contentView.bounds.size;
        UIGraphicsBeginImageContext(self.contentView.frame.size);
        UIImage *image = UIGraphicsGetImageFromCurrentImageContext();
        UIGraphicsEndImageContext();
        image= [UIImage imageNamed:@"bgerror.png"];
        //self.contentView.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"bgerror.png"]];
        

        
        
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
}

-(IBAction)editBusiness:(id)sender
{
    
        
        NSData  *VendorData =    [mPref valueForKey:@"SaveRegisterDetails"];
      NSDictionary  *myDictionary =   (NSDictionary*) [NSKeyedUnarchiver unarchiveObjectWithData:VendorData];
        if (myDictionary==nil) {
            myDictionary=nil;
        }
        
    
        NSMutableDictionary *dictionary = [myDictionary mutableCopy];
    
        [dictionary setValue:[SetStoreDeatils valueForKey:@"RegEmail"] forKey:@"RegEmail"];
        [dictionary setValue:[SetStoreDeatils valueForKey:@"PhoneNo"] forKey:@"PhoneNo"];
        //RegEmail = "sravanthi.devpoint@gmail.com";
        
        if (dictionary != nil) {
                Sale_Registration *mSReg  =[[Sale_Registration alloc]initWithNibName:@"Sale_Registration" bundle:nil];
                mSReg.EditRegisted = dictionary;
                
                [self presentViewController:mSReg animated:YES completion:nil];
            
        }
}

-(IBAction)back:(id)sender
{
    [self dismissViewControllerAnimated:YES completion:nil];
}



-(IBAction)continueBtn:(id)sender{
    
}



/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
