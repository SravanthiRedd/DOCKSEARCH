//
//  Store_List.h
//  RPRT
//
//  Created by sravanthi Gumma on 10/09/1938 Saka.
//  Copyright © 1938 Saka DevpointSolutions. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Store_List : UIViewController<UITableViewDelegate,UITableViewDataSource>

@property(strong,nonatomic) NSString *StoreLikes;
@property(strong,nonatomic) NSString *ListType;
@property (weak, nonatomic) IBOutlet UIButton *Radious;
@property(weak,nonatomic) IBOutlet UILabel *pageTitle;
@property(weak,nonatomic) IBOutlet UIView *helpSectionView;

@end
