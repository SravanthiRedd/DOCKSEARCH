//
//  Store_List.m
//  RPRT
//
//  Created by sravanthi Gumma on 10/09/1938 Saka.
//  Copyright © 1938 Saka DevpointSolutions. All rights reserved.
//

#import "Store_List.h"
#import "Web_Services.h"
#import "MainViewController.h"
#import "Store_ListCell.h"
#import "PopUpViewController.h"
#import "RMMapper.h"
#import "RTStore_List.h"

@interface Store_List ()<UISearchBarDelegate,CLLocationManagerDelegate>

{
    Web_Services *mWebService;
    IBOutlet  UISearchBar *searchBar;
    bool isSearching;
    IBOutlet UITableView *storeTable;
    NSUserDefaults *mPref;
    GeoCodeLocation *geoCode;
    NSMutableArray *storesReponseList;
    NSString *storeLikeKey;
    UITableView *RadTable;
    NSArray *radiousArray;
    UIRefreshControl *refreshController;
    CLLocationManager *locationManager;
    CLLocationCoordinate2D center;
    CurrentLocation *location;
    NSString *BusinessUserRegID;
    NSString *LogInType;
}

@property(strong,nonatomic) PopUpViewController *popViewController;

@end

@implementation Store_List

@synthesize Radious;
- (void)viewDidLoad {
    [super viewDidLoad];
    
    mWebService =[Web_Services GetSharedInstance];
    geoCode = [GeoCodeLocation GetSharedInstance];
    mPref = [NSUserDefaults standardUserDefaults];
    storeLikeKey= self.StoreLikes;
    LogInType= [mPref valueForKey:LOGINTYPE];
    
    if ([storeLikeKey isEqualToString:@"All"]) {
        self.pageTitle.text= @"Near by Stores";
    }
    else if ([storeLikeKey isEqualToString:@"Connect"])
    {
        self.pageTitle.text = @"My Business Circle";
    }
    else if ([storeLikeKey isEqualToString:@"Store Like"])
    {
        self.pageTitle.text= @"My Stores";
    }
    
    self.helpSectionView.layer.shadowColor = [UIColor lightGrayColor].CGColor;
    self.helpSectionView.layer.shadowOffset = CGSizeMake(0, 4);
    self.helpSectionView.layer.shadowOpacity = 1;
    self.helpSectionView.layer.shadowRadius = 1.0;
    
    
    [self seachOffer:@""];
    
    NSString *path = [[NSBundle mainBundle] pathForResource:CATEGORY ofType:@"plist"];
    NSMutableDictionary *dict = [NSMutableDictionary dictionaryWithContentsOfFile:path];
    radiousArray = [[NSArray alloc] init];
    radiousArray= [dict valueForKey:@"Radious"];
      [self RadiousBtnTitle];
RadTable = [[UITableView alloc]initWithFrame:CGRectMake(Radious.frame.origin.x, Radious.frame.origin.y+40, Radious.frame.size.width+18,220) style:UITableViewStylePlain];
    
    RadTable.delegate = self;
    RadTable.dataSource = self;
    RadTable.scrollEnabled=NO;
    RadTable.hidden= YES;
    [self.view addSubview:RadTable];
    
    refreshController = [[UIRefreshControl alloc] init];
    refreshController.tintColor = [UIColor grayColor];
    [refreshController addTarget:self action:@selector(refershControlAction) forControlEvents:UIControlEventValueChanged];
    [storeTable addSubview:refreshController];
    storeTable.alwaysBounceVertical = YES;

    
    
    NSData  *VendorData =    [mPref valueForKey:@"SaveRegisterDetails"];
    NSDictionary  *myDictionary =   (NSDictionary*) [NSKeyedUnarchiver unarchiveObjectWithData:VendorData];
    if (myDictionary==nil) {
        
        BusinessUserRegID = [NSString stringWithFormat:@"%@",[myDictionary valueForKey:@"BusinessRegisterID"]];
        
      
    }
    
    
    
    
  }

-(void)refershControlAction
{
   [refreshController endRefreshing];
     [self seachOffer:@""];
    [storeTable reloadData];
    
    
    //[self viewDidLoad];
   
}


-(void)searchBarTextDidBeginEditing:(UISearchBar *)searchBar
{
    isSearching=YES;
}


//- (void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)seachtext {
//    NSLog(@"Text change - %d",isSearching);
//    
//    //Remove all objects first.
//    // [filteredContentList removeAllObjects];
//    
//    if([seachtext length] != 0) {
//        isSearching = YES;
//        [self seachOffer:seachtext];
//    }
//    else if([seachtext length]==0)
//    {
//      
//        [storeTable reloadData];
//    }
//    else {
//        isSearching = NO;
//    }
//    // [self.tblContentList reloadData];
//}



-(NSString*)getLocation
{
    locationManager = [[CLLocationManager alloc] init];
    locationManager.delegate = self;
    [locationManager setDesiredAccuracy:kCLLocationAccuracyBest];
    if ([[[UIDevice currentDevice] systemVersion] floatValue] >= 8) {
        [locationManager requestAlwaysAuthorization];
    }
    if ([[[UIDevice currentDevice] systemVersion] floatValue] >= 9.2) {
        [locationManager requestWhenInUseAuthorization];
    }
    [locationManager startUpdatingLocation];
    CLLocation *mLocation = [locationManager location];
    center = [mLocation coordinate];
    NSString *latLong =[NSString stringWithFormat:@"%f,%f",center.latitude,center.longitude];
    return latLong;
   // geoCode = [location geoCodeArea:&center.latitude Longitude:&center.longitude];

}




- (void)seachOffer:(NSString *)substring {
    @try {
        //substring =@"Bas";
        //if (geoCode.Latitude==nil || geoCode.Longitude) {
        NSString *location  =    [self getLocation];
       // }
        
        
     //   NSString *location = [NSString stringWithFormat:@"%@,%@",geoCode.Latitude,geoCode.Longitude];
        NSString *radious = [mPref valueForKey:@"Radious"];
        NSString *regID = [mPref valueForKey:USERREGISTERID];
        if (regID== nil) {
            regID= @"0";
        }
        if (radious ==nil) {
            radious = @"1000";
        }
        
        NSDictionary *storeObj = @{@"searchString":substring,
                                   @"Location":location,
                                   @"radius":radious,
                                   @"PageNo":@"10",
                                   @"PageSize":@"1",
                                   @"UserRegisterId":regID,
                                   @"ListType":storeLikeKey
                                   };
        
       
        storesReponseList = [mWebService GetStores:storeObj];
        
      
        
        NSLog(@"Inputobj %@",storeObj);
        NSLog(@" Out Put %@",storesReponseList);
            
            [storeTable reloadData];
            
        //}
        
    } @catch (NSException *exception) {
       // [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(IBAction)back:(id)sender
{
    [self dismissViewControllerAnimated:YES completion:nil];
    
}


- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (tableView == storeTable) {
        
        if(storesReponseList.count==0)
        {
             if ([storeLikeKey isEqualToString:@"Connect"]) {
                 [self.helpSectionView setHidden:NO];
            }
            
            return 0;
        }
        else
        {
            [self.helpSectionView setHidden:YES];
            //storeTable.hidden= YES;
        return storesReponseList.count;
        
        } // return 10;
    
    }
    else if (tableView == RadTable)
    {
        return [radiousArray count];
    }
    return 10;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (tableView == storeTable) {
    
    return 175;
    }
    else if (tableView == RadTable)
    {
        return 40;
    }
    return 40;

}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    @try {
        
        if (tableView == storeTable) {
        
        
        Store_ListCell *cell = (Store_ListCell *)[tableView dequeueReusableCellWithIdentifier:@"Store_ListCell"];
        
        //OpportunityCell *cell =(OpportunityCell *) [tableView dequeueReusableCellWithIdentifier:simpleTableIdentifier forIndexPath:indexPath];
        
        if (cell == nil)
        {
            NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"Store_ListCell" owner:self options:nil];
            cell = [nib objectAtIndex:0];
        }
        
        tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
        
        RTStore_List *storeObj = [storesReponseList objectAtIndex:indexPath.row];
        if ([storeObj.ContactPerson isEqualToString:@""]) {
            cell.storeName.text = storeObj.RegUserName;
        }
        else  cell.storeName.text=storeObj.ContactPerson;
        
        
        cell.customerCnt.text = [NSString stringWithFormat:@"Customer: %@",storeObj.CustomerCount];
        cell.UserName.text=[NSString stringWithFormat:@"%@",storeObj.RegUserName];
        cell.Distance.text =[NSString stringWithFormat:@"Distance : %@ Km",storeObj.Distance];
        cell.businesstype.text =[NSString stringWithFormat:@"%@",storeObj.BusinessType];
        cell.ContactNumber.text =[NSString stringWithFormat:@"%@",storeObj.PhoneNo];
        cell.Address.text =[NSString stringWithFormat:@"%@",storeObj.DefaultAddress];
        cell.emailID.text =[NSString stringWithFormat:@"%@",storeObj.RegEmail];
        
            NSLog(@"Customer Reaction %@",storeObj.CustomerReaction);
            NSLog(@"RequestStatus  %@",storeObj.RequestStatus);
            
            if ([LogInType isEqualToString:@"Business"])
            {
                
                if([storeObj.CustomerReaction isEqualToString:@"Connect"] && [storeObj.RequestStatus isEqualToString:@"Connected"])
                {
                    
                   [cell.likeBtn setImage:[UIImage imageNamed:@"disconnect.png"] forState:UIControlStateNormal];
                    
                }
              else  if([storeObj.CustomerReaction isEqualToString:@"Connect"] && [storeObj.RequestStatus isEqualToString:@""])
                {
                    [cell.likeBtn setImage:[UIImage imageNamed:@"disconnect.png"] forState:UIControlStateNormal];
                    cell.likeBtn.userInteractionEnabled= NO;
                    
                }
                
              else  if([storeObj.CustomerReaction isEqualToString:@""] && [storeObj.RequestStatus isEqualToString:@""])
                {
                    [cell.likeBtn setImage:[UIImage imageNamed:@"connect.png"] forState:UIControlStateNormal];
                }
                else
                {
                     [cell.likeBtn setImage:[UIImage imageNamed:@"connect.png"] forState:UIControlStateNormal];
                }
                
            }
            else if ([LogInType isEqualToString:@"Individual"] ) {
                
                if ([storeObj.CustomerReaction isEqualToString:@"Store Like"] && [storeObj.RequestStatus isEqualToString:@"Accepted"]) {
                    
                    [cell.likeBtn setImage:[UIImage imageNamed:@"like_store2.png"] forState:UIControlStateNormal];
                    
                }//like_store2.png
                
                else  if ([storeObj.CustomerReaction isEqualToString:@"Store Like"] && [storeObj.RequestStatus isEqualToString:@""]) {
                    [cell.likeBtn setImage:[UIImage imageNamed:@"like_store.png"] forState:UIControlStateNormal];
                    cell.likeBtn.userInteractionEnabled= NO;
                }
                
                else if ([storeObj.CustomerReaction isEqualToString:@"Store Unlike"] && [storeObj.RequestStatus isEqualToString:@""])
                {
                    [cell.likeBtn setImage:[UIImage imageNamed:@"like_store.png"] forState:UIControlStateNormal];//like_store2.png
                }
                else if ([storeObj.CustomerReaction isEqualToString:@""] && [storeObj.RequestStatus isEqualToString:@""])
                {
                     [cell.likeBtn setImage:[UIImage imageNamed:@"like_store.png"] forState:UIControlStateNormal];
                }
                
            
            }
          
            
            NSString *storeRegID=[NSString stringWithFormat:@"%@",storeObj.UserRegisterId];
            if ([BusinessUserRegID isEqualToString:storeRegID]) {
                cell.likeBtn.hidden= YES;
            }
            
           //UserRegisterId = 148;
//BusinessUserRegID
            
            
            
        
        NSString *imageName = [NSString stringWithFormat:@"%@",storeObj.PhotoName];;
        NSArray *imageAry = [imageName componentsSeparatedByString:@","];
        NSString *ImageURL = [NSString stringWithFormat:@"%@%@",baseImageURL, [imageAry objectAtIndex:0]];
        
        NSURL *imageURL = [NSURL URLWithString:ImageURL];
        NSString *key = [ImageURL MD5Hash];
        NSData *getData = [FTWCache objectForKey:key];
        if (getData) {
            UIImage *image = [UIImage imageWithData:getData];
            cell.profile.image  = image;
        }
        else {
            cell.profile.image  = [UIImage imageNamed:@"img_def"];
            dispatch_queue_t queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_HIGH, 0ul);
            dispatch_async(queue, ^{
                NSData *newData = [NSData dataWithContentsOfURL:imageURL];
                [FTWCache setObject:newData forKey:key];
                UIImage *image = [UIImage imageWithData:newData];
                dispatch_sync(dispatch_get_main_queue(), ^{
                    cell.profile.image  = image;
                    
                });
            });
            
            
        }
        
        [cell.likeBtn  addTarget:self action:@selector(likeBtn:) forControlEvents:UIControlEventTouchUpInside];
        [cell.CallBtn addTarget:self action:@selector(CallBtn:) forControlEvents:UIControlEventTouchUpInside];

        
        return cell;
        }
        else if (tableView == RadTable)
        {
            static NSString *CellIdentifier = @"Cell";
            // Reuse and create cell
            UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
            if (cell == nil) {
                cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
            }
            NSString *Addreline = [[radiousArray objectAtIndex:indexPath.row] valueForKey:@"Value"];;
            cell.textLabel.text = Addreline;
            cell.textLabel.textAlignment = NSTextAlignmentLeft;
            return cell;

        }
    }
    @catch (NSException *exception) {
         [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
}

-(IBAction)RadiousBtn:(id)sender
{
    RadTable.hidden= NO;
}


-(void)searchBarCancelButtonClicked:(UISearchBar *)SearchBar
{
    storeLikeKey=@"Search";
    [self seachOffer:searchBar.text];
    [SearchBar resignFirstResponder];
    [SearchBar resignFirstResponder];
    
}

-(void)searchBarSearchButtonClicked:(UISearchBar *)SearchBar
{
    storeLikeKey=@"Search";
    [self seachOffer:searchBar.text];
    [SearchBar resignFirstResponder];
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    @try {
        
        if (tableView== storeTable) {
        
             RTStore_List *storeObj = [storesReponseList objectAtIndex:indexPath.row];
            
            NSString *VenDorRedID =[NSString stringWithFormat:@"%@",storeObj.UserRegisterId];
    
    
    NSString *userRegID = [mPref valueForKey:USERREGISTERID];
    if(userRegID==nil)
    {
        userRegID= @"0";
    }
    
  //  NSString *VenDorRedID= [getSelctedOpp valueForKey:@"UserRegisterId"];
    NSString *FinalId = [NSString stringWithFormat:@"%@/%@",VenDorRedID,userRegID];
    
    NSDictionary *getStoreResp =[ mWebService GetStoreDetails:FinalId];
    
    Store_Details *mStoreDetails = [[Store_Details alloc]initWithNibName:@"Store_Details" bundle:nil];
    mStoreDetails.GetStoreDeatils =getStoreResp;
    [self presentViewController:mStoreDetails animated:YES completion:nil];
        }
        else if (tableView== RadTable)
        {
               RadTable.hidden= YES;
                NSString   *selectedRadius =[[radiousArray objectAtIndex:indexPath.row] valueForKey:@"Radious"];
                [mPref setValue:selectedRadius forKey:@"TempRadius"];
                [self StoreRadios:selectedRadius];
           
        }
        
    }
    @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
}


-(void)StoreRadios:(NSString*)radious {
    @try {
        
        [[Preferences GetSharedInstance]StoreRadious:radious];
        [self RadiousBtnTitle];
        [self viewDidLoad];
        
    }
    @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    }
    @finally {
        
    }
}


-(void)CallBtn:(UIButton*)sender
{
    CGPoint buttonPosition = [sender convertPoint:CGPointZero toView:storeTable];
    
    NSIndexPath *indexPath = [storeTable indexPathForRowAtPoint:buttonPosition];
    
    RTStore_List *BlockedItem = [storesReponseList objectAtIndex:indexPath.row];
    NSString *PhoneNumber= BlockedItem.PhoneNo;
    
    //NSString *contNumber = [selectedItem valueForKey:@"PhoneNo"];
    
    @try {
        UIDevice *device = [UIDevice currentDevice];
        if ([[device model] isEqualToString:@"iPhone"]) {
            
            NSURL *phoneUrl = [NSURL
                               URLWithString:[NSString stringWithFormat:@"telprompt:%@", PhoneNumber]];
            
            if ([[UIApplication sharedApplication] canOpenURL:phoneUrl]) {
                UIApplication *application = [UIApplication sharedApplication];
                [application openURL:phoneUrl options:@{} completionHandler:nil];

               // [[UIApplication sharedApplication] openURL:phoneUrl];
            }
            
        } else {
            
            UIAlertController *myAlertController =
            [[Web_Services alloc] alert:@"Your device doesn't support this feature."];
            [self presentViewController:myAlertController
                               animated:YES
                             completion:nil];
        }
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
    
}


-(void)RadiousBtnTitle
{
    @try {
        NSString *btnTitle;
        
        
        if ([mPref valueForKey:@"TempRadius"] ==nil) {
            NSData *registerObjj = [mPref valueForKey:@"SaveRegisterDetails"];
            
            if (registerObjj!=nil) {
                NSDictionary *myDictionary =   (NSDictionary*) [NSKeyedUnarchiver unarchiveObjectWithData:registerObjj];
                
                btnTitle = [myDictionary valueForKey:@"DefaultRadius"];
                
                if (btnTitle==nil) {
                    NSString *btnTitle1 = [mPref valueForKey:@"Radious"];
                    if (btnTitle1==nil) {
                        btnTitle1 = @"1000";
                        btnTitle= btnTitle1;
                    }
                    else{
                        btnTitle = btnTitle1;
                    }
                    
                }
            }
            
            else
            {
                NSString *btnTitle1 = [mPref valueForKey:@"Radious"];
                if (btnTitle1==nil) {
                    btnTitle1 = @"1000";
                    btnTitle= btnTitle1;
                }
                btnTitle = btnTitle1;
                
            }
            
        }
        else
            btnTitle =[mPref valueForKey:@"TempRadius"];
        // [mPref setValue:nil forKey:@"TempRadius"];
        
        
        
        
        
        
        btnTitle = [NSString stringWithFormat:@"%@",btnTitle];
        
        
        if ([btnTitle isEqualToString:@"500"]) {
            btnTitle = @"0.5 Km";
        }
        else if ([btnTitle isEqualToString:@"1000"]) {
            btnTitle = @"1 Km";
        }
        else if ([btnTitle isEqualToString:@"3000"]) {
            btnTitle = @"3 Km";
        }
        else if ([btnTitle isEqualToString:@"5000"]) {
            btnTitle = @"5 Km";
        }
        else if ([btnTitle isEqualToString:@"10000"]) {
            btnTitle = @"10 Km";
        }
        else if (btnTitle==nil)
            btnTitle= @"0.5 Km";
        
        else if([btnTitle isEqualToString:@"(null)"])
        {
            btnTitle = @"0.5 Km";
            [mPref setValue:@"500" forKey:@"Radious"];
        }
        
        [Radious setTitle:btnTitle forState:UIControlStateNormal];
        
    } @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
        
    } @finally {
        
    }
}



-(void)likeBtn:(UIButton*)sender
{
    
    @try {
        
    
    if ([mPref valueForKey:USERREGISTERID]) {
    
    
    CGPoint buttonPosition = [sender convertPoint:CGPointZero toView:storeTable];
    
    NSIndexPath *indexPath = [storeTable indexPathForRowAtPoint:buttonPosition];
    
    RTStore_List *BlockedItem = [storesReponseList objectAtIndex:indexPath.row];
        NSString *likeKey= @"";
        
        
        
        if ([LogInType isEqualToString:@"Business"])
        {
            
            if ([BlockedItem.CustomerReaction isEqualToString:@"Connected"]) {
                likeKey= @"DisConnect";
            }
            else likeKey = @"Connect";
            
          //  storeLikeKey= @"Connect";
          //  likeKey= @"Connect";
           
        }
        else if ([LogInType isEqualToString:@"Individual"] )
            
            {
                if ([BlockedItem.CustomerReaction isEqualToString:@"Store Like"]) {
                    likeKey= @"UnLike";
                }
                else likeKey = @"Like";
                
               //  storeLikeKey= @"Store Like";
            }
        
        
        
       
    
    NSDictionary *storeLikUnlikeObj = @{@"userRegisterId":BlockedItem.UserRegisterId,
                                        @"memberId":[mPref valueForKey:USERREGISTERID],
                                        @"Reaction":likeKey
                                        };

    [mWebService StoreLikeUnlike:storeLikUnlikeObj];
        [self seachOffer:@""];
        
        
      //  [self viewDidLoad];
    
    }
    else
    {
        
        self.popViewController = [[PopUpViewController alloc] initWithNibName:@"PopUpViewController" bundle:nil];
        [self.popViewController setTitle:@"This is a popup view"];
        
        [self.popViewController showInView:self.view withImage:[UIImage imageNamed:@"rprt_usinfo.png"] withMessage:@"You just triggered a great popup window" animated:YES];

        
//        Login  *mLogin = [[Login alloc]initWithNibName:LOGIN bundle:nil];
//        [self presentViewController:mLogin animated:YES completion:nil];
        
    }
        
    }
    @catch (NSException *exception) {
        [self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
    
}

- (void) showAlertPop:(NSString*)alertText expObj:(NSException*) exp{
    if(exp != nil)
    {
        NSLog(@"%@", exp.description);
    }
    UIAlertController *myAlertController =[mWebService  alert:alertText];
    [self presentViewController:myAlertController animated:YES completion:nil];
}


-(void) viewDidLayoutSubviews {
    
    @try {
        
        
        [super viewDidLayoutSubviews];
        //[self.scrollview layoutIfNeeded];
        // self.scrollview.contentSize=self.Contentview.bounds.size;
        UIGraphicsBeginImageContext(self.view.frame.size);
        UIImage *image = UIGraphicsGetImageFromCurrentImageContext();
        UIGraphicsEndImageContext();
        image= [UIImage imageNamed:@"bgerror.png"];
        storeTable.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"bgerror.png"]];
        self.view.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"bgerror.png"]];
        
        
        
        
    } @catch (NSException *exception) {
        //[self showAlertPop:@"Error while fetching data." expObj:exception];
    } @finally {
        
    }
}



@end
