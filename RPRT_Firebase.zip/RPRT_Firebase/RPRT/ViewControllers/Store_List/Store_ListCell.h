//
//  Store_ListCell.h
//  RPRT
//
//  Created by sravanthi Gumma on 10/09/1938 Saka.
//  Copyright © 1938 Saka DevpointSolutions. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Store_ListCell : UITableViewCell

@property(weak,nonatomic) IBOutlet UILabel *storeName;
@property(weak,nonatomic) IBOutlet UILabel *ContactNumber;
@property(weak,nonatomic) IBOutlet UILabel *UserName;
@property(weak,nonatomic) IBOutlet UILabel *emailID;
@property(weak,nonatomic) IBOutlet UILabel *Address;
@property(weak,nonatomic) IBOutlet UILabel *Distance;
@property(weak,nonatomic) IBOutlet UILabel *customerCnt;
@property(weak,nonatomic) IBOutlet UILabel *businesstype;
@property(weak,nonatomic) IBOutlet UIImageView *profile;
@property(weak,nonatomic) IBOutlet UIView *custView;;
@property(weak,nonatomic) IBOutlet UIButton *likeBtn;
@property(weak,nonatomic) IBOutlet UIButton *CallBtn;

@end
