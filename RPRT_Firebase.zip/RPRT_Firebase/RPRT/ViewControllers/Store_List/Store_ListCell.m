//
//  Store_ListCell.m
//  RPRT
//
//  Created by sravanthi Gumma on 10/09/1938 Saka.
//  Copyright © 1938 Saka DevpointSolutions. All rights reserved.
//

#import "Store_ListCell.h"

@implementation Store_ListCell


@synthesize  storeName= storeName;
@synthesize   ContactNumber= ContactNumber;
@synthesize   UserName= UserName;
@synthesize   emailID= emailID;
@synthesize   Address= Address;
@synthesize   Distance= Distance;
@synthesize   profile= profile;
@synthesize  businesstype = businesstype;
@synthesize  likeBtn = likeBtn;
@synthesize CallBtn= CallBtn;
@synthesize  customerCnt = customerCnt;


- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

-(void)layoutSubviews{
    //    self.layer.cornerRadius = 45/2;
    //    UIBezierPath *shadowPath = [UIBezierPath
    //                                bezierPathWithRoundedRect: self.bounds
    //                                cornerRadius: radius];
    //    self.layer.masksToBounds = false;
    //    self.layer.shadowColor = [UIColor blackColor].CGColor;
    //    self.layer.shadowOffset = CGSizeMake(0, 4);
    //    self.layer.shadowOpacity = 0.2;
    //    self.layer.shadowPath = shadowPath.CGPath;
    
    // self.view1.layer.cornerRadius=5;
    
    self.custView.layer.shadowColor = [UIColor grayColor].CGColor;
    self.custView.layer.borderColor = [UIColor colorWithRed:175.0/256.0 green:175.0/256.0 blue:175.0/256.0 alpha:1].CGColor;
    self.custView.layer.borderWidth=0.5f;
    self.custView.layer.shadowOffset = CGSizeMake(1.0, 1.0);
    self.custView.layer.shadowOpacity = 0.7;
    self.custView.layer.cornerRadius = 4.0;
    
    
    // self.layer.shadowColor = [UIColor lightGrayColor].CGColor;
    //self.layer.shadowOffset = CGSizeMake(0, 4);
    // self.layer.shadowOpacity = 1;
    //  self.layer.shadowRadius = 1.0;
    
    
    
    self.profile.layer.cornerRadius = self.profile.frame.size.width/2;
    self.profile.layer.masksToBounds = YES;
}


- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
