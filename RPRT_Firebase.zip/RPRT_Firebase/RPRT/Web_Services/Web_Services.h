//
//  Web_Services.h
//  RPRT
//
//  Created by sravanthi Gumma on 14/01/16.
//  Copyright © 2016 DevpointSolutions. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "Constances.h"
#import "GeoCodeLocation.h"


@interface Web_Services : NSObject
{
    NSMutableURLRequest *Request;
    NSDictionary *result;
    NSString *ExclusiveCnt;
  
}
+(Web_Services *)GetSharedInstance;

-(NSDictionary*)GetWebServiceResponse:(NSDictionary*)json URl:(NSString*)wSMethodName;
-(NSDictionary*)GetOpportunities:(NSDictionary*)location;
-(NSDictionary*)GetOpportinityByUserID:(NSString*)offerId;
-(NSDictionary*)GetOpportinityReview:(NSString*)offerId MethodName:(NSString*)methodName;

-(NSMutableDictionary*)GetUsersRegisterBYID:(NSString*)userRegistedID;

-(NSDictionary*)UserLoginValidation:(NSDictionary*)loginparams;

-(NSDictionary*)SaveUser:(GeoCodeLocation*)userDetails;
-(NSDictionary*)SaveBlockeditem:(NSDictionary*)blockedItemParams;
-(NSDictionary*)SaveRegister:(NSDictionary*)regDetails;

-(UIAlertController *)alert:(NSString *)message;
-(NSDictionary*)Getcategories:(NSString*)methodname;
-(NSDictionary*)SaveStoreRegister:(NSDictionary*)RegDetails;
-(NSMutableArray*)GetSubCategories:(NSString*)methodName CatgoryID:(NSString*)CatID;
-(NSDictionary*)PostOffer:(NSDictionary*)inputParams;
-(NSDictionary*)SaveOpportunityFeedback:(NSDictionary*)inputParams;
-(NSDictionary*)SaveUserViewedOpportunities:(NSDictionary*)inputParams;
-(NSDictionary*)GetTimeLeftUserByCategory:(NSString*)methodname Id:(NSString*)iD;
-(NSMutableArray*)GetVendorBlocks:(NSString*)opportunityID MethodName:(NSString*)methodName;
-(NSDictionary*)GetOpportunityByID:(NSString*)opportunityID MethodName:(NSString*)methodName;
-(NSDictionary*)GetData:(NSDictionary*)getOfferInput;
-(NSDictionary*)GetScanDetails:(NSString*)keyvalu;
-(NSDictionary*)CheckEmail:(NSString*)emailId;
-(NSDictionary*)CheckUserAlreadyPresent:(NSDictionary*)emailInfo;
-(NSDictionary*)CheckUserAlreadyPresentNew:(NSDictionary*)emailInfo;
-(NSDictionary*)checkPhoneNo:(NSString*)phoneNo;
//http://rtrpservice.azurewebsites.net/api/RPRT/http://rtrpservice.azurewebsites.net/api/RPRT/GetReservedOpportunitiesBYUserRegId/176
-(NSDictionary*)GetReservedOpportunitiesBYUserRegId:(NSString*)registerID;

-(NSDictionary*)SaveUserInfo:(GeoCodeLocation*)userInfo;
-(NSDictionary*)GetUsersInfo:(NSDictionary*)location;
-(NSArray*)UserTypes;


-(NSDictionary*)SaveUserSettings:(NSDictionary*)userInfo;
-(NSDictionary*)SaveFavouriteAddress:(NSDictionary*)userInfo;
-(NSMutableArray*)GetFavAddress:(NSString*)userRegisterId;

-(NSDictionary*)GetUserSettings:(NSString*)userRegisterId;

-(NSDictionary*)SendNotificationForNearByUsers :(NSDictionary*)notificationParams;

-(NSDictionary*)SaveCustomer:(NSDictionary*)CustoParams;

-(NSMutableArray*)GetMyCustomers:(NSString*)userRegID;

-(NSDictionary*)GetCounts:(NSDictionary*)inputParams;


-(NSString*)GetExclusive:(NSDictionary*)inputParams;
-(NSDictionary*)GetMyExclusiveOpportunities:(NSDictionary*)inputParams;

-(NSDictionary*)GetStoreDetails:(NSString*)vendorRegID;

-(NSDictionary*)ProcessLogin:(NSDictionary*)preogessLoginParams;

-(NSMutableArray*)GetStores:(NSDictionary*)inputstring;

-(NSString*)StoreLikeUnlike:(NSDictionary*)storeLikeUnObj;

-(NSString*)GenerateSalesCode:(NSString*)codeObjString;

-(NSMutableArray *)MySalesCodes:(NSString*)slareRegID;

-(NSDictionary *)SaveRequestReply:(NSDictionary*)requets;

-(NSDictionary*)GetCustomerRequests:(NSDictionary*)inputCustomerparams;

-(NSDictionary*)GetAddress:(NSDictionary*)latlongObj;

-(NSDictionary*)SendOTP:(NSString*)countryCode mobileNumber:(NSString*)mobileNumber ;

-(NSMutableArray*)GetBanner;


-(NSDictionary*)ReportSpam:(NSString*)Ids Methodname:(NSString*)MethodName;
-(NSDictionary*)HideOffer:(NSString*)Ids Methodname:(NSString*)MethodName;

-(NSString*)DeleteOpportunity:(NSString*)OppoID;

-(NSMutableArray*)GetMyNotifications:(NSString*)UserRegisterId;
-(NSString*)SendInvite:(NSString*)NotificationID inviteMessage:(NSString*)inviteMessage;
-(NSString*)AcceptReject:(NSString*)notificationID acceptReject:(NSString*)requestResult;


// SendOTP/{countryCode}/{mobileNumber}


@end
