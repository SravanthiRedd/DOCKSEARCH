//
//  Web_Services.m
//  RPRT
//
//  Created by sravanthi Gumma on 14/01/16.
//  Copyright © 2016 DevpointSolutions. All rights reserved.
//

#import "Web_Services.h"
#import "AppDelegate.h"
#import "GeoCodeLocation.h"
#import "RMMapper.h"
#import "UIImageView+AFNetworking.h"
#import "RTStore_List.h"
static Web_Services *sharedInstance = nil;

@implementation Web_Services

+(Web_Services*)GetSharedInstance {
    
    
    if (sharedInstance == nil) {
        
        sharedInstance = [[Web_Services alloc] init];
       //  Preferences *Prefer = [Preferences GetSharedInstance];
    }
    return sharedInstance;
    
    
}

-(NSDictionary*)GetData:(NSDictionary*)getOfferInput
{
    @try {
        
        NSString *radious;
        
        if ([getOfferInput valueForKey:@"radious"]==nil) {
            radious = @"1000";
            NSUserDefaults *mPref= [NSUserDefaults standardUserDefaults];
            [mPref setValue:@"1000" forKey:@"radious"];
        }
        else radious =[getOfferInput valueForKey:@"radious"];
        
        NSString *Methodname = [getOfferInput valueForKey:@"Method"];
        
        NSString *State = [[getOfferInput valueForKey:@"State"] stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
        if (State==nil) State = @"";
        NSString *Country = [[getOfferInput valueForKey:@"Country"] stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
                
        NSDictionary *locationInput  = @{@"Location":[getOfferInput valueForKey:@"Location"],
                                         @"radius":radious,
                                         @"State":State,
                                         @"Country":Country,
                                         
                                         };
        NSDictionary  *getNumberOffers=  [self GetWebServiceResponse:locationInput URl:Methodname];
        
        return getNumberOffers;

        
    } @catch (NSException *exception) {
        
    } @finally {
        
    }
    
    
}

-(NSMutableArray*)GetVendorBlocks:(NSString*)opportunityID MethodName:(NSString*)methodName
{
      @try {
          
    NSString *baseUrl = [NSString stringWithFormat:@"%@%@/%@",baseURL,methodName,opportunityID];
    // NSURL *url = [NSURL URLWithString:baseUrl];
    NSURL *RPRTUrlpath = [NSURL URLWithString:baseUrl];
    
    NSData *myData = [NSData dataWithContentsOfURL:RPRTUrlpath];
    
    NSError* error1;
    
    NSMutableArray  *getUserBlock = [NSJSONSerialization JSONObjectWithData:myData
                                                                options:kNilOptions
                                                                  error:&error1];
    
    return getUserBlock;
          
}
@catch (NSException *exception) {
    
}
@finally {
    
}


}


-(NSDictionary*)GetOpportinityByUserID:(NSString*)UserRegistedID
{
    @try {
        
        
        NSString *baseUrl = [NSString stringWithFormat:@"%@%@/%@/false",baseURL,GETOPPORTUNITIESBYUSERID,UserRegistedID];
        // NSURL *url = [NSURL URLWithString:baseUrl];
        NSURL *RPRTUrlpath = [NSURL URLWithString:baseUrl];
        
        NSData *myData = [NSData dataWithContentsOfURL:RPRTUrlpath];
        
        NSError* error1;
        
        NSDictionary  *getReviews = [NSJSONSerialization JSONObjectWithData:myData
                                                                    options:kNilOptions
                                                                      error:&error1];
        
        return getReviews;
    }
    @catch (NSException *exception) {
        
    }
    @finally {
        
    }
}



-(NSDictionary*)GetOpportinityReview:(NSString*)OfferId MethodName:(NSString*)methodName {
    @try {
        
    
    NSString *baseUrl = [NSString stringWithFormat:@"%@%@/%@",baseURL,methodName,OfferId];
    // NSURL *url = [NSURL URLWithString:baseUrl];
    NSURL *RPRTUrlpath = [NSURL URLWithString:baseUrl];
    
    NSData *myData = [NSData dataWithContentsOfURL:RPRTUrlpath];
    
    NSError* error1;
    
    NSDictionary  *getReviews = [NSJSONSerialization JSONObjectWithData:myData
                                                                       options:kNilOptions
                                                                         error:&error1];
    
    return getReviews;
    }
    @catch (NSException *exception) {
        
    }
    @finally {
        
    }
}

-(NSDictionary*) GetWebServiceResponse:(NSDictionary*)Inputstring URl:(NSString*)WSMethodName {
    
    @try {
        
        NSString *baseUrl = [NSString stringWithFormat:@"%@%@",baseURL,WSMethodName];
        NSURL *url = [NSURL URLWithString:baseUrl];
        NSError *error;
        NSData* jsonData = [NSJSONSerialization dataWithJSONObject:Inputstring options:kNilOptions error:&error];
        Request = [NSMutableURLRequest requestWithURL:url];
        [Request setURL:url];
        [Request setHTTPMethod:@"POST"];
        [Request setValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
        [Request setValue:@"application/json" forHTTPHeaderField:@"Accept"];
      //  [Request setValue:@"text/plain" forHTTPHeaderField:@"Accept"];
        
        
        
       // I think you can check by changing @"text/plain" to @"application/json"
        [Request setHTTPBody:jsonData];

        dispatch_semaphore_t semaphore = dispatch_semaphore_create(0);
        
        NSURLSession *session = [NSURLSession sharedSession];
        NSURLSessionDataTask *task = [session dataTaskWithRequest:Request completionHandler: ^(NSData *data, NSURLResponse *response, NSError *error) {
           
            
            
            if (data!=nil && error==nil) {
                result = [NSJSONSerialization
                          JSONObjectWithData:data
                          options:kNilOptions
                          error:&error];
                
                
            
                
                
            }
            
            dispatch_semaphore_signal(semaphore);
            
        }] ;
        [task resume];
        dispatch_semaphore_wait(semaphore, DISPATCH_TIME_FOREVER);

        
        return result;
        
    }
    @catch (NSException *exception) {
        
        NSLog(@"Exception %@",exception.reason);
    }
    
}



-(NSString*) GetWebServiceResponseForExclusive:(NSDictionary*)Inputstring URl:(NSString*)WSMethodName {
    
    @try {
        
        NSString *baseUrl = [NSString stringWithFormat:@"%@%@",baseURL,WSMethodName];
        NSURL *url = [NSURL URLWithString:baseUrl];
        NSError *error;
        NSData* jsonData = [NSJSONSerialization dataWithJSONObject:Inputstring options:kNilOptions error:&error];
        Request = [NSMutableURLRequest requestWithURL:url];
        [Request setURL:url];
        [Request setHTTPMethod:@"POST"];
        [Request setValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
        [Request setValue:@"application/json" forHTTPHeaderField:@"Accept"];
        //  [Request setValue:@"text/plain" forHTTPHeaderField:@"Accept"];
        
        
        
        // I think you can check by changing @"text/plain" to @"application/json"
        [Request setHTTPBody:jsonData];
        
        dispatch_semaphore_t semaphore = dispatch_semaphore_create(0);
        
        NSURLSession *session = [NSURLSession sharedSession];
        NSURLSessionDataTask *task = [session dataTaskWithRequest:Request completionHandler: ^(NSData *data, NSURLResponse *response, NSError *error) {
           
            
            
            if (data!=nil && error==nil) {
              //  if ([WSMethodName isEqualToString:@"GetMyExclusiveOpportunitiesCount"]) {
                    ExclusiveCnt = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
                    
                    //NSLog(@"String  %@",string);
                    
               // }
                
                
                
                
            }
            
            dispatch_semaphore_signal(semaphore);
            
        }] ;
        [task resume];
        dispatch_semaphore_wait(semaphore, DISPATCH_TIME_FOREVER);
        
        
        return ExclusiveCnt;
        
    }
    @catch (NSException *exception) {
        
        NSLog(@"Exception %@",exception.reason);
    }
    
}





-(NSDictionary*)SaveUser:(GeoCodeLocation*)UserDetails {
    @try {
        
   
    NSString *phoneName = [[UIDevice currentDevice] name];
    NSString *uniqueIdentifier = [[[UIDevice currentDevice] identifierForVendor] UUIDString];
    
        NSUserDefaults *mPref = [NSUserDefaults standardUserDefaults];
        NSString *savedUserID = [mPref valueForKey:@"SaveUserID"];
        if (savedUserID==nil) {
            savedUserID = @"0";
            
        }
        else
        {
            savedUserID= savedUserID;
        }
        NSString *lat=@"";
        NSString *lon= @"";
        
        
        if (UserDetails==nil) {
            lat=@"0.000000";
            lon=@"0.000000";
        }
        else
        {
            lat = UserDetails.Latitude;
            lon = UserDetails.Longitude;
        }
        
        
        NSString *gcmID = [mPref valueForKey:@"FCMID"];
        if ([gcmID isEqualToString:@""] || gcmID==nil) {
            gcmID=@"";
        }
        
    NSDictionary *locationInput  = @{@"GCM_Regid":gcmID,
                                     @"UserType":@"1",
                                     @"DeviceId":uniqueIdentifier,
                                     @"Email":@"",
                                     LATITUDE:lat,
                                     LONGITUDE:lon,
                                     @"UserName":phoneName,
                                     @"IsPrimary":@"YES",
                                     @"PhoneNo":@"",
                                     @"UserID":savedUserID,
                                     @"DeviceOS":[[UIDevice currentDevice] model],
                                     @"OsVersion":[[UIDevice currentDevice] systemVersion],
                       
                                     };
    
    NSDictionary *response=  [self GetWebServiceResponse:locationInput URl:SAVEUSERS];
    
    return response;
    }
    @catch (NSException *exception) {
        
    }
    @finally {
        
    }
}

-(NSDictionary*)GetOpportunities:(NSDictionary*)location {
    
    @try {
            NSString *locationLatLon= [NSString stringWithFormat:@"%@,%@",[location valueForKey:LATITUDE],[location valueForKey:LONGITUDE]];
    NSString *moduleId = [location valueForKey:@"ModuleId"];
        
        NSUserDefaults *mPref = [NSUserDefaults standardUserDefaults];
        
        NSString *State = [[location valueForKey:@"State"] stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
        if (State==nil) State = @"";
        NSString *Country = [[location valueForKey:@"Country"] stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
        if (Country==nil) Country = @"";
        NSString *UserID =[mPref valueForKey:USERREGISTERID];
        
        if (UserID ==nil) {
            UserID= @"0";
        }
        UserID = [NSString stringWithFormat:@"%@",UserID];
        NSString *radious;
        if ([location valueForKey:@"Radious"]==nil) {
            radious = @"1000";
            [mPref setValue:radious forKey:@"Radious"];
        }
        else
        radious =[location valueForKey:@"Radious"];
        
        NSData *registerObj = [mPref valueForKey:@"SaveRegisterDetails"];
        
        if (registerObj!=nil) {
       NSDictionary *myDictionary =   (NSDictionary*) [NSKeyedUnarchiver unarchiveObjectWithData:registerObj];
            if (radious==nil) {
                
            radious = [myDictionary valueForKey:@"DefaultRadius"];
            
            if (radious==nil) {
                radious = @"1000";
            }
            }
        }
        
        
        //Radious
    NSDictionary *locationInput  = @{@"PageSize":@"10",
                                     @"PageNo":@"1",
                                     @"KeyWords":@"",
                                     @"Location":locationLatLon,
                                     @"radius":radious,
                                     @"types":@"",
                                     @"ModuleId":moduleId,
                                     @"LocationFlag":@"NotChanged",
                                     @"Categories":@"",
                                     @"State":State,
                                     @"Country":Country,
                                     @"UserRegisterId":UserID
                                     };
    
    NSDictionary *response=  [self GetWebServiceResponse:locationInput URl:SEARCHOPPORTUNITIESGOOGLE];
    
    return response;
    }
    @catch (NSException *exception) {
        
    }
    @finally {
        
    }
}



-(NSDictionary*)UserLoginValidation:(NSDictionary*)loginparams {
    
    @try {
           NSString *username= [loginparams valueForKey:@"UserName"];
    NSString *password = [loginparams valueForKey:@"Password"];
    NSDictionary *locationInput  = @{@"Email":username,
                                     @"Password":password
                                };
    
    
    NSDictionary *response=  [self GetWebServiceResponse:locationInput URl:LOGINVENDOR];
        Preferences *Prefer = [Preferences GetSharedInstance];
        [Prefer StoreLoginUserDetails:response];
        [Prefer StoreUserTime:[response valueForKey:@"Time"]];
    
    return response;
    }
    @catch (NSException *exception) {
        
    }
    @finally {
        
    }

}

-(NSDictionary*)SaveBlockeditem:(NSDictionary*)BlockedItemParams {
    
    @try {
    NSString *DeviceId=[NSString stringWithFormat:@"%@",[BlockedItemParams valueForKey:@"DeviceId"]];
    NSString *BlockID =[NSString stringWithFormat:@"%@",[BlockedItemParams valueForKey:@"BlockedUserId"]];
    NSString *Oppid =[NSString stringWithFormat:@"%@",[BlockedItemParams valueForKey:@"OpportunityId"]];
    NSString *blockText =[NSString stringWithFormat:@"%@",[BlockedItemParams valueForKey:@"BlockText"]];
        NSString *blockid =[NSString stringWithFormat:@"%@",[BlockedItemParams valueForKey:@"BlockId"]];
        NSString *keyValue = [NSString stringWithFormat:@"%@",[BlockedItemParams valueForKey:@"KeyValue"]];
        NSString *quality =[NSString stringWithFormat:@"%@",[BlockedItemParams valueForKey:@"Quantity"]];
            NSString *claimedTime =[NSString stringWithFormat:@"%@",[BlockedItemParams valueForKey:@"ClaimedTime"]];
            NSString *TransactionComplete =[NSString stringWithFormat:@"%@",[BlockedItemParams valueForKey:@"TransactionComplete"]];

        NSDictionary *claimedDetails=@{@"BlockId":blockid,
                                       @"BlockedUserId":BlockID,
                                       @"OpportunityId":Oppid,
                                       @"BlockText":blockText,
                                       @"KeyValue":keyValue,
                                       @"DeviceId":DeviceId,
                                       @"Quantity":quality,
                                       @"ClaimedTime":claimedTime,
                                       @"TransactionComplete":TransactionComplete
                                       };
            NSDictionary *response=  [self GetWebServiceResponse:claimedDetails URl:BLOCKORNOTIFYOPPORTUNITIES];
        
        NSMutableDictionary *m = [response mutableCopy];
   
        [m setValue:[response valueForKey:@"BlockText"] forKey:@"keyValue"];
        
    return m;
    }
    @catch (NSException *exception) {
        
    }
    @finally {
        
    }
}

-(UIAlertController*)alert:(NSString*)alertMessage {
    
    @try {
       
    
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"Right Place Right Time"
                                                                   message:alertMessage
                                                            preferredStyle:UIAlertControllerStyleAlert];
    
    UIAlertAction* defaultAction = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault
                                                          handler:^(UIAlertAction * action) {}];
    
    [alert addAction:defaultAction];
    //    [self presentViewController:alert animated:YES completion:nil];
    
    return alert;
    }
    @catch (NSException *exception) {
        
    }
    @finally {
        
    }
    
}

-(NSDictionary*)SaveRegister:(NSDictionary*)RegDetails {
    @try {
      
        NSDictionary *response=  [self GetWebServiceResponse:RegDetails URl:@"SaveUsersRegister"];
        Preferences *Prefer = [Preferences GetSharedInstance];
        [Prefer StoreLoginUserDetails:response];
        [Prefer StoreUserTime:@"60"];
        
       // NSUserDefaults  *mPref = [NSUserDefaults standardUserDefaults];
        //[mPref setValue:[response valueForKey:@"Time"] forKey:@"TimeSlot"];

    return response;
    }
    @catch (NSException *exception) {
        
    }
    @finally {
        
    }
}


-(NSString*)GenerateSalesCode:(NSString*)codeObjString
{
    @try {
      
    NSString *baseUrl = [NSString stringWithFormat:@"%@%@/%@",baseURL,@"GenerateSalesCode",codeObjString];
    // NSURL *url = [NSURL URLWithString:baseUrl];
    NSURL *RPRTUrlpath = [NSURL URLWithString:baseUrl];
    
    NSData *myData = [NSData dataWithContentsOfURL:RPRTUrlpath];
    
   // NSError* error1;
        NSString* myString;
        myString = [[NSString alloc] initWithData:myData encoding:NSASCIIStringEncoding];
        
        
//    NSString  *code = [NSJSONSerialization JSONObjectWithData:myData
//                                                                     options:kNilOptions
//                                                                       error:&error1];
    
    return myString;
}
@catch (NSException *exception) {
    
}
@finally {
    
}
}

-(NSMutableArray *)MySalesCodes:(NSString*)slareRegID
{
    
    @try {
        
        NSString *baseUrl = [NSString stringWithFormat:@"%@%@/%@",baseURL,@"MySalesCodes",slareRegID];
        // NSURL *url = [NSURL URLWithString:baseUrl];
        NSURL *RPRTUrlpath = [NSURL URLWithString:baseUrl];
        
        NSData *myData = [NSData dataWithContentsOfURL:RPRTUrlpath];
        
        NSError* error1;
        
        
        
        NSMutableArray  *mysalesCodeResponse = [NSJSONSerialization JSONObjectWithData:myData
                                                          options:kNilOptions
                                                            error:&error1];
        
        return mysalesCodeResponse;
    }
    @catch (NSException *exception) {
        
    }
    @finally {
        
    }

}


-(NSDictionary*)SaveStoreRegister:(NSDictionary*)RegDetails {
    @try {
        
        //NSDictionary *dic = @{@"userReg":RegDetails};
        
        NSDictionary *response=  [self GetWebServiceResponse:RegDetails URl:@"SaveStoreRegister"];
        Preferences *Prefer = [Preferences GetSharedInstance];
        [Prefer StoreLoginUserDetails:response];
        [Prefer StoreUserTime:@"60"];
        
        // NSUserDefaults  *mPref = [NSUserDefaults standardUserDefaults];
        //[mPref setValue:[response valueForKey:@"Time"] forKey:@"TimeSlot"];
        
        return response;
    }
    @catch (NSException *exception) {
        
    }
    @finally {
        
    }
}


-(NSDictionary*)Getcategories:(NSString*)Methodname {
    @try {
       
    NSString *baseUrl = [NSString stringWithFormat:@"%@%@",baseURL,Methodname];
    // NSURL *url = [NSURL URLWithString:baseUrl];
    NSURL *RPRTUrlpath = [NSURL URLWithString:baseUrl];
    
    NSData *myData = [NSData dataWithContentsOfURL:RPRTUrlpath];
    
    NSError* error1;
    
    NSDictionary  *GetCategoryResp = [NSJSONSerialization JSONObjectWithData:myData
                                                                     options:kNilOptions
                                                                       error:&error1];
    
    return GetCategoryResp;
    }
    @catch (NSException *exception) {
        
    }
    @finally {
        
    }
 
}

-(NSMutableArray*)GetSubCategories:(NSString*)MethodName CatgoryID:(NSString*)CatID
{
    @try {
        
        NSString *baseUrl = [NSString stringWithFormat:@"%@%@/%@",baseURL,MethodName,CatID];
        // NSURL *url = [NSURL URLWithString:baseUrl];
        NSURL *RPRTUrlpath = [NSURL URLWithString:baseUrl];
        
        NSData *myData = [NSData dataWithContentsOfURL:RPRTUrlpath];
        
        NSError* error1;
        
        NSMutableArray  *GetCategoryResp = [NSJSONSerialization JSONObjectWithData:myData
                                                                         options:kNilOptions
                                                                           error:&error1];
        
        return GetCategoryResp;
    }
    @catch (NSException *exception) {
        
    }
    @finally {
        
    }
}

-(NSDictionary*)PostOffer:(NSDictionary*)InputParams {
    @try {
       
        
        
        
    NSDictionary *response=  [self GetWebServiceResponse:InputParams URl:SAVEOPPORTUNITIES];
    
    return response;
    }
    @catch (NSException *exception) {
        
    }
    @finally {
        
    }

}

-(NSDictionary*)SaveUserViewedOpportunities:(NSDictionary*)InputParams {
    @try {
       

    NSDictionary *UserViewOpp  = @{@"UserId":[InputParams valueForKey:@"UserID"],
                                    @"OpportunityID":[InputParams valueForKey:@"OpportunityID"],
                                    @"UserViewedID":@"0",
                                    @"Shortlisted":@"true",
                                    @"KeyValue":@"nil"
                                    };
    
    NSDictionary *response=  [self GetWebServiceResponse:UserViewOpp URl:SAVEUSERVIEWEDOPPORTUNITY];

    return response;
    }
    @catch (NSException *exception) {
        
    }
    @finally {
        
    }
}

-(NSDictionary*)SaveOpportunityFeedback:(NSDictionary*)InputParams
{
    @try {
        
       
        NSDictionary *UserViewOpp  = @{@"UserId":[InputParams valueForKey:@"UserID"],
                                       @"OpportunityID":[InputParams valueForKey:@"OpportunityID"],
                                       @"FeedbackTitle":[InputParams valueForKey:@"FeedbackTitle"],
                                       @"Comments":[InputParams valueForKey:@"Comments"],
                                       @"Rating":[InputParams valueForKey:@"Rating"]
                                       };
        
        NSDictionary *response=  [self GetWebServiceResponse:UserViewOpp URl:SAVEOPPORTUNITYFEEDBACK];
        
        return response;
    }
    @catch (NSException *exception) {
        
    }
    @finally {
        
    }

}

-(NSDictionary*)GetTimeLeftUserByCategory:(NSString*)Methodname Id:(NSString*)ID
{
    @try {
        
        NSString *baseUrl = [NSString stringWithFormat:@"%@%@/%@",baseURL,Methodname,ID];
        // NSURL *url = [NSURL URLWithString:baseUrl];
        NSURL *RPRTUrlpath = [NSURL URLWithString:baseUrl];
        
        NSData *myData = [NSData dataWithContentsOfURL:RPRTUrlpath];
        
        NSError* error1;
        
        NSDictionary  *GetCategoryResp = [NSJSONSerialization JSONObjectWithData:myData
                                                                           options:kNilOptions
                                                                             error:&error1];
        
        return GetCategoryResp;
    }
    @catch (NSException *exception) {
        
    }
    @finally {
        
    }
}

-(NSDictionary*)GetOpportunityByID:(NSString*)opportunityID MethodName:(NSString*)methodName
{
    @try {
        
        NSString *baseUrl = [NSString stringWithFormat:@"%@%@/%@",baseURL,methodName,opportunityID];
        // NSURL *url = [NSURL URLWithString:baseUrl];
        NSURL *RPRTUrlpath = [NSURL URLWithString:baseUrl];
        
        NSData *myData = [NSData dataWithContentsOfURL:RPRTUrlpath];
        
        NSError* error1;
        
        NSDictionary  *GetCategoryResp = [NSJSONSerialization JSONObjectWithData:myData
                                                                         options:kNilOptions
                                                                           error:&error1];
        
        return GetCategoryResp;
    }
    @catch (NSException *exception) {
        
    }
    @finally {
        
    }
}

-(NSMutableDictionary*)GetUsersRegisterBYID:(NSString*)userRegistedID
{
    @try {
        
        NSString *baseUrl = [NSString stringWithFormat:@"%@%@/%@",baseURL,GETUSERSREGISTERBYID,userRegistedID];
    
        NSURL *RPRTUrlpath = [NSURL URLWithString:baseUrl];
        
        NSData *myData = [NSData dataWithContentsOfURL:RPRTUrlpath];
        
        NSError* error1;
        
        NSDictionary  *getCategoryResp = [NSJSONSerialization JSONObjectWithData:myData
                                                                         options:kNilOptions
                                                                           error:&error1];
        
        return getCategoryResp;
    }
    @catch (NSException *exception) {
        
    }
    @finally {
        
    }

}

-(NSDictionary*)GetScanDetails:(NSString*)keyvalu
{
    @try {
        NSUserDefaults *mPref = [NSUserDefaults standardUserDefaults];
        NSString *userRegisterID =[mPref valueForKey:USERREGISTERID];
        
        NSDictionary *userViewOpp  = @{
                                       @"keyCode":keyvalu,
                                       @"VendorId":userRegisterID
                                    };
        
        NSDictionary *response=  [self GetWebServiceResponse:userViewOpp URl:SCANCODEBYID];
        
        return response;
    }
    @catch (NSException *exception) {
        
    }
    @finally {
        
    }

}
-(NSDictionary*)CheckEmail:(NSString*)emailId
{
    @try {
        NSDictionary *userViewOpp  = @{
                                       @"RegEmail":emailId
                                       };
        
        NSDictionary *response=  [self GetWebServiceResponse:userViewOpp URl:CHECKEMAILID];
        
        return response;

    } @catch (NSException *exception) {
        
    } @finally {
        
    }
}


-(NSDictionary*)CheckUserAlreadyPresent:(NSDictionary*)emailInfo
{
    @try {
        NSDictionary *userViewOpp  = @{
                                       @"RegEmail":[emailInfo valueForKey:@"RegEmail"],
                                        @"LoginType":[emailInfo valueForKey:@"LoginType"],
                                        @"DeviceId":[emailInfo valueForKey:@"DeviceId"]
                                       };
        
        NSDictionary *response=  [self GetWebServiceResponse:userViewOpp URl:@"CheckUserAlreadyPresent"];
        
        return response;
        
    } @catch (NSException *exception) {
        
    } @finally {
        
    }
}

-(NSDictionary*)CheckUserAlreadyPresentNew:(NSDictionary*)emailInfo
{
    @try {
        NSDictionary *userViewOpp  = @{
                                       @"RegEmail":[emailInfo valueForKey:@"RegEmail"],
                                       @"LoginType":[emailInfo valueForKey:@"LoginType"],
                                       @"DeviceId":[emailInfo valueForKey:@"DeviceId"]
                                       };
        
        NSDictionary *response=  [self GetWebServiceResponse:userViewOpp URl:@"CheckUserAlreadyPresentNew"];
        
        return response;
        
    } @catch (NSException *exception) {
        
    } @finally {
        
    }

}





-(NSDictionary*)checkPhoneNo:(NSString*)phoneNo
{
    @try {
        NSDictionary *userViewOpp  = @{
                                       @"PhoneNo":phoneNo
                                       };
        
        NSDictionary *response=  [self GetWebServiceResponse:userViewOpp URl:CHECKPHONENO];
        
        return response;
        
    } @catch (NSException *exception) {
        
    } @finally {
        
    }
}

-(NSDictionary*)GetReservedOpportunitiesBYUserRegId:(NSString*)registerID
{
    @try {
        
        NSString *baseUrl = [NSString stringWithFormat:@"%@%@/%@",baseURL,GETRESERVEDOPPORTUNITIESBYUSERID,registerID];
        
        NSURL *RPRTUrlpath = [NSURL URLWithString:baseUrl];
        
        NSData *myData = [NSData dataWithContentsOfURL:RPRTUrlpath];
        
        NSError* error1;
        
        NSDictionary  *GetCategoryResp = [NSJSONSerialization JSONObjectWithData:myData
                                                                         options:kNilOptions
                                                                           error:&error1];
        
        return GetCategoryResp;
    }
    @catch (NSException *exception) {
        
    }
    @finally {
        
    }
}

-(NSDictionary*)SaveUserInfo:(GeoCodeLocation*)userInfo
{
    @try {
        
        
        NSString *uniqueIdentifier = [[[UIDevice currentDevice] identifierForVendor] UUIDString];
        NSString *phoneName = [[UIDevice currentDevice] name];
        
        NSDictionary *UserViewOpp  = @{@"DeviceId":uniqueIdentifier,
                                       @"UserNme":phoneName,
                                       @"AddressName":userInfo.AddresName,
                                       @"Address1":userInfo.Address1,
                                       @"Address2":userInfo.Address2,
                                       @"Address3":userInfo.Address3,
                                       @"AreaName":userInfo.AreaName,
                                       @"City":userInfo.City,
                                       @"State":userInfo.State,
                                       @"Country":userInfo.Country,
                                       @"Latitude":userInfo.Latitude,
                                       @"Longitude":userInfo.Longitude,
                                       @"RowStatus":@"A"
                                       };
        
        NSDictionary *response=  [self GetWebServiceResponse:UserViewOpp URl:@"SaveUsersInfo"];
        
        return response;

        //return nil;
        
    } @catch (NSException *exception) {
        
    } @finally {
        
    }
}


-(NSDictionary*)GetUsersInfo:(NSDictionary*)location
{
    
        @try {
            NSString *locationLatLon= [NSString stringWithFormat:@"%@,%@",[location valueForKey:LATITUDE],[location valueForKey:LONGITUDE]];
            NSString *moduleId = [location valueForKey:@"ModuleId"];
            
            NSUserDefaults *mPref = [NSUserDefaults standardUserDefaults];
            
            NSString *State = [[location valueForKey:@"State"] stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
            if (State==nil) State = @"";
            NSString *Country = [[location valueForKey:@"Country"] stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
            if (Country==nil) Country = @"";
            NSString *UserID =[mPref valueForKey:USERREGISTERID];
            
            if (UserID ==nil) {
                UserID= @"0";
            }
            UserID = [NSString stringWithFormat:@"%@",UserID];
            NSString *radious;
            if ([location valueForKey:@"Radious"]==nil) {
                radious = @"1000";
                [mPref setValue:radious forKey:@"Radious"];
            }
            else
                radious =[location valueForKey:@"Radious"];
            
            NSData *registerObj = [mPref valueForKey:@"SaveRegisterDetails"];
            
            if (registerObj!=nil) {
                NSDictionary *myDictionary =   (NSDictionary*) [NSKeyedUnarchiver unarchiveObjectWithData:registerObj];
                
                radious = [myDictionary valueForKey:@"DefaultRadius"];
                
                if (radious==nil) {
                    radious = @"1000";
                }
            }
            
            
            //Radious
            NSDictionary *locationInput  = @{@"PageSize":@"10",
                                             @"PageNo":@"1",
                                             @"KeyWords":@"",
                                             @"Location":locationLatLon,
                                             @"radius":radious,
                                             @"types":@"",
                                             @"ModuleId":moduleId,
                                             @"LocationFlag":@"NotChanged",
                                             @"Categories":@"",
                                             @"State":State,
                                             @"Country":Country,
                                             @"UserRegisterId":UserID
                                             };
            
            NSDictionary *response=  [self GetWebServiceResponse:locationInput URl:@"GetUsersInfo"];
            
            return response;
        }
        @catch (NSException *exception) {
            
        }
        @finally {
            
        }
}

-(NSDictionary*)SendNotificationForNearByUsers :(NSDictionary*)notificationParams
{
    @try {
        
        
        NSDictionary *response=  [self GetWebServiceResponse:notificationParams URl:SENDNOTIFICATIONTONEARBYUSERS];
        
        return response;
    }
    @catch (NSException *exception) {
        
    }
    @finally {
        
    }

}

-(NSArray*)UserTypes
{
    @try {
        
        
        NSString *baseUrl = [NSString stringWithFormat:@"%@%@/%@",baseURL,@"GetLookup",@"UserType"];
        
        NSURL *RPRTUrlpath = [NSURL URLWithString:baseUrl];
        
        NSData *myData = [NSData dataWithContentsOfURL:RPRTUrlpath];
        
        NSError* error1;
        
        NSArray  *GetCategoryResp = [NSJSONSerialization JSONObjectWithData:myData
                                                                         options:kNilOptions
                                                                           error:&error1];
        
        return GetCategoryResp;

    }
    @catch (NSException *exception) {
        
    }
    @finally {
        
    }

}


-(NSDictionary*)SaveUserSettings:(NSDictionary*)userInfo
{
    @try {
        
        
        NSDictionary *response=  [self GetWebServiceResponse:userInfo URl:SAVEUSERSETTINGS];
        
        return response;
    }
    @catch (NSException *exception) {
        
    }
    @finally {
        
    }

}

-(NSDictionary*)GetUserSettings:(NSString*)userRegisterId
{
    @try {
        
        
        NSString *baseUrl = [NSString stringWithFormat:@"%@%@/%@",baseURL,@"GetUserSettings",userRegisterId];
        
        NSURL *RPRTUrlpath = [NSURL URLWithString:baseUrl];
        
        NSData *myData = [NSData dataWithContentsOfURL:RPRTUrlpath];
        
        NSError* error1;
        
        NSDictionary  *GetCategoryResp = [NSJSONSerialization JSONObjectWithData:myData
                                                                    options:kNilOptions
                                                                      error:&error1];
        
        return GetCategoryResp;
        
    }
    @catch (NSException *exception) {
        
    }
    @finally {
        
    }

}

-(NSDictionary*)SaveFavouriteAddress:(NSDictionary*)addresInfo
{
    if (addresInfo!=nil) {
        
        NSDictionary *response=  [self GetWebServiceResponse:addresInfo URl:SAVEFAVORITEADDRESS];

        return response;
    }
    
  else  return nil;
}

-(NSMutableArray*)GetFavAddress:(NSString*)userRegisterId
{
    @try {
        
        
        NSString *baseUrl = [NSString stringWithFormat:@"%@%@/%@",baseURL,GETFAVADDRESS,userRegisterId];
        
        NSURL *RPRTUrlpath = [NSURL URLWithString:baseUrl];
        
        NSData *myData = [NSData dataWithContentsOfURL:RPRTUrlpath];
        
        NSError* error1;
        
        NSMutableArray  *GetFavAddressResp = [NSJSONSerialization JSONObjectWithData:myData
                                                                         options:kNilOptions
                                                                           error:&error1];
        
        return GetFavAddressResp;
        
    }
    @catch (NSException *exception) {
        
    }
    @finally {
        
    }

}
-(NSDictionary*)SaveCustomer:(NSDictionary*)CustoParams
{
    if (CustoParams!=nil) {
        NSDictionary *response = [self GetWebServiceResponse:CustoParams URl:@"SaveCustomer"];
        return response;
    }
    
    return nil;
}

-(NSMutableArray*)GetMyCustomers:(NSString*)userRegID
{
    @try {
        
        
        NSString *baseUrl = [NSString stringWithFormat:@"%@%@/%@",baseURL,@"GetMyCustomers",userRegID];
        
        NSURL *RPRTUrlpath = [NSURL URLWithString:baseUrl];
        
        NSData *myData = [NSData dataWithContentsOfURL:RPRTUrlpath];
        
        NSError* error1;
        if (myData==nil) {
            return nil;
        }
        else
        {
        NSMutableArray  *GetFavAddressResp = [NSJSONSerialization JSONObjectWithData:myData
                                                                             options:kNilOptions
                                                                               error:&error1];
        
        return GetFavAddressResp;
        }
        
    }
    @catch (NSException *exception) {
        
    }
    @finally {
        
    }

}

-(NSDictionary*)GetCounts:(NSDictionary*)inputParams
{
    @try {
        
        
        if (inputParams!=nil) {
            NSDictionary *response = [self GetWebServiceResponse:inputParams URl:@"GetCounts"];
            return response;
        }
        
        return nil;
        
    }
    @catch (NSException *exception) {
        
    }
    @finally {
        
    }
}

-(NSString*)GetExclusive:(NSDictionary*)inputParams
{
    @try {
        
        
        if (inputParams!=nil) {
            NSString *response = [self GetWebServiceResponseForExclusive:inputParams URl:@"GetMyExclusiveOpportunitiesCount"];
            return response;
        }
        
        return nil;
        
    }
    @catch (NSException *exception) {
        
    }
    @finally {
        
    }

}


-(NSDictionary*)GetMyExclusiveOpportunities:(NSDictionary*)inputParams
{
    @try {
        
        
        if (inputParams!=nil) {
            NSDictionary *response = [self GetWebServiceResponse:inputParams URl:@"GetMyExclusiveOpportunities"];
            return response;
        }
        
        return nil;
        
    }
    @catch (NSException *exception) {
        
    }
    @finally {
        
    }
    
}

-(NSDictionary*)GetStoreDetails:(NSString*)vendorRegID
{

    NSString *baseUrl = [NSString stringWithFormat:@"%@%@/%@",baseURL,@"GetStoreDetails",vendorRegID];
    
    NSURL *RPRTUrlpath = [NSURL URLWithString:baseUrl];
    
    NSData *myData = [NSData dataWithContentsOfURL:RPRTUrlpath];
    
    NSError* error1;
    
    NSDictionary  *getStoreResponse = [NSJSONSerialization JSONObjectWithData:myData
                                                                         options:kNilOptions
                                                                           error:&error1];
    
    
    
    NSDictionary  *storeListReponsess = [RMMapper  objectWithClass:[RTStore_List class] fromDictionary:getStoreResponse];//  mutableArrayOfClass:[RTStore_List class]
                                                //  fromArrayOfDictionary:storeListReponse];
    
    NSLog(@"%@",storeListReponsess);
    return storeListReponsess;

}


-(NSDictionary*)ProcessLogin:(NSDictionary*)preogessLoginParams
{
    if (preogessLoginParams!=nil) {
      
            NSDictionary *response = [self GetWebServiceResponse:preogessLoginParams URl:@"ProcessLogin"];
            return response;
    
    }
    
    return nil;
}
-(NSMutableArray*)GetStores:(NSDictionary*)inputstring
{
    if (inputstring!=nil) {
        
        id storeListReponse = [self GetWebServiceResponse:inputstring URl:@"GetStores"];
        
        
      //  RTStore_List *person = [[RTStore_List alloc] initWithJSONString:storeListReponse];

        
    NSMutableArray  *storeListReponsess = [RMMapper mutableArrayOfClass:[RTStore_List class]
                                                    fromArrayOfDictionary:storeListReponse];
        
        NSLog(@"%@",storeListReponsess);
        
        
        return storeListReponsess;
        
    }
    return nil;
 
}
-(NSString*)StoreLikeUnlike:(NSDictionary*)storeLikeUnObj
{
    if (storeLikeUnObj!=nil) {
        
        NSString *response = [self GetWebServiceResponseForExclusive:storeLikeUnObj URl:@"StoreLikeUnlike"];
        return response;
        
    }
    
    return nil;

}
-(NSDictionary *)SaveRequestReply:(NSDictionary*)requets
{
    if (requets!=nil) {
        
        NSDictionary *storeListReponse = [self GetWebServiceResponse:requets URl:@"SaveRequestReply"];
        return storeListReponse;
        
    }
    return nil;

}

-(NSDictionary*)GetCustomerRequests:(NSDictionary*)inputCustomerparams
{
    if (inputCustomerparams!=nil) {
        
        NSDictionary *storeListReponse = [self GetWebServiceResponse:inputCustomerparams URl:@"GetCustomerRequests"];
        return storeListReponse;
        
    }
    return nil;

}

-(NSDictionary*)GetAddress:(NSDictionary*)latlongObj
{
    if (latlongObj!=nil) {
 
        NSDictionary *storeListReponse = [self GetWebServiceResponse:latlongObj URl:@"GetAddress"];
        return storeListReponse;
        
    }
    return nil;
}


-(NSDictionary*)SendOTP:(NSString*)countryCode mobileNumber:(NSString*)mobileNumber
{
    NSString *baseUrl = [NSString stringWithFormat:@"%@%@/%@/%@",baseURL,@"SendOTP",countryCode,mobileNumber];
    
    NSURL *RPRTUrlpath = [NSURL URLWithString:baseUrl];
    NSURLRequest *requestUrl = [[NSURLRequest alloc]initWithURL:RPRTUrlpath];
    NSURLResponse* response = nil;
    NSData* objectData = [NSURLConnection sendSynchronousRequest:requestUrl returningResponse:&response error:nil];
    
    //NSError* error1;
    
      //  ExclusiveCnt = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
    
    NSError *jsonError;
    NSDictionary *getStoreResponse = [NSJSONSerialization JSONObjectWithData:objectData
                                                         options:NSJSONReadingMutableContainers
                                                           error:&jsonError];
    
    
    
//    NSArray *jsonObject = [NSJSONSerialization JSONObjectWithData:[ExclusiveCnt dataUsingEncoding:NSUTF8StringEncoding]
//                                                          options:0 error:NULL];
//    NSLog(@"jsonObject=%@", jsonObject);
//    
//    
//    NSDictionary  *getStoreResponse = [NSJSONSerialization JSONObjectWithData:data
//                                                                      options:kNilOptions
//                                                                        error:&error1];
    
    return getStoreResponse;

}

-(NSMutableArray*)GetBanner
{
    NSString *baseUrl = [NSString stringWithFormat:@"%@%@",baseURL,@"GetBanner"];
    
    NSURL *RPRTUrlpath = [NSURL URLWithString:baseUrl];
    
    NSData *myData = [NSData dataWithContentsOfURL:RPRTUrlpath];
    
    NSError* error1;
    
    NSMutableArray  *bannerReponse = [NSJSONSerialization JSONObjectWithData:myData
                                                                      options:kNilOptions
                                                                        error:&error1];
    
    return bannerReponse;
}


-(NSDictionary*)ReportSpam:(NSString*)Ids Methodname:(NSString*)MethodName
{
    NSString *baseUrl = [NSString stringWithFormat:@"%@%@/%@",baseURL,MethodName,Ids];
    
    NSURL *RPRTUrlpath = [NSURL URLWithString:baseUrl];
    
    NSData *myData = [NSData dataWithContentsOfURL:RPRTUrlpath];
    
    NSError* error1;
    
    NSDictionary  *getStoreResponse = [NSJSONSerialization JSONObjectWithData:myData
                                                                      options:kNilOptions
                                                                        error:&error1];
    return getStoreResponse;
    
}
-(NSDictionary*)HideOffer:(NSString*)Ids Methodname:(NSString*)MethodName
{
    NSString *baseUrl = [NSString stringWithFormat:@"%@%@/%@",baseURL,MethodName,Ids];
    
    NSURL *RPRTUrlpath = [NSURL URLWithString:baseUrl];
    
    NSData *myData = [NSData dataWithContentsOfURL:RPRTUrlpath];
    
    NSError* error1;
    
    NSDictionary  *getStoreResponse = [NSJSONSerialization JSONObjectWithData:myData
                                                                      options:kNilOptions
                                                                        error:&error1];
  return getStoreResponse;
}

-(NSString*)DeleteOpportunity:(NSString*)OppoID
{
    NSString *baseUrl = [NSString stringWithFormat:@"%@%@/%@",baseURL,@"DeleteOpportunity",OppoID];
    
    NSURL *RPRTUrlpath = [NSURL URLWithString:baseUrl];
    
    NSData *myData = [NSData dataWithContentsOfURL:RPRTUrlpath];
    
    NSError* error1;
    
    NSString  *DeleteStaus = [NSJSONSerialization JSONObjectWithData:myData
                                                                      options:kNilOptions
                                                                        error:&error1];
    
    return DeleteStaus;
}

-(NSMutableArray*)GetMyNotifications:(NSString*)UserRegisterId
{
    NSString *baseUrl = [NSString stringWithFormat:@"%@%@/%@",baseURL,@"GetMyNotifications",UserRegisterId];
    
    NSURL *RPRTUrlpath = [NSURL URLWithString:baseUrl];
    
    NSData *myData = [NSData dataWithContentsOfURL:RPRTUrlpath];
    
    NSError* error1;
    
    NSMutableArray  *getmyNotificationsResponse = [NSJSONSerialization JSONObjectWithData:myData
                                                                      options:kNilOptions
                                                                        error:&error1];
    return getmyNotificationsResponse;

}

-(NSString*)SendInvite:(NSString*)NotificationID inviteMessage:(NSString*)inviteMessage
{
    NSString *baseUrl = [NSString stringWithFormat:@"%@%@/%@/%@",baseURL,@"SendInvite",NotificationID,inviteMessage];
    NSString *escapedUrlString = [baseUrl stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];

    
    NSURL *RPRTUrlpath = [NSURL URLWithString:escapedUrlString];
    
    NSData *myData = [NSData dataWithContentsOfURL:RPRTUrlpath];
    
    //NSError* error1;
     NSString  *getSendInviteRepons = [[NSString alloc] initWithData:myData encoding:NSUTF8StringEncoding];
    
 //   NSString  *getSendInviteReponse = [NSJSONSerialization JSONObjectWithData:myData
  //                                                           options:kNilOptions
  //                                                             error:&error1];
    NSLog(@"%@",getSendInviteRepons);
    
    return getSendInviteRepons;
    
   // return getmyNotificationsResponse;
}

-(NSString*)AcceptReject:(NSString*)notificationID acceptReject:(NSString*)requestResult
{
    NSString *baseUrl = [NSString stringWithFormat:@"%@%@/%@/%@",baseURL,@"AcceptReject",notificationID,requestResult];
    
    NSURL *RPRTUrlpath = [NSURL URLWithString:baseUrl];
    
    NSData *myData = [NSData dataWithContentsOfURL:RPRTUrlpath];
    
    //NSError* error1;
    
    
    NSString  *getSendInviteRepons = [[NSString alloc] initWithData:myData encoding:NSUTF8StringEncoding];
    
 //   NSString  *getSendInviteReponse = [NSJSONSerialization JSONObjectWithData:myData
       //                                                               options:kNilOptions
       //                                                                 error:&error1];
    NSLog(@"%@",getSendInviteRepons);
    
    return getSendInviteRepons;

}



//"~/api/RPRT/GetMyNotifications/{UserRegisterId}": Returns RT_Notifications
//"~/api/RPRT/SendInvite/{NotificationId}/{InviteMessage}": Returns int
//"~/api/RPRT/AcceptReject/{NotificationId}/{Result}": Returns int
//
//



@end
